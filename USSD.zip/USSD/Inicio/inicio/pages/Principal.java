package inicio.pages;

import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import inicio.test.prepagoTodoEnUno.TestConsultaYOtros;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class Principal {

	ObjetosConfigAux objAux;
	TestConsultaYOtros testCons;
	Properties prop = new Properties();
	private String ambiente;
	private Connection Conec = null;
	Statement stamt;
	String[] Datos;
	Boolean test;
	By btnTecladoNum, txtIngresarNum, btnLlamar, btnEnviar, btnCancelar, btnTecladoNumOcultar;

	/** LISTA ELEMENTOS */

	public void listaElementos() throws IOException {
		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);
		btnTecladoNum = By.xpath(prop.getProperty("btnTecladoNum"));
		txtIngresarNum = By.xpath(prop.getProperty("txtIngresarNum"));
		btnLlamar = By.xpath(prop.getProperty("btnLlamar"));
		btnEnviar = By.xpath(prop.getProperty("btnEnviar"));
		btnCancelar = By.xpath(prop.getProperty("btnCancelar"));
		btnTecladoNumOcultar = By.xpath(prop.getProperty("btnTecladoNumOcultar"));
	}

	By txtTiendaMovistar = By.xpath("//android.widget.TextView[@package='com.android.phone']");
	By txtMarcarOpcion = By.id("com.android.phone:id/input_field");
	By btnAceptar = By.xpath("//android.widget.Button[@text='Aceptar']");

	/* Constructor */
	public Principal(ObjetosConfigAux objAux) throws IOException {
		listaElementos();
		this.objAux = objAux;
		testCons = new TestConsultaYOtros();
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickBtnTecladoNum() {
		objAux.getDriver().findElement(btnTecladoNum).click();
	}

	public void clickBtnTecladoNumOcultar() {
		objAux.getDriver().findElement(btnTecladoNumOcultar).click();
	}

	public void setTxtIngresarNum(String numero) {
		objAux.getDriver().findElement(txtIngresarNum).sendKeys(numero);
	}

	public void clickBtnLlamar() {
		objAux.getDriver().findElement(btnLlamar).click();
	}

	public String getTxtTiendaMovistar() {
		return objAux.getDriver().findElement(txtTiendaMovistar).getText();
	}

	public void setTxtMarcarOpcion(String opcion) {
		objAux.getDriver().findElement(txtMarcarOpcion).sendKeys(opcion);
	}

	public void clickBtnEnviar() throws InterruptedException, IOException {
		objAux.getDriver().findElement(btnEnviar).click();
		Thread.sleep(5000);
		clickBtnAceptarTEST();
	}

	@SuppressWarnings("rawtypes")
	public void clickBtnAceptar() throws InterruptedException, IOException {

		objAux.getDriver().findElement(btnAceptar).click();
		System.out.println("ACEPTAR VISIBLE");

		((AndroidDriver) objAux.getDriver()).pressKeyCode(AndroidKeyCode.HOME);
		Thread.sleep(3000);
	}

	public Boolean presentBtnAceptar() throws InterruptedException, IOException {

		if ((objAux.getDriver().findElements(btnAceptar)).size() != 0) {
			test = true;
		} else {
			test = false;
		}
		return test;
	}

	@SuppressWarnings("rawtypes")
	public void clickBtnAceptarTEST() throws InterruptedException, IOException {

		if ((objAux.getDriver().findElements(btnAceptar)).size() != 0) {
			objAux.getDriver().findElement(btnAceptar).click();
			System.out.println("ACEPTAR VISIBLE");
			
			clickBtnCancelar();
			testCons.setup();
		}

		((AndroidDriver) objAux.getDriver()).pressKeyCode(AndroidKeyCode.HOME);
		Thread.sleep(3000);
	}

	@SuppressWarnings("rawtypes")
	public void clickBtnCancelar() throws InterruptedException {

		Thread.sleep(3000);

		if ((objAux.getDriver().findElements(btnCancelar)).size() != 0) {
			objAux.getDriver().findElement(btnCancelar).click();
			((AndroidDriver) objAux.getDriver()).pressKeyCode(AndroidKeyCode.BACK);
		}
	}

	/** M�TODOS */

	public void execLlamar() throws IOException, InterruptedException {

		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);
		ambiente = prop.getProperty("Ambiente");

		if (!objAux.EsperaElemento(objAux.getDriver(), btnTecladoNumOcultar))
			clickBtnTecladoNum();

		if (ambiente.equals("Produccion")) {
			setTxtIngresarNum("*611#");
			clickBtnLlamar();
			Thread.sleep(3000);
		} else {
			setTxtIngresarNum("*776#");
			clickBtnLlamar();
			Thread.sleep(3000);
			execTxtMarcarOpcionPruebas("7"); // Opcion 7
		}
	}

	@SuppressWarnings("rawtypes")
	public void execSeleccionarOpcionTest(String opcionMenu) throws IOException, InterruptedException {

		String obtenerTexto = getTxtTiendaMovistar();

		Pattern pattern = Pattern.compile("\\d+:" + opcionMenu);
		Matcher matcher = pattern.matcher(obtenerTexto);

		String dato = null;
		if (matcher.find())
			dato = matcher.group().replace(":" + opcionMenu, "");
		setTxtMarcarOpcion(dato);
		System.out.println("dato  " + dato);
		((AndroidDriver) objAux.getDriver()).pressKeyCode(AndroidKeyCode.BACK);
		Thread.sleep(500);

		objAux.AdminDocPdf.generaEvidencia("Seleccionar Opci�n: " + dato + " = " + opcionMenu,
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnEnviar();
	}

	@SuppressWarnings("rawtypes")
	public void execTxtMarcarOpcion(String opcion) throws IOException, InterruptedException {
		objAux.getDriver().findElement(txtMarcarOpcion).sendKeys(opcion);
		((AndroidDriver) objAux.getDriver()).pressKeyCode(AndroidKeyCode.BACK);
		Thread.sleep(500);
		objAux.AdminDocPdf.generaEvidencia("Seleccionar Opci�n: ", Shutterbug.shootPage(objAux.getDriver()).getImage());
		clickBtnEnviar();
	}

	@SuppressWarnings("rawtypes")
	public void execTxtMarcarOpcionPruebas(String opcion) throws IOException, InterruptedException {
		objAux.getDriver().findElement(txtMarcarOpcion).sendKeys(opcion);
		((AndroidDriver) objAux.getDriver()).pressKeyCode(AndroidKeyCode.BACK);
		Thread.sleep(500);
		clickBtnEnviar();
	}

	public static int countLines(String str) {
		int count = 0;
		int total = str.length();
		for (int i = 0; i < total; ++i) {
			char letter = str.charAt(i);
			if (letter == '\n')
				++count;
			System.out.println("total: " + total);
		}
		return count;
	}

	public void execTest() {
		System.out.println("getTxtTiendaMovistar(): " + getTxtTiendaMovistar());
		countLines(getTxtTiendaMovistar());
	}

	@SuppressWarnings("rawtypes")
	public void execOpcionAtras_0() throws IOException, InterruptedException {

		setTxtMarcarOpcion("0");
		((AndroidDriver) objAux.getDriver()).pressKeyCode(AndroidKeyCode.BACK);
		objAux.AdminDocPdf.generaEvidencia("Marcar Opci�n Atr�s 0",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		clickBtnEnviar();
	}

	@SuppressWarnings("rawtypes")
	public void execOpcionInicio_00() throws IOException, InterruptedException {

		if (ambiente.equals("Produccion")) {
			setTxtMarcarOpcion("00");
			((AndroidDriver) objAux.getDriver()).pressKeyCode(AndroidKeyCode.BACK);
			objAux.AdminDocPdf.generaEvidencia("Marcar Opci�n Inicio 00",
					Shutterbug.shootPage(objAux.getDriver()).getImage());
			clickBtnEnviar();
		}
	}

	public void execOpcionInicioValidacion_00() throws IOException, InterruptedException {

		if (!((objAux.getDriver().findElements(btnAceptar)).size() != 0)) {
			setTxtMarcarOpcion("00");
			objAux.AdminDocPdf.generaEvidencia("Volver al Inicio 00", Shutterbug.shootPage(objAux.getDriver()).getImage());
			clickBtnEnviar();

			if (ambiente.equals("Produccion"))
				assertTrue(getTxtTiendaMovistar().contains("Mi Movistar"), "Mi Movistar");

			objAux.AdminDocPdf.generaEvidencia("Validaci�n de la opci�n Inicio 00",
					Shutterbug.shootPage(objAux.getDriver()).getImage());
		}
	}

	/** CONEXION BD */

	public void ConnectionDB() {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Conec = DriverManager.getConnection(
					//							"jdbc:sqlserver://evolution03;databaseName=AuditQA;", "QAGCONTROL", "GcontrolQA1$");
					"jdbc:sqlserver://evolution03;databaseName=AuditQA;user=QAGCONTROL;Password=GcontrolQA1$");

			if (Conec != null) {

				System.out.println("Successfully connected");

			}
		} catch (SQLException excepcionSql) {
			JOptionPane.showMessageDialog(null, excepcionSql.getMessage(),
					"Error en base de datos", JOptionPane.ERROR_MESSAGE);
		}

		catch (ClassNotFoundException claseNoEncontrada) {
			JOptionPane.showMessageDialog(null, claseNoEncontrada.getMessage(),
					"No se encontr� el controlador", JOptionPane.ERROR_MESSAGE);
		}
	}

	// Metodo de ejecucion de insert,update,delete a la base de datos
	public String[] querySQL(String query) {
		// CONTROLA QUE LA CONSULTA NO ESTE NULA O VACIA
		try {
			ConnectionDB();

			stamt = Conec.createStatement();
			// SE ENVIA CODIGO DE INSERCION SQL
			stamt.executeUpdate(query);
			// SE CIERRA CONEXION
			Conec.close();
		}
		// IMPRIME CON CONSOLA EL SI EXISTIO ALGUN ERROR EN LA CONEXION
		catch (Exception e) {
			e.printStackTrace();
		}
		// NO RETORNA NADA
		return Datos;
	}
}