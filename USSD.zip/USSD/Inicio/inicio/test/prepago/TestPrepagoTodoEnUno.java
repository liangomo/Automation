//package inicio.test.prepago;
//
//import static org.testng.Assert.assertTrue;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.io.StringWriter;
//import java.net.MalformedURLException;
//
//import org.testng.ITestResult;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.AfterMethod;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.BeforeMethod;
//import org.testng.annotations.Test;
//
//import com.assertthat.selenium_shutterbug.core.Shutterbug;
//import com.lowagie.text.DocumentException;
//
//import control.elementos.ObjetosConfigAux;
//import evidencia.doc.pdf.AdminDocPdf;
//import inicio.pages.Principal;
//import manager.param.AdminParam;
//import model.DispositivoPrueba;
//import model.Estados;
//import model.Navegadores;
//import model.TipoCone;
//
//public class TestPrepagoTodoEnUno {
//
//	ObjetosConfigAux objAux;
//	Principal objPpal;
//	String datoPrueba = "Prepago Segundos";
//	String modulo = (this.getClass().getSimpleName()).substring(4);
//	String usuario = System.getProperty("user.name");
//	String ambiente;
//
//	@BeforeClass
//	public void setup() throws IOException, InterruptedException {
//
//		objAux = new ObjetosConfigAux("42006dc24e6814a7", true);
//		objPpal = new Principal(objAux);
//		objPpal.execLlamar();
//		ambiente = objAux.ambiente;
//	}
//
//	@BeforeMethod
//	public void setupMethod() throws IOException, InterruptedException {
//
//		if (objPpal.presentBtnAceptar().equals(true)) {
//			objPpal.clickBtnAceptar();
//			objAux.getDriver().quit();
//			objAux = new ObjetosConfigAux("42006dc24e6814a7", true);
//			objPpal = new Principal(objAux);
//			objPpal.execLlamar();
//		}
//	}
//
//	/**
//	 * CASOS DE PRUEBA
//	 */
//
//	@Test(priority = 1)
//	public void cp001_PREPTodoEn1_CambPlanSem() throws IOException, InterruptedException {
//
//		objAux.AdminDocPdf = new AdminDocPdf(ambiente, Navegadores.ANDROID, DispositivoPrueba.Movil);
//		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "PrepagoTodoEnUno");
//		objAux.AdminParam.ObtenerParametros();
//
//		objPpal.execOpcionInicio_00();
//
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Menu")); // Opcion 1
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Item")); // Opcion 1
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Opcion")); // Opcion 1
//		assertTrue(objPpal.getTxtTiendaMovistar().contains(objAux.buscaElementoParametro("Validacion")),
//				objAux.buscaElementoParametro("Validacion"));
//
//		objPpal.execOpcionAtras_0();
//		assertTrue(objPpal.getTxtTiendaMovistar().contains(objAux.buscaElementoParametro("OpcionAtras")),
//				"Vuelve al men� anterior, contiene " + "'" + objAux.buscaElementoParametro("OpcionAtras") + "'");
//	}
//
//	@Test(priority = 2)
//	public void cp002_PREPTodoEn1_CambPlanSemPlus() throws IOException, InterruptedException {
//
//		objAux.AdminDocPdf = new AdminDocPdf(ambiente, Navegadores.ANDROID, DispositivoPrueba.Movil);
//		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "PrepagoTodoEnUno");
//		objAux.AdminParam.ObtenerParametros();
//
//		objPpal.execOpcionInicio_00();
//
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Menu")); // Opcion 1
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Item")); // Opcion 1
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Opcion")); // Opcion 2
//		assertTrue(objPpal.getTxtTiendaMovistar().contains(objAux.buscaElementoParametro("Validacion")),
//				objAux.buscaElementoParametro("Validacion"));
//	}
//
//	@Test(priority = 3)
//	public void cp003_PREPTodoEn1_CambPlanQuinc() throws IOException, InterruptedException {
//
//		objAux.AdminDocPdf = new AdminDocPdf(ambiente, Navegadores.ANDROID, DispositivoPrueba.Movil);
//		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "PrepagoTodoEnUno");
//		objAux.AdminParam.ObtenerParametros();
//
//		objPpal.execOpcionInicio_00();
//
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Menu")); // Opcion 1
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Item")); // Opcion 1
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Opcion")); // Opcion 3
//		assertTrue(objPpal.getTxtTiendaMovistar().contains(objAux.buscaElementoParametro("Validacion")),
//				objAux.buscaElementoParametro("Validacion"));
//	}
//
//	@Test(priority = 4)
//	public void cp004_PREPTodoEn1_CambPlanMes() throws IOException, InterruptedException {
//
//		objAux.AdminDocPdf = new AdminDocPdf(ambiente, Navegadores.ANDROID, DispositivoPrueba.Movil);
//		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "PrepagoTodoEnUno");
//		objAux.AdminParam.ObtenerParametros();
//
//		objPpal.execOpcionInicio_00();
//
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Menu")); // Opcion 1
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Item")); // Opcion 1
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Opcion")); // Opcion 4
//		assertTrue(objPpal.getTxtTiendaMovistar().contains(objAux.buscaElementoParametro("Validacion")),
//				objAux.buscaElementoParametro("Validacion"));
//	}
//
//	@Test(priority = 5)
//	public void cp005_PREPTodoEn1_CondCambPlan() throws IOException, InterruptedException {
//
//		objAux.AdminDocPdf = new AdminDocPdf(ambiente, Navegadores.ANDROID, DispositivoPrueba.Movil);
//		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "PrepagoTodoEnUno");
//		objAux.AdminParam.ObtenerParametros();
//
//		objPpal.execOpcionInicio_00();
//
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Menu")); // Opcion 1
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Item")); // Opcion 2
//		assertTrue(objPpal.getTxtTiendaMovistar().contains(objAux.buscaElementoParametro("Validacion")),
//				objAux.buscaElementoParametro("Validacion"));
//	}
//
//	@Test(priority = 6)
//	public void cp006_PREPTodoEn1_QueEs() throws IOException, InterruptedException {
//
//		objAux.AdminDocPdf = new AdminDocPdf(ambiente, Navegadores.ANDROID, DispositivoPrueba.Movil);
//		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "PrepagoTodoEnUno");
//		objAux.AdminParam.ObtenerParametros();
//
//		objPpal.execOpcionInicio_00();
//
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Menu")); // Opcion 1
//		objPpal.execSeleccionarOpcionTest(objAux.buscaElementoParametro("Item")); // Opcion 3
//		assertTrue(objPpal.getTxtTiendaMovistar().contains(objAux.buscaElementoParametro("Validacion")),
//				objAux.buscaElementoParametro("Validacion"));
//	}
//
//	@AfterMethod
//	public void finalizeTest(ITestResult t)
//			throws MalformedURLException, DocumentException, IOException, InterruptedException {
//
//		objPpal.execOpcionInicioValidacion_00();
//		String resultado;
//
//		if (t.getStatus() == ITestResult.SUCCESS) {
//			objAux.AdminDocPdf.crearDocumento(Estados.SUCCESS);
//			resultado = "Satisfactorio";
//		} else {
//			StringWriter sw = new StringWriter();
//			PrintWriter pw = new PrintWriter(sw);
//			Throwable cause = t.getThrowable();
//			if (null != cause) {
//				cause.printStackTrace(pw);
//				objAux.AdminDocPdf.generaEvidencia(
//						"Resultado NO Esperado: "
//								+ sw.getBuffer().toString().substring(0, sw.getBuffer().toString().indexOf("at ")),
//								Shutterbug.shootPage(objAux.getDriver()).getImage());
//			} else {
//				objAux.AdminDocPdf.generaEvidencia("Resultado NO Esperado: ",
//						Shutterbug.shootPage(objAux.getDriver()).getImage());
//			}
//
//			objAux.AdminDocPdf.crearDocumento(Estados.FAILED);
//			resultado = "Fallido";
//		}
//
//		String casoPrueba = objAux.AdminDocPdf.getNombreCasoPrueba();
//		String fechaEjecucion = objAux.AdminDocPdf.getFechaEjecucionBD();
//
//		objPpal.querySQL("INSERT INTO AUTOM.EjecucionesUSSD (FechaHoraEjecucion, Modulo, CasoPrueba, DatoPrueba, "
//				+ "Ambiente, Usuario, Resultado) VALUES("+ "'" + fechaEjecucion + "'" + "," + "'" + modulo  + "'" + ","
//				+ "'" + casoPrueba + "'" + "," + "'" + datoPrueba + "'" + "," + "'" + ambiente + "'" + ","	+ "'" 
//				+ usuario + "'" + "," + "'"	+ resultado + "'" + ")");
//	}
//
//	@AfterClass
//	public void tearDowns() throws InterruptedException {
//		objPpal.clickBtnCancelar();
//		objAux.getDriver().quit();
//	}
//}