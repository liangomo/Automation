package general;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;

public class e {

	public static void main(String[] args) {
		
		System.out.println(obtenerHora());

	}

	/** METODO 1 */
	public static int diffDias(int fecha1Ano,int fecha1Mes,int fecha1Dia,int fecha2Ano,int fecha2Mes,int fecha2Dia) {

		int result=0;

		/* Escriba el codigo que tome las dos fechas que est�n como par�metros y retorne la diferencia en d�as entre 
		estas fechas */
		
		/*****/
		LocalDate t1=LocalDate.of(fecha1Ano, fecha1Mes, fecha1Dia);
		LocalDate t2=LocalDate.of(fecha2Ano, fecha2Mes, fecha2Dia);
		
		result=Period.between(t1, t2).getDays();
		/*****/

		return result;
	}


	/** METODO 2 */
	public static String obtenerHora() {

		int hora, minutos, segundos;

		/* Escriba el codigo para Obtener la hora actual en formato HH:mm:ss */
		
		/*****/
	    Calendar calendario = Calendar.getInstance();
	    hora =calendario.get(Calendar.HOUR_OF_DAY);
	    minutos = calendario.get(Calendar.MINUTE);
	    segundos = calendario.get(Calendar.SECOND);
		/*****/
	    
		return hora + ":" + minutos + ":" + segundos;
	}


	/** METODO 3 */

	public boolean validacionError(String ... cadenas) {

		/* Encuentre el error en esta sentencia y ecribala como debe quedar indicando donde est� el error */

//		if (cadenas.length < 2)
//			return false;
//		for (int i=1; i < cadenas.length; i++)
//			if (!cadenas[i-1]==(cadenas[i]))
//				return false;
//		return true;   
//		
//		/*****/
//		if (cadenas.length < 2)
//			return false;
//		for (int i=1; i < cadenas.length; i++)
//			if (!(cadenas[i-1]==(cadenas[i])))
//				return false;
//		return true;
//		/*****/
//		if (cadenas.length < 2)
//			return false;
//		for (int i=1; i < cadenas.length; i++)
//			if (!cadenas[i-1].equals(cadenas[i]))
//				return false;
		return true; 
	}

	
	/** METODO 4 */

	public FileWriter generacionArchivo(String rutaArchivo, String nombreArchivo) {
		
		FileWriter fichero = null;

		/* Escriba el codigo para generar un archivo en formato txt e indicar la ruta donde queda generado, adicionalmente
		 * el archivo debe contener el texto 'Hola mundo'*/

		/*****/
		  try {
		   fichero = new FileWriter(rutaArchivo + nombreArchivo, true);
		  } catch (IOException e) {
		   e.printStackTrace();
		  }
		  
		  PrintWriter pw = null;
		  pw = new PrintWriter(fichero);
		  pw.println("Hola Mundo");
		
		/*****/
		
		return fichero;
		
		//Puede usar cualquier API para manejo de archivos
	}

	
	/** METODO 5 */

	public static String expresionRegular(String textoEntrada) {
		
		String textoSalida = "";
		
		/* Escriba el m�todo que elimine los caracteres alfanum�ricos de un texto que solo puede incluir numeros 
		 * 
		 * Ej: "Tengo 11 lapiceros y 12 cuadernos"  -> Texto Entrada
		 *  	Realizar el m�todo
		 *  	Resultado = "1112" -> Texto Salida
		 * */
		
		/*****/
		
		textoSalida=textoEntrada.replaceAll("[^\\d]", "");
		
		/*****/
		
		return textoSalida;

	}
}