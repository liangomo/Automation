import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.sql.SQLException;
import resources.LanzadorHelper;
import A_Utilitarios.ClaseAyudante;
import B_CPV.Controlador.Controlador;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;

public class Lanzador extends LanzadorHelper
{
	//	/* Definici�n de argumentos para tener en cuenta en los callscript */
	Object[] tmp = new Object[9];
	Document doc;

	public void testMain(Object[] args) throws DocumentException, MalformedURLException, IOException, SQLException
	{
		int iter = 1;

		for (int i = 0; i < iter; i++) {


			/* Llamado Vistas */
			ClaseAyudante help = new ClaseAyudante();
			Controlador cont = new Controlador(help);

			/** Creaci�n Carpetas */
			File folder0 = new File("C:\\tmp\\PSE");
			folder0.mkdir();

			File folder1 = new File("C:\\tmp\\PSE\\Imagenes");
			folder1.mkdir();


			/** Conexi�n a la Base de Datos */

			/* Consulta en la tabla casos de prueba los registros que se deben ejecutar = 1 */
			ResultSet rs = help.Consulta("SELECT * FROM PSE.CasosPrueba WHERE Ejecucion = 1 AND Ejecutado = 'NO EJECUTADO' ");

			/* Creaci�n PDF */
			String fecha = help.ObtenerFecha();
			String hora = help.ObtenerHora();
			doc = help.createPdf("Detallado_PSE_" + help.ObtenerMes() +  "_" + fecha + "_" + hora);


			/* Definici�n de argumentos que ser�n llamados en los callscript para identificar 
			 * el caso de prueba, el cliente y la cuenta */

			try {

				while(rs.next())
				{
					tmp [0] = rs.getString("IDCliente");
					tmp [1] = rs.getString("IDCuenta");
					tmp [2] = rs.getString("CodCP");
					tmp [3] = doc;
					tmp [4] = fecha;
					tmp [5] = hora;
					tmp [6] = rs.getString("Descripcion");
					tmp [7] = rs.getString("Transaccion");
					tmp [8] = false;

					/* Validaci�n del m�dulo por el que pasa la trx */
					if (rs.getBoolean("InternetExplorer")) {
						tmp [8] = true;						
						help.addTexto("INTERNET EXPLORER\n");
						System.out.println("Explorer");
						help.MatarProceso(); sleep(3);
						//help.getExplorer("https://desarrollo.pse.com.co/SamplePPE3/GetBankList.aspx");
						help.getExplorer("https://200.124.124.171/PSEBANCODEBOGOTA/Comercio.jsp");
						cont.testMain(tmp);
						help.MatarProceso();

						/* Insertar resultado en Base de Datos para el informe Resumen */
						querySQL("INSERT INTO PSE.ConsolidadosEjecucion VALUES('" + "PSE_Regresion" + "','" + ObtenerA�o() + "','" + ObtenerMes() + "','" 
								+ fecha +  "','" + hora +  "','" + tmp[2] +  "','" + tmp[7] + " - I.EXPLORER" +  "','" + rs.getString("ResultadoEsperado") +  "','"  
								+ "EXITOSO" +  "','" + "EXITOSO" + "','" 
								+ "C:\\tmp\\PSE\\" + "Detallado_PSE_" + help.ObtenerMes() + "_" + tmp [4] + "_" + tmp [5] + ".pdf" + "')");

						/* Marcar como ejecutado el caso para este navegador */
						querySQL("UPDATE PSE.CasosPrueba SET InternetExplorer = '0' WHERE CodCP = '" + tmp[2] + "'");

						help.getDriver().quit();
					}

					if (rs.getBoolean("GoogleChrome")) {
						help.addTexto("GOOGLE CHROME\n");
						System.out.println("Chrome");
						help.MatarProceso(); sleep(3);
						help.getChrome("https://200.124.124.171/PSEBANCODEBOGOTA/Comercio.jsp");
						cont.testMain(tmp);

						/* Insertar resultado en Base de Datos para el informe Resumen */
						querySQL("INSERT INTO PSE.ConsolidadosEjecucion VALUES('" + "PSE_Regresion" + "','" + ObtenerA�o() + "','" + ObtenerMes() + "','" 
								+ fecha +  "','" + hora +  "','" + tmp[2] +  "','" + tmp[7] + " - G.CHROME" +  "','" + rs.getString("ResultadoEsperado") +  "','"  
								+ "EXITOSO" +  "','" + "EXITOSO" + "','" 
								+ "C:\\tmp\\PSE\\" + "Detallado_PSE_" + help.ObtenerMes() + "_" + tmp [4] + "_" + tmp [5] + ".pdf" + "')");

						/* Marcar como ejecutado el caso para este navegador */
						querySQL("UPDATE PSE.CasosPrueba SET GoogleChrome = '0' WHERE CodCP = '" + tmp[2] + "'");

						help.getDriver().quit();
					}

					if (rs.getBoolean("MozillaFirefox")) {
						help.addTexto("MOZILLA FIREFOX\n");
						System.out.println("Firefox");
						help.MatarProceso(); sleep(3);
						help.getFirefox("https://200.124.124.171/PSEBANCODEBOGOTA/Comercio.jsp");
						cont.testMain(tmp);

						/* Insertar resultado en Base de Datos para el informe Resumen */
						querySQL("INSERT INTO PSE.ConsolidadosEjecucion VALUES('" + "PSE_Regresion" + "','" + ObtenerA�o() + "','" + ObtenerMes() + "','" 
								+ fecha +  "','" + hora +  "','" + tmp[2] +  "','" + tmp[7] + " - M.FIREFOX" +  "','" + rs.getString("ResultadoEsperado") +  "','"  
								+ "EXITOSO" +  "','" + "EXITOSO" + "','" 
								+ "C:\\tmp\\PSE\\" + "Detallado_PSE_" + help.ObtenerMes() + "_" + tmp [4] + "_" + tmp [5] + ".pdf" + "')");

						/* Marcar como ejecutado el caso para este navegador */
						querySQL("UPDATE PSE.CasosPrueba SET MozillaFirefox = '0' WHERE CodCP = '" + tmp[2] + "'");

						help.getDriver().quit();
					}

					/* Actualizar el caso de prueba a EJECUTADO al finalizar la transacci�n */
					querySQL("UPDATE PSE.CasosPrueba SET Ejecutado = 'EJECUTADO' WHERE CodCP = '" + tmp[2] + "'");
				}

				help.closePDF();
			}
			catch(Exception e)
			{
				e.printStackTrace();

				querySQL("INSERT INTO PSE.ConsolidadosEjecucion VALUES('" + "PSE_Regresion" + "','" + ObtenerA�o() + "','" + ObtenerMes() + "','" 
						+ fecha +  "','" + hora +  "','" + tmp[2] +  "','" + tmp[7] +  "','" + rs.getString("ResultadoEsperado") +  "','"  
						+ "FALLAS T�CNICAS" +  "','" + "FALLIDO" + "','" 
						+ "C:\\tmp\\PSE\\" + "Detallado_PSE_" + help.ObtenerMes() + "_" + tmp [4] + "_" + tmp [5] + ".pdf" + "')");


			} finally {
				help.closePDF();
				//help.getDriver().quit();
			}
		}
	}
}