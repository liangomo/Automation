package B_CPV.Vistas;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.openqa.selenium.By;

import com.rational.test.ft.domain.java.eclipse.Util;

import A_Utilitarios.ClaseAyudante;
import B_CPV.Objetos.O2_IngresoPortalBanco;
import B_CPV.Objetos.O3_ServicioCPVClaveTD;

public class V3_ServicioCPVClaveTD {

	ClaseAyudante help;
	O3_ServicioCPVClaveTD claveTD;

	public V3_ServicioCPVClaveTD(ClaseAyudante help) {
		this.help = help;
		claveTD = new O3_ServicioCPVClaveTD(help); 
	}

	// Variable para validaci�n de token bloqueado
	boolean band = false;


	public boolean claveTD (Object[] args) throws IOException, InterruptedException, SQLException
	{

		/* Capturar im�gen y guardar en PDF */
		help.getCapturaImagen(args[2] + "_V2_IngresoPortalBanco");

		/**
		 *  Conexi�n a la Base de Datos
		 *   */

		/* Consulta de la informaci�n de las cuentas respecto al cliente y caso de prueba */
		ResultSet rs = help.Consulta("SELECT * FROM PSE.Cuentas WHERE IDCuenta = '" + args[1] + "'");
		rs.next();


		/** 
		 * Diligenciamiento Clave TD
		 * */

		/* Clave Tarjeta D�bito */
		claveTD.setTxtClave(rs.getString("ClaveTD")); 
		Thread.sleep(2000);

		/* Capturar im�gen y guardar en PDF */
		help.getCapturaImagen(args[2] + "_ClaveTD");

		System.out.println("TRX - " + rs.getString("Descripcion"));
		
		/** VALIDACI�N DE CLIENTES CON TOKEN BLOQUEADO */
		if (rs.getString("Descripcion").equals("PN CON Token Bloqueado")) {
			//			String trxbloqueada = ((String)label_accesoDenegadoSuTokenSeE().getProperty(".text"));
			//callScript("A_CPV.Vista.V6_FinalizacionTrx", args);
			band = true;

			/* Consulta de la informaci�n de las cuentas respecto al cliente y caso de prueba */
			ResultSet cp = help.Consulta("SELECT * FROM PSE.CasosPrueba WHERE CodCP = '" + args[2] + "'");
			cp.next();

			/* Inclusi�n en los informes */

			//imagen = browser_htmlBrowser(ANY, LOADED).getScreenSnapshot();	//Captura de pantalla

			//	String resultEsperado = (rs.getString("ResultadoEsperado")).replaceAll(",","");
			//			if (resultEsperado.equals(trxbloqueada))
			//				veredicto = "CORRECTO";
			//			else 
			//				veredicto = "FALLIDO";

			/* Capturar im�gen y guardar en PDF */
			help.addTexto("Cliente Token Bloqueado");
			help.getCapturaImagen(args[2] + "_Cliente Token BLoqueado");

			help.getDriver().quit();

			//			if ((boolean) args[8])
			//			help.getDriver().switchTo().alert().accept();
		}


		/** VALIDACI�N DE CLIENTES CON TOKEN */
		if(!band)
		{
			if (rs.getString("Descripcion").contains("CON Token")) {

				System.out.println("BAND555555555");

				/* Consulta de la informaci�n del cliente y cuenta para obtener el Token */
				ResultSet ct = help.Consulta("SELECT A.TipoID, A.NumeroID " +
						"FROM PSE.Clientes A JOIN PSE.CasosPrueba B ON A.IDCliente = B.IDCliente " +
						"WHERE B.IDCliente = '" + args[0] + "' " + 
						"AND B.IDCuenta = '" + args[1] + "'");

				ct.next();

				/* Clave Token */
				Thread.sleep(5000);
				String Token = help.Cliente(ct.getString("TipoID"), ct.getString("NumeroID"));
				System.out.println("TOKEN: " + Token);
				claveTD.setTxtToken(Token);


				/* Capturar im�gen y guardar en PDF */
				help.addTexto("Cliente con Token");
				help.getCapturaImagen(args[2] + "_Cliente con Token");

				/* Bot�n Continuar */
				claveTD.clickContinuar();
				Thread.sleep(3000);


				/** Validaci�n de Sitio Seguro Ventana emergente */

				// Certifique que el c�digo es correcto
				help.getDriver().switchTo().frame("_iframe-EmailBox");
				claveTD.clickChkAceptar();

				// Clic en Bot�n Continuar
				claveTD.clickAceptar();
				help.getDriver().switchTo().defaultContent();
				Thread.sleep(2000);

			} else {

				/** PARA CLIENTES SIN TOKEN */

				/* Bot�n Continuar */
				claveTD.clickContinuar();

				/* Validaci�n Sin Token */
				//	button_continuarbutton3().waitForExistence();
				//	button_continuarbutton3().click();
			}
		}

		return band;
	}

}