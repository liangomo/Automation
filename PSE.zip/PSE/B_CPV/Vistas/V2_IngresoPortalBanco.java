package B_CPV.Vistas;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import A_Utilitarios.ClaseAyudante;
import B_CPV.Objetos.O1_FormularioPSE;
import B_CPV.Objetos.O2_IngresoPortalBanco;

public class V2_IngresoPortalBanco {

	ClaseAyudante help;
	O2_IngresoPortalBanco ingresoPortal;

	public V2_IngresoPortalBanco(ClaseAyudante help) {
		this.help = help;
		ingresoPortal = new O2_IngresoPortalBanco(help); 
	}


	public void ingresoPortal (Object[] args) throws IOException, InterruptedException, SQLException
	{

		/**
		 *  Conexi�n a la Base de Datos
		 *   */

		ClaseAyudante Help = new ClaseAyudante() {};

		/* Consulta del cliente respecto al caso de prueba */
		ResultSet rs = Help.Consulta("SELECT * "+
				" FROM PSE.CasosPrueba A JOIN PSE.Clientes B ON A.IDCliente = B.IDCliente"+
				" WHERE A.CodCP = '" + args[2] + "'");
		rs.next();



		/** 
		 * Diligenciamiento de informaci�n del cliente 
		 * */

		Thread.sleep(4000);
		
		/* Tipo de Identificaci�n */
		ingresoPortal.setSelectTipoIdentificacion(rs.getString("TipoIDValue"));

		/* N�mero de Identificaci�n */
		ingresoPortal.setTxtIdentificacion(rs.getString("NumeroID"));

		
		/* Capturar im�gen y guardar en PDF */
		help.getCapturaImagen(args[2] + "_V2_IngresoPortalBanco");


		/* Bot�n Banca Personas */
		ingresoPortal.setBtnNatural();
	}
}