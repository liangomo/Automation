package B_CPV.Vistas;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import A_Utilitarios.ClaseAyudante;
import B_CPV.Objetos.O1_FormularioPSE;

import com.lowagie.text.Document;

public class V1_FormularioPSE {

	ClaseAyudante help;
	O1_FormularioPSE formularioPSE;

	public V1_FormularioPSE(ClaseAyudante help) {
		this.help = help;
		formularioPSE = new O1_FormularioPSE(help); 
	}
	
	
	public void linkCertificado() throws InterruptedException
	{
		System.out.println("LINK");
		formularioPSE.clickLinkCertificado();
	}
	
	
	public void formularioPSE(Object[] args) throws IOException, InterruptedException, SQLException
	{
		
		ResultSet rs = help.Consulta("SELECT * FROM PSE.FormularioPSE");
		rs.next();

		if(help.buscarObjeto(formularioPSE.getLinkCertificado()))
			formularioPSE.clickLinkCertificado();
		
		formularioPSE.setTxtCus(rs.getString("CUS"));
		formularioPSE.setTxtCodigoEntidad(rs.getString("CodEntidadFinanciera"));
		formularioPSE.setTxtCodigoComercio(rs.getString("IDComercio"));
		formularioPSE.setTxtNombreComercio(rs.getString("NombreComercio"));
		formularioPSE.setTxtValorCompra(rs.getString("ValorCompra"));
		formularioPSE.setTxtValorIVA(rs.getString("ValorIva"));
		formularioPSE.setTxtNumeroFactura(rs.getString("NumFactura"));
		formularioPSE.setTxtCodigoServicio(rs.getString("CodServicio"));
		formularioPSE.setTxtTipoUsuario(rs.getString("TipoUsuario"));
		formularioPSE.setTxtCicloTransaccion(rs.getString("CicloTrx"));
		
		/* Capturar im�gen y guardar en PDF */
		help.addTexto("Digita Datos de Usuario");
		help.getCapturaImagen(args[2] + "_V1_FormularioPSE");
	
		formularioPSE.clickBtnPagar();
		
		help.cambiarVentana();
		
		if(help.buscarObjeto(formularioPSE.getLinkCertificado()))
			formularioPSE.clickLinkCertificado();
	}
}