package B_CPV.Vistas;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import A_Utilitarios.ClaseAyudante;
import B_CPV.Objetos.O4_InformacionCuenta;
import B_CPV.Objetos.O5_DatosTD_Token;
import B_CPV.Objetos.O6_FinalizacionTrx;

public class V5_DatosTD_Token {
	
	ClaseAyudante help;
	O5_DatosTD_Token token;
	O6_FinalizacionTrx guardarPDF;

	public V5_DatosTD_Token(ClaseAyudante help) {
		this.help = help;
		token = new O5_DatosTD_Token(help); 
		guardarPDF = new O6_FinalizacionTrx(help); 
	}
	
	
	public void datosToken (Object[] args) throws IOException, InterruptedException, SQLException
	{
		/**
		 *  Conexi�n a la Base de Datos
		 *   */

		ClaseAyudante Help = new ClaseAyudante() {};

		/* Consulta de la informaci�n de las cuentas respecto al cliente y caso de prueba */
		ResultSet rs = Help.Consulta("SELECT * FROM PSE.Cuentas WHERE IDCuenta = '" + args[1] + "'");
		rs.next();
		Thread.sleep(2000);


		/** VALIDACI�N DE CLIENTES CON TOKEN */

		if (rs.getString("Descripcion").contains("CON Token")) {

			/* Consulta de la informaci�n del cliente y cuenta para obtener el Token */
			ResultSet ct = Help.Consulta("SELECT A.TipoID, A.NumeroID " +
					"FROM PSE.Clientes A JOIN PSE.CasosPrueba B ON A.IDCliente = B.IDCliente " +
					"WHERE B.IDCliente = '" + args[0] + "' " + 
					"AND B.IDCuenta = '" + args[1] + "'");

			ct.next();

			/* Clave Token */
			String Token = help.Cliente(ct.getString("TipoID"), ct.getString("NumeroID"));
			Thread.sleep(5000);
			token.setTxtToken(Token);
			
			/* Capturar im�gen y guardar en PDF */
			help.addTexto("Cliente con Token");
			help.getCapturaImagen(args[2] + "_Cliente con Token");

			/* Realizar Pago */
			token.clickBtnPagar();


			/** PARA CLIENTES SIN TOKEN CON VALIDACI�N DE DIGITOS DE LA TARJETA D�BITO */
			/* Para los CP de Digitos TD y que no muestre el campo de n�mero TD */
		} else {

			/** PARA CLIENTES SIN TOKEN */

			System.out.println("Cliente sin Token no val�da 16 d�gitos de la tarjeta d�bito");

			/* 16 D�gitos de la Tarjeta D�bito */
			token.setTxtNumeroTD1(rs.getString("NumeroTD"));

			/* Nuevamente 16 D�gitos de la Tarjeta D�bito */
			token.setTxtNumeroTD2(rs.getString("NumeroTD"));
			
			/* Capturar im�gen y guardar en PDF */
			help.addTexto("Cliente SIN Token");
			help.getCapturaImagen(args[2] + "_Cliente SIN Token");

			/* Realizar Pago */
			token.clickBtnPagar();
		}
	}
}