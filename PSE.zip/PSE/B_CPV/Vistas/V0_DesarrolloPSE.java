package B_CPV.Vistas;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.server.handler.SendKeys;

import A_Utilitarios.ClaseAyudante;
import B_CPV.Objetos.O0_DesarrolloPSE;

public class V0_DesarrolloPSE {

	ClaseAyudante help;
	O0_DesarrolloPSE desarrolloPSE;

	public V0_DesarrolloPSE(ClaseAyudante help) {
		this.help = help;
		desarrolloPSE = new O0_DesarrolloPSE(help); 
	}
	
	public void linkCertificado() throws InterruptedException
	{
		System.out.println("LINK");
		desarrolloPSE.clickLinkCertificado();
	}
	
	
	public void desarrolloPSE(Object[] args) throws IOException, InterruptedException, SQLException
	{
//		/* Capturar im�gen y guardar en PDF */
//		help.addTexto("IngresoPSE");
//		help.getCapturaImagen(args[2] + "_IngresoPSE");
		
		if(help.buscarObjeto(desarrolloPSE.getLinkCertificado()))
			desarrolloPSE.clickLinkCertificado();
		
		
		
		Thread.sleep(2000);
		desarrolloPSE.selectLstBanks();
		
		/* Capturar im�gen y guardar en PDF */
		help.getCapturaImagen(args[2] + "_Seleccionar Banco");
		
		desarrolloPSE.clickBtnConfirmar();
		Thread.sleep(2000);
		
		desarrolloPSE.setTxtTiketID("123456789012");
		desarrolloPSE.setTxtAmount("9000");
		desarrolloPSE.setTxtServiceCode("1234");
		desarrolloPSE.setTxtVATAmount("12");
		desarrolloPSE.setTxtPaymentDesc("PruebaAutomatizacion");
		desarrolloPSE.setTxtRefNumber1("55");
		desarrolloPSE.setTxtRefNumber2("66");
		desarrolloPSE.setTxtRefNumber3("77");
		
		/* Capturar im�gen y guardar en PDF */
		help.getCapturaImagen(args[2] + "_DatosPago");
		
		desarrolloPSE.clickBtnComprar();
		
		Thread.sleep(2000);
		desarrolloPSE.selectLstBanks();
		/* Capturar im�gen y guardar en PDF */
		help.getCapturaImagen(args[2] + "_Seleccionar Banco");
		desarrolloPSE.clickBtnConfirmar();
		
		Thread.sleep(8000);
		
		
		desarrolloPSE.setBodyRefresh();
		
		Thread.sleep(5000);
		
		desarrolloPSE.setTxtPNEMail("oguarac@bancodebogota.com.co");
		Thread.sleep(3000);
		/* Capturar im�gen y guardar en PDF */
		help.getCapturaImagen(args[2] + "_Correo");
		
		desarrolloPSE.clickBtnSeguir();
		Thread.sleep(15000);
		
//		if(help.buscarObjeto(desarrolloPSE.getLinkCertificado()))
//			System.out.println("Certificado");
//			/* Capturar im�gen y guardar en PDF */
//			help.getCapturaImagen(args[2] + "_Link");
//			desarrolloPSE.clickLinkCertificado();
	}
}