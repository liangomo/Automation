package B_CPV.Vistas;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import A_Utilitarios.ClaseAyudante;
import B_CPV.Objetos.O4_InformacionCuenta;

public class V4_InformacionCuenta {

	/** DEFINICI�N DE VARIABLES: */

	// Variables para validaci�n de cuenta origen
	boolean esCoincidente = false;

	ClaseAyudante help;
	O4_InformacionCuenta datosCuenta;

	public V4_InformacionCuenta(ClaseAyudante help) {
		this.help = help;
		datosCuenta = new O4_InformacionCuenta(help); 
	}

	public void infoCuenta (Object[] args) throws IOException, InterruptedException, SQLException
	{
		/**
		 *  Conexi�n a la Base de Datos
		 *   */

		ClaseAyudante Help = new ClaseAyudante() {};
		
		/* Capturar im�gen y guardar en PDF */
		help.addTexto("PagarDesde");
		help.getCapturaImagen(args[2] + "_PagarDesde");

		/* Consulta de la informaci�n del formulario PSE respecto al comercio */
		ResultSet rs = Help.Consulta("SELECT * FROM PSE.Cuentas WHERE IDCuenta = '" + args[1] + "'");
		rs.next();
	
		Thread.sleep(8000);
		datosCuenta.selectLstPagarDesde(rs.getString("TipoCuenta"), rs.getString("NumeroCuenta"));


		/* Click en Bot�n Continuar */
		//		if(esCoincidente)
		//		{
		//browser_htmlBrowser(document_bancoDeBogot�(ANY,LOADED),DEFAULT_FLAGS).inputKeys("{TAB}");

		/* Capturar im�gen y guardar en PDF */
		help.addTexto("PagarDesde");
		help.getCapturaImagen(args[2] + "_PagarDesde");

		datosCuenta.clickBtnContinuar();
		//		}
	}
}
