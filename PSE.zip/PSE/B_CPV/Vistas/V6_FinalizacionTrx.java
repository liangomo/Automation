package B_CPV.Vistas;

import java.io.IOException;
import java.sql.SQLException;
import A_Utilitarios.ClaseAyudante;
import B_CPV.Objetos.O0_DesarrolloPSE;
import B_CPV.Objetos.O5_DatosTD_Token;
import B_CPV.Objetos.O6_FinalizacionTrx;

public class V6_FinalizacionTrx {
	
	ClaseAyudante help;
	O6_FinalizacionTrx guardarPDF;

	public V6_FinalizacionTrx(ClaseAyudante help) {
		this.help = help;
		guardarPDF = new O6_FinalizacionTrx(help); 
	}
	
	
	public void finalizacionTrx (Object[] args) throws IOException, InterruptedException, SQLException
	{
		Thread.sleep(10000);
		help.addTexto("FIN TRX");

		/* Capturar im�gen y guardar en PDF */
		help.getCapturaImagen(args[2] + "_V6_FinalizacionTrx");
		
//		guardarPDF.clickimagenPDF();
//		Thread.sleep(5000);
	//	help.getDriver().switchTo().
	}
}