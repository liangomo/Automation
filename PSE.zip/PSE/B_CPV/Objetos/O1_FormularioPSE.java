package B_CPV.Objetos;

import org.openqa.selenium.By;
import A_Utilitarios.ClaseAyudante;

public class O1_FormularioPSE {

	ClaseAyudante help;
	By txtCus =  By.id("TrazabilityCode");
	By txtCodigoEntidad = By.id("FinancialInstitutionCode");
	By txtCodigoComercio = By.id("EntityCode");
	By txtNombreComercio = By.id("EntityName");
	By txtValorCompra = By.id("TransactionValue");
	By txtValorIVA = By.id("VatValue");
	By txtNumeroFactura = By.id("TicketId");
	By txtCodigoServicio = By.id("ServiceCode");
	By txtTipoUsuario = By.id("UserType");
	By txtCicloTransaccion = By.id("TransactionCycle");
	By txtDescripcionCompra = By.id("PaymentDescription");
	By txtReferencia1 = By.id("ReferenceNumber1");
	By txtReferencia2 = By.id("ReferenceNumber2");
	By txtReferencia3 = By.id("ReferenceNumber3");
	By btnPagar = By.id("bPagar");
	By linkCertificado = By.id("overridelink");

	
	public O1_FormularioPSE(ClaseAyudante help)
	{
		this.help = help;
	}
	
	public void setTxtCus(String cus)
	{
		this.help.getDriver().findElement(txtCus).sendKeys(cus);
	}
	
	
	public void setTxtCodigoEntidad(String codigoEnt)
	{
		this.help.getDriver().findElement(txtCodigoEntidad).sendKeys(codigoEnt);
	}

	public void setTxtCodigoComercio(String codigoComercio)
	{
		this.help.getDriver().findElement(txtCodigoComercio).sendKeys(codigoComercio);
	}

	public void setTxtNombreComercio(String nombreComercio)
	{
		this.help.getDriver().findElement(txtNombreComercio).sendKeys(nombreComercio);
	}

	public void setTxtValorCompra(String valorCompra)
	{
		this.help.getDriver().findElement(txtValorCompra).sendKeys(valorCompra);
	}

	public void setTxtValorIVA(String valorIva)
	{
		this.help.getDriver().findElement(txtValorIVA).sendKeys(valorIva);
	}

	public void setTxtNumeroFactura(String numeroFactura)
	{
		this.help.getDriver().findElement(txtNumeroFactura).sendKeys(numeroFactura);
	}

	public void setTxtCodigoServicio(String codigoServicio)
	{
		this.help.getDriver().findElement(txtCodigoServicio).sendKeys(codigoServicio);
	}

	public void setTxtTipoUsuario(String tipoUsuario)
	{
		this.help.getDriver().findElement(txtTipoUsuario).sendKeys(tipoUsuario);
	}

	public void setTxtCicloTransaccion(String cicloTransaccion)
	{
		this.help.getDriver().findElement(txtCicloTransaccion).sendKeys(cicloTransaccion);
	}

	public void setTxtDescripcionCompra(String descripcionCompra)
	{
		this.help.getDriver().findElement(txtDescripcionCompra).sendKeys(descripcionCompra);
	}

	public void setTxtReferencia1(String referencia1)
	{
		this.help.getDriver().findElement(txtReferencia1).sendKeys(referencia1);
	}

	public void setTxtReferencia2(String referencia2)
	{
		this.help.getDriver().findElement(txtReferencia2).sendKeys(referencia2);
	}

	public void setTxtReferencia3(String referencia3)
	{
		this.help.getDriver().findElement(txtReferencia3).sendKeys(referencia3);
	}

	public void clickBtnPagar()
	{
		this.help.getDriver().findElement(btnPagar).click();
	}
	
	public void clickLinkCertificado()
	{
		this.help.getDriver().findElement(linkCertificado).click();
	}
	
	public By getLinkCertificado()
	{
		return linkCertificado;
	}
	
}