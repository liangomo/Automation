package B_CPV.Objetos;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import A_Utilitarios.ClaseAyudante;

public class O2_IngresoPortalBanco {

	ClaseAyudante help;
	By selectTipoIdentificacion = By.id("IdentificationType");
	By txtIdentificacion = By.id("Identification");
	By btnNatural = By.id("button_btnNatural");
	By btnEmpresas = By.id("button_btnEmpresas");

	
	public O2_IngresoPortalBanco(ClaseAyudante util)
	{
		this.help = util;
	}
	
	public void setSelectTipoIdentificacion(String tipoIdentificacion)
	{
	//	this.help.getDriver().findElement(selectTipoIdentificacion).sendKeys(tipoIdentificacion);
		Select dropdown = new Select(this.help.getDriver().findElement(selectTipoIdentificacion));
		dropdown.selectByValue(tipoIdentificacion);
	}

	public void setTxtIdentificacion(String identificacion)
	{
		this.help.getDriver().findElement(txtIdentificacion).sendKeys(identificacion);
	}

	public void setBtnNatural()
	{
		this.help.getDriver().findElement(btnNatural).click();
	}

	public void setBtnEmpresas()
	{
		this.help.getDriver().findElement(btnEmpresas).click();
	}
}