package B_CPV.Objetos;

import org.openqa.selenium.By;
import A_Utilitarios.ClaseAyudante;

public class O5_DatosTD_Token {
	ClaseAyudante help;
	By txtToken = By.id("userToken");
	By btnPagar = By.id("button_validate");
	By txtNumeroTD1 = By.id("digitCard");
	By txtNumeroTD2 = By.id("digitCardPass");
	
	
	public O5_DatosTD_Token(ClaseAyudante help)
	{
		this.help = help;
	}
	
	public void setTxtToken(String token)
	{
		this.help.getDriver().findElement(txtToken).sendKeys(token);
	}
	
	public void clickBtnPagar()
	{
		this.help.getDriver().findElement(btnPagar).click();
	}
	
	public void setTxtNumeroTD1(String numeroTD1)
	{
		this.help.getDriver().findElement(txtNumeroTD1).sendKeys(numeroTD1);
	}
	
	public void setTxtNumeroTD2(String numeroTD2)
	{
		this.help.getDriver().findElement(txtNumeroTD2).sendKeys(numeroTD2);
	}
}