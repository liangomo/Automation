package B_CPV.Objetos;

import org.openqa.selenium.By;
import A_Utilitarios.ClaseAyudante;

public class O6_FinalizacionTrx {

	ClaseAyudante help;
	By imagenPDF = By.xpath("//*[@id=\"confirmPaymentForm\"]/table[1]/tbody/tr/td[1]/table/tbody/tr[4]/td/a/img");
	
	public O6_FinalizacionTrx(ClaseAyudante help)
	{
		this.help = help;
	}
	
	public void clickimagenPDF()
	{
		this.help.getDriver().findElement(imagenPDF).click();
	}
}