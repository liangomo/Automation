package B_CPV.Objetos;

import org.openqa.selenium.By;

import A_Utilitarios.ClaseAyudante;

public class O3_ServicioCPVClaveTD {

	ClaseAyudante help;
	By txtClave = By.id("Password");
	By txtToken = By.id("UserToken");
	By btnSalir = By.id("button2");
	By btnContinuar = By.id("button_validate");
	By chkAceptar = By.id("checkbox");
	By btnAceptar = By.id("button3");
	
	
	public O3_ServicioCPVClaveTD(ClaseAyudante util)
	{
		this.help = util;
	}
	
	public void setTxtClave(String clave) {
		this.help.getDriver().findElement(txtClave).sendKeys(clave);
	}
	
	public void setTxtToken(String token) {
		this.help.getDriver().findElement(txtToken).sendKeys(token);
	}
	
	public void clickSalir() {
		this.help.getDriver().findElement(btnSalir).click();
	}
	
	public void clickContinuar() {
		this.help.getDriver().findElement(btnContinuar).click();
	}
	
	public void clickChkAceptar() {
		this.help.getDriver().findElement(chkAceptar).click();
	}
	
	public void clickAceptar() {
		this.help.getDriver().findElement(btnAceptar).click();
	}
	
}