package B_CPV.Objetos;

import java.awt.List;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.xalan.templates.ElemComment;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import A_Utilitarios.ClaseAyudante;

public class O4_InformacionCuenta {

	ClaseAyudante help;
	By lstPagarDesde = By.id("Product2Pay");
	By btnContinuar = By.id("button_validate");
	int salida = 0;

	public O4_InformacionCuenta(ClaseAyudante help)
	{
		this.help = help;
	}

	public void selectLstPagarDesde(String tipoCuenta, String numeroCuenta)
	{
		/* Patr�n de comparacion del campo seleccionar cuenta origen incluyendo expresi�n regular para el saldo */
		String regex = "[0-9.,$-]";
		Pattern patron = Pattern.compile(tipoCuenta + " - " + numeroCuenta + " con saldo: " + regex);
		Boolean esCoincidente = false;
		Select dropdown = new Select(this.help.getDriver().findElement(lstPagarDesde));
		java.util.List<WebElement> elementCount = dropdown.getOptions();
		int iSize = elementCount.size();
		
		//Verificar si inicia en 0 o en 1
		for (int pa = 0; pa<iSize; pa++) {
			
			String sValue = elementCount.get(pa).getText();
			Matcher emparejador = patron.matcher(sValue);
			esCoincidente = emparejador.find();
			
			if (esCoincidente) {
				salida = pa;
			}
		}
		
		dropdown.selectByIndex(salida);
	}


	public String selectLstPagarDesde1()
	{
		return (this.help.getDriver().findElement(lstPagarDesde).getAttribute("Value"));
	}


	public void clickBtnContinuar()
	{
		this.help.getDriver().findElement(btnContinuar).click();
	}
}