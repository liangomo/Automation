package B_CPV.Objetos;

import java.awt.AWTException;
import java.awt.event.KeyEvent;

import javafx.event.ActionEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.rational.test.ft.cm.ActionAddToClearCase;
import com.sun.glass.ui.Robot;

import A_Utilitarios.ClaseAyudante;

public class O0_DesarrolloPSE {

	ClaseAyudante help;
	By linkCertificado = By.id("overridelink");
	By lstBanks = By.id("lstBanks");
	By btnConfirmar = By.id("btnConfirm");
	By txtTiketID =  By.id("txtTicketID");
	By txtAmount = By.id("txtAmount");
	By txtServiceCode = By.id("txtServiceCode");
	By txtVATAmount = By.id("txtVATAmount");
	By txtPaymentDesc = By.id("txtPaymentDescription");
	By txtRefNumber1 = By.id("txtReferenceNumber1");
	By txtRefNumber2 = By.id("txtReferenceNumber2");
	By txtRefNumber3 = By.id("txtReferenceNumber3");
	By btnComprar = By.id("btnBuy");
	By txtPNEMail = By.id("PNEMail");
	By btnSeguir = By.id("btnSeguir");
	
	By bodyRefresh = By.xpath("//body");


	public O0_DesarrolloPSE(ClaseAyudante help)
	{
		this.help = help;
	}
	
	
	public void clickLinkCertificado()
	{
		this.help.getDriver().findElement(linkCertificado).click();
	}
	
	public By getLinkCertificado()
	{
		return linkCertificado;
	}
	
	public void selectLstBanks()
	{
		Select dropdown = new Select(this.help.getDriver().findElement(lstBanks));
		dropdown.selectByValue("1001");
	}
	
	public void clickBtnConfirmar()
	{
		this.help.getDriver().findElement(btnConfirmar).click();
	}
	
	
	public void setTxtTiketID(String ticketID)
	{
		this.help.getDriver().findElement(txtTiketID).sendKeys(ticketID);
	}
	
	public void setTxtAmount(String amount)
	{
		this.help.getDriver().findElement(txtAmount).sendKeys(amount);
	}
	
	public void setTxtServiceCode(String service)
	{
		this.help.getDriver().findElement(txtServiceCode).sendKeys(service);
	}
	
	public void setTxtVATAmount(String VATAAmount)
	{
		this.help.getDriver().findElement(txtVATAmount).sendKeys(VATAAmount);
	}
	
	public void setTxtPaymentDesc(String paymentDesc)
	{
		this.help.getDriver().findElement(txtPaymentDesc).sendKeys(paymentDesc);
	}
	
	public void setTxtRefNumber1(String refNumber1)	{
		this.help.getDriver().findElement(txtRefNumber1).sendKeys(refNumber1);
	}
	
	public void setTxtRefNumber2(String refNumber2)
	{
		this.help.getDriver().findElement(txtRefNumber2).sendKeys(refNumber2);
	}
	
	public void setTxtRefNumber3(String refNumber3)
	{
		this.help.getDriver().findElement(txtRefNumber3).sendKeys(refNumber3);
	}
	
	public void clickBtnComprar()
	{
		this.help.getDriver().findElement(btnComprar).click();
	}

	public void setTxtPNEMail (String PNEMail)
	{
		this.help.getDriver().findElement(txtPNEMail).sendKeys(PNEMail);		
	}
	
	public void clickBtnSeguir()
	{
		this.help.getDriver().findElement(btnSeguir).click();
	}

	public void setBodyRefresh()
	{
		this.help.getDriver().findElement(bodyRefresh).sendKeys(Keys.F5);
	}

}
