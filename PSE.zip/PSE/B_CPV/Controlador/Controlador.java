package B_CPV.Controlador;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;

import consumirServicios.DesasignarDigipass;
import A_Utilitarios.ClaseAyudante;
import B_CPV.Vistas.*;

public class Controlador {

	/* Llamado Vistas */
	ClaseAyudante help;
	V0_DesarrolloPSE desarrolloPSE;
	V1_FormularioPSE formularioPSE;
	V2_IngresoPortalBanco ingresoPortal;
	V3_ServicioCPVClaveTD claveTD;
	V4_InformacionCuenta infoCuenta;
	V5_DatosTD_Token datosToken;
	V6_FinalizacionTrx finalizacionTrx;
	
	public Controlador(ClaseAyudante help)
	{
		this.help = help;
		desarrolloPSE = new V0_DesarrolloPSE(help);
		formularioPSE = new V1_FormularioPSE(help);
		ingresoPortal = new V2_IngresoPortalBanco(help);
		claveTD = new V3_ServicioCPVClaveTD(help);
		infoCuenta = new V4_InformacionCuenta(help);
		datosToken = new V5_DatosTD_Token(help);
		finalizacionTrx = new V6_FinalizacionTrx(help);
	}
	
	public void testMain(Object[] args) throws DocumentException, IOException, InterruptedException, SQLException
	{
		
		/** LLAMADO A CADA VISTA DE LA APLICACI�N */

		Thread.sleep(5000);
		
		/* Ingreso de la informaci�n del comercio */
	//	desarrolloPSE.desarrolloPSE(args);
		
		/* Ingreso de la informaci�n del comercio */
		formularioPSE.formularioPSE(args);
		
		/* Ingreso tipo y n�mero de documento del cliente */
		ingresoPortal.ingresoPortal(args);

		/* Ingreso clave de Tarjeta D�bito y Token para clientes con Token */
		boolean validacion = (boolean) claveTD.claveTD(args);


		/* Validaci�n para los casos que continuan el flujo normal
		 * No aplica para clientes con Token Bloqueado */
		
		if(!validacion)
		{
			/* Ingreso cuenta origen */
			infoCuenta.infoCuenta(args);

			/* Ingreso n�mero Tarjeta D�bito o Token para clientes con Token */
			datosToken.datosToken(args);
			
			/* Comprobaci�n de trx e informe de resultados */
			finalizacionTrx.finalizacionTrx(args);
		}
		
	}

}