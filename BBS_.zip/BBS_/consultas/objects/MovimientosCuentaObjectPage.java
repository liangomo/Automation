package consultas.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import utilitarios.Utilitarios;

public class MovimientosCuentaObjectPage {
	Utilitarios util;

	public MovimientosCuentaObjectPage(Utilitarios util){
		this.util = util;
	}
	
	/**
	 * Objetos Cuentas Ahorros y Corriente
	 */
	
	private By selectGrupoCtas = By.xpath("//*[@id=\"TABLE2\"]/tbody/tr/td/table/tbody/tr[1]/td[2]/select");
	private By selectCuentaCtas = By.xpath("//*[@id=\"TABLE2\"]/tbody/tr/td/table/tbody/tr[2]/td[2]/select");
	
	private By lblSaldoDisponibleCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[1]/td/table/tbody/tr[2]/td[1]");
	private By lblSaldoCanjeCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[1]/td/table/tbody/tr[2]/td[2]");
	private By lblSaldoTotalCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[1]/td/table/tbody/tr[2]/td[3]");
	private By lblDiasEnSobregiroCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td[1]");
	private By lblFechaCorteCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td[2]");
	
	private By selectTipoMovimientoCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[1]/tbody/tr[2]/td/select");
	private By checkRangoFechasCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr[1]/td/font/input");
	private By selectDiaDesdeCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[1]/td[2]/font/select");
	private By selectMesDesdeCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[1]/td[4]/font/select");
	private By selectDiaHastaCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td[2]/font/select");
	private By selectMesHastaCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td[4]/font/select");
	private By checkUltimosMovimientoCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[3]/tbody/tr/td/font[1]/input");
	private By txtCtdMovimientosCtas = By.name("DATA10");
//	/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[3]/tbody/tr/td/font[2]/input
//	/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[3]/tbody/tr/td/font[2]/input
	
	private By checkRangoValorCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[4]/tbody/tr[1]/td/font/input");
	private By txtValorDesdeCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[4]/tbody/tr[2]/td/font/input");
	private By txtValorHastaCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[4]/tbody/tr[3]/td/font/input");
	private By checkTotalDebCrCtas = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[5]/tbody/tr/td/font[1]/input");
	private By btnConsultarCtas = By.xpath("//*[@id=\"consulta\"]");
	
	private By tblMovimientosCtas = By.xpath("/html/body/form/div[1]/table[3]");
	
	private By btnNotacontableCtas = By.xpath("/html/body/form/center[2]/table[1]/tbody/tr/td[2]/button");
	private By btnRegresarCtas = By.xpath("/html/body/form/center[2]/table[1]/tbody/tr/td[3]/div/button");
	private By btnExportarCtas = By.xpath("/html/body/form/center[2]/table[2]/tbody/tr[1]/td[2]/button");
	private By btnImpresionInteligenteCtas = By.id("button1");
	private By selectTipoArchivo = By.xpath("/html/body/form/center[2]/table[2]/tbody/tr[3]/td[2]/select");
	private By btnSolicitarArchivoCtas = By.xpath("/html/body/form/center[2]/table[2]/tbody/tr[3]/td[3]/button");

	public void setSelectGrupoCtas(String select) {
		this.util.getDriver().findElement(selectGrupoCtas).sendKeys(select);
	}

	public void setSelectCuentaCtas(String select) {
		this.util.getDriver().findElement(selectCuentaCtas).sendKeys(select);
	}
	
	public String getLblSaldoDisponibleCtas() {
		return this.util.getDriver().findElement(lblSaldoDisponibleCtas).getText();
	}

	public String getLblSaldoCanjeCtas() {
		return this.util.getDriver().findElement(lblSaldoCanjeCtas).getText();
	}

	public String getLblSaldoTotalCtas() {
		return this.util.getDriver().findElement(lblSaldoTotalCtas).getText();
	}

	public String getLblDiasEnSobregiroCtas() {
		return this.util.getDriver().findElement(lblDiasEnSobregiroCtas).getText();
	}

	public String getLblFechaCorteCtas() {
		return this.util.getDriver().findElement(lblFechaCorteCtas).getText();
	}

	public void setSelectTipoMovimientoCtas(String select) {
		this.util.getDriver().findElement(selectTipoMovimientoCtas).sendKeys(select);
	}
	
	public void setCheckRangoFechasCtas() {
		this.util.getDriver().findElement(checkRangoFechasCtas).click();
	}
	
	public void setSelectDiaDesdeCtas(String select) {
		new Select(this.util.getDriver().findElement(selectDiaDesdeCtas)).selectByVisibleText(select);
//		this.util.getDriver().findElement(selectDiaDesdeCtas).sendKeys(select);
	}
	
	public void setSelectMesDesdeCtas(String select) {
		this.util.getDriver().findElement(selectMesDesdeCtas).sendKeys(select);
	}
	
	public void setSelectDiaHastaCtas(String select) {
		new Select(this.util.getDriver().findElement(selectDiaHastaCtas)).selectByVisibleText(select);
//		this.util.getDriver().findElement(selectDiaHastaCtas).sendKeys(select);
	}
	
	public void setSelectMesHastaCtas(String select) {
		this.util.getDriver().findElement(selectMesHastaCtas).sendKeys(select);
	}
	
	public void setCheckUltimosMovimientoCtas() {
		this.util.getDriver().findElement(checkUltimosMovimientoCtas).click();
	}
	
	public void setTxtCtdMovimientosCtas(String txt) {
		this.util.getDriver().findElement(txtCtdMovimientosCtas).sendKeys(txt);
	}
	
	public void setCheckRangoValorCtas() {
		this.util.getDriver().findElement(checkRangoValorCtas).click();
	}
	
	public void setTxtValorDesdeCtas(String txt) {
		this.util.getDriver().findElement(txtValorDesdeCtas).sendKeys(txt);
	}
	
	public void setTxtValorHastaCtas(String txt) {
		this.util.getDriver().findElement(txtValorHastaCtas).sendKeys(txt);
	}
	
	public void setCheckTotalDebCrCtas() {
		this.util.getDriver().findElement(checkTotalDebCrCtas).click();
	}
	
	public void setBtnConsultarCtas() {
		this.util.getDriver().findElement(btnConsultarCtas).click();
	}
	
	public By getTblMovimientosCtas() {
		return tblMovimientosCtas;
	}
	
	public void setBtnNotacontableCtas() {
		this.util.getDriver().findElement(btnNotacontableCtas).click();
	}
	
	public void setBtnRegresarCtas() {
		this.util.getDriver().findElement(btnRegresarCtas).click();
	}
	
	public void setSelectTipoArchivo(String select) {
		this.util.getDriver().findElement(selectTipoArchivo).sendKeys(select);
	}
	
	public void setBtnExportarCtas() {
		this.util.getDriver().findElement(btnExportarCtas).click();
	}
	
	public void setBtnImpresionInteligenteCtas() {
		this.util.getDriver().findElement(btnImpresionInteligenteCtas).click();
	}
	
	public void setBtnSolicitarArchivoCtas() {
		this.util.getDriver().findElement(btnSolicitarArchivoCtas).click();
	}
	
	/** 
	 * Objetos Credito Rotativo
	 */
	
	private By selectGrupoRot = By.xpath("/html/body/form/table[4]/tbody/tr[1]/td[2]/font/b/font/select");
	private By selectGrupoCuentaRot = By.xpath("/html/body/form/table[4]/tbody/tr[2]/td[2]/select");
	
	private By selectFechaDesdeRot = By.name("fecha1");
	private By selectFechaHastaRot = By.name("fecha2");
	private By btnConsultarRot = By.xpath("//*[@id=\"consulta\"]");
	
	private By lblCupoTotalRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[1]/table/tbody/tr[1]/td[2]");
	private By lblCupoUtilizadoRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[1]/table/tbody/tr[2]/td[2]");
	private By lblValorCanjeRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[1]/table/tbody/tr[3]/td[2]");
	private By lblCupoDisponibleRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[1]/table/tbody/tr[4]/td[2]");
	private By lblOtrosGastosRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[1]/table/tbody/tr[5]/td[2]");
	private By lblPagoTotalRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[1]/table/tbody/tr[6]/td[2]");
	private By lblInteresesCorrientesRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[1]/table/tbody/tr[7]/td[2]");
	private By lblInteresesdeMoraRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[1]/table/tbody/tr[8]/td[2]");
	private By lblValorFacturadoRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[2]/table/tbody/tr[1]/td[2]");
	private By lblFechaLimitePagoRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[2]/table/tbody/tr[2]/td[2]");
	private By lblSaldoCapitalFactPendienteRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[2]/table/tbody/tr[3]/td[2]");
	private By lblSaldoInteresCorrienteFactPendienteRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[2]/table/tbody/tr[4]/td[2]");
	private By lblSaldoInteresMoraFactPendienteRot = By.xpath("/html/body/form/table[7]/tbody/tr/td[2]/table/tbody/tr[5]/td[2]");
	
	private By tblMovimientosRot = By.xpath("/html/body/form/table[9]");
	
	private By btnRegrerarRot = By.xpath("/html/body/form/div/button");
	private By btnExportarRot = By.xpath("/html/body/form/table[10]/tbody/tr[1]/td[2]/button");
	private By btnImpresionIntRot = By.xpath("/html/body/form/table[10]/tbody/tr[2]/td[2]/button");

	public void setSelectGrupoRot(String select) {
		this.util.getDriver().findElement(selectGrupoRot).sendKeys(select);
	}

	public void setSelectGrupoCuentaRot(String select) {
		this.util.getDriver().findElement(selectGrupoCuentaRot).sendKeys(select);
	}

	public void setSelectFechaDesdeRot(String select) {
		this.util.getDriver().findElement(selectFechaDesdeRot).sendKeys(select);
	}

	public void setSelectFechaHastaRot(String select) {
		this.util.getDriver().findElement(selectFechaHastaRot).sendKeys(select);
	}

	public void setBtnConsultarRot() {
		this.util.getDriver().findElement(btnConsultarRot).click();
	}

	public String getLblCupoTotalRot() {
		return this.util.getDriver().findElement(lblCupoTotalRot).getText();
	}
	
	public String getLblCupoUtilizadoRot() {
		return this.util.getDriver().findElement(lblCupoUtilizadoRot).getText();
	}
	
	public String getLblValorCanjeRot() {
		return this.util.getDriver().findElement(lblValorCanjeRot).getText();
	}
	
	public String getLblCupoDisponibleRot() {
		return this.util.getDriver().findElement(lblCupoDisponibleRot).getText();
	}
	
	public String getLblOtrosGastosRot() {
		return this.util.getDriver().findElement(lblOtrosGastosRot).getText();
	}
	
	public String getLblPagoTotalRot() {
		return this.util.getDriver().findElement(lblPagoTotalRot).getText();
	}
	
	public String getLblInteresesCorrientesRot() {
		return this.util.getDriver().findElement(lblInteresesCorrientesRot).getText();
	}
	
	public String getLblInteresesdeMoraRot() {
		return this.util.getDriver().findElement(lblInteresesdeMoraRot).getText();
	}
	
	public String getLblValorFacturadoRot() {
		return this.util.getDriver().findElement(lblValorFacturadoRot).getText();
	}
	
	public String getLblFechaLimitePagoRot() {
		return this.util.getDriver().findElement(lblFechaLimitePagoRot).getText();
	}
	
	public String getLblSaldoCapitalFactPendienteRot() {
		return this.util.getDriver().findElement(lblSaldoCapitalFactPendienteRot).getText();
	}
	
	public String getLblSaldoInteresCorrienteFactPendienteRot() {
		return this.util.getDriver().findElement(lblSaldoInteresCorrienteFactPendienteRot).getText();
	}
	
	public String getLblSaldoInteresMoraFactPendienteRot() {
		return this.util.getDriver().findElement(lblSaldoInteresMoraFactPendienteRot).getText();
	}
	
	public By getTblMovimientosRot() {
		return tblMovimientosRot;
	}
	
	public void setBtnRegrerarRot() {
		this.util.getDriver().findElement(btnRegrerarRot).click();
	}
	
	public void setBtnExportarRot() {
		this.util.getDriver().findElement(btnExportarRot).click();
	}
	
	public void setBtnImpresionIntRot() {
		this.util.getDriver().findElement(btnImpresionIntRot).click();
	}
	
	/**
	 * Objetos Tarjeta de Credito
	 */
	
	private By selectGrupoTC = By.xpath("//*[@id=\"TABLE2\"]/tbody/tr/td/table/tbody/tr[1]/td[2]/b/font/select");
	private By selectTarjetaTC = By.xpath("//*[@id=\"TABLE2\"]/tbody/tr/td/table/tbody/tr[2]/td[2]/select");
	
	private By lblCupoTotalTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[2]/td[1]");
	private By lblCupoComprasTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[2]/td[2]");
	private By lblCupoAvancesTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[2]/td[3]");
	private By lblSaldoTotalTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[5]/td[1]");
	private By lblValorMinimoTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[5]/td[2]");
	private By lblFechaProximoPagoTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[2]/td/table/tbody/tr[5]/td[3]");
	
	private By checkTipoMovimientoTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[1]/tbody/tr[1]/td/font/input");
	private By selectTransaccionTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[1]/tbody/tr[2]/td/select");
	private By checkRangoFechasTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr[1]/td/font/input");
	private By selectRangoDiaDesdeTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[1]/td[2]/font/select");
	private By selectRangoMesDesdeTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[1]/td[4]/font/select");
	private By selectRangoDiaHastaTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td[2]/font/select");
	private By selectRangoMesHastaTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td[4]/font/select");
	private By checkUltimosMovTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/table[3]/tbody/tr/td/font[1]/input");
	private By btnConsultarTC = By.xpath("/html/body/form/div[1]/table[1]/tbody/tr[1]/td[2]/table/tbody/tr/td/table/tbody/tr/td/div/button");
	 	
	private By tblMovimientosTC = By.xpath("/html/body/form/div[1]/table[3]");
	
	private By btnRegresarTC = By.xpath("/html/body/form/center[2]/table[1]/tbody/tr/td[2]/div/button");
	private By btnExportarTC = By.xpath("/html/body/form/center[2]/table[2]/tbody/tr[1]/td[2]/button");
	private By btnImpresionIntTC = By.xpath("//*[@id=\"button1\"]");
	private By btnSolicitarArchivoTC = By.xpath("/html/body/form/center[2]/table[2]/tbody/tr[3]/td[2]/button");

	public void setSelectGrupoTC(String select) {
		this.util.getDriver().findElement(selectGrupoTC).sendKeys(select);
	}
	
	public void setSelectTarjetaTC(String select) {
		this.util.getDriver().findElement(selectTarjetaTC).sendKeys(select);
	}
	
	public String getLblCupoTotalTC() {
		return this.util.getDriver().findElement(lblCupoTotalTC).getText();
	}
	
	public String getLblCupoComprasTC() {
		return this.util.getDriver().findElement(lblCupoComprasTC).getText();
	}
	
	public String getLblCupoAvancesTC() {
		return this.util.getDriver().findElement(lblCupoAvancesTC).getText();
	}
	
	public String getLblSaldoTotalTC() {
		return this.util.getDriver().findElement(lblSaldoTotalTC).getText();
	}
	
	public String getLblValorMinimoTC() {
		return this.util.getDriver().findElement(lblValorMinimoTC).getText();
	}
	
	public String getLblFechaProximoPagoTC() {
		return this.util.getDriver().findElement(lblFechaProximoPagoTC).getText();
	}
	
	public void setCheckTipoMovimientoTC() {
		this.util.getDriver().findElement(checkTipoMovimientoTC).click();
	}
	
	public void setSelectTransaccionTC(String select) {
		this.util.getDriver().findElement(selectTransaccionTC).sendKeys(select);
	}
	
	public void setCheckRangoFechasTC() {
		this.util.getDriver().findElement(checkRangoFechasTC).click();
	}
	
	public void setSelectRangoDiaDesdeTC(String select) {
		this.util.getDriver().findElement(selectRangoDiaDesdeTC).sendKeys(select);
	}
	
	public void setSelectRangoMesDesdeTC(String select) {
		this.util.getDriver().findElement(selectRangoMesDesdeTC).sendKeys(select);
	}
	
	public void setSelectRangoDiaHastaTC(String select) {
		this.util.getDriver().findElement(selectRangoDiaHastaTC).sendKeys(select);
	}
	
	public void setSelectRangoMesHastaTC(String select) {
		this.util.getDriver().findElement(selectRangoMesHastaTC).sendKeys(select);
	}
	
	public void setCheckUltimosMovTC() {
		this.util.getDriver().findElement(checkUltimosMovTC).click();
	}
	
	public void setBtnConsultarTC() {
		this.util.getDriver().findElement(btnConsultarTC).click();
	}
	
	public By getTblMovimientosTC() {
		return tblMovimientosTC;
	}
	
	public void setBtnRegresarTC() {
		this.util.getDriver().findElement(btnRegresarTC).click();
	}
	
	public void setBtnExportarTC() {
		this.util.getDriver().findElement(btnExportarTC).click();
	}
	
	public void setBtnImpresionIntTC() {
		this.util.getDriver().findElement(btnImpresionIntTC).click();
	}
	
	public void setBtnSolicitarArchivoTC() {
		this.util.getDriver().findElement(btnSolicitarArchivoTC).click();
	}
}