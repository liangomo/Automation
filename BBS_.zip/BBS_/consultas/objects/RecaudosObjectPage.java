package consultas.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class RecaudosObjectPage {
	Utilitarios util;
	
	private By lblAlerta = By.xpath("/html/body/form/p[2]");
	
	private By selectGrupo = By.name("DATA1");
	private By selectCuenta = By.name("DATA2");
	private By selectTipoRecaudo = By.name("DATA3");
	private By txtReferencia1 = By.name("DATA8");
	private By txtValorTransaccion = By.name("DATA7");
	private By btnConsultar = By.name("button3");
	
	private By tblRecaudos = By.xpath("/html/body/form/table[4]");
	private By tblRecaudos2 = By.xpath("/html/body/form/div/center/table/tbody/tr/td/div/center/table");
	
	private By selectTipoArchivo = By.name("DATA10");
	private By btnExportar = By.xpath("/html/body/form/center/table/tbody/tr[2]/td[3]/button");
	private By btnImpresionInt = By.xpath("/html/body/form/center/table/tbody/tr[3]/td[2]/button");
	private By btnSolicitudArch = By.name("DATA11");
	private By btnSolicitarArch = By.name("button1");
	
	
	public RecaudosObjectPage(Utilitarios util){
		this.util = util;
	}


	public By getLblAlerta() {
		return lblAlerta;
	}


	public void setLblAlerta(By lblAlerta) {
		this.lblAlerta = lblAlerta;
	}


	public By getSelectGrupo() {
		return selectGrupo;
	}


	public void setSelectGrupo(By selectGrupo) {
		this.selectGrupo = selectGrupo;
	}


	public By getSelectCuenta() {
		return selectCuenta;
	}


	public void setSelectCuenta(By selectCuenta) {
		this.selectCuenta = selectCuenta;
	}


	public By getSelectTipoRecaudo() {
		return selectTipoRecaudo;
	}


	public void setSelectTipoRecaudo(By selectTipoRecaudo) {
		this.selectTipoRecaudo = selectTipoRecaudo;
	}


	public By getTxtReferencia1() {
		return txtReferencia1;
	}


	public void setTxtReferencia1(By txtReferencia1) {
		this.txtReferencia1 = txtReferencia1;
	}


	public By getTxtValorTransaccion() {
		return txtValorTransaccion;
	}


	public void setTxtValorTransaccion(By txtValorTransaccion) {
		this.txtValorTransaccion = txtValorTransaccion;
	}


	public By getBtnConsultar() {
		return btnConsultar;
	}


	public void setBtnConsultar(By btnConsultar) {
		this.btnConsultar = btnConsultar;
	}


	public By getTblRecaudos() {
		return tblRecaudos;
	}


	public void setTblRecaudos(By tblRecaudos) {
		this.tblRecaudos = tblRecaudos;
	}


	public By getTblRecaudos2() {
		return tblRecaudos2;
	}


	public void setTblRecaudos2(By tblRecaudos2) {
		this.tblRecaudos2 = tblRecaudos2;
	}


	public By getSelectTipoArchivo() {
		return selectTipoArchivo;
	}


	public void setSelectTipoArchivo(By selectTipoArchivo) {
		this.selectTipoArchivo = selectTipoArchivo;
	}


	public By getBtnExportar() {
		return btnExportar;
	}


	public void setBtnExportar(By btnExportar) {
		this.btnExportar = btnExportar;
	}


	public By getBtnImpresionInt() {
		return btnImpresionInt;
	}


	public void setBtnImpresionInt(By btnImpresionInt) {
		this.btnImpresionInt = btnImpresionInt;
	}


	public By getBtnSolicitudArch() {
		return btnSolicitudArch;
	}


	public void setBtnSolicitudArch(By btnSolicitudArch) {
		this.btnSolicitudArch = btnSolicitudArch;
	}


	public By getBtnSolicitarArch() {
		return btnSolicitarArch;
	}


	public void setBtnSolicitarArch(By btnSolicitarArch) {
		this.btnSolicitarArch = btnSolicitarArch;
	}
}