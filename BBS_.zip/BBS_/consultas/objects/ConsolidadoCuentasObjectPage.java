package consultas.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class ConsolidadoCuentasObjectPage {	
	Utilitarios util;

	By lblConsolidado = By.xpath("/html/body/form/table[1]/tbody/tr[1]/td[1]/font/b/font");
	By lblEmpresa = By.xpath("/html/body/form/table[1]/tbody/tr[3]/td[1]/font/b/font[1]");
	By lblUsuario = By.xpath("/html/body/form/table[1]/tbody/tr[4]/td[1]/font/b/font[2]");
	By selectGrupo = By.name("DATA1");
	By selectOtrosProductos = By.name("DATA2");
	By selectFecha = By.name("DATA3");
	By btnExportar = By.xpath("/html/body/form/p[4]/table/tbody/tr/td[2]/button");
	By btnRegresar = By.xpath("/html/body/form/p[4]/table/tbody/tr/td[3]/div/button");
	By tableCuentasCte = By.xpath("/html/body/form/table[3]/tbody");
	By tableCuentas = By.xpath("/html/body/form/table[4]/tbody");
	By tableCuentasTQ = By.xpath("/html/body/form/table[5]/tbody");
	By lblErrorTransaccion = By.xpath("/html/body/form/p[2]");
	
	public ConsolidadoCuentasObjectPage(Utilitarios util){
		this.util = util;
	}
	
	public By getTableCuentasCte(){
		return tableCuentasCte;
	}
	
	public By getTableCuentas(){
		return tableCuentas;
	}
	
	public By getTableCuentasTQ(){
		return tableCuentasTQ;
	}
	
	public void clickConsultaCuenta(String xpath){
		this.util.getDriver().findElement(By.xpath(xpath + "/font/b/a")).click();
	}
	
	public String getDatosCuenta(String xpath){
		return this.util.getDriver().findElement(By.xpath(xpath)).getText();
	}
		
	public void clickSelectGrupo(String grupo){
		this.util.getDriver().findElement(selectGrupo).sendKeys(grupo);
	}
	
	public void clickSelectOtrosProductos(String otro){
		this.util.getDriver().findElement(selectOtrosProductos).sendKeys(otro);
	}
	
	public void clickSelectFecha(String fecha){
		this.util.getDriver().findElement(selectFecha).sendKeys(fecha);
	}
	
	public void clickBtnExportar(){
		this.util.getDriver().findElement(btnExportar).click();
	}
	
	public void clickBtnRegresar(){
		this.util.getDriver().findElement(btnRegresar).click();
	}
	
	public By getLblErrorTransaccion(){
		return lblErrorTransaccion;
	}
	
	public String getErrorTransaccion(){
		return this.util.getDriver().findElement(lblErrorTransaccion).getText();
	}
	
	public By getSig(String path){
		return By.xpath("/html/body/form/p[3]/a[" + path + "]");
	}
	
	public String getLblSig(By path){
		return this.util.getDriver().findElement(path).getText();
	}
	
	public void clickLinkSig(By path){
		this.util.getDriver().findElement(path).click();	
	}
}