package consultas.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class MenuConsultasObjectPage {
	Utilitarios util;
	By lnkSaldos = By.name("EWF_BUTTON_T1 Con Cons Neg");
	By lnkExtractos = By.name("EWF_BUTTON_T2 Consulta Extractos");
	By lnkTrasladoSaldos = By.name("EWF_BUTTON_T3-MovimientosTES-1");
	By lnkRecaudosLinea = By.name("EWF_BUTTON_Recaudos Linea");
	By lnkHistoricoRecaudos = By.name("EWF_BUTTON_Historico Recaudos T4");
	By lnkVentasConTarjeta = By.name("EWF_BUTTON_T5A - Depositos Electronicos I");
	By lnkConsultaTransferencias = By.name("EWF_BUTTON_Consulta de Transferencias");
	By lnkDetalleAhorro = By.name("EWF_BUTTON_T1S1 Detalle Ahorros");
	By lnkCuentaCorrienteEspecial = By.name("EWF_BUTTON_Cuenta Corriente Especial");
	By lnkConsultaCupoCredito = By.name("EWF_BUTTON_T1G Con Cons Credito Cupo1");
	
	public MenuConsultasObjectPage(Utilitarios util){
		this.util = util;
	}
	
	public void clickLnkSaldos(){
		this.util.getDriver().findElement(lnkSaldos).click();
	}
	
	public void clickLnkExtractos(){
		this.util.getDriver().findElement(lnkExtractos).click();
	}
	
	public void clickLnkTrasladoSaldos(){
		this.util.getDriver().findElement(lnkTrasladoSaldos).click();
	}
	
	public void clickLnkRecaudosLinea(){
		this.util.getDriver().findElement(lnkRecaudosLinea).click();
	}
	
	public void clickLnkHistoricoRecaudos(){
		this.util.getDriver().findElement(lnkHistoricoRecaudos).click();
	}
	
	public void clickLnkVentasConTarjeta(){
		this.util.getDriver().findElement(lnkVentasConTarjeta).click();
	}
	
	public void clickLnkConsultaTransferencias(){
		this.util.getDriver().findElement(lnkConsultaTransferencias).click();
	}
	
	public void clickLnkDetalleAhorro(){
		this.util.getDriver().findElement(lnkDetalleAhorro).click();
	}
	
	public void clickLnkCuentaCorrienteEspecial(){
		this.util.getDriver().findElement(lnkCuentaCorrienteEspecial).click();
	}
	
	public void clickLnkConsultaCupoCredito(){
		this.util.getDriver().findElement(lnkConsultaCupoCredito).click();
	}
}