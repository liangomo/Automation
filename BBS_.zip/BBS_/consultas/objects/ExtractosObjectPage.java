package consultas.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class ExtractosObjectPage {
	Utilitarios util;
	private By selectGrupo = By.name("DATA1");
	private By selectNegocio = By.name("DATA2");
	private By selectPeriodo = By.name("DATA3");
	private By selectSolicitudArchivo = By.name("DATA25");
	private By btnInformacionPantalla = By.name("Aceptar");
	private By btnSolicitarArchivo = By.name("/html/body/form/table[9]/tbody/tr/td[2]/button");
	private By lblModulo = By.xpath("/html/body/form/table[1]/tbody/tr/td");
	private By lblEmpresa = By.xpath("/html/body/form/table[3]/tbody/tr[1]/td[2]");
	private By lblUsuario = By.xpath("/html/body/form/table[3]/tbody/tr[2]/td[2]");
	private By lblResultado = By.xpath("/html/body/form/p[2]");
	private By selectTipoMovimiento = By.name("DATA7");
	private By checkRangoFecha = By.name("DATA26");
	private By selectDelDia = By.name("DATA9");
	private By selectDelMes = By.name("DATA10");
	private By selectDelAnnio = By.name("DATA11");
	private By selectHastaDia = By.name("DATA12");
	private By selectHastaMes = By.name("DATA13");
	private By selectHastaAnnio = By.name("DATA14");
	private By checkRangoValor = By.name("DATA27");
	private By txtValorDesde = By.name("DATA22");
	private By txtValorHasta = By.name("DATA23");
	private By checkTotales = By.name("DATA24");
	private By btnConsultar = By.name("button1");
	private By tblSaldos = By.xpath("/html/body/form/p[3]/table[10]");
	private By tblMovimientos = By.xpath("/html/body/form/p[3]/table[12]");
	
	private By lblError = By.xpath("/html/body/form/p[3]/table[1]/tbody/tr/td/b/font");
	
	public ExtractosObjectPage(Utilitarios util) {
		this.util = util;
	}

	public void setSelectGrupo(String select) {
		this.util.getDriver().findElement(selectGrupo).sendKeys(select);
	}

	public void setSelectNegocio(String select) {
		this.util.getDriver().findElement(selectNegocio).sendKeys(select);
	}

	public void setSelectPeriodo(String select) {
		this.util.getDriver().findElement(selectPeriodo).sendKeys(select);
	}

	public void setSelectSolicitudArchivo(String select) {
		this.util.getDriver().findElement(selectSolicitudArchivo).sendKeys(select);
	}

	public void setBtnInformacionPantalla() {
		this.util.getDriver().findElement(btnInformacionPantalla).click();
	}

	public void setBtnSolicitarArchivo() {
		this.util.getDriver().findElement(btnSolicitarArchivo).click();
	}

	public String getLblModulo() {
		return this.util.getDriver().findElement(lblModulo).getText();
	}

	public String getLblEmpresa() {
		return this.util.getDriver().findElement(lblEmpresa).getText();
	}

	public String getLblUsuario() {
		return this.util.getDriver().findElement(lblUsuario).getText();
	}

	public String getLblResultado() {
		return this.util.getDriver().findElement(lblResultado).getText();
	}

	public void setSelectTipoMovimiento(String select) {
		this.util.getDriver().findElement(selectTipoMovimiento).sendKeys(select);
	}

	public void setCheckRangoFecha() {
		this.util.getDriver().findElement(checkRangoFecha).click();
	}

	public void setSelectDelDia(String select) {
		this.util.getDriver().findElement(selectDelDia).sendKeys(select);
	}

	public void setSelectDelMes(String select) {
		this.util.getDriver().findElement(selectDelMes).sendKeys(select);
	}

	public void setSelectDelAnnio(String select) {
		this.util.getDriver().findElement(selectDelAnnio).sendKeys(select);
	}

	public void setSelectHastaDia(String select) {
		this.util.getDriver().findElement(selectHastaDia).sendKeys(select);
	}

	public void setSelectHastaMes(String select) {
		this.util.getDriver().findElement(selectHastaMes).sendKeys(select);
	}

	public void setSelectHastaAnnio(String select) {
		this.util.getDriver().findElement(selectHastaAnnio).sendKeys(select);
	}

	public void setCheckRangoValor() {
		this.util.getDriver().findElement(checkRangoValor).click();
	}

	public void setTxtValorDesde(String valor) {
		this.util.getDriver().findElement(txtValorDesde).sendKeys(valor);
	}

	public void setTxtValorHasta(String valor) {
		this.util.getDriver().findElement(txtValorHasta).sendKeys(valor);
	}

	public void setCheckTotales() {
		this.util.getDriver().findElement(checkTotales).click();
	}

	public void setBtnConsultar() {
		this.util.getDriver().findElement(btnConsultar).click();
	}

	public By getTblSaldos() {
		return tblSaldos;
	}

	public By getTblMovimientos() {
		return tblMovimientos;
	}
	
	public By getLblError() {
		return lblError;
	}
}