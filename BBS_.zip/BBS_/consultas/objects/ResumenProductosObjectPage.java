package consultas.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class ResumenProductosObjectPage {
	
	Utilitarios util;
	
	By lblEmpresa = By.xpath("/html/body/form/table[1]/tbody/tr[3]/td[1]/table/tbody/tr/td[2]/font/b/font");
	By lblUsuario = By.xpath("/html/body/form/table[1]/tbody/tr[4]/td[1]/table/tbody/tr/td[2]/font/b/font");
	By selectGrupo = By.name("DATA1");
	By tableProductos = By.xpath("/html/body/form/table[4]");
	
	public ResumenProductosObjectPage(Utilitarios util){
		this.util = util;
	}
	
	public By getLblEmpresa(){
		return lblEmpresa;
	}
	
	public By getLblusuario(){
		return lblUsuario;
	}
	
	public By getTableProductos (){
		return tableProductos;
	}
	
	public void clickSelectGrupo(String grupo){
		System.out.println("Selecciona el grupo a trabajar");
		this.util.getDriver().findElement(selectGrupo).sendKeys(grupo);
	}
	
	public void clickConsultaProducto(String xpath){
		System.out.println("Selecciona Cuenta a consultar");
		this.util.getDriver().findElement(By.xpath("/html/body/form/table[4]/tbody/" + xpath + "/font/b/a")).click();
	}
}