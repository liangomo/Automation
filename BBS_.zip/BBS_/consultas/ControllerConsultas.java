package consultas;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.sql.ResultSet;

import general.ControllerGeneral;
import general.views.FramePage;
import general.views.GroupingPage;
import general.views.IndexPage;
import general.views.LoginPage;

import utilitarios.Datos;
import utilitarios.Utilitarios;
import consultas.views.ConsolidadoCuentasPage;
import consultas.views.ExtractosPage;
import consultas.views.MenuConsultasPage;
import consultas.views.MovimientosCuentaPage;
import consultas.views.ResumenProductosPage;

public class ControllerConsultas {
	Utilitarios util;
	Datos d;
	static MenuConsultasPage menu;
	static ResumenProductosPage resumen;
	static ConsolidadoCuentasPage consolidado;
	static MovimientosCuentaPage movimiento;
	static ControllerGeneral general;
	static ExtractosPage extractos;
	
	public ControllerConsultas(Utilitarios util){
		this.util = util;
		menu = new MenuConsultasPage(this.util);
		resumen = new ResumenProductosPage(this.util);
		consolidado = new ConsolidadoCuentasPage(this.util);
		movimiento = new MovimientosCuentaPage(this.util);
		general = new ControllerGeneral(this.util);
		extractos = new ExtractosPage(util);
	}

	public void consultas(Datos d) throws InterruptedException{
		this.d = d;
		general.ingreso(this.d);
		general.cambioFrame("GROUPING");
		general.modulo(this.d.getNombreModulo());
		general.cambioFrame("DEFAULT");
		general.cambioFrame("MENU");
		this.menu(this.d.getSubModulo());
		Thread.sleep(5000);
	}

	public void menu(String op) throws InterruptedException {
		switch(op){
		case "Saldos":
			menu.Saldos();
			general.cambioFrame("DEFAULT");
			general.cambioFrame("MAIN");
			resumen.ResumenProductos(d);

			if(consolidado.ConsultaCuenta(d))
				movimiento.ConsultaSaldosMov(d);

			if(d.getDescripcionMovimiento().equals("No Aplica")) {
				general.cambioFrame("DEFAULT");
				general.cambioFrame("MENU");
				menu.Saldos();

				general.cambioFrame("DEFAULT");
				general.cambioFrame("MAIN");
				resumen.ResumenProductosDetalle(d);

				if(consolidado.ConsultaCuentaDetalle(d))
					movimiento.ConsultaSaldosDet(d);
			} else 
				movimiento.MovimientosCuenta(d);

			break;
		case "Extractos":
			menu.Extractos();
			general.cambioFrame("DEFAULT");
			general.cambioFrame("MAIN");
			extractos.extractos(d);
			break;
		case "Traslado Electr�nico de Saldos":
			menu.TrasladoSaldos();
			general.cambioFrame("DEFAULT");
			general.cambioFrame("MAIN");
			break;
		case "Recaudos L�nea":
			menu.RecaudosLinea();
			general.cambioFrame("DEFAULT");
			general.cambioFrame("MAIN");
			break;
		case "Hist�rico Recaudos":
			menu.HistoricoRecaudos();
			general.cambioFrame("DEFAULT");
			general.cambioFrame("MAIN");
			break;
		case "Ventas con Tarjetas":
			menu.VentaConTarjeta();
			general.cambioFrame("DEFAULT");
			general.cambioFrame("MAIN");
			break;
		case "Consulta de Transferencias":
			menu.ConsultaTransferencia();
			general.cambioFrame("DEFAULT");
			general.cambioFrame("MAIN");
			break;
		case "Detalle Ahorros":
			menu.DetalleAhorro();
			general.cambioFrame("DEFAULT");
			general.cambioFrame("MAIN");
			break;
		case "Cuenta Corriente Especial":
			menu.CuentaCorrienteEspecial();
			general.cambioFrame("DEFAULT");
			general.cambioFrame("MAIN");
			break;
		case "Consulta Cupo Credito":
			menu.ConsultaCupoCredito();
			general.cambioFrame("DEFAULT");
			general.cambioFrame("MAIN");
			break;
		}
	}
}