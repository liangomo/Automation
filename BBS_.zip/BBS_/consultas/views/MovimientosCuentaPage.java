package consultas.views;

import org.openqa.selenium.JavascriptExecutor;

import consultas.objects.MovimientosCuentaObjectPage;
import consultas.objects.ResumenProductosObjectPage;
import utilitarios.Datos;
import utilitarios.Utilitarios;

public class MovimientosCuentaPage {
	Utilitarios util;
	MovimientosCuentaObjectPage movimiento;

	public MovimientosCuentaPage(Utilitarios util){
		this.util = util;
		movimiento = new MovimientosCuentaObjectPage(util); 
	}

	public void ConsultaSaldosMov(Datos d){
		if(d.getNombreProducto().equals("Cuenta Corriente") || d.getNombreProducto().equals("Cuenta de Ahorros")){
			d.setSaldoDisponibleMOV(movimiento.getLblSaldoDisponibleCtas());
			d.setSaldoCanjeMOV(movimiento.getLblSaldoCanjeCtas());
			d.setSaldoTotalMOV(movimiento.getLblSaldoTotalCtas());
		} else if(d.getNombreProducto().equals("Tarjeta de Credito")){
			d.setCupoTotalMOV(movimiento.getLblCupoTotalTC());
			d.setCupoDisponibleMOV(movimiento.getLblCupoComprasTC());
			d.setCupoAvancesTCMOV(movimiento.getLblCupoAvancesTC());
			d.setSaldoTotalTCMOV(movimiento.getLblSaldoTotalTC());
			d.setValorMinimoTCMOV(movimiento.getLblValorMinimoTC());
			d.setFechaProximoPagoTCMOV(movimiento.getLblFechaProximoPagoTC());
		} else if(d.getNombreProducto().equals("Credito Rotativo")) {
			d.setCupoTotalMOV(movimiento.getLblCupoTotalRot());
			d.setCupoUtilizadoMOV(movimiento.getLblCupoUtilizadoRot());
			d.setValorCanjeMOV(movimiento.getLblValorCanjeRot());
			d.setCupoDisponibleMOV(movimiento.getLblCupoDisponibleRot());
			d.setOtrosGastosMOV(movimiento.getLblOtrosGastosRot());
			d.setPagoTotalMOV(movimiento.getLblPagoTotalRot());
			d.setInteresesCorrientesMOV(movimiento.getLblInteresesCorrientesRot());
			d.setInteresesdeMoraMOV(movimiento.getLblInteresesdeMoraRot());
			d.setValorFacturadoMOV(movimiento.getLblValorFacturadoRot());
			d.setFechaLimitePagoMOV(movimiento.getLblFechaLimitePagoRot());
			d.setSaldoCapitalFactPendienteMOV(movimiento.getLblSaldoCapitalFactPendienteRot());
			d.setSaldoInteresCorrienteFactPendienteMOV(movimiento.getLblSaldoInteresCorrienteFactPendienteRot());
			d.setSaldoInteresMoraFactPendienteMOV(movimiento.getLblSaldoInteresMoraFactPendienteRot());
		}
		this.util.getCapturaImagen(d.getCasoPrueba() + "_ConsolidadoCuentas_" + d.getNavegador());
	}

	public void ConsultaSaldosDet(Datos d){
		if(d.getNombreProducto().equals("Cuenta Corriente") || d.getNombreProducto().equals("Cuenta de Ahorros")){
			d.setSaldoDisponibleMOVDET(movimiento.getLblSaldoDisponibleCtas());
			d.setSaldoCanjeMOVDET(movimiento.getLblSaldoCanjeCtas());
			d.setSaldoTotalMOVDET(movimiento.getLblSaldoTotalCtas());
		} else if(d.getNombreProducto().equals("Tarjeta de Credito")){
			d.setCupoTotalMOVDET(movimiento.getLblCupoTotalTC());
			d.setCupoDisponibleMOVDET(movimiento.getLblCupoTotalTC());
			d.setCupoAvancesTCMOVDET(movimiento.getLblCupoAvancesTC());
			d.setSaldoTotalTCMOVDET(movimiento.getLblSaldoTotalTC());
			d.setValorMinimoTCMOVDET(movimiento.getLblValorMinimoTC());
			d.setFechaProximoPagoTCMOVDET(movimiento.getLblFechaProximoPagoTC());
		} else if(d.getNombreProducto().equals("Credito Rotativo")) {
			d.setCupoTotalMOVDET(movimiento.getLblCupoTotalRot());
			d.setCupoUtilizadoMOVDET(movimiento.getLblCupoUtilizadoRot());
			d.setValorCanjeMOVDET(movimiento.getLblValorCanjeRot());
			d.setCupoDisponibleMOVDET(movimiento.getLblCupoDisponibleRot());
			d.setOtrosGastosMOVDET(movimiento.getLblOtrosGastosRot());
			d.setPagoTotalMOVDET(movimiento.getLblPagoTotalRot());
			d.setInteresesCorrientesMOV(movimiento.getLblInteresesCorrientesRot());
			d.setInteresesdeMoraMOVDET(movimiento.getLblInteresesdeMoraRot());
			d.setValorFacturadoMOVDET(movimiento.getLblValorFacturadoRot());
			d.setFechaLimitePagoMOVDET(movimiento.getLblFechaLimitePagoRot());
			d.setSaldoCapitalFactPendienteMOVDET(movimiento.getLblSaldoCapitalFactPendienteRot());
			d.setSaldoInteresCorrienteFactPendienteMOVDET(movimiento.getLblSaldoInteresCorrienteFactPendienteRot());
			d.setSaldoInteresMoraFactPendienteMOVDET(movimiento.getLblSaldoInteresMoraFactPendienteRot());
		}
		this.util.getCapturaImagen(d.getCasoPrueba() + "_ConsolidadoCuentas_" + d.getNavegador());
	}

	public void MovimientosCuenta(Datos d) throws InterruptedException {
		movimiento.setSelectTipoMovimientoCtas(d.getDescripcionMovimiento());
		
		switch(d.getTipoMov()) {
		case "Rango de Fechas":
			movimiento.setCheckRangoFechasCtas();
			movimiento.setSelectDiaDesdeCtas("1");
			movimiento.setSelectMesDesdeCtas("Mayo");
			movimiento.setSelectDiaHastaCtas("5");
			movimiento.setSelectMesHastaCtas("Mayo");			
			break;
		case "Ultimos Movimientos":
			movimiento.setCheckUltimosMovimientoCtas();
			movimiento.setCheckUltimosMovimientoCtas();
			movimiento.setTxtCtdMovimientosCtas("10");
			break;
		case "Rango de Valor":
			movimiento.setCheckUltimosMovimientoCtas();
			movimiento.setCheckRangoValorCtas();
			movimiento.setTxtValorDesdeCtas("500000");
			movimiento.setTxtValorHastaCtas("10000000");
			break;
		case "Totales d�bitos/cr�ditos":
			movimiento.setCheckTotalDebCrCtas();
			break;
		}
		movimiento.setBtnConsultarCtas();
		Thread.sleep(10000);
		d.setResultadoObtenido(this.util.getRecorrerTabla(movimiento.getTblMovimientosCtas(), "ALL"));
		this.util.scrollDown();
		this.util.getCapturaImagen(d.getCasoPrueba() + "_MovimientosCuenta_" + d.getNavegador());
	}
	
	public void validacion(Datos d){
		if(d.getSaldoDisponibleMOV().equals(d.getSaldoDisponibleMOVDET()) && d.getSaldoCanjeMOV().equals(d.getSaldoCanjeMOVDET()) && d.getSaldoTotalMOV().equals(d.getSaldoTotalMOVDET()) &&
				d.getDiasEnSobregiroMOV().equals(d.getDiasEnSobregiroMOVDET()) && d.getFechaCorteMOV().equals(d.getFechaCorteMOVDET()) && d.getMovimientosMOV().equals(d.getMovimientosMOVDET()) &&
				d.getCupoTotalMOV().equals(d.getCupoTotalMOVDET()) && d.getCupoUtilizadoMOV().equals(d.getCupoUtilizadoMOVDET()) && d.getValorCanjeMOV().equals(d.getValorCanjeMOVDET()) &&
				d.getCupoDisponibleMOV().equals(d.getCupoDisponibleMOVDET()) && d.getOtrosGastosMOV().equals(d.getOtrosGastosMOVDET()) && d.getPagoTotalMOV().equals(d.getPagoTotalMOVDET()) &&
				d.getInteresesCorrientesMOV().equals(d.getInteresesCorrientesMOVDET()) && d.getInteresesdeMoraMOV().equals(d.getInteresesdeMoraMOVDET()) &&
				d.getValorFacturadoMOV().equals(d.getValorFacturadoMOVDET()) && d.getFechaLimitePagoMOV().equals(d.getFechaLimitePagoMOVDET()) &&
				d.getSaldoCapitalFactPendienteMOV().equals(d.getSaldoCapitalFactPendienteMOVDET()) && d.getSaldoInteresCorrienteFactPendienteMOV().equals(d.getSaldoInteresCorrienteFactPendienteMOVDET()) &&
				d.getSaldoInteresMoraFactPendienteMOV().equals(d.getSaldoInteresMoraFactPendienteMOVDET()) && d.getMovimientosRotMOV().equals(d.getMovimientosRotMOVDET()) &&
				d.getCupoTotalTCMOV().equals(d.getCupoTotalTCMOVDET()) && d.getCupoComprasTCMOV().equals(d.getCupoComprasTCMOVDET()) &&
				d.getCupoAvancesTCMOV().equals(d.getCupoAvancesTCMOVDET()) && d.getSaldoTotalTCMOV().equals(d.getSaldoTotalTCMOVDET()) &&
				d.getValorMinimoTCMOV().equals(d.getValorMinimoTCMOVDET()) &&d.getFechaProximoPagoTCMOV().equals(d.getFechaProximoPagoTCMOVDET()) && d.getResultadoObtenido().equals("Datos Coincidentes Entre Pantallas")) {
			d.setResultadoObtenido("Datos Coincidentes Entre Pantallas");
		}
		else
			d.setResultadoObtenido("Datos No Coinciden Entre Pantallas");
	}
}