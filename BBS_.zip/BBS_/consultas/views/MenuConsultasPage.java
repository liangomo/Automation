package consultas.views;

import general.objects.GroupingObjectPage;

import consultas.objects.MenuConsultasObjectPage;
import utilitarios.Utilitarios;

public class MenuConsultasPage {
	Utilitarios util;
	MenuConsultasObjectPage menu;
	
	public MenuConsultasPage(Utilitarios util){
		this.util = util;
		menu = new MenuConsultasObjectPage(util); 
	}
	
	public void ConsultaCupoCredito() throws InterruptedException{
		menu.clickLnkConsultaCupoCredito();
		Thread.sleep(2500);
	}
	
	public void ConsultaTransferencia()throws InterruptedException{
		menu.clickLnkConsultaTransferencias();
		Thread.sleep(2500);
	}
	
	public void CuentaCorrienteEspecial()throws InterruptedException{
		menu.clickLnkCuentaCorrienteEspecial();
		Thread.sleep(2500);
	}
	
	public void DetalleAhorro()throws InterruptedException{
		menu.clickLnkDetalleAhorro();
		Thread.sleep(2500);
	}
	
	public void Extractos()throws InterruptedException{
		menu.clickLnkExtractos();
		Thread.sleep(2500);
	}
	
	public void HistoricoRecaudos()throws InterruptedException{
		menu.clickLnkHistoricoRecaudos();
		Thread.sleep(2500);
	}
	
	public void RecaudosLinea()throws InterruptedException{
		menu.clickLnkRecaudosLinea();
		Thread.sleep(2500);
	}
	
	public void Saldos()throws InterruptedException{
		menu.clickLnkSaldos();
		Thread.sleep(2500);
	}
	
	public void TrasladoSaldos()throws InterruptedException{
		menu.clickLnkTrasladoSaldos();
		Thread.sleep(2500);
	}
	
	public void VentaConTarjeta()throws InterruptedException{
		menu.clickLnkVentasConTarjeta();
		Thread.sleep(2500);
	}
}