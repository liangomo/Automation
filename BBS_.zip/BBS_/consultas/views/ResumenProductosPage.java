package consultas.views;

import general.objects.GroupingObjectPage;

import consultas.objects.ResumenProductosObjectPage;
import utilitarios.Datos;
import utilitarios.Utilitarios;

public class ResumenProductosPage {
	Utilitarios util;
	ResumenProductosObjectPage resumen;
	
	public ResumenProductosPage(Utilitarios util){
		this.util = util;
		resumen = new ResumenProductosObjectPage(util); 
	}
	
	public void ResumenProductos(Datos d) throws InterruptedException{
		String path = this.util.getRecorrerTabla(resumen.getTableProductos(), d.getNombreProducto());
		this.util.getCapturaImagen(d.getCasoPrueba() + "_ResumenProductos_" + d.getNavegador());
		
		resumen.clickConsultaProducto(path);
		if(d.getNombreProducto().equals("Tarjeta de Credito"))
			Thread.sleep(400000);
		else
			Thread.sleep(10000);
	}
	
	public void ResumenProductosDetalle(Datos d) throws InterruptedException{
		String path = this.util.getRecorrerTabla(resumen.getTableProductos(),  d.getNombreProducto());
		path = path.replace("td[1]", "td[2]");
		this.util.getCapturaImagen(d.getCasoPrueba() + "_ResumenProductos_" + d.getNavegador());
		resumen.clickConsultaProducto(path);
		Thread.sleep(40000);
	}
}