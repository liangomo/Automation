package consultas.views;

import general.objects.LoginObjectPage;

import org.openqa.selenium.By;

import consultas.objects.ConsolidadoCuentasObjectPage;
import consultas.objects.ResumenProductosObjectPage;
import sun.util.BuddhistCalendar;
import utilitarios.Datos;
import utilitarios.Utilitarios;

public class ConsolidadoCuentasPage {
	Utilitarios util;
	ConsolidadoCuentasObjectPage consolidado;

	public ConsolidadoCuentasPage(Utilitarios util){
		this.util = util;
		consolidado = new ConsolidadoCuentasObjectPage(util); 
	}

	public boolean ConsultaCuenta(Datos d) throws InterruptedException{
		String path, th;
		boolean retorno = false;
		String cuenta = null;

		if(d.getNombreProducto().equals("Cuenta Corriente") || d.getNombreProducto().equals("Cuenta de Ahorros") || d.getNombreProducto().equals("TESORERIA QUINCE"))
			cuenta = d.getNroProducto().substring(0, 3) + "-" + d.getNroProducto().substring(3, d.getNroProducto().length() - 1) + "-" + d.getNroProducto().substring(d.getNroProducto().length() - 1);
		else if(d.getNombreProducto().equals("Tarjeta de Credito"))
			cuenta = d.getNroProducto().substring(0, 5) + "******" + d.getNroProducto().substring(d.getNroProducto().length()-5,d.getNroProducto().length() - 1);
		else if(d.getNombreProducto().equals("CDT") || d.getNombreProducto().equals("Credito M/L") || d.getNombreProducto().equals("Credito M/E"))
			cuenta = d.getNroProducto().substring(0, d.getNroProducto().length() - 1) + "-" + d.getNroProducto().substring(d.getNroProducto().length() - 1);

		String[] prueba = util.getDriver().findElement(By.xpath("/html/body/form/p[3]")).getText().split(" ");
		
		int cantidad = Integer.parseInt(prueba[prueba.length - 1]) + 1;

		if(cantidad == 2)
			cantidad = 1;

		int i = 1;

		while(i <= cantidad){
			if(d.getNombreProducto().equals("Cuenta Corriente"))	{
				path = this.util.getRecorrerTabla(consolidado.getTableCuentasCte(), cuenta);
				th = "/html/body/form/table[3]/tbody/";
			} else if(d.getNombreProducto().equals("TESORERIA QUINCE")){
				path = this.util.getRecorrerTabla(consolidado.getTableCuentasTQ(), cuenta);
				th = "/html/body/form/table[5]/tbody/";
			} else{
				path = this.util.getRecorrerTabla(consolidado.getTableCuentas(), cuenta);
				th = "/html/body/form/table[4]/tbody/";
			}

			if(!path.equals("No Encontrado")){
				String fila = path.split("/")[0].replaceAll("tr\\[", "");

				fila = fila.replaceAll("\\]", "");

				if(d.getNombreProducto().equals("Cuenta Corriente") || d.getNombreProducto().equals("Cuenta de Ahorros")){
					d.setEstado(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNombreCuenta(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setNroCuenta(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setSaldoDisponible(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setSaldoenCanje(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					d.setSaldoTotal(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[6]"));

					consolidado.clickConsultaCuenta(th + "tr[" + fila + "]/td[2]");	
					retorno = true;
				}else if(d.getNombreProducto().equals("TESORERIA QUINCE")){
					d.setNroObligacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroObligacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setCupoDisponible(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setCupoTotal(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setCupoUtilizado(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
				} else if(d.getNombreProducto().equals("CDT")){
					d.setNombreCDT(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroCDT(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setFechaVto(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setValor(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setTasaNominal(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					d.setValorRetenido(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[6]"));
					d.setInteresPagado(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[7]"));
				} else if(d.getNombreProducto().equals("Credito M/L")){
					d.setNombreObligacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroObligacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setValorObligacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setFechaInicialCre(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setTasaNominal(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					d.setSaldoCapital(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[6]"));
					d.setSaldoInteresNominal(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[7]"));
					d.setOficinaRadicacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[8]"));
					d.setFechaFinalCredito(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[9]"));
					d.setTasaInteresMora(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[10]"));
					d.setValoraPagar(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[11]"));
				} else if(d.getNombreProducto().equals("Tarjeta de Credito")){
					d.setNombreTC(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroTC(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setSaldoActual(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setValorMinimo(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setFechaPago(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));

					consolidado.clickConsultaCuenta(th + "tr[" + fila + "]/td[1]");	
					retorno = true;
					Thread.sleep(300000);
				} else if(d.getNombreProducto().equals("Credito M/E")) {
					d.setNombreObligacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroObligacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setValorObligacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setFechaInicialCre(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setTasaNominal(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					d.setSaldoCapital(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[6]"));
					d.setSaldoInteresNominal(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[7]"));
					d.setOficinaRadicacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[8]"));
					d.setFechaFinalCredito(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[9]"));
					d.setTasaInteresMora(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[10]"));

				} else if(d.getNombreProducto().equals("Credito Rotativo")) {
					d.setNombreObligacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroObligacion(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setCupoTotal(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setValorenCanje(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setCupoDisponible(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					d.setInteresesCorrientes(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[6]"));
					d.setInteresesMora(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[7]"));
					d.setCupoUtilizado(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[8]"));
					d.setOtrosGastos(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[9]"));
					d.setPagoTotal(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[10]"));

					util.getDriver().findElement(By.xpath("/html/body/form/table[4]/tbody/tr[" + fila +"]/td[1]/font/a")).click();
					retorno = true;
				} else {
					System.out.println("PRODUCTO NO EXISTE");
				}
				i = cantidad;
			}
			else{
				if(i < cantidad){
					consolidado.clickLinkSig(consolidado.getSig("" + cantidad));
					Thread.sleep(30000);
				}else if(cantidad == i && cantidad > 1){
					if(util.buscarObjeto(consolidado.getLblErrorTransaccion()))
						System.out.println(consolidado.getErrorTransaccion());
					else
						System.out.println("Cuenta no Encontrada");
				}		
			}
			i++;
		}
		return retorno;
	}

	public boolean ConsultaCuentaDetalle(Datos d) throws InterruptedException{
		String path, th;
		boolean retorno = false;
		String cuenta = null;

		System.out.println("Busqueda de " + d.getNombreProducto() + " Nro " + d.getNroProducto() + "");
		if(d.getNombreProducto().equals("Cuenta Corriente") || d.getNombreProducto().equals("Cuenta de Ahorros") || d.getNombreProducto().equals("TESORERIA QUINCE"))
			cuenta = d.getNroProducto().substring(0, 3) + "-" + d.getNroProducto().substring(3, d.getNroProducto().length() - 1) + "-" + d.getNroProducto().substring(d.getNroProducto().length() - 1);
		else if(d.getNombreProducto().equals("Tarjeta de Credito"))
			cuenta = d.getNroProducto().substring(0, 5) + "******" + d.getNroProducto().substring(d.getNroProducto().length()-5,d.getNroProducto().length() - 1);
		else if(d.getNombreProducto().equals("CDT") || d.getNombreProducto().equals("Credito M/L") || d.getNombreProducto().equals("Credito M/E"))
			cuenta = d.getNroProducto().substring(0, d.getNroProducto().length() - 1) + "-" + d.getNroProducto().substring(d.getNroProducto().length() - 1);

		String[] prueba = util.getDriver().findElement(By.xpath("/html/body/form/p[3]")).getText().split(" ");

		int cantidad = Integer.parseInt(prueba[prueba.length - 1]) + 1;

		if(cantidad == 2)
			cantidad = 1;

		int i = 1;

		while(i <= cantidad){
			if(d.getNombreProducto().equals("Cuenta Corriente"))	{
				path = this.util.getRecorrerTabla(consolidado.getTableCuentasCte(), cuenta);
				th = "/html/body/form/table[3]/tbody/";
			} else if(d.getNombreProducto().equals("TESORERIA QUINCE")){
				path = this.util.getRecorrerTabla(consolidado.getTableCuentasTQ(), cuenta);
				th = "/html/body/form/table[5]/tbody/";
			} else{
				path = this.util.getRecorrerTabla(consolidado.getTableCuentas(), cuenta);
				th = "/html/body/form/table[4]/tbody/";
			}

			if(!path.equals("No Encontrado")){
				String fila = path.split("/")[0].replaceAll("tr\\[", "");

				fila = fila.replaceAll("\\]", "");

				if(d.getNombreProducto().equals("Cuenta Corriente") || d.getNombreProducto().equals("Cuenta de Ahorros")){
					d.setEstadoDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNombreCuentaDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setNroCuentaDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setSaldoDisponibleDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setSaldoenCanjeDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					d.setSaldoTotalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[6]"));
					this.util.getCapturaImagen(d.getCasoPrueba() + "_ConsolidadoCuentas_" + d.getNavegador());
					consolidado.clickConsultaCuenta(th + "tr[" + fila + "]/td[2]");	
					retorno = true;
				}else if(d.getNombreProducto().equals("TESORERIA QUINCE")){
					d.setNroObligacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroObligacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setCupoDisponibleDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setCupoTotalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setCupoUtilizadoDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					this.util.getCapturaImagen(d.getCasoPrueba() + "_ConsolidadoCuentas_" + d.getNavegador());
				} else if(d.getNombreProducto().equals("CDT")){
					d.setNombreCDTDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroCDTDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setFechaVtoDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setValorDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setTasaNominalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					d.setValorRetenidoDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[6]"));
					d.setInteresPagadoDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[7]"));
					this.util.getCapturaImagen(d.getCasoPrueba() + "_ConsolidadoCuentas_" + d.getNavegador());
				} else if(d.getNombreProducto().equals("Credito M/L")){
					d.setNombreObligacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroObligacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setValorObligacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setFechaInicialCreDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setTasaNominalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					d.setSaldoCapitalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[6]"));
					d.setSaldoInteresNominalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[7]"));
					d.setOficinaRadicacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[8]"));
					d.setFechaFinalCreditoDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[9]"));
					d.setTasaInteresMoraDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[10]"));
					d.setValoraPagarDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[11]"));
					this.util.getCapturaImagen(d.getCasoPrueba() + "_ConsolidadoCuentas_" + d.getNavegador());
				} else if(d.getNombreProducto().equals("Tarjeta de Credito")){
					d.setNombreTCDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroTCDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setSaldoActualDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setValorMinimoDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setFechaPagoDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					this.util.getCapturaImagen(d.getCasoPrueba() + "_ConsolidadoCuentas_" + d.getNavegador());

					consolidado.clickConsultaCuenta(th + "tr[" + fila + "]/td[1]");	
					retorno = true;
					Thread.sleep(300000);
				} else if(d.getNombreProducto().equals("Credito M/E")) {
					d.setNombreObligacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroObligacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setValorObligacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setFechaInicialCreDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setTasaNominalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					d.setSaldoCapitalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[6]"));
					d.setSaldoInteresNominalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[7]"));
					d.setOficinaRadicacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[8]"));
					d.setFechaFinalCreditoDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[9]"));
					d.setTasaInteresMoraDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[10]"));
					this.util.getCapturaImagen(d.getCasoPrueba() + "_ConsolidadoCuentas_" + d.getNavegador());

				} else if(d.getNombreProducto().equals("Credito Rotativo")) {
					d.setNombreObligacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[1]"));
					d.setNroObligacionDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[2]"));
					d.setCupoTotalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[3]"));
					d.setValorenCanjeDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[4]"));
					d.setCupoDisponibleDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[5]"));
					d.setInteresesCorrientesDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[6]"));
					d.setInteresesMoraDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[7]"));
					d.setCupoUtilizadoDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[8]"));
					d.setOtrosGastosDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[9]"));
					d.setPagoTotalDet(consolidado.getDatosCuenta(th + "tr[" + fila + "]/td[10]"));
					this.util.getCapturaImagen(d.getCasoPrueba() + "_ConsolidadoCuentas_" + d.getNavegador());

					util.getDriver().findElement(By.xpath("/html/body/form/table[4]/tbody/tr[" + fila +"]/td[1]/font/a")).click();
					retorno = true;
				} else {
					System.out.println("PRODUCTO NO EXISTE");
				}
				i = cantidad;
			}
			else{
				if(i < cantidad){
					consolidado.clickLinkSig(consolidado.getSig("" + cantidad));
					Thread.sleep(30000);
				}else if(cantidad == i && cantidad > 1){
					if(util.buscarObjeto(consolidado.getLblErrorTransaccion()))
						System.out.println(consolidado.getErrorTransaccion());
					else
						System.out.println("Cuenta no Encontrada");
				}		
			}
			i++;
		}
		validacion(d);
		return retorno;
	}

	public void validacion(Datos d) {
		if(d.getEstado().equals(d.getEstadoDet()) && d.getNombreCuenta().equals(d.getNombreCuentaDet()) && d.getNroCuenta().equals(d.getNroCuentaDet()) &&
				d.getSaldoDisponible().equals(d.getSaldoDisponibleDet()) && d.getSaldoenCanje().equals(d.getSaldoenCanjeDet()) && d.getSaldoTotal().equals(d.getSaldoTotalDet()) &&
				d.getNombreObligacion().equals(d.getNombreObligacionDet()) && d.getNroObligacion().equals(d.getNroObligacionDet()) && d.getCupoDisponible().equals(d.getCupoDisponibleDet()) &&
				d.getCupoTotal().equals(d.getCupoTotalDet()) && d.getCupoUtilizado().equals(d.getCupoUtilizadoDet()) && d.getNombreCDT().equals(d.getNombreCDTDet()) &&
				d.getNroCDT().equals(d.getNroCDTDet()) && d.getFechaVto().equals(d.getFechaVtoDet()) && d.getValor().equals(d.getValorDet()) &&
				d.getTasaNominal().equals(d.getTasaNominalDet()) && d.getValorRetenido().equals(d.getValorRetenidoDet()) && d.getInteresPagado().equals(d.getInteresPagadoDet()) &&
				d.getValorObligacion().equals(d.getValorObligacionDet()) && d.getFechaInicialCre().equals(d.getFechaInicialCreDet()) &&
				d.getSaldoCapital().equals(d.getSaldoCapitalDet()) && d.getSaldoInteresNominal().equals(d.getSaldoInteresNominalDet()) &&
				d.getOficinaRadicacion().equals(d.getOficinaRadicacionDet()) && d.getFechaFinalCredito().equals(d.getFechaFinalCreditoDet()) &&
				d.getTasaInteresMora().equals(d.getTasaInteresMoraDet()) && d.getValoraPagar().equals(d.getValoraPagarDet()) &&
				d.getNombreTC().equals(d.getNombreTCDet()) && d.getNroTC().equals(d.getNroTCDet()) && d.getSaldoActual().equals(d.getSaldoActualDet()) &&
				d.getValorMinimo().equals(d.getValorMinimoDet()) && d.getFechaPago().equals(d.getFechaPagoDet()) && d.getValorenCanje().equals(d.getValorenCanjeDet()) &&
				d.getInteresesCorrientes().equals(d.getInteresesCorrientesDet()) && d.getInteresesMora().equals(d.getInteresesMoraDet()) && d.getOtrosGastos().equals(d.getOtrosGastosDet()) &&
				d.getPagoTotal().equals(d.getPagoTotalDet())){
			d.setResultadoObtenido("Datos Coincidentes Entre Pantallas");
		}
		else
			d.setResultadoObtenido("Datos No Coinciden Entre Pantallas");
	}
}