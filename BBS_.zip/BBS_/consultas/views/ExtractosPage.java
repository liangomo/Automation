package consultas.views;

import javax.swing.JOptionPane;

import utilitarios.Datos;
import utilitarios.Utilitarios;
import consultas.objects.ExtractosObjectPage;
import consultas.objects.MovimientosCuentaObjectPage;

public class ExtractosPage {
	Utilitarios util;
	ExtractosObjectPage extractos;

	public ExtractosPage(Utilitarios util){
		this.util = util;
		extractos = new ExtractosObjectPage(util); 
	}

	public void extractos(Datos d) throws InterruptedException {
		extractos.setSelectGrupo(d.getGrupo());

		extractos.setSelectNegocio(util.generarNegocio(d));
		Thread.sleep(5000);

		extractos.setSelectPeriodo("Febrero");

		System.out.println(d.getGrupo() + " - " + util.generarNegocio(d) + " - " + util.ObtenerMesExtracto());

		switch (d.getDescripcionMovimiento()) { 
		case "Tipo de Archivo":
			this.solicitarArchivo(d);
			break;
		default:
			this.informacionPantalla(d);
			break;
		}
	}


	public void solicitarArchivo(Datos d) {

	}

	public void informacionPantalla(Datos d) throws InterruptedException {
		extractos.setBtnInformacionPantalla();
		Thread.sleep(5000);

		extractos.setSelectTipoMovimiento(d.getDescripcionMovimiento());

		switch (d.getTipoMov()) {
		case "Rango Fecha":
			extractos.setCheckRangoFecha();
			extractos.setSelectDelDia("1");
			extractos.setSelectDelMes("Febrero");
			extractos.setSelectDelAnnio("2017");
			extractos.setSelectHastaDia("28");
			extractos.setSelectHastaMes("Febrero");
			extractos.setSelectHastaAnnio("2017");
			break;
		case "Rango Valor":
			extractos.setCheckRangoValor();
			extractos.setTxtValorDesde("1000000");
			extractos.setTxtValorHasta("99999999");
			break;
		case "Totales Deb/Cre":
			extractos.setCheckTotales();
			break;
		}

		extractos.setBtnConsultar();

		Thread.sleep(10000);

		d.setResultadoObtenido(this.util.getRecorrerTabla(extractos.getTblMovimientos(), "ALL"));
		this.util.scrollDown();
	}
}