import general.ControllerGeneral;
import general.views.FramePage;
import general.views.GroupingPage;
import general.views.IndexPage;
import general.views.LoginPage;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import resources.LanzadorHelper;
import utilitarios.Datos;
import utilitarios.Utilitarios;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;

import consultas.ControllerConsultas;
import consultas.views.ConsolidadoCuentasPage;
import consultas.views.MovimientosCuentaPage;
import consultas.views.ResumenProductosPage;

public class Lanzador extends LanzadorHelper {
	Utilitarios util =  new Utilitarios();
	ControllerGeneral general = new ControllerGeneral(util);
	ControllerConsultas consultas = new ControllerConsultas(util);
	File folder0;
	File folder1;
	Document doc;
	Datos d;

	public void testMain(Object[] args) throws DocumentException {
		try {
			/** Creaci�n Carpetas */
			folder0 = new File("C:\\tmp\\BBS");
			folder0.mkdir();

			folder1 = new File("C:\\tmp\\BBS\\Imagenes");
			folder1.mkdir();
			
			ArrayList<Datos> data = util.ejecutar("SELECT C.CasoPrueba, C.DescripcionCaso, M.NombreModulo, C.SubModulo, P.NombreProducto, CU.NroProducto,CU.EstProducto, "
					+ " C.Ejecutar, C.ResultadoEsperado, C.Ejecutado, U.Usuario, MO.DescripcionMovimiento, u.Password, N.Navegador, MO.TipoMov, CU.Grupo"
					+ " FROM BBS.CasosPrueba C, BBS.Usuarios U, BBS.Modulos M, BBS.Cuentas CU, BBS.Navegador N, BBS.Productos P, BBS.Movimientos MO"
					+ " WHERE C.IdUsuario = U.Idusuario  AND M.IdModulo = C.IdModulo AND P.IdProducto = C.IdProducto"
					+ " AND C.IdProducto = CU.IdProducto AND C.EstProducto = CU.EstProducto AND N.Ejecutar = 1 AND C.Ejecutado = 0"
					+ " AND C.Ejecutar = 1 AND C.IdUsuario = CU.IdUsuario AND C.IdMovimiento = MO.IdMovimiento ORDER BY N.Navegador, C.CasoPrueba");

			String pdf = "INICIO";
			
			boolean band = false;

			for(int i = 0; i < data.size(); i++) {
				if(i > 0)
					util.getDocumento().newPage();
				
				d = data.get(i);

				switch(d.getNombreModulo()) {
				case "CONSULTAS":
					if(!pdf.equals("CONSULTAS")) {
						if(band){
							util.closePDF();
							band = false;
						}
						util.setPDF("Detallado_BBS_" + d.getNombreModulo() + "_" + util.ObtenerMes() +  "_" + util.ObtenerFecha() + "_" + util.ObtenerHora(), d);
						pdf = "CONSULTAS";
						band = true;
					}
					consultas.consultas(d);
					d.setVeredicto();
					util.setTextoPDF("Resultado Obtenido: " + d.getResultadoObtenido());
					util.setTituloPDF("Veredicto: " + d.getVeredicto());
					break;
				case "PAGOS":
					System.out.println("MODULO PAGOS");
					break;
				case "TRANSFERENCIAS":
					System.out.println("MODULO TRANSFERENCIAS");
					break;
				case "SERVICIO AL CLIENTE":
					System.out.println("MODULO SERVICIO AL CLIENTE");
					break;
				case "ADMINISTRACION":
					System.out.println("MODULO ADMINISTRACION");
					break;
				case "MONEDA EXTRANJERA":
					System.out.println("MODULO MONEDA EXTRANJERA");
					break;
				case "GENERAL":
					if(!pdf.equals("GENERAL")){
						if(band){
							util.closePDF();
							band = false;
						}
						util.setPDF("Detallado_BBS_" + d.getNombreModulo() + "_" + util.ObtenerMes() +  "_" + util.ObtenerFecha() + "_" + util.ObtenerHora(), d);
						pdf = "GENERAL";
						band = true;
					}
					d.setResultadoObtenido(general.ingreso(d));
					d.setVeredicto();
					util.setTextoPDF("Resultado Obtenido: " + d.getResultadoObtenido());
					util.setTituloPDF("Veredicto: " + d.getVeredicto());
					break;
				}
				util.getDriver().quit();
				util.insertarSQL("INSERT INTO BBS.ConsolidadoEjecucion VALUES('" + util.ObtenerFecha() + "','" + util.ObtenerHora() + "','" + d.getCasoPrueba() +  "','" + d.getNombreModulo() + " - " + d.getNavegador() + " - " + System.getProperty("os.name").toLowerCase() + "','" + d.getResultadoEsperado() +  "','"  + d.getResultadoObtenido() +  "','" + d.getVeredicto() + "')");
				util.insertarSQL("UPDATE BBS.CasosPrueba SET Ejecutado = 1 WHERE CasoPrueba = '" + d.getCasoPrueba() + "'");
			}
		} catch (Exception e) {
			util.getCapturaImagen(d.getCasoPrueba() + "_ErrorTrx_" + d.getNavegador());
			util.insertarSQL("INSERT INTO BBS.ConsolidadoEjecucion VALUES('" + util.ObtenerFecha() + "','" + util.ObtenerHora() + "','" + d.getCasoPrueba() +  "','" + d.getNombreModulo() + " - " + d.getNavegador()  + " - " + System.getProperty("os.name").toLowerCase() +  "','" + d.getResultadoEsperado() +  "','Caso Incompleto','Caso Incompleto')");
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			e.printStackTrace(new PrintStream(os));		
		}
		finally {
			if(util.getDriver() != null)
				util.getDriver().quit();
			if(util.getDocumento() != null)
				util.closePDF();
			folder1.delete();
		}
	}
}