package pagos.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class MenuPagosObjectPage {
	Utilitarios util;
	
	By lnkPagos = By.name("EWF_BUTTON_T9-Pagos en Linea");
	By lnkPagosVirtuales = By.name("EWF_BUTTON_T9-Pagos Virtuales");
	By lnkConsultaPagosProgramados = By.name("EWF_BUTTON_T9A Consulta Pagos Programados");
	By lnkAdministracionBeneficiarios = By.name("EWF_BUTTON_T9-Admin Beneficiarios");
	By lnkPagoNomina = By.name("EWF_BUTTON_T12 Pago de Nomina");
	By lnkHistoricoNomina = By.name("EWF_BUTTON_Consulta Pago Nomina");
	By lnkActivarRangoCh = By.name("EWF_BUTTON_T17 Activacion Chequeras");
	
	public MenuPagosObjectPage(Utilitarios util){
		this.util = util;
	}
	
	public void clickLnkPagos(){
		this.util.getDriver().findElement(lnkPagos).click();
	}
	
	public void clickLnkPagosVirtuales(){
		this.util.getDriver().findElement(lnkPagosVirtuales).click();
	}
	
	public void clickLnkConsultaPagosProgramados(){
		this.util.getDriver().findElement(lnkConsultaPagosProgramados).click();
	}
	
	public void clickLnkAdministracionBeneficiarios(){
		this.util.getDriver().findElement(lnkAdministracionBeneficiarios).click();
	}
	
	public void clickLnkPagoNomina(){
		this.util.getDriver().findElement(lnkPagoNomina).click();
	}
	
	public void clickLnkHistoricoNomina(){
		this.util.getDriver().findElement(lnkHistoricoNomina).click();
	}
	
	public void clickLnkActivarRangoCh(){
		this.util.getDriver().findElement(lnkActivarRangoCh).click();
	}
}