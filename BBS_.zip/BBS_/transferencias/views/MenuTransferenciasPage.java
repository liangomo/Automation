package transferencias.views;

import transferencias.objects.MenuTransferenciasObjectPages;
import utilitarios.Utilitarios;
import consultas.objects.MenuConsultasObjectPage;

public class MenuTransferenciasPage {
	Utilitarios util;
	MenuTransferenciasObjectPages menu;

	public MenuTransferenciasPage(Utilitarios util){
		this.util = util;
		menu = new MenuTransferenciasObjectPages(util); 
	}

	public void Transferencias() throws InterruptedException{
		menu.setLnkTransferencias();
		Thread.sleep(2500);
	}

	public void ConsultaTransferenciasProgramadas()throws InterruptedException{
		menu.setLnkConsultaTransferenciasProgramadas();
		Thread.sleep(2500);
	}

	public void InscripcionEncargosFiduciarios()throws InterruptedException{
		menu.setLnkInscripcionEncargosFiduciarios();
		Thread.sleep(2500);
	}

	public void TrasladoFondosSebra()throws InterruptedException{
		menu.setLnkTrasladoFondosSebra();
		Thread.sleep(2500);
	}
}