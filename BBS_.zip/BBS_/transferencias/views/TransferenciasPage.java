package transferencias.views;

import transferencias.objects.MenuTransferenciasObjectPages;
import transferencias.objects.TranferenciasObjectPage;
import utilitarios.Utilitarios;

public class TransferenciasPage {
	Utilitarios util;
	TranferenciasObjectPage transfer;

	public TransferenciasPage(Utilitarios util){
		this.util = util;
		transfer = new TranferenciasObjectPage(util); 
	}
	
	public void adicionar() {
		
	}
}