package transferencias.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class MenuTransferenciasObjectPages {
	Utilitarios util;
	private By lnkTransferencias = By.name("EWF_BUTTON_T6-Transferencia fondos-1");
	private By lnkConsultaTransferenciasProgramadas = By.name("EWF_BUTTON_T7- Consulta Transferencias");
	private By lnkInscripcionEncargosFiduciarios = By.name("EWF_BUTTON_Inscripcion Encargos Fiduciarios");
	private By lnkTrasladoFondosSebra = By.name("EWF_BUTTON_T6 SEBRA");
	
	public MenuTransferenciasObjectPages(Utilitarios util){
		this.util = util;
	}

	public void setLnkTransferencias() {
		this.util.getDriver().findElement(lnkTransferencias).click();
	}

	public void setLnkConsultaTransferenciasProgramadas() {
		this.util.getDriver().findElement(lnkConsultaTransferenciasProgramadas).click();
	}

	public void setLnkInscripcionEncargosFiduciarios() {
		this.util.getDriver().findElement(lnkInscripcionEncargosFiduciarios).click();
	}

	public void setLnkTrasladoFondosSebra() {
		this.util.getDriver().findElement(lnkTrasladoFondosSebra).click();
	}
}