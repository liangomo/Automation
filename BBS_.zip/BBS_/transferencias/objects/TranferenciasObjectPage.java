package transferencias.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class TranferenciasObjectPage {
	Utilitarios util;
	private By lblTitulo = By.xpath("/html/body/form/table[1]/tbody/tr/td[1]");
	private By selectGrupo = By.name("DATA5");
	private By selectOrdenarPor = By.name("DATA4");
	private By tblTransferencias = By.xpath("/html/body/form/table[4]");
	private By btnAdicionar = By.xpath("/html/body/form/p[3]/button[1]");
	private By btnModificar = By.xpath("/html/body/form/p[3]/button[2]");
	private By btnEliminar = By.xpath("/html/body/form/p[3]/button[3]");
	private By btnAprobarInscripcion = By.xpath("/html/body/form/p[3]/button[4]");
	
	public TranferenciasObjectPage(Utilitarios util){
		this.util = util;
	}
	
	public By getLblTitulo() {
		return lblTitulo;
	}
	
	public void setSelectGrupo(String select) {
		this.util.getDriver().findElement(selectGrupo).sendKeys(select);
	}
	
	public void setSelectOrdenarPor(String select) {
		this.util.getDriver().findElement(selectOrdenarPor).sendKeys(select);
	}
	
	public By getTblTransferencias() {
		return tblTransferencias;
	}
	
	public void setBtnAdicionar() {
		this.util.getDriver().findElement(btnAdicionar).click();
	}
	
	public void setBtnModificar() {
		this.util.getDriver().findElement(btnModificar).click();
	}
	
	public void setBtnEliminar() {
		this.util.getDriver().findElement(btnEliminar).click();
	}
	
	public void setBtnAprobarInscripcion() {
		this.util.getDriver().findElement(btnAprobarInscripcion).click();
	}
}