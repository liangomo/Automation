package utilitarios;

import java.util.ArrayList;

public class Datos {
	private String grupo;
	private String tipoMov;
	private String casoPrueba;
	private String descripcionCaso; 
	private String nombreModulo;
	private String subModulo;
	private String nombreProducto; 
	private String nroProducto; 
	private String estProducto; 
	private boolean ejecutar;
	private String resultadoEsperado; 
	private String resultadoObtenido;
	private boolean ejecutado; 
	private String usuario; 
	private String password;
	private String navegador;
	private String veredicto;
	private String descripcionMovimiento;
	private String estado = "";
	private String nombreCuenta = "";
	private String nroCuenta = "";
	private String saldoDisponible = "";
	private String saldoenCanje = "";
	private String saldoTotal = "";
	private String nombreObligacion = "";
	private String nroObligacion = "";
	private String cupoDisponible = "";
	private String cupoTotal = "";
	private String cupoUtilizado = "";
	private String nombreCDT = "";
	private String nroCDT = "";
	private String fechaVto = "";
	private String valor = "";
	private String tasaNominal = "";
	private String valorRetenido = "";
	private String interesPagado = "";
	private String valorObligacion = "";
	private String fechaInicialCre = "";
	private String saldoCapital = "";
	private String saldoInteresNominal = "";
	private String oficinaRadicacion = "";
	private String fechaFinalCredito = "";
	private String tasaInteresMora = "";
	private String valoraPagar = "";
	private String nombreTC = "";
	private String nroTC = "";
	private String saldoActual = "";
	private String valorMinimo = "";
	private String FechaPago = "";
	private String valorenCanje = "";
	private String interesesCorrientes = "";
	private String interesesMora = "";
	private String otrosGastos = "";
	private String pagoTotal = "";
	private String estadoDet = "";
	private String nombreCuentaDet = "";
	private String nroCuentaDet = "";
	private String saldoDisponibleDet = "";
	private String saldoenCanjeDet = "";
	private String saldoTotalDet = "";
	private String nombreObligacionDet = "";
	private String nroObligacionDet = "";
	private String cupoDisponibleDet = "";
	private String cupoTotalDet = "";
	private String cupoUtilizadoDet = "";
	private String nombreCDTDet = "";
	private String nroCDTDet = "";
	private String fechaVtoDet = "";
	private String valorDet = "";
	private String tasaNominalDet = "";
	private String valorRetenidoDet = "";
	private String interesPagadoDet = "";
	private String valorObligacionDet = "";
	private String fechaInicialCreDet = "";
	private String saldoCapitalDet = "";
	private String saldoInteresNominalDet = "";
	private String oficinaRadicacionDet = "";
	private String fechaFinalCreditoDet = "";
	private String tasaInteresMoraDet = "";
	private String valoraPagarDet = "";
	private String nombreTCDet = "";
	private String nroTCDet = "";
	private String saldoActualDet = "";
	private String valorMinimoDet = "";
	private String FechaPagoDet = "";
	private String valorenCanjeDet = "";
	private String interesesCorrientesDet = "";
	private String interesesMoraDet = "";
	private String otrosGastosDet = "";
	private String pagoTotalDet = "";
	private String saldoDisponibleMOV = "";
	private String saldoCanjeMOV = "";
	private String saldoTotalMOV = "";
	private String diasEnSobregiroMOV = "";
	private String fechaCorteMOV = "";
	private String movimientosMOV = "";
	private String cupoTotalMOV = "";
	private String cupoUtilizadoMOV = "";
	private String valorCanjeMOV = "";
	private String cupoDisponibleMOV = "";
	private String otrosGastosMOV = "";
	private String pagoTotalMOV = "";
	private String interesesCorrientesMOV = "";
	private String interesesdeMoraMOV = "";
	private String valorFacturadoMOV = "";
	private String fechaLimitePagoMOV = "";
	private String saldoCapitalFactPendienteMOV = "";
	private String saldoInteresCorrienteFactPendienteMOV = "";
	private String saldoInteresMoraFactPendienteMOV = "";
	private String movimientosRotMOV = "";
	private String cupoTotalTCMOV = "";
	private String cupoComprasTCMOV = "";
	private String cupoAvancesTCMOV = "";
	private String saldoTotalTCMOV = "";
	private String valorMinimoTCMOV = "";
	private String fechaProximoPagoTCMOV = "";
	private String saldoDisponibleMOVDET = "";
	private String saldoCanjeMOVDET = "";
	private String saldoTotalMOVDET = "";
	private String diasEnSobregiroMOVDET = "";
	private String fechaCorteMOVDET = "";
	private String movimientosMOVDET = "";
	private String cupoTotalMOVDET = "";
	private String cupoUtilizadoMOVDET = "";
	private String valorCanjeMOVDET = "";
	private String cupoDisponibleMOVDET = "";
	private String otrosGastosMOVDET = "";
	private String pagoTotalMOVDET = "";
	private String interesesCorrientesMOVDET = "";
	private String interesesdeMoraMOVDET = "";
	private String valorFacturadoMOVDET = "";
	private String fechaLimitePagoMOVDET = "";
	private String saldoCapitalFactPendienteMOVDET = "";
	private String saldoInteresCorrienteFactPendienteMOVDET = "";
	private String saldoInteresMoraFactPendienteMOVDET = "";
	private String movimientosRotMOVDET = "";
	private String cupoTotalTCMOVDET = "";
	private String cupoComprasTCMOVDET = "";
	private String cupoAvancesTCMOVDET = "";
	private String saldoTotalTCMOVDET = "";
	private String valorMinimoTCMOVDET = "";
	private String fechaProximoPagoTCMOVDET = "";



	public String getCasoPrueba() {
		return casoPrueba;
	}
	public void setCasoPrueba(String casoPrueba) {
		this.casoPrueba = casoPrueba;
	}
	public String getDescripcionCaso() {
		return descripcionCaso;
	}
	public void setDescripcionCaso(String descripcionCaso) {
		this.descripcionCaso = descripcionCaso;
	}
	public String getNombreModulo() {
		return nombreModulo;
	}
	public void setNombreModulo(String nombreModulo) {
		this.nombreModulo = nombreModulo;
	}
	public String getSubModulo() {
		return subModulo;
	}
	public void setSubModulo(String subModulo) {
		this.subModulo = subModulo;
	}
	public String getNombreProducto() {
		return nombreProducto;
	}
	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}
	public String getNroProducto() {
		return nroProducto;
	}
	public void setNroProducto(String nroProducto) {
		this.nroProducto = nroProducto;
	}
	public String getEstProducto() {
		return estProducto;
	}
	public void setEstProducto(String estProducto) {
		this.estProducto = estProducto;
	}
	public boolean getEjecutar() {
		return ejecutar;
	}
	public void setEjecutar(boolean ejecutar) {
		this.ejecutar = ejecutar;
	}
	public String getResultadoEsperado() {
		return resultadoEsperado;
	}
	public void setResultadoEsperado(String resultadoEsperado) {
		this.resultadoEsperado = resultadoEsperado;
	}
	public String getResultadoObtenido() {
		return resultadoObtenido;
	}
	public void setResultadoObtenido(String resultadoObtenido) {
		this.resultadoObtenido = resultadoObtenido;
	}
	public boolean getEjecutado() {
		return ejecutado;
	}
	public void setEjecutado(boolean ejecutado) {
		this.ejecutado = ejecutado;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNavegador() {
		return navegador;
	}
	public void setNavegador(String navegador) {
		this.navegador = navegador;
	}
	public String getVeredicto() {
		return veredicto;
	}
	public void setVeredicto() {
		if(getResultadoEsperado().equals(getResultadoObtenido()))
			this.veredicto = "Caso de Prueba Exitoso";
		else
			this.veredicto = "Caso de Prueba Fallido";
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getNombreCuenta() {
		return nombreCuenta;
	}
	public void setNombreCuenta(String nombreCuenta) {
		this.nombreCuenta = nombreCuenta;
	}
	public String getNroCuenta() {
		return nroCuenta;
	}
	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}
	public String getSaldoDisponible() {
		return saldoDisponible;
	}
	public void setSaldoDisponible(String saldoDisponible) {
		this.saldoDisponible = saldoDisponible;
	}
	public String getSaldoenCanje() {
		return saldoenCanje;
	}
	public void setSaldoenCanje(String saldoenCanje) {
		this.saldoenCanje = saldoenCanje;
	}
	public String getSaldoTotal() {
		return saldoTotal;
	}
	public void setSaldoTotal(String saldoTotal) {
		this.saldoTotal = saldoTotal;
	}
	public String getNombreObligacion() {
		return nombreObligacion;
	}
	public void setNombreObligacion(String nombreObligacion) {
		this.nombreObligacion = nombreObligacion;
	}
	public String getNroObligacion() {
		return nroObligacion;
	}
	public void setNroObligacion(String nroObligacion) {
		this.nroObligacion = nroObligacion;
	}
	public String getCupoDisponible() {
		return cupoDisponible;
	}
	public void setCupoDisponible(String cupoDisponible) {
		this.cupoDisponible = cupoDisponible;
	}
	public String getCupoTotal() {
		return cupoTotal;
	}
	public void setCupoTotal(String cupoTotal) {
		this.cupoTotal = cupoTotal;
	}
	public String getCupoUtilizado() {
		return cupoUtilizado;
	}
	public void setCupoUtilizado(String cupoUtilizado) {
		this.cupoUtilizado = cupoUtilizado;
	}
	public String getNombreCDT() {
		return nombreCDT;
	}
	public void setNombreCDT(String nombreCDT) {
		this.nombreCDT = nombreCDT;
	}
	public String getNroCDT() {
		return nroCDT;
	}
	public void setNroCDT(String nroCDT) {
		this.nroCDT = nroCDT;
	}
	public String getFechaVto() {
		return fechaVto;
	}
	public void setFechaVto(String fechaVto) {
		this.fechaVto = fechaVto;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	public String getTasaNominal() {
		return tasaNominal;
	}
	public void setTasaNominal(String tasaNominal) {
		this.tasaNominal = tasaNominal;
	}
	public String getValorRetenido() {
		return valorRetenido;
	}
	public void setValorRetenido(String valorRetenido) {
		this.valorRetenido = valorRetenido;
	}
	public String getInteresPagado() {
		return interesPagado;
	}
	public void setInteresPagado(String interesPagado) {
		this.interesPagado = interesPagado;
	}
	public String getValorObligacion() {
		return valorObligacion;
	}
	public void setValorObligacion(String valorObligacion) {
		this.valorObligacion = valorObligacion;
	}
	public String getFechaInicialCre() {
		return fechaInicialCre;
	}
	public void setFechaInicialCre(String fechaInicialCre) {
		this.fechaInicialCre = fechaInicialCre;
	}
	public String getSaldoCapital() {
		return saldoCapital;
	}
	public void setSaldoCapital(String saldoCapital) {
		this.saldoCapital = saldoCapital;
	}
	public String getSaldoInteresNominal() {
		return saldoInteresNominal;
	}
	public void setSaldoInteresNominal(String saldoInteresNominal) {
		this.saldoInteresNominal = saldoInteresNominal;
	}
	public String getOficinaRadicacion() {
		return oficinaRadicacion;
	}
	public void setOficinaRadicacion(String oficinaRadicacion) {
		this.oficinaRadicacion = oficinaRadicacion;
	}
	public String getFechaFinalCredito() {
		return fechaFinalCredito;
	}
	public void setFechaFinalCredito(String fechaFinalCredito) {
		this.fechaFinalCredito = fechaFinalCredito;
	}
	public String getTasaInteresMora() {
		return tasaInteresMora;
	}
	public void setTasaInteresMora(String tasaInteresMora) {
		this.tasaInteresMora = tasaInteresMora;
	}
	public String getValoraPagar() {
		return valoraPagar;
	}
	public void setValoraPagar(String valoraPagar) {
		this.valoraPagar = valoraPagar;
	}
	public String getNombreTC() {
		return nombreTC;
	}
	public void setNombreTC(String nombreTC) {
		this.nombreTC = nombreTC;
	}
	public String getNroTC() {
		return nroTC;
	}
	public void setNroTC(String nroTC) {
		this.nroTC = nroTC;
	}
	public String getSaldoActual() {
		return saldoActual;
	}
	public void setSaldoActual(String saldoActual) {
		this.saldoActual = saldoActual;
	}
	public String getValorMinimo() {
		return valorMinimo;
	}
	public void setValorMinimo(String valorMinimo) {
		this.valorMinimo = valorMinimo;
	}
	public String getFechaPago() {
		return FechaPago;
	}
	public void setFechaPago(String fechaPago) {
		FechaPago = fechaPago;
	}
	public String getValorenCanje() {
		return valorenCanje;
	}
	public void setValorenCanje(String valorenCanje) {
		this.valorenCanje = valorenCanje;
	}
	public String getInteresesCorrientes() {
		return interesesCorrientes;
	}
	public void setInteresesCorrientes(String interesesCorrientes) {
		this.interesesCorrientes = interesesCorrientes;
	}
	public String getInteresesMora() {
		return interesesMora;
	}
	public void setInteresesMora(String interesesMora) {
		this.interesesMora = interesesMora;
	}
	public String getOtrosGastos() {
		return otrosGastos;
	}
	public void setOtrosGastos(String otrosGastos) {
		this.otrosGastos = otrosGastos;
	}
	public String getPagoTotal() {
		return pagoTotal;
	}
	public void setPagoTotal(String pagoTotal) {
		this.pagoTotal = pagoTotal;
	}
	public void setVeredicto(String veredicto) {
		this.veredicto = veredicto;
	}
	public String getEstadoDet() {
		return estadoDet;
	}
	public void setEstadoDet(String estadoDet) {
		this.estadoDet = estadoDet;
	}
	public String getNombreCuentaDet() {
		return nombreCuentaDet;
	}
	public void setNombreCuentaDet(String nombreCuentaDet) {
		this.nombreCuentaDet = nombreCuentaDet;
	}
	public String getNroCuentaDet() {
		return nroCuentaDet;
	}
	public void setNroCuentaDet(String nroCuentaDet) {
		this.nroCuentaDet = nroCuentaDet;
	}
	public String getSaldoDisponibleDet() {
		return saldoDisponibleDet;
	}
	public void setSaldoDisponibleDet(String saldoDisponibleDet) {
		this.saldoDisponibleDet = saldoDisponibleDet;
	}
	public String getSaldoenCanjeDet() {
		return saldoenCanjeDet;
	}
	public void setSaldoenCanjeDet(String saldoenCanjeDet) {
		this.saldoenCanjeDet = saldoenCanjeDet;
	}
	public String getSaldoTotalDet() {
		return saldoTotalDet;
	}
	public void setSaldoTotalDet(String saldoTotalDet) {
		this.saldoTotalDet = saldoTotalDet;
	}
	public String getNombreObligacionDet() {
		return nombreObligacionDet;
	}
	public void setNombreObligacionDet(String nombreObligacionDet) {
		this.nombreObligacionDet = nombreObligacionDet;
	}
	public String getNroObligacionDet() {
		return nroObligacionDet;
	}
	public void setNroObligacionDet(String nroObligacionDet) {
		this.nroObligacionDet = nroObligacionDet;
	}
	public String getCupoDisponibleDet() {
		return cupoDisponibleDet;
	}
	public void setCupoDisponibleDet(String cupoDisponibleDet) {
		this.cupoDisponibleDet = cupoDisponibleDet;
	}
	public String getCupoTotalDet() {
		return cupoTotalDet;
	}
	public void setCupoTotalDet(String cupoTotalDet) {
		this.cupoTotalDet = cupoTotalDet;
	}
	public String getCupoUtilizadoDet() {
		return cupoUtilizadoDet;
	}
	public void setCupoUtilizadoDet(String cupoUtilizadoDet) {
		this.cupoUtilizadoDet = cupoUtilizadoDet;
	}
	public String getNombreCDTDet() {
		return nombreCDTDet;
	}
	public void setNombreCDTDet(String nombreCDTDet) {
		this.nombreCDTDet = nombreCDTDet;
	}
	public String getNroCDTDet() {
		return nroCDTDet;
	}
	public void setNroCDTDet(String nroCDTDet) {
		this.nroCDTDet = nroCDTDet;
	}
	public String getFechaVtoDet() {
		return fechaVtoDet;
	}
	public void setFechaVtoDet(String fechaVtoDet) {
		this.fechaVtoDet = fechaVtoDet;
	}
	public String getValorDet() {
		return valorDet;
	}
	public void setValorDet(String valorDet) {
		this.valorDet = valorDet;
	}
	public String getTasaNominalDet() {
		return tasaNominalDet;
	}
	public void setTasaNominalDet(String tasaNominalDet) {
		this.tasaNominalDet = tasaNominalDet;
	}
	public String getValorRetenidoDet() {
		return valorRetenidoDet;
	}
	public void setValorRetenidoDet(String valorRetenidoDet) {
		this.valorRetenidoDet = valorRetenidoDet;
	}
	public String getInteresPagadoDet() {
		return interesPagadoDet;
	}
	public void setInteresPagadoDet(String interesPagadoDet) {
		this.interesPagadoDet = interesPagadoDet;
	}
	public String getValorObligacionDet() {
		return valorObligacionDet;
	}
	public void setValorObligacionDet(String valorObligacionDet) {
		this.valorObligacionDet = valorObligacionDet;
	}
	public String getFechaInicialCreDet() {
		return fechaInicialCreDet;
	}
	public void setFechaInicialCreDet(String fechaInicialCreDet) {
		this.fechaInicialCreDet = fechaInicialCreDet;
	}
	public String getSaldoCapitalDet() {
		return saldoCapitalDet;
	}
	public void setSaldoCapitalDet(String saldoCapitalDet) {
		this.saldoCapitalDet = saldoCapitalDet;
	}
	public String getSaldoInteresNominalDet() {
		return saldoInteresNominalDet;
	}
	public void setSaldoInteresNominalDet(String saldoInteresNominalDet) {
		this.saldoInteresNominalDet = saldoInteresNominalDet;
	}
	public String getOficinaRadicacionDet() {
		return oficinaRadicacionDet;
	}
	public void setOficinaRadicacionDet(String oficinaRadicacionDet) {
		this.oficinaRadicacionDet = oficinaRadicacionDet;
	}
	public String getFechaFinalCreditoDet() {
		return fechaFinalCreditoDet;
	}
	public void setFechaFinalCreditoDet(String fechaFinalCreditoDet) {
		this.fechaFinalCreditoDet = fechaFinalCreditoDet;
	}
	public String getTasaInteresMoraDet() {
		return tasaInteresMoraDet;
	}
	public void setTasaInteresMoraDet(String tasaInteresMoraDet) {
		this.tasaInteresMoraDet = tasaInteresMoraDet;
	}
	public String getValoraPagarDet() {
		return valoraPagarDet;
	}
	public void setValoraPagarDet(String valoraPagarDet) {
		this.valoraPagarDet = valoraPagarDet;
	}
	public String getNombreTCDet() {
		return nombreTCDet;
	}
	public void setNombreTCDet(String nombreTCDet) {
		this.nombreTCDet = nombreTCDet;
	}
	public String getNroTCDet() {
		return nroTCDet;
	}
	public void setNroTCDet(String nroTCDet) {
		this.nroTCDet = nroTCDet;
	}
	public String getSaldoActualDet() {
		return saldoActualDet;
	}
	public void setSaldoActualDet(String saldoActualDet) {
		this.saldoActualDet = saldoActualDet;
	}
	public String getValorMinimoDet() {
		return valorMinimoDet;
	}
	public void setValorMinimoDet(String valorMinimoDet) {
		this.valorMinimoDet = valorMinimoDet;
	}
	public String getFechaPagoDet() {
		return FechaPagoDet;
	}
	public void setFechaPagoDet(String fechaPagoDet) {
		FechaPagoDet = fechaPagoDet;
	}
	public String getValorenCanjeDet() {
		return valorenCanjeDet;
	}
	public void setValorenCanjeDet(String valorenCanjeDet) {
		this.valorenCanjeDet = valorenCanjeDet;
	}
	public String getInteresesCorrientesDet() {
		return interesesCorrientesDet;
	}
	public void setInteresesCorrientesDet(String interesesCorrientesDet) {
		this.interesesCorrientesDet = interesesCorrientesDet;
	}
	public String getInteresesMoraDet() {
		return interesesMoraDet;
	}
	public void setInteresesMoraDet(String interesesMoraDet) {
		this.interesesMoraDet = interesesMoraDet;
	}
	public String getOtrosGastosDet() {
		return otrosGastosDet;
	}
	public void setOtrosGastosDet(String otrosGastosDet) {
		this.otrosGastosDet = otrosGastosDet;
	}
	public String getPagoTotalDet() {
		return pagoTotalDet;
	}
	public void setPagoTotalDet(String pagoTotalDet) {
		this.pagoTotalDet = pagoTotalDet;
	}
	public String getSaldoDisponibleMOV() {
		return saldoDisponibleMOV;
	}
	public String getSaldoCanjeMOV() {
		return saldoCanjeMOV;
	}
	public String getSaldoTotalMOV() {
		return saldoTotalMOV;
	}
	public String getDiasEnSobregiroMOV() {
		return diasEnSobregiroMOV;
	}
	public String getFechaCorteMOV() {
		return fechaCorteMOV;
	}
	public String getMovimientosMOV() {
		return movimientosMOV;
	}
	public String getCupoTotalMOV() {
		return cupoTotalMOV;
	}
	public String getCupoUtilizadoMOV() {
		return cupoUtilizadoMOV;
	}
	public String getValorCanjeMOV() {
		return valorCanjeMOV;
	}
	public String getCupoDisponibleMOV() {
		return cupoDisponibleMOV;
	}
	public String getOtrosGastosMOV() {
		return otrosGastosMOV;
	}
	public String getPagoTotalMOV() {
		return pagoTotalMOV;
	}
	public String getInteresesCorrientesMOV() {
		return interesesCorrientesMOV;
	}
	public String getInteresesdeMoraMOV() {
		return interesesdeMoraMOV;
	}
	public String getValorFacturadoMOV() {
		return valorFacturadoMOV;
	}
	public String getFechaLimitePagoMOV() {
		return fechaLimitePagoMOV;
	}
	public String getSaldoCapitalFactPendienteMOV() {
		return saldoCapitalFactPendienteMOV;
	}
	public String getSaldoInteresCorrienteFactPendienteMOV() {
		return saldoInteresCorrienteFactPendienteMOV;
	}
	public String getSaldoInteresMoraFactPendienteMOV() {
		return saldoInteresMoraFactPendienteMOV;
	}
	public String getMovimientosRotMOV() {
		return movimientosRotMOV;
	}
	public String getCupoTotalTCMOV() {
		return cupoTotalTCMOV;
	}
	public String getCupoComprasTCMOV() {
		return cupoComprasTCMOV;
	}
	public String getCupoAvancesTCMOV() {
		return cupoAvancesTCMOV;
	}
	public String getSaldoTotalTCMOV() {
		return saldoTotalTCMOV;
	}
	public String getValorMinimoTCMOV() {
		return valorMinimoTCMOV;
	}
	public String getFechaProximoPagoTCMOV() {
		return fechaProximoPagoTCMOV;
	}
	public String getSaldoDisponibleMOVDET() {
		return saldoDisponibleMOVDET;
	}
	public String getSaldoCanjeMOVDET() {
		return saldoCanjeMOVDET;
	}
	public String getSaldoTotalMOVDET() {
		return saldoTotalMOVDET;
	}
	public String getDiasEnSobregiroMOVDET() {
		return diasEnSobregiroMOVDET;
	}
	public String getFechaCorteMOVDET() {
		return fechaCorteMOVDET;
	}
	public String getMovimientosMOVDET() {
		return movimientosMOVDET;
	}
	public String getCupoTotalMOVDET() {
		return cupoTotalMOVDET;
	}
	public String getCupoUtilizadoMOVDET() {
		return cupoUtilizadoMOVDET;
	}
	public String getValorCanjeMOVDET() {
		return valorCanjeMOVDET;
	}
	public String getCupoDisponibleMOVDET() {
		return cupoDisponibleMOVDET;
	}
	public String getOtrosGastosMOVDET() {
		return otrosGastosMOVDET;
	}
	public String getPagoTotalMOVDET() {
		return pagoTotalMOVDET;
	}
	public String getInteresesCorrientesMOVDET() {
		return interesesCorrientesMOVDET;
	}
	public String getInteresesdeMoraMOVDET() {
		return interesesdeMoraMOVDET;
	}
	public String getValorFacturadoMOVDET() {
		return valorFacturadoMOVDET;
	}
	public String getFechaLimitePagoMOVDET() {
		return fechaLimitePagoMOVDET;
	}
	public String getSaldoCapitalFactPendienteMOVDET() {
		return saldoCapitalFactPendienteMOVDET;
	}
	public String getSaldoInteresCorrienteFactPendienteMOVDET() {
		return saldoInteresCorrienteFactPendienteMOVDET;
	}
	public String getSaldoInteresMoraFactPendienteMOVDET() {
		return saldoInteresMoraFactPendienteMOVDET;
	}
	public String getMovimientosRotMOVDET() {
		return movimientosRotMOVDET;
	}
	public String getCupoTotalTCMOVDET() {
		return cupoTotalTCMOVDET;
	}
	public String getCupoComprasTCMOVDET() {
		return cupoComprasTCMOVDET;
	}
	public String getCupoAvancesTCMOVDET() {
		return cupoAvancesTCMOVDET;
	}
	public String getSaldoTotalTCMOVDET() {
		return saldoTotalTCMOVDET;
	}
	public String getValorMinimoTCMOVDET() {
		return valorMinimoTCMOVDET;
	}
	public String getFechaProximoPagoTCMOVDET() {
		return fechaProximoPagoTCMOVDET;
	}
	public void setSaldoDisponibleMOV(String saldoDisponibleMOV) {
		this.saldoDisponibleMOV = saldoDisponibleMOV;
	}
	public void setSaldoCanjeMOV(String saldoCanjeMOV) {
		this.saldoCanjeMOV = saldoCanjeMOV;
	}
	public void setSaldoTotalMOV(String saldoTotalMOV) {
		this.saldoTotalMOV = saldoTotalMOV;
	}
	public void setDiasEnSobregiroMOV(String diasEnSobregiroMOV) {
		this.diasEnSobregiroMOV = diasEnSobregiroMOV;
	}
	public void setFechaCorteMOV(String fechaCorteMOV) {
		this.fechaCorteMOV = fechaCorteMOV;
	}
	public void setMovimientosMOV(String movimientosMOV) {
		this.movimientosMOV = movimientosMOV;
	}
	public void setCupoTotalMOV(String cupoTotalMOV) {
		this.cupoTotalMOV = cupoTotalMOV;
	}
	public void setCupoUtilizadoMOV(String cupoUtilizadoMOV) {
		this.cupoUtilizadoMOV = cupoUtilizadoMOV;
	}
	public void setValorCanjeMOV(String valorCanjeMOV) {
		this.valorCanjeMOV = valorCanjeMOV;
	}
	public void setCupoDisponibleMOV(String cupoDisponibleMOV) {
		this.cupoDisponibleMOV = cupoDisponibleMOV;
	}
	public void setOtrosGastosMOV(String otrosGastosMOV) {
		this.otrosGastosMOV = otrosGastosMOV;
	}
	public void setPagoTotalMOV(String pagoTotalMOV) {
		this.pagoTotalMOV = pagoTotalMOV;
	}
	public void setInteresesCorrientesMOV(String interesesCorrientesMOV) {
		this.interesesCorrientesMOV = interesesCorrientesMOV;
	}
	public void setInteresesdeMoraMOV(String interesesdeMoraMOV) {
		this.interesesdeMoraMOV = interesesdeMoraMOV;
	}
	public void setValorFacturadoMOV(String valorFacturadoMOV) {
		this.valorFacturadoMOV = valorFacturadoMOV;
	}
	public void setFechaLimitePagoMOV(String fechaLimitePagoMOV) {
		this.fechaLimitePagoMOV = fechaLimitePagoMOV;
	}
	public void setSaldoCapitalFactPendienteMOV(String saldoCapitalFactPendienteMOV) {
		this.saldoCapitalFactPendienteMOV = saldoCapitalFactPendienteMOV;
	}
	public void setSaldoInteresCorrienteFactPendienteMOV(
			String saldoInteresCorrienteFactPendienteMOV) {
		this.saldoInteresCorrienteFactPendienteMOV = saldoInteresCorrienteFactPendienteMOV;
	}
	public void setSaldoInteresMoraFactPendienteMOV(
			String saldoInteresMoraFactPendienteMOV) {
		this.saldoInteresMoraFactPendienteMOV = saldoInteresMoraFactPendienteMOV;
	}
	public void setMovimientosRotMOV(String movimientosRotMOV) {
		this.movimientosRotMOV = movimientosRotMOV;
	}
	public void setCupoTotalTCMOV(String cupoTotalTCMOV) {
		this.cupoTotalTCMOV = cupoTotalTCMOV;
	}
	public void setCupoComprasTCMOV(String cupoComprasTCMOV) {
		this.cupoComprasTCMOV = cupoComprasTCMOV;
	}
	public void setCupoAvancesTCMOV(String cupoAvancesTCMOV) {
		this.cupoAvancesTCMOV = cupoAvancesTCMOV;
	}
	public void setSaldoTotalTCMOV(String saldoTotalTCMOV) {
		this.saldoTotalTCMOV = saldoTotalTCMOV;
	}
	public void setValorMinimoTCMOV(String valorMinimoTCMOV) {
		this.valorMinimoTCMOV = valorMinimoTCMOV;
	}
	public void setFechaProximoPagoTCMOV(String fechaProximoPagoTCMOV) {
		this.fechaProximoPagoTCMOV = fechaProximoPagoTCMOV;
	}
	public void setSaldoDisponibleMOVDET(String saldoDisponibleMOVDET) {
		this.saldoDisponibleMOVDET = saldoDisponibleMOVDET;
	}
	public void setSaldoCanjeMOVDET(String saldoCanjeMOVDET) {
		this.saldoCanjeMOVDET = saldoCanjeMOVDET;
	}
	public void setSaldoTotalMOVDET(String saldoTotalMOVDET) {
		this.saldoTotalMOVDET = saldoTotalMOVDET;
	}
	public void setDiasEnSobregiroMOVDET(String diasEnSobregiroMOVDET) {
		this.diasEnSobregiroMOVDET = diasEnSobregiroMOVDET;
	}
	public void setFechaCorteMOVDET(String fechaCorteMOVDET) {
		this.fechaCorteMOVDET = fechaCorteMOVDET;
	}
	public void setMovimientosMOVDET(String movimientosMOVDET) {
		this.movimientosMOVDET = movimientosMOVDET;
	}
	public void setCupoTotalMOVDET(String cupoTotalMOVDET) {
		this.cupoTotalMOVDET = cupoTotalMOVDET;
	}
	public void setCupoUtilizadoMOVDET(String cupoUtilizadoMOVDET) {
		this.cupoUtilizadoMOVDET = cupoUtilizadoMOVDET;
	}
	public void setValorCanjeMOVDET(String valorCanjeMOVDET) {
		this.valorCanjeMOVDET = valorCanjeMOVDET;
	}
	public void setCupoDisponibleMOVDET(String cupoDisponibleMOVDET) {
		this.cupoDisponibleMOVDET = cupoDisponibleMOVDET;
	}
	public void setOtrosGastosMOVDET(String otrosGastosMOVDET) {
		this.otrosGastosMOVDET = otrosGastosMOVDET;
	}
	public void setPagoTotalMOVDET(String pagoTotalMOVDET) {
		this.pagoTotalMOVDET = pagoTotalMOVDET;
	}
	public void setInteresesCorrientesMOVDET(String interesesCorrientesMOVDET) {
		this.interesesCorrientesMOVDET = interesesCorrientesMOVDET;
	}
	public void setInteresesdeMoraMOVDET(String interesesdeMoraMOVDET) {
		this.interesesdeMoraMOVDET = interesesdeMoraMOVDET;
	}
	public void setValorFacturadoMOVDET(String valorFacturadoMOVDET) {
		this.valorFacturadoMOVDET = valorFacturadoMOVDET;
	}
	public void setFechaLimitePagoMOVDET(String fechaLimitePagoMOVDET) {
		this.fechaLimitePagoMOVDET = fechaLimitePagoMOVDET;
	}
	public void setSaldoCapitalFactPendienteMOVDET(
			String saldoCapitalFactPendienteMOVDET) {
		this.saldoCapitalFactPendienteMOVDET = saldoCapitalFactPendienteMOVDET;
	}
	public void setSaldoInteresCorrienteFactPendienteMOVDET(
			String saldoInteresCorrienteFactPendienteMOVDET) {
		this.saldoInteresCorrienteFactPendienteMOVDET = saldoInteresCorrienteFactPendienteMOVDET;
	}
	public void setSaldoInteresMoraFactPendienteMOVDET(
			String saldoInteresMoraFactPendienteMOVDET) {
		this.saldoInteresMoraFactPendienteMOVDET = saldoInteresMoraFactPendienteMOVDET;
	}
	public void setMovimientosRotMOVDET(String movimientosRotMOVDET) {
		this.movimientosRotMOVDET = movimientosRotMOVDET;
	}
	public void setCupoTotalTCMOVDET(String cupoTotalTCMOVDET) {
		this.cupoTotalTCMOVDET = cupoTotalTCMOVDET;
	}
	public void setCupoComprasTCMOVDET(String cupoComprasTCMOVDET) {
		this.cupoComprasTCMOVDET = cupoComprasTCMOVDET;
	}
	public void setCupoAvancesTCMOVDET(String cupoAvancesTCMOVDET) {
		this.cupoAvancesTCMOVDET = cupoAvancesTCMOVDET;
	}
	public void setSaldoTotalTCMOVDET(String saldoTotalTCMOVDET) {
		this.saldoTotalTCMOVDET = saldoTotalTCMOVDET;
	}
	public void setValorMinimoTCMOVDET(String valorMinimoTCMOVDET) {
		this.valorMinimoTCMOVDET = valorMinimoTCMOVDET;
	}
	public void setFechaProximoPagoTCMOVDET(String fechaProximoPagoTCMOVDET) {
		this.fechaProximoPagoTCMOVDET = fechaProximoPagoTCMOVDET;
	}
	/**
	 * @return the tipoMovimiento
	 */
	public String getDescripcionMovimiento() {
		return descripcionMovimiento;
	}
	/**
	 * @param tipoMovimiento the tipoMovimiento to set
	 */
	public void setDescripcionMovimiento(String descripcionMovimiento) {
		this.descripcionMovimiento = descripcionMovimiento;
	}
	/**
	 * @return the tipoMov
	 */
	public String getTipoMov() {
		return tipoMov;
	}
	/**
	 * @param tipoMov the tipoMov to set
	 */
	public void setTipoMov(String tipoMov) {
		this.tipoMov = tipoMov;
	}
	/**
	 * @return the grupo
	 */
	public String getGrupo() {
		return grupo;
	}
	/**
	 * @param grupo the grupo to set
	 */
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
}