package utilitarios;

import inicio.Inicio;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import sqlConexion.ConsultaSQL;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
//import com.rational.test.ft.object.interfaces.TestObject;

public class Utilitarios {
	private java.sql.Connection Conec = null;
	Statement St;
	int numeroKill = 0;
	Connection conexionBD;
	Statement stamt;
	String[] Datos;
	String Conn = "//AQUILESSQL25\\REPOSITORY";
	protected int i;
	String cont;
	Paragraph parrafo;
	Document documento = null;
	private WebDriver driver;

	public WebDriver getDriver()
	{
		return driver;
	}

	public void setDriver(WebDriver driver)
	{
		this.driver = driver;
	}

	public void getExplorer(String baseUrl) throws InterruptedException
	{
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		capabilities.setCapability("requireWindowFocus", true);
		System.setProperty("webdriver.ie.driver", "D:\\driverSelenium\\IEDriverServer.exe");
		setDriver(new InternetExplorerDriver(capabilities));

		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		getDriver().get(baseUrl);
		getDriver().manage().window().maximize();

		setTextoPDF("NAVEGADOR PRUEBA: " + getDriver() );	

		Thread.sleep(3000);
	}


	public void getChrome(String baseUrl)
	{
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		System.setProperty("webdriver.chrome.driver", "D:\\driverSelenium\\chromedriver.exe");
		setDriver(new ChromeDriver(capabilities));

		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		getDriver().get(baseUrl);
		getDriver().manage().window().maximize();	
	}


	public void getFirefox(String baseUrl) throws InterruptedException
	{
		ProfilesIni profile = new ProfilesIni();
		FirefoxProfile myprofile = profile.getProfile("Selenium");
		System.setProperty("webdriver.gecko.driver", "D:\\driverSelenium\\geckodriver.exe");
		setDriver(new FirefoxDriver(myprofile));

		getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		getDriver().get(baseUrl);
		getDriver().manage().window().maximize();

		Thread.sleep(15000);
	}

	public void cambiarVentana() throws InterruptedException
	{
		Thread.sleep(5000);

		Set<String> allHandles = getDriver().getWindowHandles();

		allHandles.remove(allHandles.iterator().next());

		String lastHandle = allHandles.iterator().next();
		lastHandle = allHandles.iterator().next();

		getDriver().switchTo().window(lastHandle);
		getDriver().manage().window().maximize();

		Thread.sleep(5000);
	}

	public boolean buscarObjeto(By by)
	{
		try
		{
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			getDriver().findElement(by);
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			return true;
		}
		catch(NoSuchElementException e) {
			return false;
		}
	}

	public String getRecorrerTabla(By path, String validar) {
		String retorno = "No Encontrado";
		WebElement tabla = getDriver().findElement(path);
		List<WebElement> filas = tabla.findElements(By.tagName("tr"));

		int row_num, col_num;
		row_num = 1;
		if(buscarObjeto(path)) {
			for(WebElement trElement : filas) {

				List<WebElement> td_collection = trElement.findElements(By.tagName("td"));

				col_num = 1;

				for(WebElement tdElement : td_collection) {
					if(validar.equals("ALL")) {
						System.out.print(tdElement.getText() + "\t");

						if(row_num > 1)
							retorno = "Movimientos Generados Exitosamente";
						else
							retorno = "No se encontraron Movimientos";
					}
					if(tdElement.getText().equals(validar)) {
						retorno = "tr[" + row_num + "]/td[" + col_num + "]";
					}
					col_num++;
				}
				row_num++;
			} 
		}
		return retorno;
	}

	public void scrollDown() {
		JavascriptExecutor jse = (JavascriptExecutor)getDriver();
		jse.executeScript("window.scrollBy(0, 200)", "");
	}

	/**
	 * METODOS PARA MANEJO DE LOGS (ARCHIVOS .TXT, .PDF y ARCHIVOS .JPG)
	 * */

	// M�todo para la generacion o apertura del archivo
	public FileWriter generacionArchivo(String rutaArchivo, String nombreArchivo) {
		FileWriter fichero = null;
		try {
			fichero = new FileWriter(rutaArchivo + nombreArchivo, true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fichero;
	}

	// M�todo para ingresar cadenas de texto al archivo
	public void InsertarArchivo(FileWriter fichero, String sentencia) {

		PrintWriter pw = null;
		pw = new PrintWriter(fichero);
		pw.println(sentencia);
	}

	// M�todo para ingresar cadenas de texto al archivo sin salto de l�nea
	public void ContinuarRegistro(FileWriter fichero, String sentencia) {

		PrintWriter pw = null;
		pw = new PrintWriter(fichero);
		pw.print(sentencia);
	}

	// M�todo para cerrar y cuardar el archivo
	public void cerrarArchivo(FileWriter fichero) {
		try {
			fichero.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	/**
	 * 
	 * METODOS PARA EL MANEJO DE HORA, MINUTOS Y SEGUNDOS (FECHAS)
	 * 
	 * */

	// M�todo para obtener FECHA en formato, A�o/Mes/Dia
	public String ObtenerFecha() {
		String fecha;	
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("yyyyMMdd");
		fecha = formato.format(calendar.getTime());
		return fecha;
	}

	// M�todo para obtener mes de certificaci�n
	public String ObtenerMes() {
		Calendar miCalendario = Calendar.getInstance();
		int mes; 
		String m;

		if (ObtenerDia() > 20)
			if(miCalendario.get(Calendar.MONTH) == 11)
				mes = 1;
			else
				mes = miCalendario.get(Calendar.MONTH)+2;
		else
			mes = miCalendario.get(Calendar.MONTH) + 1;

		if(mes < 10)
			m = "0" + mes;
		else
			m = "" + mes;

		return m;
	}

	public String ObtenerMesExtracto() {
		Calendar miCalendario = Calendar.getInstance();
		int mes; 
		String m;

		mes = miCalendario.get(Calendar.MONTH) + 1;
		
		if(mes == 1)
			mes = 12;
		else
			mes = mes - 1;

		if (mes < 10)
			m = "0" + mes;
		else
			m = "" + mes;

		String mesCertif = "";

		switch (m) {

		case "01": {
			mesCertif = "Enero";
			break;
		} case "02": {
			mesCertif = "Febrero";
			break;
		} case "03": {
			mesCertif = "Marzo";
			break;
		} case "04": {
			mesCertif = "Abril";
			break;
		} case "05": {
			mesCertif = "Mayo";
			break;
		} case "06": {
			mesCertif = "Junio";
			break;
		} case "07": {
			mesCertif = "Julio";
			break;
		} case "08": {
			mesCertif = "Agosto";
			break;
		} case "09": {
			mesCertif = "Septiembre";
			break;
		} case "10": {
			mesCertif = "Octubre";
			break;
		} case "11": {
			mesCertif = "Noviembre";
			break;
		} case "12": {
			mesCertif = "Diciembre";
			break;
		} 
		}
		return mesCertif;
	}
	// M�todo para obteber el d�a actual
	public Integer ObtenerDia() {
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		return diaHoy;
	}

	// M�todo para obtener HORA en formato Hora:Minutos:Segundos
	public String ObtenerHora() {
		String hora;	
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("HHmmss");
		calendar.get(Calendar.MONTH);
		hora = formato.format(calendar.getTime());
		return hora;
	}

	/* Consumo OTP */
	public String Cliente(String TipoId, String NroID) {
		String otp = null;

		try {
			Inicio in = new Inicio();
			ConsultaSQL con = new ConsultaSQL();
			String[] TipoDoc = { "C�dula de Ciudadan�a",
					"C�dula de Extranjer�a", "Tarjeta de identidad",
					"Pasaporte", "Registro civil", "Nit persona natural",
					"Nit de extranjer�a", "Nit persona jur�dica" };

			int tipo = 0;



			for (int i = 0; i < TipoDoc.length; i++) {
				if (TipoDoc[i].equals(TipoId)) {
					tipo = i + 1;
					i = TipoDoc.length;
				}
			}
			ResultSet rs = con
					.Consulta("SELECT * FROM SemillasDigipass WHERE TipoID = '"
							+ tipo + "' AND NroId = '" + NroID + "'");

			while (rs.next()) {
				otp = in.generacion("" + tipo, rs.getString("NroID"),
						rs.getString("EstadoSemilla"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return otp;
	}

	/**
	 * METODOS PARA MANEJO DE BASE DE DATOS
	 * */

	public void ConnectionDB() {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Conec = DriverManager.getConnection("jdbc:sqlserver://AQUILESSQL25\\REPOSITORY;databaseName=BD_AUT_BBS;", "usr_AUTBBS", "usr_AUTBBS#2016");
		} catch (SQLException excepcionSql) {
			System.out.println("Error en base de datos");
		}

		catch (ClassNotFoundException claseNoEncontrada) {
			System.out.println("No se encontr� el controlador");
		}
	}

	// Metodo para las consultas a la base de datos
	public ResultSet Consulta(String sql) {
		ConnectionDB();

		ResultSet res = null;
		try {
			Statement s = Conec.createStatement();
			res = s.executeQuery(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	// Metodo de ejecucion de insert,update,delete a la base de datos
	public String[] insertarSQL(String consulta) {
		// CONTROLA QUE LA CONSULTA NO ESTE NULA O VACIA
		try {
			ConnectionDB();

			stamt = Conec.createStatement();
			// SE ENVIA CODIGO DE INSERCION SQL
			stamt.executeUpdate(consulta);
			// SE CIERRA CONEXION
			Conec.close();
		}
		// IMPRIME CON CONSOLA EL SI EXISTIO ALGUN ERROR EN LA CONEXION
		catch (SQLException e) {
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			e.printStackTrace(new PrintStream(os));		
			System.out.println(new String(os.toByteArray()));
		}
		// NO RETORNA NADA
		return Datos;
	}

	// FUNCION PARA GUARDAR LAS IMAGENES CAPTURADAS
	public void guardarImagen(RenderedImage image, String Nombre) {
		String ruta = "C:\\tmp\\PSE\\Imagenes\\" + Nombre + ".jpg";

		// DECLARA Y CREA EL ARCHIVO CON LA IMAGEN RECIBIDA
		File file = new File(ruta);
		try {
			ImageIO.write(image, "jpg", file);
		} catch (IOException e) {
			e.printStackTrace();
		}
		setImagenPDF(ruta);
	}

	// METODO QUE CREA UN PDF PARA PRESENTAR LOS RESULTADOS DE LOS SCRIPT
	// METODO QUE CREA UN PDF PARA PRESENTAR LOS RESULTADOS DE LOS SCRIPT
	public void setPDF(String nombre, Datos d) throws DocumentException, MalformedURLException, IOException {
		// SE CREA UN DOCUMENTO CON TAMA�O CARTA Y SE ESCOJE LA RUTA Y NOMBRE DEL ARCHIVO
		setDocumento(new Document(PageSize.LETTER, 80, 80, 75, 75));

		String archivo = "C:\\tmp\\BBS\\" + nombre + ".pdf";

		PdfWriter.getInstance(getDocumento(), new FileOutputStream(archivo, true));

		// SE LE AGREGA EL TITULO Y AUTOR AL DOCUMENTO
		getDocumento().addTitle("Registro Ejecuci�n " + nombre);
		getDocumento().addAuthor("Equipo de Automatizaci�n - Direcci�n de Desarrollo Tecnologico");
		getDocumento().open();

		// SE CREA UN PARAGRAFO QUE LLEBA EL ENCABEZADO DEL DOCUMENTO TITULO
		// LETRA GRANDE
		Paragraph titulo = new Paragraph();
		titulo.setAlignment(Paragraph.ALIGN_CENTER);
		titulo.setFont(FontFactory.getFont("Ebrima", 12, Font.BOLD));
		titulo.add("REGISTRO EJECUCION PRUEBAS DE REGRESION BBS\n");
		// SE AGREGA EL PARAGRAFO AL DOCUMENTO
		getDocumento().add(titulo);
	}

	/* M�todo para a�adir texto al PDF */
	public void setTextoPDF(String Cadena)
	{
		try {
			setParrafo(new Paragraph());
			getParrafo().setFont(FontFactory.getFont("Ebrima", 10, Font.NORMAL));
			getParrafo().setAlignment(Paragraph.ALIGN_LEFT);
			getParrafo().add(Cadena);

			getDocumento().add(getParrafo());
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	public void setTituloPDF(String Cadena)
	{
		try {
			setParrafo(new Paragraph());
			getParrafo().setFont(FontFactory.getFont("Ebrima", 10, Font.BOLD));
			getParrafo().setAlignment(Paragraph.ALIGN_LEFT);
			getParrafo().add(Cadena);

			getDocumento().add(getParrafo());
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	/* M�otdo para agregar una im�gen a un PDF */
	public void setImagenPDF(String ruta)
	{
		Image imagen;
		try {
			imagen = Image.getInstance(ruta);

			imagen.setAlignment(Image.ALIGN_CENTER);
			imagen.setUseVariableBorders(true);
			imagen.scalePercent(15);
			getDocumento().add(imagen);
		} catch (BadElementException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	/* M�todo para cerrar PDF */
	public void closePDF() throws DocumentException
	{
		getDocumento().close();
	}

	public Paragraph getParrafo()
	{
		return parrafo;
	}

	public void setParrafo(Paragraph parrafo)
	{
		this.parrafo = parrafo;
	}

	public Document getDocumento()
	{
		return documento;
	}

	public void setDocumento(Document documento)
	{
		this.documento = documento;
	}

	// METODO QUE RECORTA LA IMAGEN A UNAS MEDIDAS PREESTABLESIDAS
	public void cutImage(String ruta) throws IOException {
		File file = new File(ruta);
		BufferedImage bi = ImageIO.read(file);

		if (bi.getWidth() > 937) {
			bi = bi.getSubimage(0, 0, 937, bi.getHeight());
			ImageIO.write(bi, "jpg", file);
		}
	}

	// FUNCION PARA GUARDAR LAS IMAGENES CAPTURADAS
	public void getCapturaImagen(String Nombre) {	
		try
		{
			String ruta = "C:\\tmp\\BBS\\Imagenes\\" + Nombre + ".png";
			File scrFile = ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);    
			FileUtils.copyFile(scrFile, new File(ruta));
			setImagenPDF(ruta);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	public ArrayList<Datos> ejecutar(String Query) throws SQLException{
		ArrayList<Datos> casos= new ArrayList<>();

		ResultSet rs = this.Consulta(Query);

		while(rs.next()) {
			Datos d = new Datos();
			d.setGrupo(rs.getString("Grupo"));
			d.setCasoPrueba(rs.getString("CasoPrueba"));
			d.setDescripcionCaso(rs.getString("DescripcionCaso"));
			d.setNombreModulo(rs.getString("NombreModulo"));
			d.setSubModulo(rs.getString("SubModulo"));
			d.setNombreProducto(rs.getString("NombreProducto"));
			d.setNroProducto(rs.getString("NroProducto"));
			d.setEstProducto(rs.getString("EstProducto"));
			d.setEjecutar(rs.getBoolean("Ejecutar"));
			d.setResultadoEsperado(rs.getString("ResultadoEsperado"));
			d.setEjecutado(rs.getBoolean("Ejecutado"));
			d.setUsuario(rs.getString("Usuario"));
			d.setPassword(rs.getString("Password"));
			d.setNavegador(rs.getString("Navegador"));
			d.setDescripcionMovimiento(rs.getString("DescripcionMovimiento"));
			d.setTipoMov(rs.getString("TipoMov"));

			casos.add(d);
		}		
		rs.close();

		return casos;
	}

	public String generarNegocio(Datos d) {
		String negocio = "";
		if(d.getNombreProducto().equals("Cuenta Corriente")) {
			negocio = "CC" + d.getNroProducto().substring(d.getNroProducto().length() - 4, d.getNroProducto().length());
		} else if(d.getNombreProducto().equals("Cuenta de Ahorros")) {
			negocio = "CAH" + d.getNroProducto().substring(d.getNroProducto().length() - 4, d.getNroProducto().length());
		} else if(d.getNombreProducto().equals("Tarjeta de Credito")) {
			negocio = "TC" + d.getNroProducto().substring(d.getNroProducto().length() - 4, d.getNroProducto().length());
		}

		return negocio;
	}

}