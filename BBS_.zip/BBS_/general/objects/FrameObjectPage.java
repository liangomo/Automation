package general.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class FrameObjectPage {
	Utilitarios util;
	
	private By frmCompany = By.name("company");
	private By frmGrouping = By.name("grouping");
	private By frmMenu = By.name("menu");
	private By frmMain = By.name("main");
	private By frmXSell = By.name("xsell");	

	public FrameObjectPage(Utilitarios util) {
		this.util = util;
	}

	public void setFrmCompany() {
		util.getDriver().switchTo().frame(this.util.getDriver().findElement(frmCompany));
	}

	public void setFrmGrouping() {
		util.getDriver().switchTo().frame(this.util.getDriver().findElement(frmGrouping));
	}

	public void setFrmMenu() {
		util.getDriver().switchTo().frame(this.util.getDriver().findElement(frmMenu));
	}

	public void setFrmMain() {
		util.getDriver().switchTo().frame(this.util.getDriver().findElement(frmMain));
	}

	public void setFrmXSell() {
		util.getDriver().switchTo().frame(this.util.getDriver().findElement(frmXSell));
	}
	
	public void setFrmDefault() {
		util.getDriver().switchTo().defaultContent();
	}
}