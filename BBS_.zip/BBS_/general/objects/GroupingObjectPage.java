package general.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class GroupingObjectPage {
	Utilitarios util;
	
	private By lnkConsultas = By.name("EWF_BUTTON_GROUP-CONSULTAS");
	private By lnkPagos = By.name("EWF_BUTTON_GROUP-PAGOS");
	private By lnkTransferencias =By.name("EWF_BUTTON_GROUP-TRANSFERENCIAS");
	private By lnkServicioAlCliente =By.name("EWF_BUTTON_GROUP-SERVICIO_CLIENTE");
	private By lnkAdministracion = By.name("EWF_BUTTON_GROUP-ADMINISTRACION");
	private By lnkMonedaExtranjera = By.name("EWF_BUTTON_GROUP-DIVISAS");	
	
	public GroupingObjectPage(Utilitarios util){
		this.util = util;
	}

	public void setLnkConsultas() {
		this.util.getDriver().findElement(lnkConsultas).click();
	}

	public void setLnkPagos() {
		this.util.getDriver().findElement(lnkPagos).click();
	}

	public void setLnkTransferencias() {
		this.util.getDriver().findElement(lnkTransferencias).click();
	}

	public void setLnkServicioAlCliente() {
		this.util.getDriver().findElement(lnkServicioAlCliente).click();
	}

	public void setLnkAdministracion() {
		this.util.getDriver().findElement(lnkAdministracion).click();
	}

	public void setLnkMonedaExtranjera() {
		this.util.getDriver().findElement(lnkMonedaExtranjera).click();
	}
}