package general.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class XSellObjectPage {
	Utilitarios util;
		
	private By selectIrRapido = By.name("JUMP_SELECT");
	private By lnkAyuda = By.xpath("/html/body/form/table/tbody/tr/td[2]/a[1]/font");
	private By lnkImprimir = By.xpath("/html/body/form/table/tbody/tr/td[2]/a[2]/font");
	private By lnkManual = By.xpath("/html/body/form/table/tbody/tr/td[2]/a[3]/font");
	private By lnkLink = By.xpath("/html/body/form/table/tbody/tr/td[2]/a[4]/font");
	private By lnkDemo = By.xpath("/html/body/form/table/tbody/tr/td[2]/a[5]");
	private By lnkTerminarSesion = By.xpath("/html/body/form/table/tbody/tr/td[2]/a[6]/font");
		
	public XSellObjectPage(Utilitarios util){
		this.util = util;
	}

	public void setSelectIrRapido(String select) {
		this.util.getDriver().findElement(selectIrRapido).sendKeys(select);
	}

	public void setLnkAyuda() {
		this.util.getDriver().findElement(lnkAyuda).click();
	}

	public void setLnkImprimir() {
		this.util.getDriver().findElement(lnkImprimir).click();
	}

	public void setLnkManual() {
		this.util.getDriver().findElement(lnkManual).click();
	}

	public void setLnkLink() {
		this.util.getDriver().findElement(lnkLink).click();
	}

	public void setLnkDemo() {
		this.util.getDriver().findElement(lnkDemo).click();
	}

	public void setLnkTerminarSesion() {
		this.util.getDriver().findElement(lnkTerminarSesion).click();
	}
}