package general.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import utilitarios.Utilitarios;

import com.itextpdf.text.Utilities;

public class IndexObjectPage {
	Utilitarios util;	

	private By btnLeido = By.xpath("//*[@id=\"milayer\"]/map/area[2]");
	private By btnVolver = By.xpath("//*[@id=\"milayer\"]/map/area[1]");
	private By btnLeidoIE = By.cssSelector("area[alt=\"LEIDO\"]");
	private By btnVolverIE = By.cssSelector("area[alt=\"VOLVER\"]");
	private By lblErrorAmbiente = By.xpath("/html/body/h1");
	private By imgMatrizNavegacion = By.xpath("//*[@id=\"milayer\"]/img");

	public IndexObjectPage(Utilitarios util){
		this.util = util;
	}

	public By getBtnLeido(String n) {
		if(n.equals("Explorer"))
			return btnVolverIE;
		else
			return btnVolver;
	}

	public void setBtnLeido(String n) {
		if(n.equals("Explorer"))
			this.util.getDriver().findElement(btnLeidoIE).sendKeys(Keys.ENTER);
		else
			this.util.getDriver().findElement(btnLeido).sendKeys(Keys.ENTER);
	}

	public By getBtnVolver(String n) {
		if(n.equals("Explorer"))
			return btnVolverIE;
		else
			return btnVolver;
	}

	public void setBtnVolver(String n) {
		if(n.equals("Explorer"))
			this.util.getDriver().findElement(btnVolverIE).sendKeys(Keys.ENTER);
		else
			this.util.getDriver().findElement(btnVolver).sendKeys(Keys.ENTER);
	}

	public By getLblErrorAmbiente() {
		return lblErrorAmbiente;
	}

	public By getImgMatrizNavegacion() {
		return imgMatrizNavegacion;
	}
}