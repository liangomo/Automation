package general.objects;

import org.openqa.selenium.By;

import utilitarios.Utilitarios;

public class LoginObjectPage {
	Utilitarios util;
	
	private By txtUsuario = By.name("RqrdAN000Usuario");
	private By txtPassword = By.name("RqrdAN000Clave");
	private By btnIngresar = By.cssSelector("input.btn");
	private By btnBorrar = By.xpath("/html/body/form/table[1]/tbody/tr[5]/td/input[2]");
	private By lblIngresoFallido = By.xpath("/html/body/form/div/font/b");
	
	public LoginObjectPage(Utilitarios util){
		this.util = util;
	}

	public void setTxtUsuario(String text) {
		this.util.getDriver().findElement(txtUsuario).sendKeys(text);
	}

	public void setTxtPassword(String text) {
		this.util.getDriver().findElement(txtPassword).sendKeys(text);
	}

	public void setBtnIngresar() {
		this.util.getDriver().findElement(btnIngresar).click();
	}

	public void setBtnBorrar() {
		this.util.getDriver().findElement(btnBorrar).click();
	}

	public By getLblIngresoFallido() {
		return lblIngresoFallido;
	}
}