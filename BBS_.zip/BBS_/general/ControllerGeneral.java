package general;

import general.views.FramePage;
import general.views.GroupingPage;
import general.views.IndexPage;
import general.views.LoginPage;

import org.omg.PortableServer.THREAD_POLICY_ID;

import utilitarios.Datos;
import utilitarios.Utilitarios;
import consultas.ControllerConsultas;
import consultas.views.ConsolidadoCuentasPage;
import consultas.views.MenuConsultasPage;
import consultas.views.MovimientosCuentaPage;
import consultas.views.ResumenProductosPage;

public class ControllerGeneral {
	Utilitarios util;
	static IndexPage index;
	static LoginPage login;
	static FramePage frame;
	static GroupingPage grouping;
	String url = "https://test2.bancodebogota.com.co";

	public ControllerGeneral(Utilitarios util){
		this.util = util;
		index = new IndexPage(this.util);
		login = new LoginPage(this.util);
		frame = new FramePage(this.util);
		grouping = new GroupingPage(this.util);
	}

	public void navegador(String nav) throws InterruptedException {
		switch(nav) {
		case "Chrome":
			util.getChrome(url);
			break;
		case "Mozilla":
			util.getFirefox(url);
			break;
		case "Explorer":
			util.getExplorer(url);
			break;
		}
	}

	public String ingreso(Datos d) throws InterruptedException {
		navegador(d.getNavegador());

		Thread.sleep(5000);

		String valida = index.validarImagen(d.getNavegador());

		this.util.setTituloPDF(d.getCasoPrueba() + " - " + d.getNavegador());
		this.util.setTextoPDF("Descripcion: " + d.getDescripcionCaso());
		this.util.setTextoPDF("Resultado Esperado: " + d.getResultadoEsperado());


		if(valida.equals("Matriz de Navegaci�n y Botones Correctos")) {
			if(d.getUsuario().length() > 0) {	
				index.leido(d.getNavegador());
				if(index.errorAmb().equals(""))
				{
					valida = login.login(d);
					this.util.getCapturaImagen(d.getCasoPrueba() + "_ValidacionLogin_" + d.getNavegador());
				}
				else 
					valida = index.errorAmb();
			}
			else 
				this.util.getCapturaImagen(d.getCasoPrueba() + "_ValidacionPantalla_" + d.getNavegador());
		}
		return valida;
	}

	public void cambioFrame(String f) throws InterruptedException {
		switch(f) {
		case "GROUPING":
			frame.frameGrouping();
			break;
		case "COMPANY":
			frame.frameCompany();
			break;
		case "DEFAULT":
			frame.frameDefault();
			break;
		case "MAIN":
			frame.frameMain();
			break;
		case "MENU":
			frame.frameMenu();
			break;
		case "XSELL":
			frame.frameXSell();
			break;
		}
	}

	public void modulo(String m) throws InterruptedException {
		switch(m) {
		case "CONSULTAS":
			grouping.Consultas();
			break;
		case "TRANSFERENCIAS":
			grouping.Transferencias();
			break;
		case "SERVICIO AL CLIENTE":
			grouping.ServicioAlCliente();
			break;
		case "ADMINISTRACION":
			grouping.Administracion();
			break;
		case "MONEDA EXTRANJERA":
			grouping.MonedaExtranjera();
			break;
		}
	}
}