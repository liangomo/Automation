package general.views;

import general.objects.GroupingObjectPage;

import consultas.views.ConsolidadoCuentasPage;
import utilitarios.Utilitarios;

public class GroupingPage {
	Utilitarios util;
	GroupingObjectPage grouping;
	
	public GroupingPage(Utilitarios util){
		this.util = util;
		grouping = new GroupingObjectPage(util); 
	}
	
	public void Administracion() throws InterruptedException{
		System.out.println("Ingresa modulo Administraci�n");
		grouping.setLnkAdministracion();
		Thread.sleep(2500);
	}
	
	public void Consultas() throws InterruptedException{
		System.out.println("Ingresa modulo Consultas");
		grouping.setLnkConsultas();
		Thread.sleep(2500);
	}
	
	public void MonedaExtranjera() throws InterruptedException{
		System.out.println("Ingresa modulo Moneda Extranjera");
		grouping.setLnkMonedaExtranjera();
		Thread.sleep(2500);
	}
	
	public void Pagos() throws InterruptedException{
		System.out.println("Ingresa modulo Pagos");
		grouping.setLnkPagos();
		Thread.sleep(2500);
	}
	
	public void ServicioAlCliente() throws InterruptedException{
		System.out.println("Ingresa modulo Servicion Al Cliente");
		grouping.setLnkServicioAlCliente();
		Thread.sleep(2500);
	}
	
	public void Transferencias() throws InterruptedException{
		System.out.println("Ingresa modulo Transferencias");
		grouping.setLnkTransferencias();
		Thread.sleep(2500);
	}
}