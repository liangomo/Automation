package general.views;

import pagos.objects.MenuPagosObjectPage;
import utilitarios.Utilitarios;

public class MenuPagosPage {
	Utilitarios util;
	MenuPagosObjectPage menu;
	
	public MenuPagosPage(Utilitarios util){
		this.util = util;
		menu = new MenuPagosObjectPage(util); 
	}
	
	public void Pagos() throws InterruptedException{
		menu.clickLnkPagos();
		Thread.sleep(2500);
	}
	
	public void PagosVirtuales()throws InterruptedException{
		menu.clickLnkPagosVirtuales();
		Thread.sleep(2500);
	}
	
	public void ConsultaPagosProgramados()throws InterruptedException{
		menu.clickLnkConsultaPagosProgramados();
		Thread.sleep(2500);
	}
	
	public void AdministracionBeneficiarios()throws InterruptedException{
		menu.clickLnkAdministracionBeneficiarios();
		Thread.sleep(2500);
	}
	
	public void PagoNomina()throws InterruptedException{
		menu.clickLnkPagoNomina();
		Thread.sleep(2500);
	}
	
	public void HistoricoNomina()throws InterruptedException{
		menu.clickLnkHistoricoNomina();
		Thread.sleep(2500);
	}
	
	public void ActivarRangoCheques()throws InterruptedException{
		menu.clickLnkActivarRangoCh();
		Thread.sleep(2500);
	}
}