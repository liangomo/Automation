package general.views;

import general.objects.FrameObjectPage;
import general.objects.LoginObjectPage;

import utilitarios.Utilitarios;

public class FramePage {
	Utilitarios util;
	FrameObjectPage frame;
	
	public FramePage(Utilitarios util){
		this.util = util;
		frame = new FrameObjectPage(util); 
	}

	public void frameCompany() throws InterruptedException{
		frame.setFrmCompany();
		Thread.sleep(5000);
	}

	public void frameGrouping() throws InterruptedException{
		frame.setFrmGrouping();
		Thread.sleep(5000);
	}

	public void frameMain() throws InterruptedException{
		frame.setFrmMain();
		Thread.sleep(5000);
	}

	public void frameMenu() throws InterruptedException{
		frame.setFrmMenu();
		Thread.sleep(5000);
	}

	public void frameXSell() throws InterruptedException{
		frame.setFrmXSell();
		Thread.sleep(5000);
	}

	public void frameDefault() throws InterruptedException{
		frame.setFrmDefault();
		Thread.sleep(5000);
	}
}