package general.views;

import general.objects.IndexObjectPage;
import general.objects.LoginObjectPage;

import utilitarios.Datos;
import utilitarios.Utilitarios;

public class LoginPage {
	Utilitarios util;
	LoginObjectPage login;
	
	public LoginPage(Utilitarios util){
		this.util = util;
		login = new LoginObjectPage(util); 
	}
	
	public String login(Datos d) throws InterruptedException{
		login.setTxtUsuario(d.getUsuario());
		login.setTxtPassword(d.getPassword());
		
		this.util.getCapturaImagen(d.getCasoPrueba() + "_Login_" + d.getNavegador());
		
		login.setBtnIngresar();
		Thread.sleep(5000);
		
		if(this.util.buscarObjeto(login.getLblIngresoFallido()))
			return this.util.getDriver().findElement(login.getLblIngresoFallido()).getText();
		else
			return "Ingreso Exitoso";
	}
}