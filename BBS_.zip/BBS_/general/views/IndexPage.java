package general.views;

import general.objects.IndexObjectPage;

import utilitarios.Utilitarios;;

public class IndexPage {
	Utilitarios util;
	IndexObjectPage index;
	
	public IndexPage(Utilitarios util){
		this.util = util;
		index = new IndexObjectPage(util); 
	}
	
	public void leido(String navegador){
		System.out.println("Click Boton Leido");
		index.setBtnLeido(navegador);
	}
	
	public void volver(String navegador){
		System.out.println("Click Boton Volver");
		index.setBtnVolver(navegador);
	}
	
	public String errorAmb() {
		if(this.util.buscarObjeto(index.getLblErrorAmbiente()))
			return this.util.getDriver().findElement(index.getLblErrorAmbiente()).getText();
		else
			return "";
	}
	
	public String validarImagen(String navegador) throws InterruptedException {
		boolean validaImagen = util.buscarObjeto(index.getImgMatrizNavegacion());
		boolean validaLeido = util.buscarObjeto(index.getBtnLeido(navegador));
		boolean validaVolver = util.buscarObjeto(index.getBtnVolver(navegador));
		
		if(!validaImagen)
			return "No se evidencia Matriz de Navegaci�n";
		else if(!validaLeido)
			return "No se evidencia Boton Leido";
		else if(!validaVolver)
			return "No se evidencia Boton Volver";
		else
			return "Matriz de Navegaci�n y Botones Correctos";
	}
}