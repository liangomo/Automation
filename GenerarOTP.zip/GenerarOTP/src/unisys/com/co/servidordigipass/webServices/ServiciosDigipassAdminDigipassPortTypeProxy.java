package unisys.com.co.servidordigipass.webServices;

public class ServiciosDigipassAdminDigipassPortTypeProxy implements unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassPortType {
  private String _endpoint = null;
  private unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassPortType serviciosDigipassAdminDigipassPortType = null;
  
  public ServiciosDigipassAdminDigipassPortTypeProxy() {
    _initServiciosDigipassAdminDigipassPortTypeProxy();
  }
  
  public ServiciosDigipassAdminDigipassPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initServiciosDigipassAdminDigipassPortTypeProxy();
  }
  
  private void _initServiciosDigipassAdminDigipassPortTypeProxy() {
    try {
      serviciosDigipassAdminDigipassPortType = (new unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassLocator()).getServiciosDigipassAdminDigipassSOAP11port_http();
      if (serviciosDigipassAdminDigipassPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)serviciosDigipassAdminDigipassPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)serviciosDigipassAdminDigipassPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (serviciosDigipassAdminDigipassPortType != null)
      ((javax.xml.rpc.Stub)serviciosDigipassAdminDigipassPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassPortType getServiciosDigipassAdminDigipassPortType() {
    if (serviciosDigipassAdminDigipassPortType == null)
      _initServiciosDigipassAdminDigipassPortTypeProxy();
    return serviciosDigipassAdminDigipassPortType;
  }
  
  
}