/**
 * ClienteCanalDigipassRangoVO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package unisys.com.co.servidordigipass.webServices.vo.xsd;

public class ClienteCanalDigipassRangoVO  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -2566168152169621569L;

	private java.lang.String banco;

    private java.lang.String canal;

    private java.lang.String numeroIdCliente;

    private java.lang.String numeroIdUsuario;

    private java.lang.String serialFinal;

    private java.lang.String serialInicial;

    private java.lang.String tipoIdCliente;

    private java.lang.String tipoIdUsuario;

    public ClienteCanalDigipassRangoVO() {
    }

    public ClienteCanalDigipassRangoVO(
           java.lang.String banco,
           java.lang.String canal,
           java.lang.String numeroIdCliente,
           java.lang.String numeroIdUsuario,
           java.lang.String serialFinal,
           java.lang.String serialInicial,
           java.lang.String tipoIdCliente,
           java.lang.String tipoIdUsuario) {
           this.banco = banco;
           this.canal = canal;
           this.numeroIdCliente = numeroIdCliente;
           this.numeroIdUsuario = numeroIdUsuario;
           this.serialFinal = serialFinal;
           this.serialInicial = serialInicial;
           this.tipoIdCliente = tipoIdCliente;
           this.tipoIdUsuario = tipoIdUsuario;
    }


    /**
     * Gets the banco value for this ClienteCanalDigipassRangoVO.
     * 
     * @return banco
     */
    public java.lang.String getBanco() {
        return banco;
    }


    /**
     * Sets the banco value for this ClienteCanalDigipassRangoVO.
     * 
     * @param banco
     */
    public void setBanco(java.lang.String banco) {
        this.banco = banco;
    }


    /**
     * Gets the canal value for this ClienteCanalDigipassRangoVO.
     * 
     * @return canal
     */
    public java.lang.String getCanal() {
        return canal;
    }


    /**
     * Sets the canal value for this ClienteCanalDigipassRangoVO.
     * 
     * @param canal
     */
    public void setCanal(java.lang.String canal) {
        this.canal = canal;
    }


    /**
     * Gets the numeroIdCliente value for this ClienteCanalDigipassRangoVO.
     * 
     * @return numeroIdCliente
     */
    public java.lang.String getNumeroIdCliente() {
        return numeroIdCliente;
    }


    /**
     * Sets the numeroIdCliente value for this ClienteCanalDigipassRangoVO.
     * 
     * @param numeroIdCliente
     */
    public void setNumeroIdCliente(java.lang.String numeroIdCliente) {
        this.numeroIdCliente = numeroIdCliente;
    }


    /**
     * Gets the numeroIdUsuario value for this ClienteCanalDigipassRangoVO.
     * 
     * @return numeroIdUsuario
     */
    public java.lang.String getNumeroIdUsuario() {
        return numeroIdUsuario;
    }


    /**
     * Sets the numeroIdUsuario value for this ClienteCanalDigipassRangoVO.
     * 
     * @param numeroIdUsuario
     */
    public void setNumeroIdUsuario(java.lang.String numeroIdUsuario) {
        this.numeroIdUsuario = numeroIdUsuario;
    }


    /**
     * Gets the serialFinal value for this ClienteCanalDigipassRangoVO.
     * 
     * @return serialFinal
     */
    public java.lang.String getSerialFinal() {
        return serialFinal;
    }


    /**
     * Sets the serialFinal value for this ClienteCanalDigipassRangoVO.
     * 
     * @param serialFinal
     */
    public void setSerialFinal(java.lang.String serialFinal) {
        this.serialFinal = serialFinal;
    }


    /**
     * Gets the serialInicial value for this ClienteCanalDigipassRangoVO.
     * 
     * @return serialInicial
     */
    public java.lang.String getSerialInicial() {
        return serialInicial;
    }


    /**
     * Sets the serialInicial value for this ClienteCanalDigipassRangoVO.
     * 
     * @param serialInicial
     */
    public void setSerialInicial(java.lang.String serialInicial) {
        this.serialInicial = serialInicial;
    }


    /**
     * Gets the tipoIdCliente value for this ClienteCanalDigipassRangoVO.
     * 
     * @return tipoIdCliente
     */
    public java.lang.String getTipoIdCliente() {
        return tipoIdCliente;
    }


    /**
     * Sets the tipoIdCliente value for this ClienteCanalDigipassRangoVO.
     * 
     * @param tipoIdCliente
     */
    public void setTipoIdCliente(java.lang.String tipoIdCliente) {
        this.tipoIdCliente = tipoIdCliente;
    }


    /**
     * Gets the tipoIdUsuario value for this ClienteCanalDigipassRangoVO.
     * 
     * @return tipoIdUsuario
     */
    public java.lang.String getTipoIdUsuario() {
        return tipoIdUsuario;
    }


    /**
     * Sets the tipoIdUsuario value for this ClienteCanalDigipassRangoVO.
     * 
     * @param tipoIdUsuario
     */
    public void setTipoIdUsuario(java.lang.String tipoIdUsuario) {
        this.tipoIdUsuario = tipoIdUsuario;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ClienteCanalDigipassRangoVO)) return false;
        ClienteCanalDigipassRangoVO other = (ClienteCanalDigipassRangoVO) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.banco==null && other.getBanco()==null) || 
             (this.banco!=null &&
              this.banco.equals(other.getBanco()))) &&
            ((this.canal==null && other.getCanal()==null) || 
             (this.canal!=null &&
              this.canal.equals(other.getCanal()))) &&
            ((this.numeroIdCliente==null && other.getNumeroIdCliente()==null) || 
             (this.numeroIdCliente!=null &&
              this.numeroIdCliente.equals(other.getNumeroIdCliente()))) &&
            ((this.numeroIdUsuario==null && other.getNumeroIdUsuario()==null) || 
             (this.numeroIdUsuario!=null &&
              this.numeroIdUsuario.equals(other.getNumeroIdUsuario()))) &&
            ((this.serialFinal==null && other.getSerialFinal()==null) || 
             (this.serialFinal!=null &&
              this.serialFinal.equals(other.getSerialFinal()))) &&
            ((this.serialInicial==null && other.getSerialInicial()==null) || 
             (this.serialInicial!=null &&
              this.serialInicial.equals(other.getSerialInicial()))) &&
            ((this.tipoIdCliente==null && other.getTipoIdCliente()==null) || 
             (this.tipoIdCliente!=null &&
              this.tipoIdCliente.equals(other.getTipoIdCliente()))) &&
            ((this.tipoIdUsuario==null && other.getTipoIdUsuario()==null) || 
             (this.tipoIdUsuario!=null &&
              this.tipoIdUsuario.equals(other.getTipoIdUsuario())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBanco() != null) {
            _hashCode += getBanco().hashCode();
        }
        if (getCanal() != null) {
            _hashCode += getCanal().hashCode();
        }
        if (getNumeroIdCliente() != null) {
            _hashCode += getNumeroIdCliente().hashCode();
        }
        if (getNumeroIdUsuario() != null) {
            _hashCode += getNumeroIdUsuario().hashCode();
        }
        if (getSerialFinal() != null) {
            _hashCode += getSerialFinal().hashCode();
        }
        if (getSerialInicial() != null) {
            _hashCode += getSerialInicial().hashCode();
        }
        if (getTipoIdCliente() != null) {
            _hashCode += getTipoIdCliente().hashCode();
        }
        if (getTipoIdUsuario() != null) {
            _hashCode += getTipoIdUsuario().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ClienteCanalDigipassRangoVO.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassRangoVO"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("banco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "banco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "canal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroIdCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "numeroIdCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroIdUsuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "numeroIdUsuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serialFinal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "serialFinal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serialInicial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "serialInicial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoIdCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "tipoIdCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoIdUsuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "tipoIdUsuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
