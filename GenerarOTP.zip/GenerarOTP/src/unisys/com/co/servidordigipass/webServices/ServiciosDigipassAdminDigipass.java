/**
 * ServiciosDigipassAdminDigipass.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package unisys.com.co.servidordigipass.webServices;

public interface ServiciosDigipassAdminDigipass extends javax.xml.rpc.Service {
    public java.lang.String getServiciosDigipassAdminDigipassSOAP11port_httpAddress();

    public unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassPortType getServiciosDigipassAdminDigipassSOAP11port_http() throws javax.xml.rpc.ServiceException;

    public unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassPortType getServiciosDigipassAdminDigipassSOAP11port_http(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
