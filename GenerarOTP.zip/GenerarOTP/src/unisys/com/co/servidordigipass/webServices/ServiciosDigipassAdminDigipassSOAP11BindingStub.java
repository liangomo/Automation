/**
 * ServiciosDigipassAdminDigipassSOAP11BindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package unisys.com.co.servidordigipass.webServices;

public class ServiciosDigipassAdminDigipassSOAP11BindingStub extends org.apache.axis.client.Stub implements unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassPortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[17];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("reasignarDigipassIndvAdmon");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_asignarDigipassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("bloquearDigipass");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_bloquearDigipassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "CanalDigipassCausalVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.CanalDigipassCausalVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("asignarDigipassAut");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_asignarDigipassAutIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "AsignacionAutVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.AsignacionAutVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaAsignacionAut"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaAsignacionAut.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("asignarDigipass");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_asignarDigipassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("generarOTP");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_generarOTPIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaValidaOTP"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaValidaOTP.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("RevAsigDigiPassCA");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_revAsigDigiPassCA"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassRangoVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassRangoVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("anularDigipass");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_anularDigipassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "CanalDigipassCausalVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.CanalDigipassCausalVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("desBloquearDigipass");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_desBloquearDigipassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "CanalDigipassVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.CanalDigipassVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("activarDigipassCodActivacion");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_activarDigipassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ActivarDigiPassCodActivacionVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ActivarDigiPassCodActivacionVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaActivacion"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("asignarDigipassClienteAdmin");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_asignarDigipassClienteAdmin"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassRangoVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassRangoVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("asignarDigipassPorRango");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_asignarDigipassPorRangoIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassRangoVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassRangoVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("activarDigipass");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_activarDigipassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CodigoActivacionMobile");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_CodigoActivacionMobileIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaActivacion"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("desAsignarDigipass");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_desAsignarDigipassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("sincronizarDigipass");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_sincronizarDigipassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipass2OtpVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipass2OtpVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("RevAsigDigiPass");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_RevAsigDigiPassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("liberarDigipass");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "_liberarDigipassIn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "CanalDigipassVO"), unisys.com.co.servidordigipass.webServices.vo.xsd.CanalDigipassVO.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc"));
        oper.setReturnClass(unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[16] = oper;

    }

    public ServiciosDigipassAdminDigipassSOAP11BindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public ServiciosDigipassAdminDigipassSOAP11BindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    @SuppressWarnings({ "unused", "rawtypes", "unchecked" })
	public ServiciosDigipassAdminDigipassSOAP11BindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
			java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaActivacion");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaAsignacionAut");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaAsignacionAut.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaCodDesc");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://vo.ejb.servidordigipass.co.com.unisys/xsd", "RespuestaValidaOTP");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaValidaOTP.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ActivarDigiPassCodActivacionVO");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.webServices.vo.xsd.ActivarDigiPassCodActivacionVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "AsignacionAutVO");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.webServices.vo.xsd.AsignacionAutVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "CanalDigipassCausalVO");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.webServices.vo.xsd.CanalDigipassCausalVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "CanalDigipassVO");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.webServices.vo.xsd.CanalDigipassVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipass2OtpVO");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipass2OtpVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassRangoVO");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassRangoVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassVO");
            cachedSerQNames.add(qName);
            cls = unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    @SuppressWarnings("rawtypes")
	protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc reasignarDigipassIndvAdmon(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO _asignarDigipassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:reasignarDigipassIndvAdmon");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "reasignarDigipassIndvAdmon"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_asignarDigipassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc bloquearDigipass(unisys.com.co.servidordigipass.webServices.vo.xsd.CanalDigipassCausalVO _bloquearDigipassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:bloquearDigipass");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "bloquearDigipass"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_bloquearDigipassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaAsignacionAut asignarDigipassAut(unisys.com.co.servidordigipass.webServices.vo.xsd.AsignacionAutVO _asignarDigipassAutIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:asignarDigipassAut");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "asignarDigipassAut"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_asignarDigipassAutIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaAsignacionAut) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaAsignacionAut) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaAsignacionAut.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc asignarDigipass(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO _asignarDigipassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:asignarDigipass");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "asignarDigipass"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_asignarDigipassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaValidaOTP generarOTP(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO _generarOTPIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:generarOTP");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "generarOTP"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_generarOTPIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaValidaOTP) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaValidaOTP) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaValidaOTP.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc revAsigDigiPassCA(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassRangoVO _revAsigDigiPassCA) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:RevAsigDigiPassCA");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "RevAsigDigiPassCA"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_revAsigDigiPassCA});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc anularDigipass(unisys.com.co.servidordigipass.webServices.vo.xsd.CanalDigipassCausalVO _anularDigipassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:anularDigipass");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "anularDigipass"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_anularDigipassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc desBloquearDigipass(unisys.com.co.servidordigipass.webServices.vo.xsd.CanalDigipassVO _desBloquearDigipassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:desBloquearDigipass");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "desBloquearDigipass"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_desBloquearDigipassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion activarDigipassCodActivacion(unisys.com.co.servidordigipass.webServices.vo.xsd.ActivarDigiPassCodActivacionVO _activarDigipassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:activarDigipassCodActivacion");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "activarDigipassCodActivacion"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_activarDigipassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc asignarDigipassClienteAdmin(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassRangoVO _asignarDigipassClienteAdmin) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:asignarDigipassClienteAdmin");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "asignarDigipassClienteAdmin"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_asignarDigipassClienteAdmin});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc asignarDigipassPorRango(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassRangoVO _asignarDigipassPorRangoIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:asignarDigipassPorRango");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "asignarDigipassPorRango"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_asignarDigipassPorRangoIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc activarDigipass(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO _activarDigipassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:activarDigipass");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "activarDigipass"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_activarDigipassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion codigoActivacionMobile(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO _CodigoActivacionMobileIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:CodigoActivacionMobile");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "CodigoActivacionMobile"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_CodigoActivacionMobileIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaActivacion.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc desAsignarDigipass(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO _desAsignarDigipassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:desAsignarDigipass");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "desAsignarDigipass"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_desAsignarDigipassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc sincronizarDigipass(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipass2OtpVO _sincronizarDigipassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:sincronizarDigipass");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "sincronizarDigipass"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_sincronizarDigipassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc revAsigDigiPass(unisys.com.co.servidordigipass.webServices.vo.xsd.ClienteCanalDigipassVO _RevAsigDigiPassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:RevAsigDigiPass");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "RevAsigDigiPass"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_RevAsigDigiPassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc liberarDigipass(unisys.com.co.servidordigipass.webServices.vo.xsd.CanalDigipassVO _liberarDigipassIn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:liberarDigipass");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys/xsd", "liberarDigipass"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {_liberarDigipassIn});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) _resp;
            } catch (java.lang.Exception _exception) {
                return (unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc) org.apache.axis.utils.JavaUtils.convert(_resp, unisys.com.co.servidordigipass.ejb.vo.xsd.RespuestaCodDesc.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
