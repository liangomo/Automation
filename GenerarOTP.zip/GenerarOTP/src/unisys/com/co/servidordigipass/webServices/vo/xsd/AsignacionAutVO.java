/**
 * AsignacionAutVO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package unisys.com.co.servidordigipass.webServices.vo.xsd;

public class AsignacionAutVO  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -3100466044133259652L;

	private java.lang.String banco;

    private java.lang.String canal;

    private java.lang.String llave;

    private java.lang.String modelo;

    private java.lang.String nombreCliente;

    private java.lang.String numeroIdCliente;

    private java.lang.String serial;

    private java.lang.String tipoIdCliente;

    public AsignacionAutVO() {
    }

    public AsignacionAutVO(
           java.lang.String banco,
           java.lang.String canal,
           java.lang.String llave,
           java.lang.String modelo,
           java.lang.String nombreCliente,
           java.lang.String numeroIdCliente,
           java.lang.String serial,
           java.lang.String tipoIdCliente) {
           this.banco = banco;
           this.canal = canal;
           this.llave = llave;
           this.modelo = modelo;
           this.nombreCliente = nombreCliente;
           this.numeroIdCliente = numeroIdCliente;
           this.serial = serial;
           this.tipoIdCliente = tipoIdCliente;
    }


    /**
     * Gets the banco value for this AsignacionAutVO.
     * 
     * @return banco
     */
    public java.lang.String getBanco() {
        return banco;
    }


    /**
     * Sets the banco value for this AsignacionAutVO.
     * 
     * @param banco
     */
    public void setBanco(java.lang.String banco) {
        this.banco = banco;
    }


    /**
     * Gets the canal value for this AsignacionAutVO.
     * 
     * @return canal
     */
    public java.lang.String getCanal() {
        return canal;
    }


    /**
     * Sets the canal value for this AsignacionAutVO.
     * 
     * @param canal
     */
    public void setCanal(java.lang.String canal) {
        this.canal = canal;
    }


    /**
     * Gets the llave value for this AsignacionAutVO.
     * 
     * @return llave
     */
    public java.lang.String getLlave() {
        return llave;
    }


    /**
     * Sets the llave value for this AsignacionAutVO.
     * 
     * @param llave
     */
    public void setLlave(java.lang.String llave) {
        this.llave = llave;
    }


    /**
     * Gets the modelo value for this AsignacionAutVO.
     * 
     * @return modelo
     */
    public java.lang.String getModelo() {
        return modelo;
    }


    /**
     * Sets the modelo value for this AsignacionAutVO.
     * 
     * @param modelo
     */
    public void setModelo(java.lang.String modelo) {
        this.modelo = modelo;
    }


    /**
     * Gets the nombreCliente value for this AsignacionAutVO.
     * 
     * @return nombreCliente
     */
    public java.lang.String getNombreCliente() {
        return nombreCliente;
    }


    /**
     * Sets the nombreCliente value for this AsignacionAutVO.
     * 
     * @param nombreCliente
     */
    public void setNombreCliente(java.lang.String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }


    /**
     * Gets the numeroIdCliente value for this AsignacionAutVO.
     * 
     * @return numeroIdCliente
     */
    public java.lang.String getNumeroIdCliente() {
        return numeroIdCliente;
    }


    /**
     * Sets the numeroIdCliente value for this AsignacionAutVO.
     * 
     * @param numeroIdCliente
     */
    public void setNumeroIdCliente(java.lang.String numeroIdCliente) {
        this.numeroIdCliente = numeroIdCliente;
    }


    /**
     * Gets the serial value for this AsignacionAutVO.
     * 
     * @return serial
     */
    public java.lang.String getSerial() {
        return serial;
    }


    /**
     * Sets the serial value for this AsignacionAutVO.
     * 
     * @param serial
     */
    public void setSerial(java.lang.String serial) {
        this.serial = serial;
    }


    /**
     * Gets the tipoIdCliente value for this AsignacionAutVO.
     * 
     * @return tipoIdCliente
     */
    public java.lang.String getTipoIdCliente() {
        return tipoIdCliente;
    }


    /**
     * Sets the tipoIdCliente value for this AsignacionAutVO.
     * 
     * @param tipoIdCliente
     */
    public void setTipoIdCliente(java.lang.String tipoIdCliente) {
        this.tipoIdCliente = tipoIdCliente;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AsignacionAutVO)) return false;
        AsignacionAutVO other = (AsignacionAutVO) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.banco==null && other.getBanco()==null) || 
             (this.banco!=null &&
              this.banco.equals(other.getBanco()))) &&
            ((this.canal==null && other.getCanal()==null) || 
             (this.canal!=null &&
              this.canal.equals(other.getCanal()))) &&
            ((this.llave==null && other.getLlave()==null) || 
             (this.llave!=null &&
              this.llave.equals(other.getLlave()))) &&
            ((this.modelo==null && other.getModelo()==null) || 
             (this.modelo!=null &&
              this.modelo.equals(other.getModelo()))) &&
            ((this.nombreCliente==null && other.getNombreCliente()==null) || 
             (this.nombreCliente!=null &&
              this.nombreCliente.equals(other.getNombreCliente()))) &&
            ((this.numeroIdCliente==null && other.getNumeroIdCliente()==null) || 
             (this.numeroIdCliente!=null &&
              this.numeroIdCliente.equals(other.getNumeroIdCliente()))) &&
            ((this.serial==null && other.getSerial()==null) || 
             (this.serial!=null &&
              this.serial.equals(other.getSerial()))) &&
            ((this.tipoIdCliente==null && other.getTipoIdCliente()==null) || 
             (this.tipoIdCliente!=null &&
              this.tipoIdCliente.equals(other.getTipoIdCliente())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBanco() != null) {
            _hashCode += getBanco().hashCode();
        }
        if (getCanal() != null) {
            _hashCode += getCanal().hashCode();
        }
        if (getLlave() != null) {
            _hashCode += getLlave().hashCode();
        }
        if (getModelo() != null) {
            _hashCode += getModelo().hashCode();
        }
        if (getNombreCliente() != null) {
            _hashCode += getNombreCliente().hashCode();
        }
        if (getNumeroIdCliente() != null) {
            _hashCode += getNumeroIdCliente().hashCode();
        }
        if (getSerial() != null) {
            _hashCode += getSerial().hashCode();
        }
        if (getTipoIdCliente() != null) {
            _hashCode += getTipoIdCliente().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AsignacionAutVO.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "AsignacionAutVO"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("banco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "banco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "canal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("llave");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "llave"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modelo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "modelo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "nombreCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroIdCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "numeroIdCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "serial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoIdCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "tipoIdCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
