/**
 * ServiciosDigipassAdminDigipassLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package unisys.com.co.servidordigipass.webServices;
import unisys.com.co.servidordigipass.webServices.vo.xsd.*;
import unisys.com.co.servidordigipass.*;

public class ServiciosDigipassAdminDigipassLocator extends org.apache.axis.client.Service implements unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipass {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServiciosDigipassAdminDigipassLocator() {
    }


    public ServiciosDigipassAdminDigipassLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ServiciosDigipassAdminDigipassLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ServiciosDigipassAdminDigipassSOAP11port_http
    private java.lang.String ServiciosDigipassAdminDigipassSOAP11port_http_address = "http://10.86.83.126:8080/axis2/services/ServiciosDigipassAdminDigipass";

    public java.lang.String getServiciosDigipassAdminDigipassSOAP11port_httpAddress() {
        return ServiciosDigipassAdminDigipassSOAP11port_http_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ServiciosDigipassAdminDigipassSOAP11port_httpWSDDServiceName = "ServiciosDigipassAdminDigipassSOAP11port_http";

    public java.lang.String getServiciosDigipassAdminDigipassSOAP11port_httpWSDDServiceName() {
        return ServiciosDigipassAdminDigipassSOAP11port_httpWSDDServiceName;
    }

    public void setServiciosDigipassAdminDigipassSOAP11port_httpWSDDServiceName(java.lang.String name) {
        ServiciosDigipassAdminDigipassSOAP11port_httpWSDDServiceName = name;
    }

    public unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassPortType getServiciosDigipassAdminDigipassSOAP11port_http() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ServiciosDigipassAdminDigipassSOAP11port_http_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getServiciosDigipassAdminDigipassSOAP11port_http(endpoint);
    }

    public unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassPortType getServiciosDigipassAdminDigipassSOAP11port_http(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassSOAP11BindingStub _stub = new unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassSOAP11BindingStub(portAddress, this);
            _stub.setPortName(getServiciosDigipassAdminDigipassSOAP11port_httpWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setServiciosDigipassAdminDigipassSOAP11port_httpEndpointAddress(java.lang.String address) {
        ServiciosDigipassAdminDigipassSOAP11port_http_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassSOAP11BindingStub _stub = new unisys.com.co.servidordigipass.webServices.ServiciosDigipassAdminDigipassSOAP11BindingStub(new java.net.URL(ServiciosDigipassAdminDigipassSOAP11port_http_address), this);
                _stub.setPortName(getServiciosDigipassAdminDigipassSOAP11port_httpWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ServiciosDigipassAdminDigipassSOAP11port_http".equals(inputPortName)) {
            return getServiciosDigipassAdminDigipassSOAP11port_http();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys", "ServiciosDigipassAdminDigipass");
    }

    private java.util.HashSet ports = null;

    @SuppressWarnings("unchecked")
	public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://webServices.servidordigipass.co.com.unisys", "ServiciosDigipassAdminDigipassSOAP11port_http"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ServiciosDigipassAdminDigipassSOAP11port_http".equals(portName)) {
            setServiciosDigipassAdminDigipassSOAP11port_httpEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
