/**
 * ClienteCanalDigipassVO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package unisys.com.co.servidordigipass.webServices.vo.xsd;

public class ClienteCanalDigipassVO  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -2370365753394400639L;

	private java.lang.String banco;

    private java.lang.String canal;

    private java.lang.String numeroIdCliente;

    private java.lang.String numeroIdUsuario;

    private java.lang.String serial;

    private java.lang.String tipoIdCliente;

    private java.lang.String tipoIdUsuario;

    public ClienteCanalDigipassVO() {
    }

    public ClienteCanalDigipassVO(
           java.lang.String banco,
           java.lang.String canal,
           java.lang.String numeroIdCliente,
           java.lang.String numeroIdUsuario,
           java.lang.String serial,
           java.lang.String tipoIdCliente,
           java.lang.String tipoIdUsuario) {
           this.banco = banco;
           this.canal = canal;
           this.numeroIdCliente = numeroIdCliente;
           this.numeroIdUsuario = numeroIdUsuario;
           this.serial = serial;
           this.tipoIdCliente = tipoIdCliente;
           this.tipoIdUsuario = tipoIdUsuario;
    }


    /**
     * Gets the banco value for this ClienteCanalDigipassVO.
     * 
     * @return banco
     */
    public java.lang.String getBanco() {
        return banco;
    }


    /**
     * Sets the banco value for this ClienteCanalDigipassVO.
     * 
     * @param banco
     */
    public void setBanco(java.lang.String banco) {
        this.banco = banco;
    }


    /**
     * Gets the canal value for this ClienteCanalDigipassVO.
     * 
     * @return canal
     */
    public java.lang.String getCanal() {
        return canal;
    }


    /**
     * Sets the canal value for this ClienteCanalDigipassVO.
     * 
     * @param canal
     */
    public void setCanal(java.lang.String canal) {
        this.canal = canal;
    }


    /**
     * Gets the numeroIdCliente value for this ClienteCanalDigipassVO.
     * 
     * @return numeroIdCliente
     */
    public java.lang.String getNumeroIdCliente() {
        return numeroIdCliente;
    }


    /**
     * Sets the numeroIdCliente value for this ClienteCanalDigipassVO.
     * 
     * @param numeroIdCliente
     */
    public void setNumeroIdCliente(java.lang.String numeroIdCliente) {
        this.numeroIdCliente = numeroIdCliente;
    }


    /**
     * Gets the numeroIdUsuario value for this ClienteCanalDigipassVO.
     * 
     * @return numeroIdUsuario
     */
    public java.lang.String getNumeroIdUsuario() {
        return numeroIdUsuario;
    }


    /**
     * Sets the numeroIdUsuario value for this ClienteCanalDigipassVO.
     * 
     * @param numeroIdUsuario
     */
    public void setNumeroIdUsuario(java.lang.String numeroIdUsuario) {
        this.numeroIdUsuario = numeroIdUsuario;
    }


    /**
     * Gets the serial value for this ClienteCanalDigipassVO.
     * 
     * @return serial
     */
    public java.lang.String getSerial() {
        return serial;
    }


    /**
     * Sets the serial value for this ClienteCanalDigipassVO.
     * 
     * @param serial
     */
    public void setSerial(java.lang.String serial) {
        this.serial = serial;
    }


    /**
     * Gets the tipoIdCliente value for this ClienteCanalDigipassVO.
     * 
     * @return tipoIdCliente
     */
    public java.lang.String getTipoIdCliente() {
        return tipoIdCliente;
    }


    /**
     * Sets the tipoIdCliente value for this ClienteCanalDigipassVO.
     * 
     * @param tipoIdCliente
     */
    public void setTipoIdCliente(java.lang.String tipoIdCliente) {
        this.tipoIdCliente = tipoIdCliente;
    }


    /**
     * Gets the tipoIdUsuario value for this ClienteCanalDigipassVO.
     * 
     * @return tipoIdUsuario
     */
    public java.lang.String getTipoIdUsuario() {
        return tipoIdUsuario;
    }


    /**
     * Sets the tipoIdUsuario value for this ClienteCanalDigipassVO.
     * 
     * @param tipoIdUsuario
     */
    public void setTipoIdUsuario(java.lang.String tipoIdUsuario) {
        this.tipoIdUsuario = tipoIdUsuario;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ClienteCanalDigipassVO)) return false;
        ClienteCanalDigipassVO other = (ClienteCanalDigipassVO) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.banco==null && other.getBanco()==null) || 
             (this.banco!=null &&
              this.banco.equals(other.getBanco()))) &&
            ((this.canal==null && other.getCanal()==null) || 
             (this.canal!=null &&
              this.canal.equals(other.getCanal()))) &&
            ((this.numeroIdCliente==null && other.getNumeroIdCliente()==null) || 
             (this.numeroIdCliente!=null &&
              this.numeroIdCliente.equals(other.getNumeroIdCliente()))) &&
            ((this.numeroIdUsuario==null && other.getNumeroIdUsuario()==null) || 
             (this.numeroIdUsuario!=null &&
              this.numeroIdUsuario.equals(other.getNumeroIdUsuario()))) &&
            ((this.serial==null && other.getSerial()==null) || 
             (this.serial!=null &&
              this.serial.equals(other.getSerial()))) &&
            ((this.tipoIdCliente==null && other.getTipoIdCliente()==null) || 
             (this.tipoIdCliente!=null &&
              this.tipoIdCliente.equals(other.getTipoIdCliente()))) &&
            ((this.tipoIdUsuario==null && other.getTipoIdUsuario()==null) || 
             (this.tipoIdUsuario!=null &&
              this.tipoIdUsuario.equals(other.getTipoIdUsuario())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBanco() != null) {
            _hashCode += getBanco().hashCode();
        }
        if (getCanal() != null) {
            _hashCode += getCanal().hashCode();
        }
        if (getNumeroIdCliente() != null) {
            _hashCode += getNumeroIdCliente().hashCode();
        }
        if (getNumeroIdUsuario() != null) {
            _hashCode += getNumeroIdUsuario().hashCode();
        }
        if (getSerial() != null) {
            _hashCode += getSerial().hashCode();
        }
        if (getTipoIdCliente() != null) {
            _hashCode += getTipoIdCliente().hashCode();
        }
        if (getTipoIdUsuario() != null) {
            _hashCode += getTipoIdUsuario().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ClienteCanalDigipassVO.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "ClienteCanalDigipassVO"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("banco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "banco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "canal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroIdCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "numeroIdCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroIdUsuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "numeroIdUsuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "serial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoIdCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "tipoIdCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoIdUsuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://vo.webServices.servidordigipass.co.com.unisys/xsd", "tipoIdUsuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
