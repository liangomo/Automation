package general;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestMF {

	public static void main(String[] args) {

	    WebDriver driver = new FirefoxDriver();///// la inspecion del elemento se realizo en explorer
	    driver.get("https://webkoral/wKoral/ModAjustes/modAjustes_Facturacion.aspx");
	    driver.findElement(By.id("ctl00_principal_fuArchivo")).click();
	    driver.switchTo().activeElement().sendKeys("/home/likewise-open/GLOBAL/123/Documents/filename.txt");
	    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	    driver.findElement(By.id("ctl00_principal_btnCargue"));
	}
}
