package general;

import java.io.IOException;
import java.util.Set;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class Helper {

	ObjetosConfigAux objConfAux;

	/* Constructor */
	public Helper(ObjetosConfigAux objConfAux) {
		this.objConfAux = objConfAux;
	}

	public void clickBtnCancelarImprimir() throws IOException {

		objConfAux.getDriver().switchTo().defaultContent();
		String thisWindow=objConfAux.getDriver().getWindowHandle();
		Set<String> keySet=objConfAux.getDriver().getWindowHandles();

		for (String s:keySet) {

			if (!s.equals(thisWindow)) {
				boolean kill=false;
				objConfAux.getDriver().switchTo().window(s);
				objConfAux.getDriver().switchTo().defaultContent();
				String html=objConfAux.getDriver().findElement(By.tagName("html")).getAttribute("innerHTML");
				Document doc=Jsoup.parse(html);
				Element cancelButton=doc.selectFirst("#print-header>div>button.cancel");

				if (cancelButton!=null) {
					System.out.println("Cancel button found");
					objConfAux.AdminDocPdf.generaEvidencia("Validacion Boton Imprimir",
							Shutterbug.shootPage(objConfAux.getDriver()).getImage());
					objConfAux.getDriver().findElement(By.cssSelector(cancelButton.cssSelector())).click();
					kill=true;
				}
				objConfAux.getDriver().switchTo().window(thisWindow);
				if (kill) break;
			}
		}
	}
}