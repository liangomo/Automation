package consultas.paginas;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import general.Helper;

public class ConsultarHistoricoIMEI {

	ObjetosConfigAux objAux;
	Helper help;

	/** LISTA ELEMENTOS */
	By linkConsultarHistorico = By.linkText("Consulta Historico IMEI");
	By linkConsultaImei = By.xpath("//*[@id='form1']/section/h1");
	By imgImprimir = By.id("Imprimir");
	By btnImprimir = By.xpath("//a[@class='btn btn_print']");
	By btnCancelar = By.xpath("//*[@id=\"print-header\"]/div/button[2]"); //
	By btnDescargar = By.xpath("//*[@id='form1']/section/article[3]/a[2]");
	By imgRegistreImei = By.xpath("//*[@id='form1']/section/article[4]/div/a");
	By linkSaberIMEI = By.xpath("//*[@id=\"boton_interogacion\"]");
	By cboxClose = By.id("cboxClose");
	By btnRegistrAhora = By.xpath("//a[@class='Btn_banner_imei']");
	By imgMovistarCo = By.xpath("//*[@id=\"footer_2016\"]/div[1]/div/div[2]/div[1]/a/img");

	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");
	By btnAdelantePag = By.xpath("//*[@id='form1']/section/article[2]/div[3]/ul/li[4]/a");
	By contPaginacion = By.xpath("//a[@data-pagina]");
	By body = By.tagName("body");

	/* Constructor */
	public ConsultarHistoricoIMEI(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
		help = new Helper(objConfAux);
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkConsultarHistorico() {
		this.objAux.getDriver().findElement(linkConsultarHistorico).click();
	}

	public void clickLinkConsultaImei() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(linkConsultaImei);
		this.objAux.getDriver().findElement(linkConsultaImei).click();
	}

	public void clickImgImprimir() {
		this.objAux.getDriver().findElement(imgImprimir).click();
	}

	public void clickBtnCancelar() {
		objAux.EsperaElemento(objAux.getDriver(), btnCancelar);
		this.objAux.getDriver().findElement(btnCancelar).click();
	}

	public void clickBtnDescargar() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnDescargar);
		this.objAux.getDriver().findElement(btnDescargar).click();
	}

	public void clickBtnAdelantePag() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnAdelantePag);
		this.objAux.getDriver().findElement(btnAdelantePag).click();
	}

	public int getContPaginacion() {
		return this.objAux.getDriver().findElements(contPaginacion).size();
	}

	public void clickLinkSaberIMEI() {
		this.objAux.getDriver().findElement(linkSaberIMEI).click();
	}

	public void clickCboxClose() {
		this.objAux.getDriver().findElement(cboxClose).click();
	}

	public void clickBtnRegistrAhora() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnRegistrAhora);
		this.objAux.getDriver().findElement(btnRegistrAhora).click();
	}

	public void clickBtnImprimir() throws InterruptedException {

		objAux.scrollMostrarObjetosNoVisibles(btnImprimir);
		WebDriver driver=objAux.getDriver();

		String script="{"
				+ "var element=document.querySelector('#form1 > section > article.btn_wrapper > a.btn.btn_print');"
				+ "setTimeout(function(){element.click();},1500);"
				+ "}";

		((JavascriptExecutor)driver).executeScript(script);
		Thread.sleep(7000);
	}

	public void getBodyFrameDefaultContent() {
		this.objAux.getDriver().switchTo().defaultContent();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execConsultarHistoricoIMEI() throws InterruptedException, AWTException, IOException {

		clickLinkConsultarHistorico();
		objAux.AdminDocPdf.generaEvidencia("Validacion Ingreso correcto al modulo IMEI ",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");

		int numPaginas = getContPaginacion()-1;
		for (int i=1; i==numPaginas; i++) {
			clickBtnAdelantePag();
			Thread.sleep(5000);
			clickLinkConsultaImei();
			objAux.AdminDocPdf.generaEvidencia("Paginacion", Shutterbug.shootPage(objAux.getDriver()).getImage());
		}

		clickBtnDescargar();
		objAux.keyPressAbrirDescargas();

		objAux.cambiarVentana();

		objAux.AdminDocPdf.generaEvidencia("Descarga .csv", Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();

		objAux.cambiarVentanaAnterior();
		Thread.sleep(2000);
		this.objAux.getDriver().switchTo().frame("LegacyContainer");
		this.objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");

		clickBtnImprimir();
		objAux.AdminDocPdf.generaEvidencia("Boton Imprimir.csv", Shutterbug.shootPage(objAux.getDriver()).getImage());

		help.clickBtnCancelarImprimir();
	}

	public void execValidarLinks() throws InterruptedException, AWTException, IOException {

		clickLinkConsultarHistorico();
		objAux.AdminDocPdf.generaEvidencia("Validacion Ingreso correcto al modulo IMEI ",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");

		clickBtnRegistrAhora();
		Thread.sleep(2000);
		objAux.cambiarVentana();
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Registra Ahora", Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
	}
}