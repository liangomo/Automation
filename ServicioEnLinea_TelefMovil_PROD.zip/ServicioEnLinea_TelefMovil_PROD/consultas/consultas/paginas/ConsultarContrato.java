package consultas.paginas;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ConsultarContrato {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By linkConsultarContrato = By.linkText("Consultar Contrato");
	By lblContratoUnico = By.xpath("/html/body/div/div[1]/div/h1");

	By btnSolicitarContrato = By.linkText("Solicitar contrato");
	By txtIntroduceEmail = By.id("actualiza_mail");
	By btnEnviar = By.linkText("Enviar");
	By lblSolicitudEnviada = By.xpath("/html/body/div/div[2]/p");
	By btnVolver = By.linkText("Volver");

	By btnHistoricoCambios = By.linkText("Consultar hist�rico de cambios");
	By lblHistoricoCambios = By.xpath("//*[@id=\"contenedor_tabla_pospago\"]/p");

	By lblCondicionesServicio = By.xpath("/html/body/div/div[1]/div/h1");
	By linkDescarga = By.linkText("Descarga condiciones de servicio");

	/* Constructor */
	public ConsultarContrato(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkConsultarContrato() {
		this.objAux.getDriver().findElement(linkConsultarContrato).click();
	}

	public void clickBtnSolicitarContrato() {
		this.objAux.getDriver().findElement(btnSolicitarContrato).click();
	}

	public void sendTxtIntroduceEmail(String email) {
		this.objAux.getDriver().findElement(txtIntroduceEmail).clear();
		this.objAux.getDriver().findElement(txtIntroduceEmail).sendKeys(email);
	}

	public void clickBtnEnviar() {
		this.objAux.getDriver().findElement(btnEnviar).click();
	}

	public String getLblSolicitudEnviada() {
		return this.objAux.getDriver().findElement(lblSolicitudEnviada).getText();
	}

	public void clickBtnVolver() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnVolver);
		this.objAux.getDriver().findElement(btnVolver).click();
	}

	public void clickBtnHistoricoCambios() {
		this.objAux.getDriver().findElement(btnHistoricoCambios).click();
	}

	public String getLblHistoricoCambios() {
		return this.objAux.getDriver().findElement(lblHistoricoCambios).getText();
	}

	public String getLblCondicionesServicio() {
		return this.objAux.getDriver().findElement(lblCondicionesServicio).getText();
	}

	public void clickLinkDescarga() {
		this.objAux.getDriver().findElement(linkDescarga).click();
	}

	/** METODOS */

	public void execIngresarSolicitudContrato() throws InterruptedException, AWTException, IOException {

		clickLinkConsultarContrato();

		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		clickBtnSolicitarContrato();
		sendTxtIntroduceEmail(objAux.buscaElementoParametro("Email"));
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo e introducir email",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnEnviar();
		assertEquals(getLblSolicitudEnviada(), objAux.buscaElementoParametro("Contenido"));
		objAux.AdminDocPdf.generaEvidencia("Envio Contrato", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnVolver();
		objAux.AdminDocPdf.generaEvidencia("Volver Contrato", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execConsultarHistoricoCambios() throws InterruptedException, IOException {

		clickLinkConsultarContrato();

		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		clickBtnHistoricoCambios();
		assertEquals(getLblHistoricoCambios(), objAux.buscaElementoParametro("Contenido"));
		objAux.AdminDocPdf.generaEvidencia("Consulta Historico", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnVolver();
		objAux.AdminDocPdf.generaEvidencia("Volver Historico", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execDescargarCondicionesServicio() throws IOException, InterruptedException {

		clickLinkConsultarContrato();
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertEquals(getLblCondicionesServicio(), objAux.buscaElementoParametro("Contenido"));
		objAux.AdminDocPdf.generaEvidencia("Ingreso Modulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickLinkDescarga();
		objAux.AdminDocPdf.generaEvidencia("Archivo Descargado", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}