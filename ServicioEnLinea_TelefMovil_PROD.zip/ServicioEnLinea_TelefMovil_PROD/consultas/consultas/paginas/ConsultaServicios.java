package consultas.paginas;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ConsultaServicios {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By linkConsultaServicios = By.linkText("Consulta de servicios");
	By btnActivacionServicio = By.id("ctl00_ContentPlaceHolder1_btnActivarServicios_Click");
	By lblConsServ = By.xpath("//*[@id='contenido']/div[2]/div[2]/table/tbody/tr[2]/td/table/tbody/tr[1]/td/div/div");
	By linkVolverCuenta = By.id("ctl00_ContentPlaceHolder1_volverMC");
	By lblTelefoniaMovil = By.xpath("//*[@id=\"top_contenido\"]/h1");
	By cmbTipoServicio = By.id("ctl00_ContentPlaceHolder1_cmbTipoServicio");
	By radioDetalleServicio = By.id("ctl00_ContentPlaceHolder1_lstDetalleServicio_0");
	By txtDescripcionServicio = By.name("ctl00$ContentPlaceHolder1$txtDescripcion");
	By btnSiguiente = By.id("ctl00_ContentPlaceHolder1_lnkSiguiente");
	By lblPregutaActivacion = By.xpath("//*[@id=\"Table7\"]/tbody/tr[3]/td/div[2]/strong");
	By body = By.tagName("body");

	/* Constructor */
	public ConsultaServicios(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkConsultaServicios() {
		this.objAux.getDriver().findElement(linkConsultaServicios).click();
	}

	public void clickBtnActivacionServicio() {
		this.objAux.getDriver().findElement(btnActivacionServicio).click();
	}

	public String getLblConsultaServicios() {
		return this.objAux.getDriver().findElement(lblConsServ).getText();
	}

	public void clickLinkVolverCuenta() {
		this.objAux.getDriver().findElement(linkVolverCuenta).click();
	}

	public String getLblTelefoniaMovil() {
		return this.objAux.getDriver().findElement(lblTelefoniaMovil).getText();
	}

	public void setCmbTipoServicio(String tipoServicio) {
		Select dropdown = new Select(this.objAux.getDriver().findElement(cmbTipoServicio));
		dropdown.selectByVisibleText(tipoServicio);
	}

	public void clickRadioDetalleServicio() {
		this.objAux.getDriver().findElement(radioDetalleServicio).click();
	}

	public String getTxtDescripcionServicio() {
		objAux.EsperaElemento(objAux.getDriver(), txtDescripcionServicio);
		return this.objAux.getDriver().findElement(txtDescripcionServicio).getText();
	}

	public void clickBtnSiguiente() {
		this.objAux.getDriver().findElement(btnSiguiente).click();
	}

	public String getLblPregutaActivacion() {
		return this.objAux.getDriver().findElement(lblPregutaActivacion).getText();
	}
	
	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execValidarActivacionServicio() throws IOException, InterruptedException {

		clickLinkConsultaServicios();

		clickBtnActivacionServicio();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("ActivacionServ")));
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Mensaje")));
		objAux.AdminDocPdf.generaEvidencia("Activacion Servicio", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execVolverAMiCuenta() throws InterruptedException, IOException {

		clickLinkConsultaServicios();
		objAux.AdminDocPdf.generaEvidencia("Detalle Servicio", Shutterbug.shootPage(objAux.getDriver()).getImage());
		
		clickLinkVolverCuenta();
		assertEquals(getLblTelefoniaMovil(), objAux.buscaElementoParametro("VolverCuenta"));
		objAux.AdminDocPdf.generaEvidencia("Volver a la cuenta", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}