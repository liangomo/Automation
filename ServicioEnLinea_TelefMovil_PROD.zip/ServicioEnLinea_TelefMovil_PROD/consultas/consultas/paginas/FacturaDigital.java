package consultas.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class FacturaDigital {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By linkFacturaPROD = By.linkText("Factura Digital");
	By linkFacturaPruebas = By.linkText("Factura y Contrato Digital");
	By body = By.tagName("body");
	By barTitulo = By.id("barTitulo");
	By imgCerrar = By.id("btnXCerrar");
	By imgFacturaDigital = By.xpath("//img[@src='imagenes/tit_FacturaDigital.jpg']");

	By imgNovedades = By.xpath("//img[@onclick='doBienV();']");
	By imgImprimir = By.xpath("//img[@onclick='doImprime();']");
	By imgExportarFactura = By.xpath("//img[@onclick='doExportComa();']");
	By imgInfoGrafica = By.xpath("//img[@onclick='doGraf();']");
	By spanDetalleInfoGrafica = By.xpath("//*[@id='nomBr']");
	By imgAdminCorreos = By.xpath("//img[@onclick='doPass();']");

	By imgPrimeraPag = By.xpath("//img[@onclick='doPriPag();']");
	By imgAnteriorPag = By.xpath("//img[@onclick='doAntPag();']");
	By imgSiguientePag = By.xpath("//img[@onclick='doSigPag();']");
	By imgUltimaPag = By.xpath("//img[@onclick='doUltPag();']");
	By txtNumeroPag = By.xpath("//input[@id='pagBus']");

	By spanNitCedula = By.xpath("/html/body/div[17]/span");
	By spanTelefono = By.xpath("/html/body/div[19]/span");
	By spanClienteNo = By.xpath("/html/body/div[21]/span");
	By spanFacturaVenta = By.xpath("/html/body/div[23]/span");
	By spanFechaExpedicion = By.xpath("/html/body/div[25]/span");
	By spanFacturaMes = By.xpath("/html/body/div[27]/span");
	By spanFechaProximaFactura = By.xpath("/html/body/div[35]/span");
	By spanNumeroParaPagos = By.xpath("/html/body/div[37]/span");
	By spanFechaLimitePago = By.xpath("/html/body/div[39]/span");
	By spanTotalPagar = By.xpath("/html/body/div[41]/span");

	By spanCargosFacturados = By.xpath("/html/body/div[3]/span");
	By spanValorImpuestos = By.xpath("/html/body/div[4]/span");
	By lblDatosFacturaCC = By.id("nomBr");
	By lblTuPlanIncluye = By.xpath("//span[@class='Estilo2' and contains(text(), 'Tu plan incluye')]");
	By lblDetCargosFact = By.xpath("//span[@class='Estilo2' and contains(text(), 'Detalle de Cargos Facturados')]");
	By lblValorConImp = By.xpath("//span[@class='Estilo2' and contains(text(), 'Valor con Impuestos')]");

	/* Constructor */
	public FacturaDigital(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkFacturaPROD() {
		this.objAux.getDriver().findElement(linkFacturaPROD).click();
	}

	public void clickLinkFacturaPruebas() {
		this.objAux.getDriver().findElement(linkFacturaPruebas).click();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	public void getBodyFramePresenta() {
		this.objAux.getDriver().switchTo().frame("presenta");
	}

	public void getBodyAlertAccept() {
		this.objAux.getDriver().switchTo().alert().accept();
	}

	public void getBodyFrameFactura() {
		this.objAux.getDriver().switchTo().frame("factura");
	}

	public void clickImgCerrar() {
		this.objAux.getDriver().findElement(imgCerrar).click();
	}

	public void clickImgNovedades() {
		this.objAux.getDriver().findElement(imgNovedades).click();
	}

	public void clickImgImprimir() {
		this.objAux.getDriver().findElement(imgImprimir).click();
	}

	public void clickImgExportarFact() {
		objAux.EsperaElemento(objAux.getDriver(), imgExportarFactura, 2);
		this.objAux.getDriver().findElement(imgExportarFactura).click();
	}

	public void clickImgInfoGrafica() {
		objAux.EsperaElemento(objAux.getDriver(), imgInfoGrafica, 2);
		this.objAux.getDriver().findElement(imgInfoGrafica).click();
	}

	public void clickImgAdminCorreos() {
		this.objAux.getDriver().findElement(imgAdminCorreos).click();
	}

	public void clickImgPrimeraPag() {
		this.objAux.getDriver().findElement(imgPrimeraPag).click();
	}

	public void clickImgAnteriorPag() {
		this.objAux.getDriver().findElement(imgAnteriorPag).click();
	}

	public void clickImgSiguientePag() {
		this.objAux.getDriver().findElement(imgSiguientePag).click();
	}

	public void clickImgUltimaPag() {
		this.objAux.getDriver().findElement(imgUltimaPag).click();
	}

	public String getSpanNitCedula() {
		return this.objAux.getDriver().findElement(spanNitCedula).getText();
	}

	public String getTxtNumeroPag() {
		return this.objAux.getDriver().findElement(txtNumeroPag).getText();
	}

	public String getSpanTelefono() {
		return this.objAux.getDriver().findElement(spanTelefono).getText();
	}

	public String getSpanClienteNo() {
		return this.objAux.getDriver().findElement(spanClienteNo).getText();
	}

	public String getSpanFacturaVenta() {
		return this.objAux.getDriver().findElement(spanFacturaVenta).getText();
	}

	public String getSpanFechaExpedicion() {
		return this.objAux.getDriver().findElement(spanFechaExpedicion).getText();
	}

	public String getSpanFacturaMes() {
		return this.objAux.getDriver().findElement(spanFacturaMes).getText();
	}

	public String getSpanFechaProximaFactura() {
		return this.objAux.getDriver().findElement(spanFechaProximaFactura).getText();
	}

	public String getSpanNumeroParaPagos() {
		return this.objAux.getDriver().findElement(spanNumeroParaPagos).getText();
	}

	public String getSpanFechaLimitePago() {
		return this.objAux.getDriver().findElement(spanFechaLimitePago).getText();
	}

	public String getSpanTotalPagar() {
		return this.objAux.getDriver().findElement(spanTotalPagar).getText();
	}

	public String getSpanCargosFacturados() {
		return this.objAux.getDriver().findElement(spanCargosFacturados).getText();
	}

	public String getSpanValorImpuestos() {
		return this.objAux.getDriver().findElement(spanValorImpuestos).getText();
	}

	public String getLblDatosFacturaCC() {
		return this.objAux.getDriver().findElement(lblDatosFacturaCC).getText();
	}

	/** METODOS */

	public void execIngresoFactura() throws InterruptedException, IOException {

		clickLinkFacturaPROD();

		objAux.cambiarVentana();
		getBodyFramePresenta();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), barTitulo, 2), "Barra Novedades");
		objAux.AdminDocPdf.generaEvidencia("Barra Novedades", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickImgCerrar();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgFacturaDigital, 2), "Bot�n Cerrar Novedades");
	}

	public void execVerificarSubmoduloPospago() throws InterruptedException, IOException {

		if (objAux.EsperaElemento(objAux.getDriver(), imgFacturaDigital, 2)) {

			clickImgNovedades();
			assertTrue(objAux.EsperaElemento(objAux.getDriver(), barTitulo, 2), "Novedades");
			objAux.AdminDocPdf.generaEvidencia("Novedades", Shutterbug.shootPage(objAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgImprimir();
			assertTrue(objAux.EsperaElemento(objAux.getDriver(), barTitulo, 2), "Imprimir");
			objAux.AdminDocPdf.generaEvidencia("Imprimir", Shutterbug.shootPage(objAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgExportarFact();
			assertTrue(objAux.EsperaElemento(objAux.getDriver(), barTitulo, 2), "Exportar Factura");
			objAux.AdminDocPdf.generaEvidencia("Exporta Factura", Shutterbug.shootPage(objAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgInfoGrafica();
			assertTrue(objAux.EsperaElemento(objAux.getDriver(), spanDetalleInfoGrafica, 2), "Informaci�n Gr�fica");
			objAux.AdminDocPdf.generaEvidencia("Info gr�fica", Shutterbug.shootPage(objAux.getDriver()).getImage());

			clickImgAdminCorreos();
			assertTrue(objAux.EsperaElemento(objAux.getDriver(), barTitulo, 2), "Administraci�n de Correos");
			objAux.AdminDocPdf.generaEvidencia("Admin Correos", Shutterbug.shootPage(objAux.getDriver()).getImage());
			clickImgCerrar();
		}
	}

	public void execVerificarSubmoduloCtaControl() throws InterruptedException, IOException {

		if (objAux.EsperaElemento(objAux.getDriver(), imgFacturaDigital, 2)) {

			clickImgNovedades();
			assertTrue(objAux.EsperaElemento(objAux.getDriver(), barTitulo, 2), "Opci�n Novedades");
			objAux.AdminDocPdf.generaEvidencia("Verif Novedades", Shutterbug.shootPage(objAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgImprimir();
			assertTrue(objAux.EsperaElemento(objAux.getDriver(), barTitulo, 2), "Opci�n Imprimir");
			objAux.AdminDocPdf.generaEvidencia("Verif Imprimir", Shutterbug.shootPage(objAux.getDriver()).getImage());
			clickImgCerrar();
		}
	}

	public void execVerificarPaginacionPosp() throws InterruptedException, IOException {

		if (objAux.EsperaElemento(objAux.getDriver(), imgFacturaDigital, 2)) {

			getBodyFrameFactura();
			assertTrue(getBody().contains(objAux.buscaElementoParametro("ContenidoFactura")),
					"Contiene palabra Se�or(a) - PagInicial");
			objAux.AdminDocPdf.generaEvidencia("Ingreso Factura", Shutterbug.shootPage(objAux.getDriver()).getImage());

			objAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgSiguientePag();
			getBodyFrameFactura();
			assertTrue(getBody().contains(objAux.buscaElementoParametro("ContenidoPagSig")),
					"Contiene Nit o C�dula - PagSig");
			objAux.AdminDocPdf.generaEvidencia("Siguiente Pag", Shutterbug.shootPage(objAux.getDriver()).getImage());

			objAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgAnteriorPag();
			getBodyFrameFactura();
			assertTrue(getBody().contains(objAux.buscaElementoParametro("ContenidoFactura")),
					"Contiene palabra Se�or(a) - AnteriorPag");
			objAux.AdminDocPdf.generaEvidencia("Anterior Pag", Shutterbug.shootPage(objAux.getDriver()).getImage());

			objAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgUltimaPag();
			// clickImgUltimaPag(); Thread.sleep(2000);
			objAux.AdminDocPdf.generaEvidencia("Ultima Pagi", Shutterbug.shootPage(objAux.getDriver()).getImage());
			// getBodyAlertAccept();
			// objConfAux.getDriver().switchTo().alert().accept();

			objAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgPrimeraPag();
			getBodyFrameFactura();
			assertTrue(getBody().contains(objAux.buscaElementoParametro("ContenidoFactura")),
					"Contiene palabra Se�or(a) - PrimerPag");
			objAux.AdminDocPdf.generaEvidencia("Primera Pag", Shutterbug.shootPage(objAux.getDriver()).getImage());

			objAux.cambiarVentana();
			getBodyFramePresenta();
		}
	}

	public void execVerificarPaginacionCC() throws InterruptedException, IOException, AWTException {

		if (objAux.EsperaElemento(objAux.getDriver(), imgFacturaDigital, 2)) {

			try {
				getBodyFrameFactura();
				objAux.AdminDocPdf.generaEvidencia("Ingreso Factura", Shutterbug.shootPage(objAux.getDriver()).getImage());

				objAux.cambiarVentana();
				getBodyFramePresenta();
				clickImgSiguientePag();
			} catch (Exception e) {
				getBodyFrameFactura();
				objAux.AdminDocPdf.generaEvidencia("Siguiente Pag", Shutterbug.shootPage(objAux.getDriver()).getImage());
			}
		}
	}

	public void execValidarInformacion() throws InterruptedException, IOException {

		if (objAux.EsperaElemento(objAux.getDriver(), imgFacturaDigital, 2)) {
			clickImgSiguientePag();
			getBodyFrameFactura();
		}
		objAux.AdminDocPdf.generaEvidencia("Validar Informacion", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
	
	public void validarInfoFacturaCC() throws IOException, InterruptedException {
		
		objAux.scrollMostrarObjetosNoVisibles(lblTuPlanIncluye);
		
		assertTrue(objAux.getDriver().findElement(lblTuPlanIncluye).isDisplayed(), "Titulo Tu Plan Incluye");
		assertTrue(objAux.getDriver().findElement(lblDetCargosFact).isDisplayed(), "Titulo Detalle Cargos Facturados");
		assertTrue(objAux.getDriver().findElement(lblValorConImp).isDisplayed(), "Titulo Valor Con Impuestos");
		
		objAux.AdminDocPdf.generaEvidencia("Validar Informacion", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}