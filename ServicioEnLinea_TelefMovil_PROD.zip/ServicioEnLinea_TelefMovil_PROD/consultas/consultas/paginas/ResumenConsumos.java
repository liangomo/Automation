package consultas.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ResumenConsumos {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By linkResumenCons = By.linkText("Resumen de consumos");
	By body = By.tagName("body");
	By lblSaldoDisponible = By.xpath("//*[@id=\"contenedorTbl\"]/div[1]");
	By linkDetalleConsumo = By.linkText("aqu�");
	By lblDetalleConsumo = By.xpath("//*[@id=\"top_contenido\"]/h1");
	By btnVolverDetalle = By.linkText("Volver"); 
	By btnDescargar = By.linkText("Descargar");
	By btnRecargaLinea = By.cssSelector("body > div > section.contiene_consumos > article:nth-child(1) > div > a:nth-child(1)");
	By btnSimulaConsumo = By.xpath("//span[@class='icon icon-datos']");
	By lblTienda = By.linkText("Tienda");
	By iframe = By.cssSelector("#ctl00_ContentPlaceHolder1_iframe_MN");

	/* Constructor */
	public ResumenConsumos(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkResumenCons() {
		this.objAux.getDriver().findElement(linkResumenCons).click();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	public String getLblSaldoDisponible() {
		return this.objAux.getDriver().findElement(lblSaldoDisponible).getText();
	}

	public void clickLinkDetalleConsumo() {
		this.objAux.getDriver().findElement(linkDetalleConsumo).click();
	}	

	public String getLblDetalleConsumo() {
		return this.objAux.getDriver().findElement(lblDetalleConsumo).getText();
	}

	public void clickBtnVolverDetalle() throws InterruptedException {
		this.objAux.getDriver().findElement(btnVolverDetalle).click();
	}
	public void swichtIframe() {
		objAux.EsperaElemento(objAux.getDriver(), iframe);
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(iframe));
	}

	public void clickBtnDescargar() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnDescargar);
		this.objAux.getDriver().findElement(btnDescargar).click();
	}

	public void clickBtnRecargaLinea() throws InterruptedException {
		this.objAux.getDriver().findElement(btnRecargaLinea).click();
	}
	public void clickBtnSimulaConsumo() throws InterruptedException {
		this.objAux.getDriver().findElement(btnSimulaConsumo).click();
	}

	/** METODOS */

	public void execValidarItemsResumenConsumosPosp() throws InterruptedException, IOException {

		clickLinkResumenCons();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al modulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.getDriver().switchTo().frame("LegacyContainer");
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");

		assertTrue(getBody().contains("Consumo de Voz"), "Consumo de Voz");
		assertTrue(getBody().contains("Consulta de Datos"), "Consulta de Datos");
		assertTrue(getBody().contains("Consulta de Mensajes"), "Consulta de Mensajes");
		objAux.AdminDocPdf.generaEvidencia("Detalle de consumo", Shutterbug.shootPage(objAux.getDriver()).getImage());
		
		clickBtnVolverDetalle();
//		this.objAux.getDriver().switchTo().frame("LegacyContainer");
		objAux.AdminDocPdf.generaEvidencia("Link volver detalle", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
	
	public void execValidarItemsResumenConsumosPrep() throws InterruptedException, IOException {

		clickLinkResumenCons();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.getDriver().switchTo().frame("LegacyContainer");
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");

		assertTrue(getBody().contains("Consulta de consumo"), "Consulta de consumo");
		assertTrue(getBody().contains("N�mero de celular"), "N�mero de celular");
		assertTrue(getBody().contains("Plan"), "Plan");
		objAux.AdminDocPdf.generaEvidencia("Detalle de consumo", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
	
	public void execValidarItemsResumenConsumosCC() throws InterruptedException, IOException, AWTException {

		clickLinkResumenCons();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al modulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertTrue(getBody().contains("Consulta Saldo"), "Consulta Saldo");
		assertTrue(getBody().contains("Consumo de Voz"), "Consumo de Voz");
		assertTrue(getBody().contains("Consulta de Datos"), "Consulta de Datos");
		assertTrue(getBody().contains("Consulta de Mensajes"), "Consulta de Mensajes");
		objAux.AdminDocPdf.generaEvidencia("Detalle de consumo", Shutterbug.shootPage(objAux.getDriver()).getImage());
		
		clickBtnRecargaLinea();
		objAux.cambiarVentana();
		objAux.EsperaElemento(objAux.getDriver(), lblTienda);
		objAux.AdminDocPdf.generaEvidencia("Recarga en Linea", Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();

		objAux.getDriver().switchTo().frame("LegacyContainer");
		swichtIframe();
		objAux.AdminDocPdf.generaEvidencia("Consumo a la fecha", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnSimulaConsumo();
		objAux.cambiarVentana();
		objAux.AdminDocPdf.generaEvidencia("Simula Consumo", Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		
		objAux.getDriver().switchTo().frame("LegacyContainer");
		swichtIframe();

		clickBtnVolverDetalle();
		objAux.getDriver().switchTo().frame("LegacyContainer");
		objAux.AdminDocPdf.generaEvidencia("Link volver detalle", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execValidarLinkAquiVolver() throws InterruptedException, IOException, AWTException {

		clickLinkDetalleConsumo();

		objAux.getDriver().switchTo().frame("LegacyContainer");
		swichtIframe();

		clickBtnDescargar();
		objAux.keyPressAbrirDescargas();
		objAux.cambiarVentana();
		objAux.AdminDocPdf.generaEvidencia("Descarga Arch.csv", Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();

		objAux.cambiarVentanaAnterior();
		Thread.sleep(2000);

		objAux.getDriver().switchTo().frame("LegacyContainer");
		swichtIframe();

		clickBtnVolverDetalle();
		objAux.getDriver().switchTo().frame("LegacyContainer");
		objAux.AdminDocPdf.generaEvidencia("Link volver detalle", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}