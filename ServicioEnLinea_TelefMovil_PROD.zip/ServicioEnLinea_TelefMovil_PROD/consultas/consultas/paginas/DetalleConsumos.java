package consultas.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class DetalleConsumos {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By linkDetalle = By.linkText("Detalle de consumos");
	By selectTipoConsumos = By.id("cmbtipcons");
	By body = By.tagName("body");
	By linkBorrarFiltros = By.linkText("Borrar filtros");
	By btnDescargar = By.xpath("//*[@id='contiene_paginas']/section/div[2]/aside[1]/a");
	By linkArchivoConsumosCSV = By.linkText("Consumos.csv");
	By linkVolver = By.linkText("Volver");
	By linkLlamadas = By.linkText("Llamadas ca�das");
	By alertLlamadas = By.xpath("//*[@id=\"contiene_paginas\"]/div/article");
	By linkPrueba1 = By.xpath("//*[@id=\"url\"]");
	By linkPrueba2 = By.xpath("//*[@id=\"file-link\"]");
	By link = By.xpath("//*[@id=\"centeredContent\"]");

	/* Constructor */
	public DetalleConsumos(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkDetalle() {
		objAux.EsperaElemento(objAux.getDriver(), linkDetalle);
		this.objAux.getDriver().findElement(linkDetalle).click();
	}

	public void selectTipoConsumo(String tipoConsumo) {
		Select dropdown = new Select(this.objAux.getDriver().findElement(selectTipoConsumos));
		dropdown.selectByVisibleText(tipoConsumo);
	}

	public String getTipoConsumo() {
		String selectedOption = new Select(this.objAux.getDriver().findElement(selectTipoConsumos))
				.getFirstSelectedOption().getText();
		return selectedOption;
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	public void clickLinkBorrarFiltros() {
		this.objAux.getDriver().findElement(linkBorrarFiltros).click();
	}

	public void clickBtnDescargar() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnDescargar);
		this.objAux.getDriver().findElement(btnDescargar).click();
	}

	public By getLinkArchivoConsumosCSV() {
		return (linkArchivoConsumosCSV);
	}

	public void clickLinkVolver() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(linkVolver);
		this.objAux.getDriver().findElement(linkVolver).click();
	}

	public void clickLinkLlamadasCaidas() {
		this.objAux.getDriver().findElement(linkLlamadas).click();
	}

	public String getAlertLlamadas() {
		return this.objAux.getDriver().findElement(alertLlamadas).getText();
	}

	public String getHrefArchivoDescargado() {
		return this.objAux.getDriver().findElement(linkPrueba1).getAttribute("href");
	}

	public String getHrefArchivoDescargado2() {
		return this.objAux.getDriver().findElement(linkPrueba2).getAttribute("href");
	}

	public void getHrefArchivoDescargado3() {
		this.objAux.getDriver().findElement(link).sendKeys("AAAA");
	}

	/** METODOS */

	public void execRevisarDetalleConsumos() throws InterruptedException, AWTException, IOException {

		clickLinkDetalle();

		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertTrue(getBody().contains(objAux.buscaElementoParametro("MensajeDetalle")),
				"Contiene Detalles de Consumo");
		objAux.AdminDocPdf.generaEvidencia("Ingreso al modulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		selectTipoConsumo(objAux.buscaElementoParametro("TipoConsumo"));
		objAux.AdminDocPdf.generaEvidencia("Resultado busqueda", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickLinkBorrarFiltros();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("MensajeBorrarFiltro")),
				"Contiene Tipo de Consumos");
		objAux.AdminDocPdf.generaEvidencia("Borrar filtros", Shutterbug.shootPage(objAux.getDriver()).getImage());
		
		clickBtnDescargar();
		objAux.keyPressAbrirDescargas();
		objAux.cambiarVentana();
		objAux.AdminDocPdf.generaEvidencia("Descarga de Archivo Consumos.csv",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();

		objAux.cambiarVentanaAnterior();
		Thread.sleep(3000);
		
		this.objAux.getDriver().switchTo().frame("LegacyContainer");
		this.objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");

		clickLinkVolver();
//		this.objConfAux.getDriver().switchTo().frame("LegacyContainer");
//		assertTrue(getBody().contains(objAux.buscaElementoParametro("MensajeBotonVolver")),
//				"Contiene Telefon�a M�vil");
		objAux.AdminDocPdf.generaEvidencia("Opcion link volver", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execValidarLlamadasCaidas() throws InterruptedException, AWTException, IOException {

		clickLinkDetalle();
		objAux.AdminDocPdf.generaEvidencia("Llamadas caidas", Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		clickLinkLlamadasCaidas();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("MensajeLlamadas")),
				"Contiene Consulta de llamadas ca�das");
		objAux.AdminDocPdf.generaEvidencia("Ingreso llamadas caidas: " + getAlertLlamadas(),
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}