package consultas.paginas;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ComoLeerFactura {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By linkComoLeerFactura = By.linkText("C�mo leer mi factura");
	By lblConoceTuFactura = By.xpath("//*[@id=\"conoceFactura\"]/div/div[1]/h2");

	/* Constructor */
	public ComoLeerFactura(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkComoLeerFactura() {
		this.objAux.getDriver().findElement(linkComoLeerFactura).click();
	}

	public String getLblConoceTuFactura() {
		return this.objAux.getDriver().findElement(lblConoceTuFactura).getText();
	}

	/** METODOS */

	public void execIngresarLeerFactura() throws InterruptedException, AWTException, IOException {

		clickLinkComoLeerFactura();

		objAux.cambiarVentana();
		assertEquals(getLblConoceTuFactura(), objAux.buscaElementoParametro("Contenido"));
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();

		objAux.cambiarVentanaAnterior();
		Thread.sleep(2000);
	}
}