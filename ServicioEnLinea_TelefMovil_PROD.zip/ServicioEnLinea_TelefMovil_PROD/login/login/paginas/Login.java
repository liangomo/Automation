package login.paginas;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class Login {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By body = By.tagName("body");
	By txtMail = By.id("formValidar");
	By txtPassword = By.id("Password");
	By btnSubmit = By.cssSelector("input.submit");
	By lblLoginFallido = By.id("fancyMessage");
	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");
	By btnCerrarSesion = By.xpath("//*[@id='encabezado2']/div[2]/ul/li[6]/a");
	By iframe = By.xpath("//*[@id='LegacyContainer']");

	/* Constructor */
	public Login(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) */

	public String getFrame() {
		return this.objAux.getDriver().findElement(iframe).getText();
	}

	public void setTxtMail(String mail) {
		objAux.EsperaElemento(objAux.getDriver(), txtMail);
		this.objAux.getDriver().findElement(txtMail).clear();
		this.objAux.getDriver().findElement(txtMail).sendKeys(mail);
	}

	public boolean setTxtMailExist() {
		return (txtMail) != null;
	}

	public void setTxtPassword(String password) {
		this.objAux.getDriver().findElement(txtPassword).clear();
		this.objAux.getDriver().findElement(txtPassword).sendKeys(password);
	}

	public void clickBtnSubmit() {
		this.objAux.getDriver().findElement(btnSubmit).click();
	}

	public String getLblLoginFallido() {
		return this.objAux.getDriver().findElement(lblLoginFallido).getText();
	}

	public void clickBtnCerrarSesion() throws InterruptedException {
		Thread.sleep(3000);
		this.objAux.getDriver().switchTo().parentFrame();
		this.objAux.getDriver().findElement(btnCerrarSesion).click();
	}

	/** METODOS */

	public void execLogin() throws InterruptedException {

		this.setTxtMail(objAux.usuario);
		this.setTxtPassword(objAux.contrasena);
		this.clickBtnSubmit();
	}

	public void loginFallido() throws InterruptedException, IOException {
		Thread.sleep(3000);
		assertEquals(getLblLoginFallido(), objAux.AdminParam.resultado.get("Contenido").toString());

		objAux.AdminDocPdf.generaEvidencia("Ingreso no permitido, mensaje fallido",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}