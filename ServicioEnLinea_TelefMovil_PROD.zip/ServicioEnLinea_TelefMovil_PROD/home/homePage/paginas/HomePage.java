package homePage.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class HomePage {

	ObjetosConfigAux objAux;
	float px = 0;

	/** LISTA ELEMENTOS */
	By linkCertificado = By.id("overridelink");
	By lnkProducto = By.xpath("//*[@class='mCSB_container']/div/ul/a");
	By contenedor = By.xpath("//*[@id='mCSB_1_container']");
	By btnHomePage = By.xpath("//*[@id='li-home']");
	By lblMiMovistar = By.xpath("//*[@id='content']/div/section/div[1]/div/div[1]");

	By body = By.tagName("body");
	By iframe = By.xpath("//*[@id='LegacyContainer']");
	By lblNombreCliente = By.xpath("//*[@id=\"content\"]/section/div[1]/div/div[1]/p[1]/span[1]");
	By lblApellidoCliente = By.xpath("//*[@id=\"content\"]/section/div[1]/div/div[1]/p[1]/span[2]");

	By lblNumCelular = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_NumeroCelular\"]");
	By lblNombreClienteProd = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_divInfoContacto']/h3");
	By lblDireccion = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_divInfoContacto\"]/p[2]");
	By lblCiudad = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_divInfoContacto']/p[3]");

	By linkOtraLinea = By.linkText("click aqu�");
	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");
	// By txtTitulo = By.xpath("//*[@id='ConetidoMargen']/section/h1");
	By txtTitulo = By.cssSelector("#content > div > section > div:nth-child(1) > div > div.mi_movistar");
	// ConetidoMargen
	By linkSiguiente = By.xpath("//*[@id=\"slides\"]/a[2]");

	By imgBannerFactura_IntPrepago = By.cssSelector("#slides > div > div > a:nth-child(1) > img");
	By imgBannerDetalle_RecargasPrepago = By.cssSelector("#slides > div > div > a:nth-child(2) > img");
	By lblPaquetesInternetPrep = By.id("LblTituloGrande");
	By lblRecargaOnlinePrep = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_divRecargaPSE\"]/p[1]");
	By btnVolver = By.id("BtnVolver");

	By imgBannerFacturaDigitalPospago = By.cssSelector("#slides > div > div > a:nth-child(1) > img");
	By imgBannerPagosOnlinePospago = By.xpath("//*[@id='slides']/div/div/a[1]/img");
	By imgBannerRenoRepoPospago = By.xpath("//*[@id='slides']/div/div/a[2]/img");
	By lblFacturaDigitalPospago = By.xpath("//*[@id='contenedor_principal']/header/div/h1");
	By lblPagosOnlinePospago = By.xpath("//*[@id='area_1']/header/h2");
	By lblRenoRepoPospago = By.xpath("//*[@id='contenedorRR']/table[1]/tbody/tr/td/div/div");

	By imgBannerPagosOnlineCtaControl = By.cssSelector("#slides > div > div > a:nth-child(1) > img");
	By imgBannerRenoRepoCtaControl = By.cssSelector("#slides > div > div > a:nth-child(2) > img");
	By lblPagosOnlineCtaControl = By.xpath("//*[@id='area_1']/header/h2");
	By lblRenoRepoCtaControl = By.xpath("//*[@id='contenedorRR']/table[1]/tbody/tr/td/div/div");
	By imgChatServicio = By.id("ctl00_lnChat");
	By lblChat = By.xpath("//*[@id=\"contenedor\"]/div[1]/section/header/h1");

	By imgImprimir = By.cssSelector("span.ladop");
	By btnImprimir = By.xpath("//*[@id=\"print-header\"]/div/button[1]");
	By btnCancelar = By.xpath("//*[@id=\"print-header\"]/div/button[2]");

	By imgFacebook = By.cssSelector("a.contiene_facebook > img");
	By lblHomeLinkFacebook = By.xpath("//*[@id=\"homelink\"]");

	By imgTwittear = By.id("l");
	By btnRegistrateTwitter = By.xpath("//*[@id=\"not-logged-in\"]/a");

	By linkConsultas = By.id("idLiMenu1");
	By linkTransacciones = By.linkText("Transacciones");
	By linkServicios = By.linkText("Servicios");

	/* Constructor */
	public HomePage(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public By getLinkCertificado() {
		return (linkCertificado);
	}

	public void clickLinkCertificado() {
		this.objAux.getDriver().findElement(linkCertificado).click();
	}

	public void clickBtnHomePage() throws InterruptedException {
		String handle = objAux.getDriver().getWindowHandle();
		objAux.getDriver().switchTo().window(handle);
		objAux.scrollMostrarObjetosNoVisibles(btnHomePage);
		if (objAux.EsperaElemento(objAux.getDriver(), btnHomePage, 2)) {
			objAux.getDriver().findElement(btnHomePage).click();
		} else {
			objAux.refreshDriver();
		}
	}

	public String getLblMiMovistar() {
		return this.objAux.getDriver().findElement(lblMiMovistar).getText();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	public String getLblNumCelular() {
		return this.objAux.getDriver().findElement(lblNumCelular).getText();
	}

	public String getLblNombreCliente() {
		return this.objAux.getDriver().findElement(lblNombreCliente).getText();
	}

	public String getLblApellidoCliente() {
		return this.objAux.getDriver().findElement(lblApellidoCliente).getText();
	}

	public String getLblNombreClienteProd() {
		return this.objAux.getDriver().findElement(lblNombreClienteProd).getText();
	}

	public String getLblDireccion() {
		return this.objAux.getDriver().findElement(lblDireccion).getText();
	}

	public String getLblCiudad() {
		return this.objAux.getDriver().findElement(lblCiudad).getText();
	}

	public void clickLinkOtraLinea() {
		this.objAux.getDriver().findElement(linkOtraLinea).click();
	}

	public By getImgPhotoUser() {
		return (imgPhotoUser);
	}

	public By getTxtTitulo() {
		// objConfAux.EsperaElemento(objConfAux.getDriver(), iframe);
		// this.objConfAux.getDriver().switchTo().frame("LegacyContainer");
		objAux.getDriver().findElement(txtTitulo).getText();
		return (txtTitulo);
	}

	public void clicklinkSiguiente() {
		this.objAux.getDriver().findElement(linkSiguiente).click();
	}

	public void clickImgBannerFactura_IntPrepago() {
		objAux.EsperaElemento(objAux.getDriver(), imgBannerFactura_IntPrepago);
		this.objAux.getDriver().findElement(imgBannerFactura_IntPrepago).click();
	}

	public String getLblPaquetesInternetPrep() {
		return this.objAux.getDriver().findElement(lblPaquetesInternetPrep).getText();
	}

	public void clickImgBannerDetalle_RecargasPrep() {
		objAux.EsperaElemento(objAux.getDriver(), imgBannerDetalle_RecargasPrepago);
		this.objAux.getDriver().findElement(imgBannerDetalle_RecargasPrepago).click();
	}

	public String getLblRecargaOnlinePrep() {
		return this.objAux.getDriver().findElement(lblRecargaOnlinePrep).getText();
	}

	public void clickImgBannerFacturaDigitalPospago() {
		objAux.EsperaElemento(objAux.getDriver(), imgBannerFacturaDigitalPospago);
		this.objAux.getDriver().findElement(imgBannerFacturaDigitalPospago).click();
	}

	public String getLblFacturaDigitalPospago() {
		return this.objAux.getDriver().findElement(lblFacturaDigitalPospago).getText();
	}

	public void clickImgBannerPagosOnlinePospago() {
		objAux.EsperaElemento(objAux.getDriver(), imgBannerPagosOnlinePospago);
		this.objAux.getDriver().findElement(imgBannerPagosOnlinePospago).click();
	}

	public String getLblPagosOnlinePospago() {
		return this.objAux.getDriver().findElement(lblPagosOnlinePospago).getText();
	}

	public void clickImgBannerRenoRepoPospago() {
		objAux.EsperaElemento(objAux.getDriver(), imgBannerRenoRepoPospago);
		this.objAux.getDriver().findElement(imgBannerRenoRepoPospago).click();
	}

	public String getLblRenoRepoPospago() {
		return this.objAux.getDriver().findElement(lblRenoRepoPospago).getText();
	}

	public void clickImgBannerPagosOnlineCtaControl() {
		this.objAux.getDriver().findElement(imgBannerPagosOnlineCtaControl).click();
	}

	public String getLblPagosOnlineCtaControl() {
		return this.objAux.getDriver().findElement(lblPagosOnlineCtaControl).getText();
	}

	public void clickImgBannerRenoRepoCtaControl() {
		this.objAux.getDriver().findElement(imgBannerRenoRepoCtaControl).click();
	}

	public String getLblRenoRepoCtaControl() {
		return this.objAux.getDriver().findElement(lblRenoRepoCtaControl).getText();
	}

	public By getBtnVolver() {
		return (btnVolver);
	}

	public void clickBtnVolver() {
		this.objAux.getDriver().findElement(btnVolver).click();
	}

	public void clickImgChatServicio() {
		this.objAux.getDriver().findElement(imgChatServicio).click();
	}

	public String getLblChat() {
		return this.objAux.getDriver().findElement(lblChat).getText();
	}

	public void clickImgImprimir() {
		this.objAux.getDriver().findElement(imgImprimir).click();
	}

	public String getBtnImprimir() {
		return this.objAux.getDriver().findElement(btnImprimir).getText();
	}

	public void clickBtnCancelar() {
		this.objAux.getDriver().findElement(btnCancelar).click();
	}

	public void clickImgFacebook() {
		this.objAux.getDriver().findElement(imgFacebook).click();
	}

	public String getLblHomeLinkFacebook() {
		return this.objAux.getDriver().findElement(lblHomeLinkFacebook).getText();
	}

	public void clickImgTwittear() {
		this.objAux.getDriver().findElement(imgTwittear).click();
	}

	public String getBtnSesionTwitter() {
		return this.objAux.getDriver().findElement(btnRegistrateTwitter).getText();
	}

	public void clickLinkConsultas() throws InterruptedException {
		objAux.EsperaElemento(objAux.getDriver(), linkConsultas);
		this.objAux.getDriver().switchTo().frame("LegacyContainer");
		this.objAux.getDriver().findElement(linkConsultas).click();
	}

	public void clickLinkTransacciones() {
		objAux.EsperaElemento(objAux.getDriver(), linkTransacciones);
		getBodyFrameLegacyContainer();
		this.objAux.getDriver().findElement(linkTransacciones).click();
	}

	public void clicklinkServicios() {
		objAux.EsperaElemento(objAux.getDriver(), linkServicios);
		getBodyFrameLegacyContainer();
		this.objAux.getDriver().findElement(linkServicios).click();
	}

	public void clickLnkProducto(String pLnkProducto) {
		List<WebElement> listaProducto = objAux.getDriver().findElements(lnkProducto);
		try {
			boolean reintentar = true;
			for (int i = 0; i <= listaProducto.size(); i++) {
				reintentar = true;
				while (reintentar) {
					if (listaProducto.get(i).isDisplayed()) {
						reintentar = false;

						if (listaProducto.get(i).getText().toString().equals(pLnkProducto)) {
							JavascriptExecutor js = (JavascriptExecutor) objAux.getDriver();
							js.executeScript("arguments[0].click()", listaProducto.get(i));
							i = listaProducto.size() + 1;
							break;
						}
					} else {
						downLstLineas();
					}
				}
			}
		} catch (Exception e) {
		}
	}

	private void downLstLineas() throws InterruptedException {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) objAux.getDriver();
		WebElement element = objAux.getDriver().findElement(contenedor);
		px = px - 92;
		js.executeScript("arguments[0].setAttribute('style', 'position: relative; top: " + px + "px; left: 0px;')",
				element);
	}

	public void getBodyFrameDefaultContent() {
		this.objAux.getDriver().switchTo().defaultContent();
	}

	public void getBodyFrameLegacyContainer() {
		this.objAux.getDriver().switchTo().frame("LegacyContainer");
	}

	public void getBodyFrameContentPlaceHolder() {
		this.objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
	}

	public void getBodyFrameChat() {
		this.objAux.getDriver().switchTo().frame("main");
	}

	public void getBodyFrameTwitter() {
		this.objAux.getDriver().switchTo().frame("twitter-widget-0");
	}

	public void getBodyFramePaqInternet() {
		this.objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_SSO");
	}

	public void keyPressCerrarVentana() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_F4);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_ALT);
		robot.keyRelease(KeyEvent.VK_F4);
	}

	/** METODOS */

	public void homeMain() throws InterruptedException, AWTException, IOException {

		Integer caracter = Integer.valueOf(getLblNombreCliente().length());
		assertTrue(getBody().contains(objAux.AdminParam.resultado.get("Texto1").toString()), "Texto1");
		assertTrue(getBody().contains(objAux.AdminParam.resultado.get("Texto2").toString()), "Texto2");
		assertTrue(caracter > 1, "Caracter");
		objAux.AdminDocPdf.generaEvidencia("Validacion home",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void homeBannerPospago() throws InterruptedException, AWTException, IOException {

		getBodyFrameLegacyContainer();

		/* Banner en movimiento */
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgBannerPagosOnlinePospago),
				"BannerPagosOnlinePospago");
		objAux.AdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgBannerRenoRepoPospago),
				"BannerRenoRepoPospago");
		objAux.AdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void homeBannerCtaControl() throws InterruptedException, AWTException, IOException {

		getBodyFrameLegacyContainer();

		/* Banner en movimiento */
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgBannerPagosOnlineCtaControl),
				"BannerPagosOnlineCtaControl");
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgBannerRenoRepoCtaControl),
				"BannerRenoRepoCtaControl");
		objAux.AdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void homeBannerPrepago() throws InterruptedException, AWTException, IOException {

		getBodyFrameLegacyContainer();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgBannerFactura_IntPrepago),
				"BannerFactura_IntPrepago");
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgBannerDetalle_RecargasPrepago),
				"BannerDetalle_RecargasPrepago");
		objAux.AdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void homeLinkChat() throws InterruptedException, AWTException, IOException {

		clickImgChatServicio();
		objAux.cambiarVentanaAnterior();
		getBodyFrameChat();
		assertTrue(getLblChat().equals(objAux.AdminParam.resultado.get("Chat").toString()), "Bot�n Chat");
		objAux.AdminDocPdf.generaEvidencia("Validacion opcion Chat de Servicio",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();
	}

	public void homeLinks() throws InterruptedException, AWTException, IOException {

		/* Validaci�n opci�n Imprimir */
		objAux.cambiarVentanaAnterior();
		getBodyFrameLegacyContainer();
		clickImgImprimir();
		objAux.cambiarVentana();
		getBodyFrameDefaultContent();
//		assertTrue(getBtnImprimir().equals(objConfAux.AdminParam.resultado.get("Imprimir").toString()),
//				"Bot�n Imprimir");
		objAux.AdminDocPdf.generaEvidencia("Validacion opcion Imprimir",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		clickBtnCancelar();

		/* Validacion opcion Facebook */
		objAux.cambiarVentanaAnterior();
		getBodyFrameLegacyContainer();
		clickImgFacebook();
		objAux.cambiarVentanaAnterior();
		assertTrue(getLblHomeLinkFacebook().equals(objAux.AdminParam.resultado.get("Facebook").toString()),
				"Opci�n Facebook");
		objAux.AdminDocPdf.generaEvidencia("Validacion opcion de Facebook",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		keyPressCerrarVentana();

		/* Validacion opcion Twitter */
		objAux.cambiarVentanaAnterior();
		getBodyFrameLegacyContainer();
		getBodyFrameTwitter();
		clickImgTwittear();
		objAux.cambiarVentana();
		assertTrue(getBtnSesionTwitter().equals(objAux.AdminParam.resultado.get("Twitter").toString()),
				"Opci�n Twitter");
		objAux.AdminDocPdf.generaEvidencia("Validacion opcion de Twitter",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
	}
}