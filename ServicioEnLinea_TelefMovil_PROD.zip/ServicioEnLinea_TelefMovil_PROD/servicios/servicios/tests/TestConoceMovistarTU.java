package servicios.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import homePage.paginas.HomePage;
import login.paginas.Login;
import manager.param.AdminParam;
import model.Ambientes;
import model.DispositivoPrueba;
import model.Estados;
import model.Navegadores;
import model.TipoCone;
import servicios.paginas.ConoceMovistarTU;

public class TestConoceMovistarTU {

	ObjetosConfigAux objAux;
	Login objLogin;
	HomePage objHome;
	ConoceMovistarTU objTU;
	Navegadores navegador;
	Ambientes ambiente = Ambientes.PRODUCCION;

	@BeforeClass
	@Parameters({ "Navegador" })
	public void setup(String navegadores) throws IOException, InterruptedException {
		objAux = new ObjetosConfigAux(navegadores);
		this.navegador = objAux.getNavegador();
		objLogin = new Login(objAux);
		objHome = new HomePage(objAux);
		objTU = new ConoceMovistarTU(objAux);
		objLogin.execLogin();
	}

	/**
	 * CASOS DE PRUEBA
	 */

	@Test(priority = 1)
	public void cp001_Servicios_ConocMovTU_IngresoPOSP()
			throws MalformedURLException, DocumentException, IOException, InterruptedException, AWTException {

		objAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "MovistarTU",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Servicios.xlsx");
		objAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clickLnkProducto(objAux.buscaElementoParametro("Producto"));
		objAux.AdminDocPdf.generaEvidencia("Ingreso Principal " + objAux.buscaElementoParametro("Producto"), 
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objHome.clicklinkServicios();
		objTU.execIngresarConoceMovistarTU();
	}

	@Test(priority = 2)
	public void cp002_Servicios_ConocMovTU_IngresoCC()
			throws MalformedURLException, DocumentException, IOException, InterruptedException, AWTException {

		objAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "MovistarTU",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Servicios.xlsx");
		objAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clickLnkProducto(objAux.buscaElementoParametro("Producto"));
		objAux.AdminDocPdf.generaEvidencia("Ingreso Principal " + objAux.buscaElementoParametro("Producto"), 
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objHome.clicklinkServicios();
		objTU.execIngresarConoceMovistarTU();
	}

	@Test(priority = 3)
	public void cp003_Servicios_ConocMovTU_IngresoPREP()
			throws MalformedURLException, DocumentException, IOException, InterruptedException, AWTException {

		objAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "MovistarTU",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Servicios.xlsx");
		objAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clickLnkProducto(objAux.buscaElementoParametro("Producto"));
		objAux.AdminDocPdf.generaEvidencia("Ingreso Principal " + objAux.buscaElementoParametro("Producto"), 
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objHome.clicklinkServicios();
		objTU.execIngresarConoceMovistarTU();
	}

	@AfterMethod
	public void finalizeTest(ITestResult t) throws MalformedURLException, DocumentException, IOException {
		if (t.getStatus() == ITestResult.SUCCESS)
			objAux.AdminDocPdf.crearDocumento(Estados.SUCCESS);
		else {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			Throwable cause = t.getThrowable();
			if (null != cause) {
				cause.printStackTrace(pw);
				objAux.AdminDocPdf.generaEvidencia(
						"Resultado NO Esperado: "
								+ sw.getBuffer().toString().substring(0, sw.getBuffer().toString().indexOf("at ")),
						Shutterbug.shootPage(objAux.getDriver()).getImage());
			} else {
				objAux.AdminDocPdf.generaEvidencia("Resultado NO Esperado: ",
						Shutterbug.shootPage(objAux.getDriver()).getImage());
			}
			objAux.AdminDocPdf.crearDocumento(Estados.FAILED);
		}
	}

	@AfterClass
	public void tearDowns() {
		objAux.getDriver().quit();
	}
}