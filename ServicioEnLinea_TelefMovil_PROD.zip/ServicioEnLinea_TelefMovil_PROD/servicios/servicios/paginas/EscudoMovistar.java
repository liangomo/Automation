package servicios.paginas;

import static org.testng.Assert.assertTrue;
import java.awt.AWTException;
import java.io.IOException;
import org.openqa.selenium.By;
import com.assertthat.selenium_shutterbug.core.Shutterbug;
import control.elementos.ObjetosConfigAux;

public class EscudoMovistar {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By linkEscudoMovistar = By.linkText("Escudo Movistar");
	By linkSeguridadMovil = By.id("lnkGrpG0001");
	By linkVolveracuenta = By.id("LinkServLinea");
	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");
	By body = By.tagName("body");

	/* Constructor */
	public EscudoMovistar(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clicklinkEscudoMovistar() {
		this.objAux.getDriver().findElement(linkEscudoMovistar).click();
	}

	public void clicklinkSeguridadParaElMovil() {
		this.objAux.getDriver().findElement(linkSeguridadMovil).click();
	}

	public void clicklinkVolveracuenta() {
		this.objAux.getDriver().findElement(linkVolveracuenta).click();
	}

	public By getimgPhotoUser() {
		return (imgPhotoUser);
	}

	public String getbody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execIngresarEscudoMovistar() throws InterruptedException, AWTException, IOException {

		clicklinkEscudoMovistar();
		Thread.sleep(3000);
		assertTrue(getbody().contains(objAux.buscaElementoParametro("Contenido")), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Ingreso Modulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clicklinkSeguridadParaElMovil();
		assertTrue(getbody().contains(objAux.buscaElementoParametro("Seguridad")), "Seguridad");
		objAux.AdminDocPdf.generaEvidencia("Link Seguridad", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clicklinkVolveracuenta();
		Thread.sleep(5000);
		assertTrue(getbody().contains(objAux.buscaElementoParametro("Volver")), "Opci�n Volver");
		objAux.AdminDocPdf.generaEvidencia("Opcion Volver", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}