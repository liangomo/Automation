package servicios.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class InternetAdicionalRecarga {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By linkInternetAdicional = By.linkText("Internet adicional con tu recarga");
	By linkRecargaAqui = By.id("LblBotonCarga");
	By linkHistorico = By.xpath("//*[@id='area_11']/a[1]");
	By body = By.tagName("body");
	By iFrame = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_iframe_SSO']");

	/* Constructor */
	public InternetAdicionalRecarga(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clicklinkInternetAdicional() {
		this.objAux.getDriver().findElement(linkInternetAdicional).click();
	}

	public void clicklinkRecargaAqui() {
		this.objAux.getDriver().findElement(linkRecargaAqui).click();
	}

	public void clickLinkHistoricoPaquetes() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(linkHistorico);
		this.objAux.getDriver().findElement(linkHistorico).click();
	}
 	public void keyPressFin() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		Thread.sleep(2000); 
	}
 	public void keyPressInicio() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_HOME);
		Thread.sleep(2000); 
	}
	public String getbody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execIngresarInternetAdicionalRecarga() throws InterruptedException, IOException {

		clicklinkInternetAdicional();
		objAux.AdminDocPdf.generaEvidencia("Ingreso Internet Adicional con tu recarga",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_SSO");
		clicklinkRecargaAqui();

		objAux.getDriver().switchTo().frame("LegacyContainer");
		System.out.println("AlgoDiciente"+getbody());
		
		assertTrue(getbody().contains(objAux.AdminParam.resultado.get("Contenido").toString()), "Contenido");

		objAux.AdminDocPdf.generaEvidencia("Validacion direccionamiento correcto LinkRecargaAqui",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execValidarLinkHistoricoInternetAddRecarga() throws InterruptedException, IOException, AWTException {

		clicklinkInternetAdicional();
		objAux.AdminDocPdf.generaEvidencia("Ingreso Internet Adicional con tu recarga",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		
	
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_SSO");
		keyPressFin();
		clickLinkHistoricoPaquetes();
		Thread.sleep(3000);
		assertTrue(getbody().contains(objAux.AdminParam.resultado.get("Contenido").toString()), "Contenido");
		keyPressInicio();
		objAux.AdminDocPdf.generaEvidencia("Validacion direccionamiento correcto LinkHistoricoPaquetes",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
	
	
}