package servicios.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class TiendaDeContenidos {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By linkTiendaDeContenidos = By.linkText("Tienda de Contenidos");
	By linkMovistarStore = By.linkText("T�rminos y condiciones");
	By body = By.tagName("body");

	/* Constructor */
	public TiendaDeContenidos(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkTiendaDeContenidos() {
		this.objAux.getDriver().findElement(linkTiendaDeContenidos).click();
	}

	public void clicklinkMovistarStore() {
		this.objAux.getDriver().findElement(linkMovistarStore).click();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execIngresarTiendaDeContenidos() throws InterruptedException, AWTException, IOException {

		clickLinkTiendaDeContenidos();
		Thread.sleep(3000);
		objAux.cambiarVentana();
		assertTrue(getBody().contains(objAux.AdminParam.resultado.get("Contenido").toString()), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Ingreso a Tienda de Contenidos",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(3000);
	}
}