package servicios.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ConoceMovistarTU {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By linkConoceMovistarTU = By.linkText("Conoce Movistar TU");
	By body = By.tagName("body");

	/* Constructor */
	public ConoceMovistarTU(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clicklinkConoceMovistarTU() {
		this.objAux.getDriver().findElement(linkConoceMovistarTU).click();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execIngresarConoceMovistarTU() throws InterruptedException, AWTException, IOException {

		clicklinkConoceMovistarTU();
		Thread.sleep(2000);
		objAux.cambiarVentana();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Contenido")), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Ingreso a Conoce MovistarTU",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(2000);
	}
}