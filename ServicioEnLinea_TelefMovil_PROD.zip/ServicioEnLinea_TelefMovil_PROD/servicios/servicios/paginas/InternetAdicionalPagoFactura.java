package servicios.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class InternetAdicionalPagoFactura {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By linkInternetAdicionalP = By.linkText("Internet adicional con pago en tu factura");
	By linkVertodos = By.xpath("//*[@id='tablaShow']/p");
	By linkVolver = By.xpath("//*[@id='contenido']/div/a");
	By body = By.tagName("body");
	By iFrame_SSO = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_iframe_SSO']");
	By btnChateaAsesor = By.xpath("html/body/div/div/div/section[2]/div[2]/div/div/div/div/a[1]");
	By btnIngresoMovistar = By.xpath("//*[@id='contenido']/div/section[2]/div[2]/div/div/div/div/a[2]/p");
	By btnCentrosExperiencia = By.xpath("html/body/div[1]/div/div/section[2]/div[2]/div/div/div/div/a[3]");
	By iFramePpal = By.xpath("//*[@id='LegacyContainer']");
	By lblMisServContratados = By.xpath("//*[@id='contenido']/div/div/header/div[1]/h1");
	By lblTienda = By.xpath("//span[contains(text(), 'Tienda')]");

	/* Constructor */
	public InternetAdicionalPagoFactura(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkInternetAdicionalP() {
		this.objAux.getDriver().findElement(linkInternetAdicionalP).click();
	}

	public void clickLinkVerTodos() {
		objAux.EsperaElemento(objAux.getDriver(), linkVertodos);
		this.objAux.getDriver().findElement(linkVertodos).click();
	}

	public void clickLinklinkVolver() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(linkVolver);
		this.objAux.getDriver().findElement(linkVolver).click();
	}

	public void clickBtnChateaAsesor() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnChateaAsesor);
		this.objAux.getDriver().findElement(btnChateaAsesor).click();
	}

	public void clickBtnIngresoMovistar() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnIngresoMovistar);
		this.objAux.getDriver().findElement(btnIngresoMovistar).click();
	}

	public void clickBtnCentrosExperiencia() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnCentrosExperiencia);
		this.objAux.getDriver().findElement(btnCentrosExperiencia).click();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	public void swichtIframe() {
		objAux.EsperaElemento(objAux.getDriver(), iFrame_SSO);
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(iFrame_SSO));
	}

	public void swichtIframePrincipal() {
		objAux.EsperaElemento(objAux.getDriver(), iFramePpal);
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(iFramePpal));
	}

	public void getBodyFrameDefaultContent() {
		this.objAux.getDriver().switchTo().defaultContent();
	}

	public void clickLblMisServContratados() {
		this.objAux.getDriver().findElement(lblMisServContratados).click();
	}

	/** METODOS */

	public void execContratarPaquetesAdicionales() throws InterruptedException, IOException, AWTException {

		clickLinkInternetAdicionalP();
		swichtIframe();
		objAux.EsperaElemento(objAux.getDriver(), lblMisServContratados);
		clickLblMisServContratados();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al modulo",	Shutterbug.shootPage(objAux.getDriver()).getImage());

		/* Chatea con un Asesor */
		clickBtnChateaAsesor();
		objAux.cambiarVentanaAnterior();
		objAux.getDriver().switchTo().frame("main");
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Chat")), "Chat Asesor");
		objAux.AdminDocPdf.generaEvidencia("Ingreso al Chat", Shutterbug.shootPage(objAux.getDriver()).getImage());
		Thread.sleep(3000);
		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(3000);

		/* Ingresa a movistar.co */
		objAux.getDriver().switchTo().frame("LegacyContainer");
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_SSO");
		clickBtnIngresoMovistar();
		objAux.cambiarVentanaAnterior();
		objAux.EsperaElemento(objAux.getDriver(), lblTienda);
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Movistar")), "Movistar - Tienda");
		objAux.AdminDocPdf.generaEvidencia("Ingreso movistar.co", Shutterbug.shootPage(objAux.getDriver()).getImage());
		Thread.sleep(3000);
		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(3000);

		/* Centros de experiencia */
		objAux.getDriver().switchTo().frame("LegacyContainer");
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_SSO");
		clickBtnCentrosExperiencia();
		objAux.cambiarVentanaAnterior();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Centros")), "Centros Experiencia");
		objAux.AdminDocPdf.generaEvidencia("Ingreso Centros de experiencia", 
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		Thread.sleep(3000);
		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(3000);
	}

	public void execIngresarInternetAdicionalPagoFactura() throws InterruptedException, IOException, AWTException {

		clickLinkInternetAdicionalP();
		swichtIframe();
		Thread.sleep(3000);
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Contenido")), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Validacion ingreso al modulo InternetAdicionalPagoFactura",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		keyPressFin();
		clickLinkVerTodos();
		Thread.sleep(3000);
		assertTrue(getBody().contains(objAux.buscaElementoParametro("VerTodos")), "Opci�n Ver Todos");
		objAux.AdminDocPdf.generaEvidencia("Validacion ingreso al modulo InternetAdicionalPagoFactura",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickLinklinkVolver();
		swichtIframePrincipal();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Volver")), "Opci�n Volver");
		objAux.AdminDocPdf.generaEvidencia("Validacion ingreso al modulo InternetAdicionalPagoFactura",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
	
 	public void keyPressFin() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		Thread.sleep(2000); 
	}
}