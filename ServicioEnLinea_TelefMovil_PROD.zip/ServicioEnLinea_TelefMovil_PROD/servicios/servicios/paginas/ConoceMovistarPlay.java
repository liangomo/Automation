package servicios.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ConoceMovistarPlay {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By linkConoceMovistarPlay = By.linkText("Conoce Movistar Play");
	By linkDisfrutaMovistarPlay = By.linkText("�Suscr�bete ahora a Movistar Play!");
	By body = By.tagName("body");

	/* Constructor */
	public ConoceMovistarPlay(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clicklinkConoceMovistarPlay() {
		this.objAux.getDriver().findElement(linkConoceMovistarPlay).click();
	}

	public void clicklinkDisfrutaMovistarPlay() {
		this.objAux.getDriver().findElement(linkDisfrutaMovistarPlay).getText();
	}

	public String getbody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execIngresarConoceMovistarPlay() throws InterruptedException, AWTException, IOException {

		clicklinkConoceMovistarPlay();
		Thread.sleep(3000);
		objAux.cambiarVentana();
		assertTrue(getbody().contains(objAux.buscaElementoParametro("Contenido")), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Ingreso a Conoce Movistar Play",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(3000);
	}
}