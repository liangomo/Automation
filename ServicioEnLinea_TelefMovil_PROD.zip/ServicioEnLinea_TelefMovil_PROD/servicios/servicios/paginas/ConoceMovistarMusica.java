package servicios.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ConoceMovistarMusica {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By linkConoceMovistarMusica = By.linkText("Conoce Movistar M�sica");
	By linkMovistarNapster = By.linkText("Preguntas Frecuentes");
	By body = By.tagName("body");

	/* Constructor */
	public ConoceMovistarMusica(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clicklinkConoceMovistarMusica() {
		this.objAux.getDriver().findElement(linkConoceMovistarMusica).click();
	}

	public void clicklinkMovistarNapster() {
		this.objAux.getDriver().findElement(linkMovistarNapster).getText();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execIngresarConoceMovistarMusica() throws InterruptedException, AWTException, IOException {

		clicklinkConoceMovistarMusica();
		Thread.sleep(3000);
		objAux.cambiarVentana();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Contenido")), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Ingreso a Conoce Movistar Musica",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(3000);
	}
}