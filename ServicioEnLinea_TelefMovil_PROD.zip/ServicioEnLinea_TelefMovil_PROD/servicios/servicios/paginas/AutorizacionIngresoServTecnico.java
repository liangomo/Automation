package servicios.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux; 

public class AutorizacionIngresoServTecnico {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By linkAutorizacionIngreso = By.linkText("Autorizaci�n Ingreso a Servicio T�cnico");
	By btnRegistro = By.xpath("//*[@id='btnEnviar']/img");
	By btnCerrar = By.xpath("//*[@id='cboxClose']");
	By txtNombres = By.id("nombre");
	By txtApellidos = By.id("apellido");
	By txtNumeroCelular = By.id("celular");
	By txtNumeroIdentificacion = By.id("identificacion");
	By chkAcepto_terminos = By.id("acepto_terminos");
	By linkGracias = By.id("cont_gracias");
	By chkAutorizaTerceros = By.name("autoriza");
	By txtNombreAutorizado = By.name("nombreAu");
	By txtNumeroIdentificacionAu = By.name("identificacionAu");
	By radAutorizaPrestamo = By.name("autorizacion");
	By body = By.tagName("body");

	/* Constructor */
	public AutorizacionIngresoServTecnico(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clicklinkAutorizacionIngreso() {
		this.objAux.getDriver().findElement(linkAutorizacionIngreso).click();
	}

	public void clickbtnRegistro() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnRegistro);
		this.objAux.getDriver().findElement(btnRegistro).click();
	}

	public void clickbtnCerrar() {
		this.objAux.getDriver().findElement(btnCerrar).click();
	}

	public void settxtNombres(String nombres) {
		this.objAux.getDriver().findElement(txtNombres).sendKeys(nombres); // variables
	}

	public void settxtApellidos(String apellidos) {
		this.objAux.getDriver().findElement(txtApellidos).sendKeys(apellidos);
	}

	public void settxtNumeroCelular(String NumeroCelular) {
		this.objAux.getDriver().findElement(txtNumeroCelular).sendKeys(NumeroCelular);
	}

	public void settxtNumeroIdentificacion(String NumeroIdentificacion) {
		this.objAux.getDriver().findElement(txtNumeroIdentificacion).sendKeys(NumeroIdentificacion);
	}

	public void clickchkAcepto_terminos() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(chkAcepto_terminos);
		this.objAux.getDriver().findElement(chkAcepto_terminos).click();
	}

	public void clicklinkGracias() {
		this.objAux.getDriver().findElement(linkGracias).click();
	}

	public void clickchkAutorizaTerceros() {
		this.objAux.getDriver().findElement(chkAutorizaTerceros).click();
	}

	public void settxtNombreAutorizado(String apellidos) {
		this.objAux.getDriver().findElement(txtNombreAutorizado).sendKeys(apellidos);
	}

	public void settxtNumeroIdentificacionAu(String numeroIdentificacion) {
		this.objAux.getDriver().findElement(txtNumeroIdentificacionAu).sendKeys(numeroIdentificacion);
	}

	public void clickradAutorizaPrestamo() {
		this.objAux.getDriver().findElement(radAutorizaPrestamo).click();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execIngresarAutorizacionIngresoServTecnico() throws InterruptedException, AWTException, IOException {

		clicklinkAutorizacionIngreso();
		objAux.cambiarVentana();
		objAux.AdminDocPdf.generaEvidencia("Ingreso correcto a Formulario AutorizacionIngreso",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickbtnRegistro(); Thread.sleep(3000);
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), btnRegistro), "Bot�n Registro");
		objAux.AdminDocPdf.generaEvidencia("Validacion sin llenar campos obligatorios del formulario",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Contenido")),
				"Mensaje Popup invalido");
		clickbtnCerrar();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("ContenidoFormulario")),
				"Contiene Mi Movistar"); 

		settxtNombres(objAux.buscaElementoParametro("Nombres"));
		settxtApellidos(objAux.buscaElementoParametro("Apellidos"));
		settxtNumeroCelular(objAux.buscaElementoParametro("NumeroCelular"));
		settxtNumeroIdentificacion(objAux.buscaElementoParametro("NumeroIdentificacion"));
		clickchkAcepto_terminos();
		objAux.AdminDocPdf.generaEvidencia("Diligenciamiento del formulario",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickbtnRegistro();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), linkGracias), "Link Gracias");
		objAux.AdminDocPdf.generaEvidencia("Registro Datos del formulario de manera Exitosa",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		Thread.sleep(2000);

		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(1000);
	}

	public void execAutorizaciontercero() throws InterruptedException, AWTException, IOException {

		clicklinkAutorizacionIngreso();
		objAux.cambiarVentana();
		objAux.AdminDocPdf.generaEvidencia("Ingreso correcto a Formulario AutorizacionIngreso",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		settxtNombres(objAux.buscaElementoParametro("Nombres"));
		settxtApellidos(objAux.buscaElementoParametro("Apellidos"));
		settxtNumeroCelular(objAux.buscaElementoParametro("NumeroCelular"));
		settxtNumeroIdentificacion(objAux.buscaElementoParametro("NumeroIdentificacion"));
		clickchkAcepto_terminos();
		clickchkAutorizaTerceros();
		objAux.AdminDocPdf.generaEvidencia("Diligenciamiento del formulario",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.EsperaElemento(objAux.getDriver(), btnRegistro);
		clickbtnRegistro(); Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Validacion de despliegue correcto del popup",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Contenido")),
				"Mensaje Popup invalido");

		clickbtnCerrar();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("ContenidoFormulario")),
				"Contiene Mi Movistar");

		settxtNombreAutorizado(objAux.buscaElementoParametro("NombreAutorizado"));
		settxtNumeroIdentificacionAu(objAux.buscaElementoParametro("NumeroIdentificacionAu"));
		clickradAutorizaPrestamo();
		objAux.AdminDocPdf.generaEvidencia("Diligenciamiento de datos Autorizacion a Terceros",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickbtnRegistro();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), linkGracias), "Link Gracias");
		objAux.AdminDocPdf.generaEvidencia("Funcionamiento correcto ingreso datos a terceros",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		Thread.sleep(2000);

		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(1000);
	}
}