package servicios.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import org.openqa.selenium.By;
import com.assertthat.selenium_shutterbug.core.Shutterbug;
import control.elementos.ObjetosConfigAux;

public class ServicioFamiliaAmigos {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By linkServicioFliaAmigos = By.linkText("Servicio familia y amigos");
	By imgBannerSerFliaAmi = By.xpath("//*[@id=\"area_1\"]/article[1]/div/img");
	By linkAqui = By.linkText("aqu�.");
	By lblFamilia = By.linkText("Familia y Amigos");
	By linkVolver = By.id("ctl00_body_Volver");
	By btnVolver = By.xpath("//*[@id=\"ctl00_body_Volver\"]");
	By btnActivateAqui = By.id("ctl00_body_ActivarServicio");
	By btnVolverActiv = By.xpath("//*[@id='ctl00_body_LinkButton1']");
	By linkTerminosCondiciones = By.id("ctl00_body_lnkTreminosCondiciones");
	By btnAceptarActiv = By.id("ctl00_body_Li1");
	By btnCancelarActiv = By.xpath("//*[@id='ctl00_body_imgCancelarNuevo']/li");
	By linkServicios = By.linkText("Servicios");
	By btnAgregarLinea = By.id("ctl00_body_AgregaMovil");
	By btnAceptarAgregarMovil = By.xpath("//*[@id='ctl00_body_imgGuardarNuevoMovil']/li");
	By txtNumeroNuevo = By.name("ctl00$body$txtNuevoMovil");
	By btnCancelarAgregarMovil = By.xpath("//*[@id='imgCancelarNuevo']/li");
	By btnAceptarConfirmacion = By.xpath("//*[@id='ctl00_body_BtnAaceptarMensaje']/li");
	By btnAceptarFinal = By.xpath("//*[@id='ctl00_body_BtnAaceptarMensaje']/li");
	By btnAceptarAgrServ = By.xpath("//*[@id='ctl00_body_Li1']");
	By btnGuardar = By.xpath("//*[@id='ctl00_body_ActualizarHijos']");
	By linkEliminarNumero = By.id("ctl00_body_lnkDel_MOVIL_5714414");
	By btnAceptarEliminacion = By.xpath("//*[@id='ctl00_body_imbEliminarMovil']/li");
	By body = By.tagName("body");

	/* Constructor */
	public ServicioFamiliaAmigos(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkServicioFliaAmigos() {
		this.objAux.getDriver().findElement(linkServicioFliaAmigos).click();
	}

	public void clicklinkVolver() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(linkVolver);
		this.objAux.getDriver().findElement(linkVolver).click();

	}

	public By getimgBannerSerFliaAmi() {
		return (imgBannerSerFliaAmi);
	}

	public void clicklinkAqui() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(linkAqui);
		this.objAux.getDriver().findElement(linkAqui).click();
	}

	public void clicklblFamilia() {
		this.objAux.getDriver().findElement(lblFamilia).click();
	}

	public void clickbtnActivateAqui() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnActivateAqui);
		this.objAux.getDriver().findElement(btnActivateAqui).click();
	}

	public void clickbtnVolvera() {
		this.objAux.getDriver().findElement(btnVolverActiv).click();
	}

	public void clicklinkTerminosCondiciones() {
		this.objAux.getDriver().findElement(linkTerminosCondiciones).click();
	}

	public void clickbtnAceptarActiv() {
		this.objAux.getDriver().findElement(btnAceptarActiv).click();
	}

	public void clickbtnCancelarActiv() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnCancelarActiv);
		this.objAux.getDriver().findElement(btnCancelarActiv).click();
	}

	public void clickbtnAgregarLinea() {
		this.objAux.getDriver().findElement(btnAgregarLinea).click();
	}

	public void clickbtnAceptarAgregarMovil() {
		this.objAux.getDriver().findElement(btnAceptarAgregarMovil).click();
	}

	public void settxtNumeroNuevo(String NumeroAgregar) {
		this.objAux.getDriver().findElement(txtNumeroNuevo).sendKeys(NumeroAgregar);
	}

	public void clickbtnCancelarAgregarMovil() {
		this.objAux.getDriver().findElement(btnCancelarAgregarMovil).click();
	}

	public void clickbtnAceptarConfirmacion() {
		this.objAux.getDriver().findElement(btnAceptarConfirmacion).click();
	}

	public void clickbtnAceptarFinal() {
		this.objAux.getDriver().findElement(btnAceptarFinal).click();
	}

	public void clicklinkEliminarNumero() {
		this.objAux.getDriver().findElement(linkEliminarNumero).click();
	}

	public void clickbtnAceptarEliminacion() {
		this.objAux.getDriver().findElement(btnAceptarEliminacion).click();
	}

	public void clickbtnAceptarAgrServ() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnAceptarAgrServ);
		this.objAux.getDriver().findElement(btnAceptarAgrServ).click();
	}

	public void clickbtnGuardar() {
		this.objAux.getDriver().findElement(btnGuardar).click();
	}

	public String getbody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	public void clicklinkServiciosSF() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(linkServicios);
		this.objAux.getDriver().findElement(linkServicios).click();
	}
	
	public void keyPressInicio() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_HOME);
		Thread.sleep(2000); 
	}

	/** METODOS */

	public void execValidarBotonVolverServicioFliaAmigos() throws InterruptedException, IOException {

		clickLinkServicioFliaAmigos();
		Thread.sleep(3000);
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertTrue(getbody().contains(objAux.AdminParam.resultado.get("Contenido").toString()), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Ingreso Pagina principal Servicio Familia y Amigos",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clicklinkVolver();
		Thread.sleep(5000);
		objAux.getDriver().switchTo().frame("LegacyContainer");
		assertTrue(getbody().contains(objAux.AdminParam.resultado.get("Volver").toString()), "Volver");
		objAux.AdminDocPdf.generaEvidencia("Validacion Boton Volver",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execIngresarServicioFamiliaAmigos() throws InterruptedException, IOException {

		clickLinkServicioFliaAmigos();
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertTrue(getbody().contains(objAux.AdminParam.resultado.get("Contenido").toString()), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Ingreso Opcion aqui: Politicas y condiciones",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clicklinkAqui();
		assertTrue(getbody().contains(objAux.AdminParam.resultado.get("Link").toString()), "Link Aqu�");
		objAux.getDriver().navigate().back();
	}

	public void execIngresarActivateAqui() throws InterruptedException, IOException, AWTException {

		clickLinkServicioFliaAmigos();
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertTrue(getbody().contains(objAux.AdminParam.resultado.get("Contenido").toString()), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Ingreso correcto a familia y amigos",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
 
		clickbtnActivateAqui();
		assertTrue(getbody().contains(objAux.AdminParam.resultado.get("MensajedeValidacion").toString()),
				"Mensaje Fallido");
		objAux.AdminDocPdf.generaEvidencia("Validacion de mensaje  correcto",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		keyPressInicio();
		
		clickbtnCancelarActiv();
		objAux.AdminDocPdf.generaEvidencia("Regreso a Pantalla inicial ServicioFamiliaAmigos",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickbtnActivateAqui();
		objAux.AdminDocPdf.generaEvidencia("Validacion de mensaje  correcto",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		
		keyPressInicio();

		clickbtnAceptarAgrServ();
		objAux.AdminDocPdf.generaEvidencia("Acepta agregar Familia y Amigos",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execIngresarAgregarLinea() throws InterruptedException, IOException {

		clickLinkServicioFliaAmigos();
		objAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertTrue(getbody().contains(objAux.AdminParam.resultado.get("Contenido").toString()), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Ingreso correcto a familia y amigos",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		/*
		 * Eliminar l�nea hijo si ya existe if
		 * (getbody().contains(objConfigAux.AdminParam.resultado.get(
		 * "NumeroAgregar").toString())) {
		 * 
		 * clicklinkEliminarNumero(); objConfigAux.AdminDocPdf.generaEvidencia(
		 * "Validar Funcionamiento Eliminar Linea",Shutterbug.shootPage(
		 * objConfigAux.getDriver()).getImage());
		 * 
		 * clickbtnAceptarEliminacion();
		 * objConfigAux.AdminDocPdf.generaEvidencia(
		 * "Linea Eliminada",Shutterbug.shootPage(objConfigAux.getDriver()).
		 * getImage());
		 * 
		 * clickbtnGuardar(); objConfigAux.AdminDocPdf.generaEvidencia(
		 * "Validar Funcionamiento Boton Guardar- Eliminacion",Shutterbug.
		 * shootPage(objConfigAux.getDriver()).getImage()); }
		 */

		clickbtnAgregarLinea();
		objAux.AdminDocPdf.generaEvidencia("Funcion Agregar Linea",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		settxtNumeroNuevo(objAux.AdminParam.resultado.get("NumeroAgregar").toString());
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Validar Funcionamiento Agregar Linea",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickbtnAceptarAgregarMovil();
		objAux.AdminDocPdf.generaEvidencia("Aceptar Agregar linea",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickbtnAceptarConfirmacion();
		objAux.AdminDocPdf.generaEvidencia("Validar Funcionamiento Boton Agregar",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickbtnGuardar();
		objAux.AdminDocPdf.generaEvidencia("Validar Funcionamiento Boton Guardar",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		assertTrue(getbody().contains(objAux.AdminParam.resultado.get("NumeroAgregar").toString()),
				"NumeroAgregado");
	}
}