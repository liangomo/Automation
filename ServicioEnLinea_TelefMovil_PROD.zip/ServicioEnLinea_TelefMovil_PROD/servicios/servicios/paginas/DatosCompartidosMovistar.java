package servicios.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class DatosCompartidosMovistar {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By linkDatosCompartidosMovistar = By.linkText("Datos compartidos Movistar");
	By linkDatosCompartidos = By.linkText("Nombre del plan");
	By btnHazloAqui = By.xpath("//*[@id='_MultiSharingOnline_WAR_MSMovistar_:_t157']");
	By txtCampoNumero = By.id("_MultiSharingOnline_WAR_MSMovistar_:repeat:0:linea");
	By txtAliasDelTitular = By.id("_MultiSharingOnline_WAR_MSMovistar_:repeat:0:alias");
	By txtAliasModificado = By.xpath("//*[@id='_MultiSharingOnline_WAR_MSMovistar_:repeat:0:alias']");
	By btnAgregar = By.xpath("//*[@id='_MultiSharingOnline_WAR_MSMovistar_:repeat:0:_t137']");
	By btnCancelar = By.id("_MultiSharingOnline_WAR_MSMovistar_:repeat:0:cancel");
	By imgValidacion = By.xpath(".//*[@id='_MultiSharingOnline_WAR_MSMovistar_:repeat:0:_t111']/div/div[1]/span[1]");
	By imgValInicial = By.xpath("//*[@id='_MultiSharingOnline_WAR_MSMovistar_:_t150']/div/div/div[2]/div[1]/img");
	By btnEditar = By.xpath("//*[@id='_MultiSharingOnline_WAR_MSMovistar_:repeat:0:_t115']"); //chrome	
	By btnEliminar = By.id ("_MultiSharingOnline_WAR_MSMovistar_:repeat:0:_t113"); 
	By btnGuardarCambio = By.id("_MultiSharingOnline_WAR_MSMovistar_:repeat:0:_t137"); 
	By btnEliminarLinea = By.xpath("//*[@id='_MultiSharingOnline_WAR_MSMovistar_:formDeleteChild:_t247']"); // Chrome
	By imgElimina = By.xpath("//*[@id='_MultiSharingOnline_WAR_MSMovistar_:formDeleteChild:_t249']/div/span");
	By imgEliminacion = By.xpath("//*[@id='_MultiSharingOnline_WAR_MSMovistar_:formDeleteChild:_t251']/span");
	By btnCerrarValidacion = By.xpath("//*[@id='_MultiSharingOnline_WAR_MSMovistar_:formDeleteChild:_t236']/span");
	By body = By.tagName("body");

	/* Constructor */
	public DatosCompartidosMovistar(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkDatosCompartidosMovistar() {
		this.objAux.getDriver().findElement(linkDatosCompartidosMovistar).click();
	}

	public void clickLinkDatosCompartidos() {
		this.objAux.getDriver().findElement(linkDatosCompartidos).getText();
	}

	public void clickBtnHazloAqui() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnHazloAqui);
		this.objAux.getDriver().findElement(btnHazloAqui).click();
	}

	public void setTxtCampoNumero(String celular) throws InterruptedException {
		this.objAux.getDriver().findElement(txtCampoNumero).sendKeys(celular);
		Thread.sleep(2000);
	}

	public void setTxtAliasDelTitular(String alias) throws InterruptedException {
		this.objAux.getDriver().findElement(txtAliasDelTitular).click(); Thread.sleep(3000);
		this.objAux.getDriver().findElement(txtAliasDelTitular).sendKeys(alias);
	}

	public void setTxtAliasModificado(String alias) {
		this.objAux.getDriver().findElement(txtAliasModificado).clear();
		this.objAux.getDriver().findElement(txtAliasModificado).sendKeys(alias);
	}

	public void clickBtnAgregar() {
		this.objAux.getDriver().findElement(btnAgregar).click();
	}

	public void clickBtnCancelar() {
		this.objAux.getDriver().findElement(btnCancelar).click();
	}

	public void clickBtnEditar() {
		this.objAux.getDriver().findElement(btnEditar).click();
	}
	
	public void clickBtnEliminar() {
		this.objAux.getDriver().findElement(btnEliminar).click();
	}

	public void clickBtnGuardarCambio() {
		this.objAux.getDriver().findElement(btnGuardarCambio).click();
	}

	public void clickBtnEliminarLinea() {
		this.objAux.getDriver().findElement(btnEliminarLinea).click();
	}

	public void clickBtnCerrarValidacion(){
		this.objAux.getDriver().findElement(btnEliminarLinea).click();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execIngresarDatosCompartidosMovistar() throws InterruptedException, AWTException, IOException {

		clickLinkDatosCompartidosMovistar();
		objAux.cambiarVentana();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), btnHazloAqui), "Bot�n Hazlo aqu�");
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Ingreso a Datos Compartidos Movistar",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		Thread.sleep(3000);
		clickBtnHazloAqui(); Thread.sleep(3000);
		setTxtCampoNumero(objAux.buscaElementoParametro("NumeroCelular"));
		setTxtAliasDelTitular(objAux.buscaElementoParametro("AliasDelTitular"));
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Contenido")), "Contenido");
		objAux.AdminDocPdf.generaEvidencia("Validacion datos de ingreso linea nueva",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnAgregar(); Thread.sleep(3000);
		assertTrue(getBody().contains(objAux.buscaElementoParametro("AliasDelTitular")), "AliasDelTitular");
		objAux.AdminDocPdf.generaEvidencia("Bot�n Agregar", Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Vuelve al inicio", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execEliminarDatosCompartidosMovistar() throws InterruptedException, AWTException, IOException {

		clickLinkDatosCompartidosMovistar();
		objAux.cambiarVentana();
		objAux.AdminDocPdf.generaEvidencia("Ingreso a Datos Compartidos Movistar",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnHazloAqui();
		setTxtCampoNumero(objAux.buscaElementoParametro("NumeroCelular"));
		setTxtAliasDelTitular(objAux.buscaElementoParametro("AliasDelTitular"));
		objAux.AdminDocPdf.generaEvidencia("Validacion datos de ingreso linea nueva",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnAgregar(); Thread.sleep(3000);
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgValidacion), "imgValidacion bot�n agregar");
		objAux.AdminDocPdf.generaEvidencia("Agregar linea nueva", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnEditar();
		Thread.sleep(3000);
		setTxtAliasModificado(objAux.buscaElementoParametro("AliasModificado"));
		objAux.AdminDocPdf.generaEvidencia("Datos Linea Nueva", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnGuardarCambio();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgValidacion), "imgValidacion bot�n guardar cambio");
		objAux.AdminDocPdf.generaEvidencia("Guardar cambio modificacion alias linea nueva",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnEliminar();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgElimina), "imgElimina bot�n eliminar");
		objAux.AdminDocPdf.generaEvidencia("Opcion Eliminar", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnEliminarLinea();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgEliminacion), "imgEliminacion bot�n eliminar linea");
		objAux.AdminDocPdf.generaEvidencia("Mensaje Eliminacion", Shutterbug.shootPage(objAux.getDriver()).getImage());
		
		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(3000);
	}

	public void execValidarOpcionCancelar() throws InterruptedException, AWTException, IOException {

		clickLinkDatosCompartidosMovistar();
		objAux.cambiarVentana();
		objAux.EsperaElemento(objAux.getDriver(), btnHazloAqui);
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnHazloAqui();
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Opcion Hazlo Aqui", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnCancelar();
		Thread.sleep(5000);
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), imgValInicial), "Imagen Validaci�n Inicial");
		objAux.AdminDocPdf.generaEvidencia("Boton Cancelar", Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Vuelve al inicio", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}