package transacciones.paginas;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class RegistraTuEquipo {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.linkText("Transacciones");
	By btnRegistraTuEquipo = By.linkText("Registra tu equipo");
	By lblPregFrecuentes = By.xpath("//*[@id='home_hurto']/div[2]/a");

	/* Constructor */
	public RegistraTuEquipo(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickBtnTransacciones() {
		this.objAux.getDriver().switchTo().frame("LegacyContainer");
		objAux.getDriver().findElement(btnTransacciones).click();
	}

	public void clickBtnRegistraTuEquipo() {
		objAux.getDriver().findElement(btnRegistraTuEquipo).click();
	}

	public String getLblPregFrecuentes() {
		return this.objAux.getDriver().findElement(lblPregFrecuentes).getText();
	}

	/** METODOS */

	public void execRegitraTuEquipo() throws InterruptedException, IOException, AWTException {

		clickBtnTransacciones();
		clickBtnRegistraTuEquipo();
		objAux.cambiarVentana();

		objAux.getDriver().switchTo().frame("form-iframe");
		assertEquals(getLblPregFrecuentes(), objAux.buscaElementoParametro("Contenido"));
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.keyPressCerrarPestana();
		objAux.cambiarVentanaAnterior();
		Thread.sleep(2000);
	}
}