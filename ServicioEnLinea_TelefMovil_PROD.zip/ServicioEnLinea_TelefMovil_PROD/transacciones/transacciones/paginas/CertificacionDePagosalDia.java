package transacciones.paginas;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class CertificacionDePagosalDia {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.linkText("Transacciones");
	By btnCertificacionPagosAlDia = By.linkText("Certificaci�n de pagos al d�a");
	By lnkCertificadoPagoAlDia = By.id("ctl00_ContentPlaceHolder1_lnkAqui");
	By btnGenerarCertif = By.id("volverMC");
	By plugCertificado = By.id("plugin");
	By btnVolverCertif = By.id("ctl00_ContentPlaceHolder1_volverMC");
	By btnVolver = By.xpath("//*[@id='area_1']/article[4]/a");
	By iframeLegacyCont = By.xpath("//*[@id='LegacyContainer']");
	By iframeFraPdf = By.xpath("//*[@id='fraPdf']");
	By lblMiCelularVolver = By.xpath("//h2[@class='azul' and contains(text(), 'Mi celular')]");

	/* Constructor */
	public CertificacionDePagosalDia(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void swichtIframeLegacyContainer() {
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(iframeLegacyCont));
	}
	
	public void swichtIframeFraPdf() {
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(iframeFraPdf));
	}

	public void clickBtnTransacciones() {
		objAux.getDriver().findElement(btnTransacciones).click();
	}

	public void clickBtnCertificacionPagosAlDia() {
		objAux.getDriver().findElement(btnCertificacionPagosAlDia).click();
	}
	
	public void clickLnkCertificadoPagoAlDia() {
		objAux.getDriver().findElement(lnkCertificadoPagoAlDia).click();
	}
	
	public void clickBtnGenerarCertif() {
		objAux.getDriver().findElement(btnGenerarCertif).click();
	}

	public void clickBtnVolver() {
		objAux.getDriver().findElement(btnVolver).click();
	}

	public void clickBtnVolverCertif() throws InterruptedException, IOException {
		objAux.scrollMostrarObjetosNoVisibles(btnVolverCertif);
		objAux.AdminDocPdf.generaEvidencia("Apertura plugin certificado 2",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.getDriver().findElement(btnVolverCertif).click();
	}

	/** METODOS */

	public void execOpcionLinksImprimir() throws IOException, InterruptedException {
		
		swichtIframeLegacyContainer();
		clickBtnTransacciones();
		clickBtnCertificacionPagosAlDia();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickLnkCertificadoPagoAlDia();
		objAux.AdminDocPdf.generaEvidencia("Link certificado de pagos al d�a", 
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		swichtIframeFraPdf();
		clickBtnGenerarCertif();
		objAux.EsperaElemento(objAux.getDriver(), plugCertificado);
		assertTrue(objAux.getDriver().findElement(plugCertificado).isDisplayed(), "Plugin Certificado Pagos");
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Apertura plugin certificado",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		objAux.getDriver().switchTo().defaultContent();
		swichtIframeLegacyContainer();
		clickBtnVolverCertif();
		objAux.EsperaElemento(objAux.getDriver(), lblMiCelularVolver);
		objAux.scrollMostrarObjetosNoVisibles(lblMiCelularVolver);
		assertTrue(objAux.getDriver().findElement(lblMiCelularVolver).isDisplayed(), "Label Mi Celular Volver");
		objAux.AdminDocPdf.generaEvidencia("Opcion Volver", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execOpcionVolver() throws IOException {
		swichtIframeLegacyContainer();
		clickBtnTransacciones();
		clickBtnCertificacionPagosAlDia();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnVolver();
		objAux.EsperaElemento(objAux.getDriver(), lblMiCelularVolver);
		assertTrue(objAux.getDriver().findElement(lblMiCelularVolver).isDisplayed(), "Label Mi Celular Volver");
		objAux.AdminDocPdf.generaEvidencia("Opcion Volver", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}