package transacciones.paginas;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ActualizacionDeDatos {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.linkText("Transacciones");
	By btnActualizacionDeDatos = By.linkText("Actualizaci�n de datos");
	By btnVolver = By.xpath("//*[@id='area_1']/article[5]/a[2]");
	By txtCtaCorreo = By.id("ctl00_ContentPlaceHolder1_txtCorreoFE");
	By btnModificar = By.id("ctl00_ContentPlaceHolder1_btnModificaMailFE");
	By txtDepartamento = By.id("ctl00_ContentPlaceHolder1_ddlDepto");
	By txtBarrio = By.id("ctl00_ContentPlaceHolder1_ddlComuna");
	By txtCiudad = By.id("ctl00_ContentPlaceHolder1_ddlCiudad");
	By txtTipoDireccion = By.id("ctl00_ContentPlaceHolder1_ddTipoCalle");
	By txtDireccion = By.id("ctl00_ContentPlaceHolder1_txtDireccion");
	By btnConfirmar = By.id("ctl00_ContentPlaceHolder1_btnAceptar");
	By txtObservacion = By.id("ctl00_ContentPlaceHolder1_txtObservacion");
	By btnContinuar = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_lnkEnviar']");
	By opcionesMenu = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li");
	By lstLineas = By.xpath("//*[@id='mCSB_1_container']");
	By iframeLegacyCont = By.xpath("//*[@id='LegacyContainer']");
	By lblRegSolicitud = By.id("ctl00_ContentPlaceHolder1_lblMensaje");
	By lblMiCelularVolver = By.xpath("//h2[@class='azul' and contains(text(), 'Mi celular')]");

	/* Constructor */
	public ActualizacionDeDatos(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void swichtIframeLegacyCont() {
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(iframeLegacyCont));
	}

	public void clickBtnCodTransacciones() {
		objAux.getDriver().findElement(btnTransacciones).click();
	}

	public void clickBtnActualizacionDeDatos() {
		objAux.getDriver().findElement(btnActualizacionDeDatos).click();
	}

	public void clickBtnVolver() {
		objAux.getDriver().findElement(btnVolver).click();
	}

	public void slcTxtBarrio(String pCodBarrio) {
		new Select(objAux.getDriver().findElement(txtBarrio)).selectByVisibleText(pCodBarrio);
	}

	public void slcTxtCiudad(String pcodCiudad) {
		new Select(objAux.getDriver().findElement(txtCiudad)).selectByVisibleText(pcodCiudad);
	}

	public void slcTxtDepartamento(String pCodDepartamento) {
		new Select(objAux.getDriver().findElement(txtDepartamento)).selectByVisibleText(pCodDepartamento);
	}

	public void slcTxtTipoDireccion(String pTipoDireccion) {
		new Select(objAux.getDriver().findElement(txtTipoDireccion)).selectByVisibleText(pTipoDireccion);
	}

	public void setTxtDireccion(String pCodDireccion) {
		objAux.getDriver().findElement(txtDireccion).clear();
		objAux.getDriver().findElement(txtDireccion).sendKeys(pCodDireccion);
	}

	public void clickBtnContinuar() {
		objAux.getDriver().findElement(btnContinuar).click();
	}

	public void clickBtnModificar() {
		objAux.getDriver().findElement(btnModificar).click();
	}

	public void setTxtObservacion(String sCodObservacion) {
		objAux.getDriver().findElement(txtObservacion).clear();
		objAux.getDriver().findElement(txtObservacion).sendKeys(sCodObservacion);
	}

	public void setTxtCtaCorreo(String sTxtCtaCorreo) {
		objAux.getDriver().findElement(txtCtaCorreo).clear();
		objAux.getDriver().findElement(txtCtaCorreo).sendKeys(sTxtCtaCorreo);
	}
	
	public void clickBtnConfirmar() {
		objAux.getDriver().findElement(btnConfirmar).click();
	}
	
	public String getLblRegSolicitud() {
		return this.objAux.getDriver().findElement(lblRegSolicitud).getText();
	}

	/** METODOS */

	public void execOpcionVolver() throws InterruptedException, IOException {

		swichtIframeLegacyCont();
		clickBtnCodTransacciones();
		clickBtnActualizacionDeDatos();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo Actualizaci�n de Datos",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
		clickBtnVolver();
		assertTrue(objAux.getDriver().findElement(lblMiCelularVolver).isDisplayed(), "Label Mi Celular Volver");
		objAux.AdminDocPdf.generaEvidencia("Validacion Opcion Volver",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execActualizacionDeDatos() throws InterruptedException, IOException {

		swichtIframeLegacyCont();
		clickBtnCodTransacciones();
		clickBtnActualizacionDeDatos();
		setTxtCtaCorreo(objAux.buscaElementoParametro("txtCtaCorreo"));
		slcTxtDepartamento(objAux.buscaElementoParametro("codDepartamento"));
		slcTxtCiudad(objAux.buscaElementoParametro("codCiudad"));
		slcTxtBarrio(objAux.buscaElementoParametro("codBarrio"));
		slcTxtTipoDireccion(objAux.buscaElementoParametro("TipoDireccion"));
		setTxtDireccion(objAux.buscaElementoParametro("codDireccion"));
		setTxtObservacion(objAux.buscaElementoParametro("codObservacion"));
		objAux.AdminDocPdf.generaEvidencia("Ingreso de Datos",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnContinuar();
		objAux.AdminDocPdf.generaEvidencia("Validacion Boton Continuar",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnConfirmar();
		assertTrue(getLblRegSolicitud().contains(objAux.buscaElementoParametro("Validacion")));
		objAux.AdminDocPdf.generaEvidencia("Validacion Boton Confirmar",
				Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}