package transacciones.paginas;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class Superpreferidos {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.linkText("Transacciones");
	By btnSuperpreferidos = By.linkText("SuperPreferidos");
	By btnAgregar = By.id("ctl00_ContentPlaceHolder1_lnkAgrega");
	By txtNumPreferido = By.id("ctl00_ContentPlaceHolder1_txtCelular1");
	By txtNombre = By.id("ctl00_ContentPlaceHolder1_txtNomPre1");
	By btnAgregarPref = By.id("ctl00_ContentPlaceHolder1_lnkAgrega");
	By btnConsultar = By.id("ctl00_ContentPlaceHolder1_lnkConsulta");
	By tblSuperpreferidos = By.id("ctl00_ContentPlaceHolder1_tabdatos");
	By cmpTblModificar = By.xpath("(//*[contains(@id, 'ctl00_ContentPlaceHolder1_lb')])[3]");
	By cmpTblEliminar = By.xpath("(//*[contains(@id, 'ctl00_ContentPlaceHolder1_chkNumero')])[1]");

	By txtNombreModificado = By.name("ctl00$ContentPlaceHolder1$txtNomPreferido");
	By btnGuardarNombre = By.id("ctl00_ContentPlaceHolder1_lnkGuardarNombre");

	By btnEliminar = By.id("ctl00_ContentPlaceHolder1_lnkElimina");
	By btnConfirmarElim = By.id("ctl00_ContentPlaceHolder1_lnkConfirmar");

	By btnVolver = By.id("ctl00_ContentPlaceHolder1_lnkVolver");
	By opcionesMenu = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li");
	By lstLineas = By.xpath("//*[@id='mCSB_1_container']");
	By iframe = By.xpath("//*[@id='LegacyContainer']");
	By body = By.tagName("body");

	/* Constructor */
	public Superpreferidos(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void swichtIframe() {
		objAux.EsperaElemento(objAux.getDriver(), iframe);
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(iframe));
	}

	public void clickBtnCodTransacciones() {
		objAux.getDriver().findElement(btnTransacciones).click();
	}

	public void clickBtnCodSuperpreferidos() {
		objAux.getDriver().findElement(btnSuperpreferidos).click();
	}

	public void clickBtnAgregar() {
		objAux.getDriver().findElement(btnAgregar).click();
	}

	public void setTxtNumPreferido(String numPreferido) {
		objAux.getDriver().findElement(txtNumPreferido).clear();
		objAux.getDriver().findElement(txtNumPreferido).sendKeys(numPreferido);
	}

	public void setTxtNombre(String nombre) {
		objAux.getDriver().findElement(txtNombre).clear();
		objAux.getDriver().findElement(txtNombre).sendKeys(nombre);
	}

	public void clickBtnAgregarPref() {
		objAux.getDriver().findElement(btnAgregarPref).click();
	}

	public void clickBtnConsultar() throws InterruptedException, IOException {
		objAux.scrollMostrarObjetosNoVisibles(btnConsultar);
		objAux.AdminDocPdf.generaEvidencia("Numero agregado", Shutterbug.shootPage(objAux.getDriver()).getImage());
		objAux.getDriver().findElement(btnConsultar).click();
	}

	public void clickLnkModificar() throws IOException, InterruptedException {

		WebElement tbl = objAux.getDriver().findElement(tblSuperpreferidos);
		WebElement campoModificar = tbl.findElement(cmpTblModificar);
		campoModificar.click();
	}

	public void clickChkEliminar() throws IOException, InterruptedException {

		WebElement tbl = objAux.getDriver().findElement(tblSuperpreferidos);
		WebElement campoEliminar = tbl.findElement(cmpTblEliminar);
		campoEliminar.click();
	}

	public void setTxtNombreModificado(String nombreModificar) throws InterruptedException, IOException {
		objAux.scrollMostrarObjetosNoVisibles(txtNombreModificado);
		objAux.getDriver().findElement(txtNombreModificado).clear();
		objAux.getDriver().findElement(txtNombreModificado).sendKeys(nombreModificar);
	}

	public void clickBtnGuardarNombre() {
		objAux.getDriver().findElement(btnGuardarNombre).click();
	}

	public void clickBtnEliminar() {
		objAux.getDriver().findElement(btnEliminar).click();
	}

	public void clickBtnConfirmarElim() {
		objAux.getDriver().findElement(btnConfirmarElim).click();
	}

	public void clickBtnVolver() {
		objAux.getDriver().findElement(btnVolver).click();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execSuperPreferidos() throws IOException, InterruptedException {

		swichtIframe();
		clickBtnCodTransacciones();
		clickBtnCodSuperpreferidos();
		objAux.AdminDocPdf.generaEvidencia("Ingreso Modulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnAgregar();
		objAux.AdminDocPdf.generaEvidencia("Opcion Agregar", Shutterbug.shootPage(objAux.getDriver()).getImage());

		setTxtNumPreferido(objAux.buscaElementoParametro("NumeroPreferido"));
		setTxtNombre(objAux.buscaElementoParametro("Nombre"));
		objAux.AdminDocPdf.generaEvidencia("Ingreso Preferido", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnAgregarPref();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Validacion Agregar")), "Validacion Agregar");
		clickBtnConsultar();

		clickLnkModificar();
		setTxtNombreModificado(objAux.buscaElementoParametro("Nombre Modificado"));
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Nombre a Modificar", Shutterbug.shootPage(objAux.getDriver()).getImage());
		clickBtnGuardarNombre();
		objAux.scrollMostrarObjetosNoVisibles(tblSuperpreferidos);
		objAux.AdminDocPdf.generaEvidencia("Nombre Modificado", Shutterbug.shootPage(objAux.getDriver()).getImage());
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Nombre Modificado")), "Nombre Modificado");

		clickChkEliminar();
		clickBtnEliminar();
		objAux.AdminDocPdf.generaEvidencia("Eliminar", Shutterbug.shootPage(objAux.getDriver()).getImage());
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Confirma Eliminar")), "Confirma Eliminar");
		clickBtnConfirmarElim();
		objAux.AdminDocPdf.generaEvidencia("Confirmaci�n", Shutterbug.shootPage(objAux.getDriver()).getImage());
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Eliminacion")), "Eliminacion");

		clickBtnVolver();
		objAux.AdminDocPdf.generaEvidencia("Opcion Volver", Shutterbug.shootPage(objAux.getDriver()).getImage());
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Validacion Volver")), "Validacion Volver");
	}
}