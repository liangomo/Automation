package transacciones.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class PagoDeSaldo {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.linkText("Transacciones");
	By linkPagoSaldo = By.linkText("Pago del saldo");
	By btnAqui = By.xpath("//div[@class='banner_tutorial_bancos']");
	By txtValorAPagar = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_valor_pagar']"); 
	By txtEntidadFinanciera = By.id("ctl00_ContentPlaceHolder1_CmbEntidad");
	By btnHacerPago = By.id("ctl00_ContentPlaceHolder1_btnPagar");
	By btnPagar = By.id("ctl00_ContentPlaceHolder1_btnPagar");
	By iframe = By.xpath("//*[@id='LegacyContainer']");
	By btnCancelar = By.id("ctl00_ContentPlaceHolder1_btnDeclina");
	By btnEditarValores = By.id("ctl00_ContentPlaceHolder1_editar_valores");
	By btnAceptar = By.id("acepta");
	By btnAceptarPago = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_btnPagar']");
	By body = By.tagName("body");
	By lblTelefMovil = By.id("ctl00_ContentPlaceHolder1_Etiqueta");

	/* Constructor */
	public PagoDeSaldo(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void swichtIframe() {
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(iframe));
	}

	public void clickTransacciones() throws InterruptedException {
		objAux.getDriver().findElement(btnTransacciones).click();
	}

	public void clicklinkPagoSaldo() {
		this.objAux.getDriver().findElement(linkPagoSaldo).click();
	}

	public void clickBtnAqui() {
		objAux.getDriver().findElement(btnAqui).click();
	}

	public void clickBtnEditarValores() {
		objAux.getDriver().findElement(btnEditarValores).click();
	}

	public void setTxtValorAPagar(String sCodValorAPagar) {
		objAux.getDriver().findElement(txtValorAPagar).clear();
		objAux.getDriver().findElement(txtValorAPagar).sendKeys(sCodValorAPagar);
	}

	public void clickTxtEntidadFinanciera(String pCodEntidadFinanciera) {
		new Select(objAux.getDriver().findElement(txtEntidadFinanciera)).selectByVisibleText(pCodEntidadFinanciera);
	}

	public void clickBtnPagar() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnPagar);
		this.objAux.getDriver().findElement(btnPagar).click();
	}

	public void clickBtnCancelar() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnCancelar);
		this.objAux.getDriver().findElement(btnCancelar).click();   
	}

	public void clickBtnAceptar() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnAceptar);
		this.objAux.getDriver().findElement(btnAceptar).click();
	}

	public void clickBtnAceptarPago() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnAceptarPago);
		this.objAux.getDriver().findElement(btnAceptarPago).click();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	public String getLblTelefMovil() {
		return this.objAux.getDriver().findElement(lblTelefMovil).getText();
	}

	/** METODOS */

	public void execPagoSinSaldo() throws InterruptedException, IOException, AWTException {
		swichtIframe();
		clickTransacciones();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objAux.getDriver()).getImage());
		clicklinkPagoSaldo();

		objAux.getDriver().switchTo().alert().accept();
		clickBtnAqui();

		pagoProds();
	}

	public void execPagoProdConSaldo() throws InterruptedException, IOException, AWTException {
		swichtIframe();
		clickTransacciones();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objAux.getDriver()).getImage());
		clicklinkPagoSaldo();
		pagoProds();
	}

	public void pagoProds() throws InterruptedException, IOException, AWTException {
		
		clickBtnEditarValores();
		setTxtValorAPagar(objAux.buscaElementoParametro("ValorAPagar"));
		clickTxtEntidadFinanciera(objAux.buscaElementoParametro("EntidadFinanciera"));
		objAux.AdminDocPdf.generaEvidencia("Valor a recargar ", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnPagar();
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Redireccionamiento pagina siguiente",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		keyPressInicio();
		objAux.AdminDocPdf.generaEvidencia("Confirmacion", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnAceptar();
		objAux.AdminDocPdf.generaEvidencia("Confirmacion Pago", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnAceptarPago(); Thread.sleep(3000);
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Validacion")));
		objAux.AdminDocPdf.generaEvidencia("Redirecciona Banco", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execBotonCancelar() throws InterruptedException, IOException, AWTException {
		swichtIframe();
		clickTransacciones();
		clicklinkPagoSaldo();

		clickBtnEditarValores();
		setTxtValorAPagar(objAux.buscaElementoParametro("ValorAPagar"));
		clickTxtEntidadFinanciera(objAux.buscaElementoParametro("EntidadFinanciera"));
		objAux.AdminDocPdf.generaEvidencia("Valor a recargar", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnPagar();
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Pag siguiente", Shutterbug.shootPage(objAux.getDriver()).getImage());

		keyPressInicio();
		objAux.AdminDocPdf.generaEvidencia("Msj de Confirmacion", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnAceptar();
		objAux.AdminDocPdf.generaEvidencia("Redirecciona Banco", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnCancelar();
		assertTrue(getLblTelefMovil().contains(objAux.buscaElementoParametro("Validacion")));
		objAux.AdminDocPdf.generaEvidencia("Pagina inicial", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void keyPressInicio() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_HOME);
		Thread.sleep(2000); 
	}
}