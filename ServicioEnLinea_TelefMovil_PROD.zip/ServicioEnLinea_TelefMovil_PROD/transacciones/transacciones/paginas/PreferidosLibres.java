package transacciones.paginas;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class PreferidosLibres {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.linkText("Transacciones");
	By btnPreferidosLibres = By.linkText("Preferidos libres");
	By btnVolver = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_volverMC']");
	By btnConsultarCualquierOperador = By.xpath(
			"//*[@id='ctl00_ContentPlaceHolder1_Listas']/tbody/tr[1]/td/table/tbody/tr[3]/td/table/tbody/tr/td[2]/a");
	By txtNumPreferido = By.id("ctl00_ContentPlaceHolder1_txtCelular1");
	By txtNombre = By.id("ctl00_ContentPlaceHolder1_txtNomPre1");
	By btnAgregarPref = By.id("ctl00_ContentPlaceHolder1_lba2");
	By btnAgregarPrefIntern = By.id("ctl00_ContentPlaceHolder1_lba1");
	By btnAgregarDatos = By.id("ctl00_ContentPlaceHolder1_lnkAgregar");
	By btnConfirmar = By.id("ctl00_ContentPlaceHolder1_lnkConfirmar");
	By btnConsultar = By.id("ctl00_ContentPlaceHolder1_lnkConsultar");
	By lnkEliminar = By.xpath("//*[contains(text(), 'Eliminar')]");

	By btnPreferidoIlimiMovistar = By.xpath(
			"//*[@id='ctl00_ContentPlaceHolder1_Listas']/tbody/tr[2]/td/table/tbody/tr[3]/td/table/tbody/tr/td[2]/a");
	By btnAgregarMovistar = By.id("ctl00_ContentPlaceHolder1_lba1");

	By btnPreferidoInternacional = By.xpath(
			"//*[@id='ctl00_ContentPlaceHolder1_Listas']/tbody/tr[3]/td/table/tbody/tr[3]/td/table/tbody/tr/td[2]/a");
	By body = By.tagName("body");

	/* Constructor */
	public PreferidosLibres(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickBtnTransacciones() {
		this.objAux.getDriver().switchTo().frame("LegacyContainer");
		objAux.getDriver().findElement(btnTransacciones).click();
	}

	public void clickBtnPreferidosLibres() {
		objAux.getDriver().findElement(btnPreferidosLibres).click();
	}

	public void clickBtnVolver() {
		objAux.getDriver().findElement(btnVolver).click();
	}

	public void clickBtnAgregarDatos() {
		objAux.getDriver().findElement(btnAgregarDatos).click();
	}

	public void clickBtnConfirmar() {
		objAux.getDriver().findElement(btnConfirmar).click();
	}

	public void clickBtnConsultar() {
		objAux.getDriver().findElement(btnConsultar).click();
	}

	public void clickLnkEliminar() {
		objAux.getDriver().findElement(lnkEliminar).click();
	}

	public void clickBtnAgregarPref() {
		objAux.getDriver().findElement(btnAgregarPref).click();
	}

	public void clickBtnAgregarPrefIntern() {
		objAux.getDriver().findElement(btnAgregarPrefIntern).click();
	}

	public void setTxtNumPreferido(String pNumPreferido) {
		objAux.getDriver().findElement(txtNumPreferido).clear();
		objAux.getDriver().findElement(txtNumPreferido).sendKeys(pNumPreferido);
	}

	public void setTxtNombre(String pCodNombre) {
		objAux.getDriver().findElement(txtNombre).clear();
		objAux.getDriver().findElement(txtNombre).sendKeys(pCodNombre);
	}

	public void clickBtnConsultarCualquierOperador() {
		objAux.getDriver().findElement(btnConsultarCualquierOperador).click();
	}

	public void clickBtnPreferidoIlimiMovistar() {
		objAux.getDriver().findElement(btnPreferidoIlimiMovistar).click();
	}

	public void clickBtnPreferidoInternacional() {
		objAux.getDriver().findElement(btnPreferidoInternacional).click();
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execValidarOpcionVolver() throws IOException {

		clickBtnTransacciones();
		clickBtnPreferidosLibres();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al modulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnVolver();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Validacion")));
		objAux.AdminDocPdf.generaEvidencia("Opcion volver", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execValidacionCualquierOperador(String preferido) throws IOException {

		if (preferido.equals("Internacional"))
			clickBtnAgregarPrefIntern();
		else
			clickBtnAgregarPref();

		setTxtNumPreferido(objAux.buscaElementoParametro("NumeroPreferido"));
		setTxtNombre(objAux.buscaElementoParametro("Nombre"));
		objAux.AdminDocPdf.generaEvidencia("Ingreso de datos", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnAgregarDatos();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("Validacion")), "Validacion");
		objAux.AdminDocPdf.generaEvidencia("Validacion Agregar", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnConfirmar();
		assertTrue(getBody().contains(objAux.buscaElementoParametro("ValidacionConfirmar")), "Validacion Confirmar");
		objAux.AdminDocPdf.generaEvidencia("Bot�n Confirmar", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnConsultar();
		objAux.AdminDocPdf.generaEvidencia("Bot�n Consultar", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickLnkEliminar();
		objAux.AdminDocPdf.generaEvidencia("Opci�n Eliminar", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execValidacion9Preferidos() throws IOException {

		clickBtnTransacciones();
		clickBtnPreferidosLibres();
		clickBtnConsultarCualquierOperador();
		objAux.AdminDocPdf.generaEvidencia("Ingreso a modulo consulta Cualquier Operador",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		execValidacionCualquierOperador("9 Preferidos");
	}

	public void execValidacionPreferidoMovistar() throws IOException {

		clickBtnTransacciones();
		clickBtnPreferidosLibres();
		clickBtnPreferidoIlimiMovistar();
		objAux.AdminDocPdf.generaEvidencia("Ingreso a modulo Preferido Ilimitado Movistar",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		execValidacionCualquierOperador("Movistar");
	}

	public void execValidacionPreferidoInternacional() throws IOException {

		clickBtnTransacciones();
		clickBtnPreferidosLibres();
		clickBtnPreferidoInternacional();
		objAux.AdminDocPdf.generaEvidencia("Ingreso a modulo Preferido Internacional",
				Shutterbug.shootPage(objAux.getDriver()).getImage());

		execValidacionCualquierOperador("Internacional");
	}
}