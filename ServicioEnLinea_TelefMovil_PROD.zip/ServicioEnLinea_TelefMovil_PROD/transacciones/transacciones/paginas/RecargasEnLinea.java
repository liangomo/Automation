package transacciones.paginas;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class RecargasEnLinea {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.linkText("Transacciones");
	By btnRecargasEnL�neaConPSE = By.linkText("Recargas en l�nea con PSE");
	By txtValorRecarga = By.id("ctl00_ContentPlaceHolder1_TxtValorPago");
	By txtNumCelular = By.id("ctl00_ContentPlaceHolder1_txtNumCelular");
	By txtEntFinanciera = By.id("ctl00_ContentPlaceHolder1_CmbEntidad");
	By btnRecarga = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_btnRecargar']");
	By btnPagar = By.id("ctl00_ContentPlaceHolder1_btnPagar");
	By btnPagarPse = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_btnPagar']");
	By btnCancelar = By.id("ctl00_ContentPlaceHolder1_btnDeclina");
	By btnCancelarPse = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_btnDeclina']");
	By iframe = By.xpath("//*[@id='LegacyContainer']");
	By lstLineas = By.xpath("//*[@id='mCSB_1_container']");
	By lblRecargaOnline = By.xpath("//*[@id='horizontalTab']/div/h2[1]");
	//	By btnMasRecargaOnline = By.xpath ("//*[@id='horizontalTab']/div/h2[1]/span");
	By btnMasRecargaOnline = By.xpath("//*[@id='horizontalTab']/div/h2[1]");
	By body = By.tagName("body");

	/* Constructor */
	public RecargasEnLinea(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void swichtIframe() {
		objAux.EsperaElemento(objAux.getDriver(), iframe);
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(iframe));
	}

	public void clickBtnTransacciones() {
		objAux.getDriver().findElement(btnTransacciones).click();
	}

	public void clickBtnRecargasEnL�neaConPSE() {
		objAux.getDriver().findElement(btnRecargasEnL�neaConPSE).click();
	}

	public void setTxtValorRecarga(String codValorRecarga) {
		objAux.getDriver().findElement(txtValorRecarga).clear();
		objAux.getDriver().findElement(txtValorRecarga).sendKeys(codValorRecarga);
	}

	public void setTxtNumCelular(String codNumCelular) {
		objAux.getDriver().findElement(txtNumCelular).clear();
		objAux.getDriver().findElement(txtNumCelular).sendKeys(codNumCelular);
	}

	public void slcTxtEntFinanciera(String codEntFinanciera) {
		new Select(objAux.getDriver().findElement(txtEntFinanciera)).selectByVisibleText(codEntFinanciera);
	}

	public void clickBtnRecarga() {
		objAux.getDriver().findElement(btnRecarga).click();
	}

	public void clickBtnPagarPse() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnPagarPse);
		this.objAux.getDriver().findElement(btnPagarPse).click();
	}

	public void clickBtnCancelar() throws InterruptedException {
		objAux.scrollMostrarObjetosNoVisibles(btnCancelar);
		this.objAux.getDriver().findElement(btnCancelar).click();
	}

	public void clickLblRecargaOnline() {
		objAux.getDriver().findElement(lblRecargaOnline).click();
	}

	public void setTxtEntFinanciera(String entidadFinanciera) {
		this.objAux.getDriver().findElement(txtEntFinanciera).sendKeys(entidadFinanciera);
	}

	public void clickBtnCancelarPse() {
		objAux.getDriver().findElement(btnCancelarPse).click();
	}

	public void clickBtnMasRecargaOnline() {
		objAux.getDriver().findElement(btnMasRecargaOnline).click();
	}

	public void clickBtnMasRecargaOnlineCcontrol(){

		if (!objAux.getDriver().findElement(btnRecarga).isEnabled()) {
			objAux.getDriver().findElement(btnMasRecargaOnline).click();
		}
	}

	public String getBody() {
		return this.objAux.getDriver().findElement(body).getText();
	}

	/** METODOS */

	public void execIngresarDatosRecarga() throws InterruptedException, IOException {

		swichtIframe();
		clickBtnTransacciones();
		clickBtnRecargasEnL�neaConPSE();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnMasRecargaOnline();
		objAux.AdminDocPdf.generaEvidencia("Recarga Online", Shutterbug.shootPage(objAux.getDriver()).getImage());

		setTxtValorRecarga(objAux.buscaElementoParametro("ValorRecarga"));
		setTxtNumCelular(objAux.buscaElementoParametro("NumeroCelular"));
		setTxtEntFinanciera(objAux.buscaElementoParametro("EntidadFinanciera"));
		objAux.AdminDocPdf.generaEvidencia("Valores recarga", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnRecarga();
		objAux.AdminDocPdf.generaEvidencia("Recargar", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execIngresarDatosRecargaCcontrol() throws InterruptedException, IOException {

		swichtIframe();
		clickBtnTransacciones();
		clickBtnRecargasEnL�neaConPSE();
		objAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnMasRecargaOnlineCcontrol();
		objAux.AdminDocPdf.generaEvidencia("RecargaOnlinePse", Shutterbug.shootPage(objAux.getDriver()).getImage());

		setTxtValorRecarga(objAux.buscaElementoParametro("ValorRecarga"));
		setTxtNumCelular(objAux.buscaElementoParametro("NumeroCelular"));
		setTxtEntFinanciera(objAux.buscaElementoParametro("EntidadFinanciera"));
		objAux.AdminDocPdf.generaEvidencia("Valores recarga", Shutterbug.shootPage(objAux.getDriver()).getImage());

		clickBtnRecarga();
		objAux.AdminDocPdf.generaEvidencia("Recargar", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execValidarBotonPagar() throws InterruptedException, IOException {

		clickBtnPagarPse();
		objAux.AdminDocPdf.generaEvidencia("Opcion Pagar", Shutterbug.shootPage(objAux.getDriver()).getImage());
	}

	public void execValidarBotonCancelar() throws InterruptedException, IOException {

		clickBtnCancelar();
		objAux.AdminDocPdf.generaEvidencia("Opcion Cancelar",Shutterbug.shootPage(objAux.getDriver()).getImage());
	}
}