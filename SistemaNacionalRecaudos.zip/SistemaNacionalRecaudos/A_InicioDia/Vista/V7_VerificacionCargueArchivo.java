package A_InicioDia.Vista;
import java.awt.image.RenderedImage;
import resources.A_InicioDia.Vista.V7_VerificacionCargueArchivoHelper;
import com.lowagie.text.Document;

public class V7_VerificacionCargueArchivo extends V7_VerificacionCargueArchivoHelper
{
	/** INICIALIZACI�N DE VARIABLES */
	
	/* Inicializaci�n de archivo para Log */
	RenderedImage imagen;
	
	public void testMain(Object[] args) 
	{
		Document doc = (Document) args[6];


		/** SCRIPT PARA LA VERIFICAR EL CARGUE DE PAQUETES DEL ARCHIVO PARCIAL 1 */

		/* Capturar im�gen y guardar en PDF */
		imagen = browser_htmlBrowser(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "Login", doc);

		
		/* Ingreso m�dulo Asignaci�n de Paquetes */
		if (button__Asignaci�nDePaquetesbu().ensureObjectIsVisible())
			button__Asignaci�nDePaquetesbu(ANY, LOADED).click();
		else {
			button_coordinadoRbutton(ANY, LOADED).click();
			button_paqueteSbutton(ANY, LOADED).click();
			button__Asignaci�nDePaquetesbu(ANY, LOADED).click(); sleep(3);
		}


		/** EVIDENCIA */
		/* Log Detallado */
		addTexto("VERIFICACI�N CARGUE 1 - Ciudad: " + args[3] + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = table_htmlTable_0(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "Verificacion", doc);

	}
}