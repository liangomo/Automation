package A_InicioDia.Vista;
import java.awt.image.RenderedImage;
import resources.A_InicioDia.Vista.V4_InicioDiaHelper;
import com.lowagie.text.Document;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V4_InicioDia extends V4_InicioDiaHelper
{
	/** INICIALIZACI�N DE VARIABLES: */

	/* Inicializacion de archivo para Log */
	RenderedImage imagen;

	public void testMain(Object[] args) 
	{
		Document doc = (Document) args[6];
		
		
		/** SCRIPT PARA EL CARGUE DE LOS ARCHIVOS DEL FTP CON LOS PAQUETES */
		
		/* Ingreso m�dulo primer nivel */
		if (button__InicioDeD�abutton().ensureObjectIsVisible())
			button__InicioDeD�abutton(ANY, LOADED).click();
		else {
			button_administradoRbutton(ANY, LOADED).click();
			button_controldiariObutton(ANY, LOADED).click();
			button__InicioDeD�abutton(ANY, LOADED).click(); sleep(3);
		}
		
		/* Clic en bot�n generar para cargar los archivos del FTP */
		button_generarsubmit().waitForExistence();
		button_generarsubmit().click();
		
		button_htmlDialogButtonAceptar().waitForExistence();
		button_htmlDialogButtonAceptar().click();
		
		if (button_htmlDialogButtonAceptar().exists())
			button_htmlDialogButtonAceptar().click();
		
		sleep(60);

		
		/** Evidencia */
		/* Capturar im�gen y guardar en PDF */
		imagen = document_sistemanacionaldereca(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "InicioDia", doc);
	}
}