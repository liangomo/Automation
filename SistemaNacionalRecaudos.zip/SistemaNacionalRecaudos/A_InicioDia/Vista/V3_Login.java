package A_InicioDia.Vista;
import java.awt.image.RenderedImage;
import resources.A_InicioDia.Vista.V3_LoginHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V3_Login extends V3_LoginHelper
{
	/** INICIALIZACI�N DE VARIABLES: */

	/* Inicializacion de archivo para Log */
	RenderedImage imagen;

	public void testMain(Object[] args) 
	{
		/* Terminar los procesos del IE */
		MatarProceso(); sleep(3);


		/** Inicio Aplicaci�n */
		startApp("SNR");


		/** Datos del Login */

		/* Datos */
		text_j_username(ANY,LOADED).waitForExistence();
		browser_htmlBrowser().maximize(); sleep(4);
		text_j_username(ANY,LOADED).click();
		text_j_username(ANY,LOADED).setText((String)args[0]); System.out.println("u"+args[0]);
		browser_htmlBrowser(document_sistemanacionaldereca(ANY,LOADED),DEFAULT_FLAGS).inputKeys("{TAB}");

		text_j_password().setText((String)args[1]);
		browser_htmlBrowser(document_sistemanacionaldereca(ANY,LOADED),DEFAULT_FLAGS).inputKeys("^{TAB}");
		form_securityForm().click();

		list_dominio().click();
		browser_htmlBrowser(document_sistemanacionaldereca(ANY,LOADED),DEFAULT_FLAGS).inputKeys((String)args[2] + "{TAB}"); sleep(2);

		/* Ingresar */
		button_ingresarAlSistemabutton().click(); sleep(2);

		/* Cerrar pesta�a 1 que se abre al ingresar */
		browser_htmlBrowser(document_sistemanacionaldereca2(),DEFAULT_FLAGS).inputKeys("^{TAB}"); sleep(3);
		browser_htmlBrowser(document_sistemanacionaldereca2(),DEFAULT_FLAGS).inputKeys("^w");
	}
}