package A_InicioDia.Vista;
import resources.A_InicioDia.Vista.V2_InicioDiaEjecutableHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V2_InicioDiaEjecutable extends V2_InicioDiaEjecutableHelper
{

	public void testMain(Object[] args) 
	{
		/** INICIO EJECUTABLE FileZillaPortable */
		
		/* Validar si FileZillaPortable est� abierto para cerrarlo */
		if (pruebassnrfFtpesUSER_FTPAtlas2().exists()) {
			pruebassnrfFtpesUSER_FTPAtlas2(ANY, LOADED).close();
		} else if (fileZillawindow().exists()) {
			fileZillawindow(ANY, LOADED).close();
		} else {}

		/* Inicio del Ejecutable */
		startApp("SNR_InicioDia");
		
		
		/** SELECCIONAR RUTAS LOCAL Y REMOTO PARA CARGUE DE ARCHIVOS AL FTP */
		
		/* Abrir el Gestor de Sitios y Seleccionar "PRUEBAS SNR F" */
		abrirElGestorDeSitios().waitForExistence();
		abrirElGestorDeSitios().click(atName("Abrir"));
		contextopopupMenu().click(atPath("PRUEBAS SNR F"));

		/* Ingresar a IN como sitio remoto */
		comboBoxcomboBox2().setText("\\IN\\");
		pruebassnrfFtpesUSER_FTPAtlas2().inputKeys("{ENTER}");

		/* Ir al sitio local donde est�n ubicados los archivos de cargue */
		comboBoxcomboBox().setText("D:\\SNR - Inicio de Dia\\Archivos");
		pruebassnrfFtpesUSER_FTPAtlas2().inputKeys("{ENTER}");

		
		/** PASAR ARCHIVOS AL FTP */
		
		/* Seleccionar la tabla en donde est�n los archivos a subir */
		sysListView32table2().click();
		pruebassnrfFtpesUSER_FTPAtlas2().inputKeys("^a"); sleep(3);

		/* Clic derecho y subir archivos que pasa a la ruta remota */
		sysListView32table2().click(RIGHT,  atCell(
              atRow(atText("CAPNOCPARCIAL_1.txt")), 
              atColumn(atText("Nombre de archivo"))), atPoint(80,10));
		contextopopupMenu().click(atPath("Subir")); sleep(3);

		/* Activar check si los archivos ya existen en el FTP para reemplazarlos */
		if (usarSiempreEstaAcci�ncheckBox().exists()) {
			usarSiempreEstaAcci�ncheckBox().click(); sleep(3);
			aceptarbutton().click();
		} else {}
		sleep(2);
		
		/* Cerrar FileZillaPortable */
		//pruebassnrfFtpesUSER_FTPAtlas2().close();

	}
}