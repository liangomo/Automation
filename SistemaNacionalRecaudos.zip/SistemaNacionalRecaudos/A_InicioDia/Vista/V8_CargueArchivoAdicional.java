package A_InicioDia.Vista;
import java.awt.image.RenderedImage;
import resources.A_InicioDia.Vista.V8_CargueArchivoAdicionalHelper;
import com.lowagie.text.Document;

public class V8_CargueArchivoAdicional extends V8_CargueArchivoAdicionalHelper
{
	/** INICIALIZACI�N DE VARIABLES: */

	/* Inicializacion de archivo para Log */
	RenderedImage imagen;

	public void testMain(Object[] args) 
	{
		Document doc = (Document) args[6];


		/** SCRIPT PARA EL CARGUE DE LOS ARCHIVOS DEL FTP CON LOS PAQUETES */

		/* Ingreso m�dulo primer nivel */
		if (button__CargarArchivoCAPNOCPAR().ensureObjectIsVisible())
			button__CargarArchivoCAPNOCPAR(ANY, LOADED).click();
		else {
			button_administradoRbutton(ANY, LOADED).click();
			button_controldiariObutton(ANY, LOADED).click();
			button__CargarArchivoCAPNOCPAR(ANY, LOADED).click(); sleep(3);
		}

		image_upload_icon().waitForExistence();
		image_upload_icon().click();

		button_htmlDialogButtonAceptar().waitForExistence();
		button_htmlDialogButtonAceptar().click(); sleep(5);
		
		
		/** EVIDENCIA */
		/* Log Detallado */
		addTexto("\n" + "Cargue archivo parcial 2" + "\n\n", doc);

		/* Capturar im�gen y guardar en PDF */
		table_htmlTable_0().waitForExistence();
		imagen = table_htmlTable_0(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "ArchivoParcial2", doc);

	}
}