package A_InicioDia.Vista;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import resources.A_InicioDia.Vista.V1_AjusteFechaArchivoHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V1_AjusteFechaArchivo extends V1_AjusteFechaArchivoHelper
{
	/** INICIALIZACI�N DE VARIABLES: */

	/* Inicializacion de archivo para Logs */
	PrintWriter pw = null;
	FileWriter insertar = null;


	public void testMain(Object[] args) throws IOException 
	{
		String[] rutasOrigen = {"D:\\SNR - Inicio de Dia\\Archivos\\CAPNOCPARCIAL_1.txt",
				"D:\\SNR - Inicio de Dia\\Archivos\\CAPNOCPARCIAL_2.txt",
		"D:\\SNR - Inicio de Dia\\Archivos\\CAPNOCTOTAL.txt"};

		String rutasDestino = "D:\\SNR - Inicio de Dia\\Archivos\\CAPNOCPARCIAL_COPIA";

		/** AJUSTAR FECHA ACTUAL A LOS ARCHIVOS DE CARGUE AL FTP */
		for(int i = 0; i < rutasOrigen.length; i++) {

			/* Creaci�n archivo CAPNOCPARCIAL_COPIA a partir del CAPNOCPARCIAL_1 original */
			PruebaLeerArchivo(rutasOrigen[i], rutasDestino);

			/* Creaci�n archivo CAPNOCPARCIAL_1 original a partir del CAPNOCPARCIAL_COPIA creado */
			PruebaLeerArchivo(rutasDestino, rutasOrigen[i]);

			/* Eliminar archivo CAPNOCPARCIAL_COPIA despu�s de utilizado */
			File ruta = new File(rutasDestino);
			ruta.delete();
		}
	}

	/** LEER ARCHIVO ORIGEN Y CREAR NUEVO CON EL CAMBIO A LA FECHA ACTUAL */
	public void PruebaLeerArchivo(String origen, String destino) throws IOException {

		/* Se define contador en cero para el primer registro que no tome salto de l�nea */
		int aux = 0;

		/* Creaci�n archivo e inserci�n */
		FileReader file = new FileReader(origen);
		BufferedReader buffer = new BufferedReader(file);
		insertar = new FileWriter(destino);
		pw = new PrintWriter(insertar);

		/* Ciclo que controla la lectura del txt e imprime en el nuevo TXT */
		String registro = "";
		while((registro = buffer.readLine())!= null)
		{
			if (registro.length() >= 1)
				if (aux == 0) 
					insertarArchivoPrimerReg(registro.substring(0, 44) + FechaInicioDia() + registro.substring(52, 273) +
							FechaInicioDia() + registro.substring(281));
				else
					insertarArchivo(registro.substring(0, 44) + FechaInicioDia() + registro.substring(52, 273) +
							FechaInicioDia() + registro.substring(281));
			aux++;
		}
		buffer.close();
		file.close();
		pw.close();

	}


	/** INSERTAR EL PRIMER REGISTRO EN EL ARCHIVO CREADO - Sin salto de l�nea */
	public void insertarArchivoPrimerReg(String sentencia) 
	{
		pw.print(sentencia);
		System.gc();
	}


	/** INSERTAR REGISTROS EN EL ARCHIVO CREADO - Con salto de l�nea */
	public void insertarArchivo(String sentencia) 
	{
		pw.print("\n"+sentencia);
		System.gc();
	}
}