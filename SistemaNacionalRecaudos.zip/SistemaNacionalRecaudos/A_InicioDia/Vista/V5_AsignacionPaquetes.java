package A_InicioDia.Vista;
import java.awt.image.RenderedImage;
import resources.A_InicioDia.Vista.V5_AsignacionPaquetesHelper;
import com.rational.test.ft.vp.*;
import com.lowagie.text.Document;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V5_AsignacionPaquetes extends V5_AsignacionPaquetesHelper
{
	/** INICIALIZACI�N DE VARIABLES */
	
	/* Inicializaci�n de archivo para Log */
	RenderedImage imagen;
	

	public void testMain(Object[] args) 
	{
		Document doc = (Document) args[6];
		
		
		/** SCRIPT PARA LA ASIGNACION DE PAQUETES AL DIGITADOR */

		/* Ingreso m�dulo Asignaci�n de Paquetes */
		if (button__Asignaci�nDePaquetesbu().ensureObjectIsVisible())
			button__Asignaci�nDePaquetesbu(ANY, LOADED).click();
		else {
			button_coordinadoRbutton(ANY, LOADED).click();
			button_paqueteSbutton(ANY, LOADED).click();
			button__Asignaci�nDePaquetesbu(ANY, LOADED).click(); sleep(3);
		}

		/* Clic en bot�n asignar paquete para seleccionar el digitador */
		button_asignarPaquetesubmit().waitForExistence();
		button_asignarPaquetesubmit().click();

		//		String regex = "[0-9]";
		//	String regex = " (394)";
		//	Pattern patron = Pattern.compile("Liliana Andrea Gomez Morales " + regex);

		list_id_digitador().click(atText((String) args[5])); 
		sleep(2);

		button_guardarsubmit().click();



		/** VALIDACI�N VEREDICTO */
		String veredicto = null,
				resultadoObtenido = null;
		ITestDataTable orderTable = (ITestDataTable) table_list_asig_paq(ANY, LOADED).getTestData("contents");

		if (orderTable.getCell(1, 7).toString().equals("A - Asignado")) {
			veredicto = "EXITOSO";
			resultadoObtenido = "A - Asignado";
		}	else {
			veredicto = "FALLIDO";
			resultadoObtenido = "No aparece en el estado correcto";
		}
		System.out.println(veredicto + "_" + resultadoObtenido);
		
		
		/** Evidencia */
		/* Log Detallado */
		addTexto("ASIGNACI�N PAQUETE - Ciudad: " + args[3] + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = document_sistemanacionaldereca(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "InicioDia", doc);

	}
}