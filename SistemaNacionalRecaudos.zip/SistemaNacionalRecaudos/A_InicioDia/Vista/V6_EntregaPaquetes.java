package A_InicioDia.Vista;
import java.awt.image.RenderedImage;
import resources.A_InicioDia.Vista.V6_EntregaPaquetesHelper;
import com.rational.test.ft.vp.*;
import com.lowagie.text.Document;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V6_EntregaPaquetes extends V6_EntregaPaquetesHelper
{
	
	/** INICIALIZACI�N DE VARIABLES */
	
	/* Inicializaci�n de archivo para Log */
	RenderedImage imagen;
	
	
	public void testMain(Object[] args) 
	{
		Document doc = (Document) args[6];

		/** SCRIPT PARA LA ENTREGA DE PAQUETE FISICO AL DIGITADOR */

		/* Ingreso m�dulo Entrega de Paquetes F�sicos */
		if (button__EntregaDePaquetesF�sic().ensureObjectIsVisible())
			button__EntregaDePaquetesF�sic(ANY, LOADED).click();
		else {
			button_coordinadoRbutton(ANY, LOADED).click();
			button_paqueteSbutton(ANY, LOADED).click();
			button__EntregaDePaquetesF�sic(ANY, LOADED).click(); sleep(3);
		}

		/* Clic en cada uno de los check */

		ITestDataTable orderTable = (ITestDataTable) table_list_paq_fisico(ANY, LOADED).getTestData("contents");

		for ( int row = 1; row < orderTable.getRowCount(); row++) {
			table_list_paq_fisico().click(atCell(atRow(atIndex(row)), 
					atColumn(atIndex(8))));
		}

		sleep(3);
		button_guardarsubmit().click(); sleep(4);


		/** Evidencia */
		/* Log Detallado */
		addTexto("Ciudad: " + args[3] + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = document_sistemanacionaldereca(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "Login", doc);

	}
}