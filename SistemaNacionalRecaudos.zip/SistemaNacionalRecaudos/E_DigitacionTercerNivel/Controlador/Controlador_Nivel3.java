package E_DigitacionTercerNivel.Controlador;
import resources.E_DigitacionTercerNivel.Controlador.Controlador_Nivel3Helper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class Controlador_Nivel3 extends Controlador_Nivel3Helper
{

	public void testMain(Object[] args) {

		/* Ingreso m�dulo tercer nivel */
		if (button__Digitaci�nTercerNivelb().ensureObjectIsVisible())
			button__Digitaci�nTercerNivelb(ANY, LOADED).click();
		else {
			button_digitadoRbutton().click();
			button__Digitaci�nTercerNivelb().click();
		}

		callScript("E_DigitacionTercerNivel.Vista.V1_SeleccionarPaquete_3", args);
		callScript("E_DigitacionTercerNivel.Vista.V2_ConfirmarPaquete_3", args);
		callScript("E_DigitacionTercerNivel.Vista.V3_VistaDigitacion_3", args);
		callScript("E_DigitacionTercerNivel.Vista.V4_AdicionarCuenta_3", args);

	}
}