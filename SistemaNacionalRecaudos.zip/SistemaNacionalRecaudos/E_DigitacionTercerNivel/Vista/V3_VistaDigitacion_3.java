package E_DigitacionTercerNivel.Vista;
import java.awt.image.RenderedImage;
import resources.E_DigitacionTercerNivel.Vista.V3_VistaDigitacion_3Helper;
import com.lowagie.text.Document;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V3_VistaDigitacion_3 extends V3_VistaDigitacion_3Helper
{
	/** INICIALIZACI�N DE VARIABLES: */

	// Inicializacion de archivo para Log
	RenderedImage imagen;

	public void testMain(Object[] args) 
	{
		Document doc = (Document) args[9];
		
		/** Imagen 3 */
		table_htmlTable_0().waitForExistence();
		
		/* Log Detallado */
		addTexto("Paquete: " + args[2] + " - Cuenta: " + args[8] + " - Imagen3" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = table_htmlTable_0(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "TercerNivel_Paq" + args[2] + "_Imagen3", doc); sleep(3);
		
		/* Paso de Pantalla */
		image_editar().waitForExistence();
		image_editar().click();

	}
}