package E_DigitacionTercerNivel.Vista;
import java.awt.image.RenderedImage;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import resources.E_DigitacionTercerNivel.Vista.V4_AdicionarCuenta_3Helper;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.vp.*;
import com.lowagie.text.Document;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V4_AdicionarCuenta_3 extends V4_AdicionarCuenta_3Helper
{
	/** INICIALIZACI�N DE VARIABLES: */

	/* Inicializacion de archivo para Log */
	RenderedImage imagen;

	/* Arreglos */
	ArrayList<String> arregloCampo = new ArrayList<String>();
	ArrayList<String> arregloValor = new ArrayList<String>();

	public void testMain(Object[] args) throws SQLException 
	{

		/**
		 *  Conexi�n a la Base de Datos
		 *   */

		/* Consulta de la informaci�n */
		ResultSet rs = Consulta("SELECT * FROM SNR.Cuentas WHERE IDCuenta = " + args[3]);
		rs.next();

		arregloCampo.add(rs.getString("Campo_0"));
		arregloCampo.add(rs.getString("Campo_1"));
		arregloCampo.add(rs.getString("Campo_2"));
		arregloCampo.add(rs.getString("Campo_3"));
		arregloCampo.add(rs.getString("Campo_4"));
		arregloCampo.add(rs.getString("Campo_5"));
		arregloCampo.add(rs.getString("Campo_6"));

		arregloValor.add(rs.getString("Valor_0"));
		arregloValor.add(rs.getString("Valor_1"));
		arregloValor.add(rs.getString("Valor_2"));
		arregloValor.add(rs.getString("Valor_3"));
		arregloValor.add(rs.getString("Valor_4"));
		arregloValor.add(rs.getString("Valor_5"));
		arregloValor.add(rs.getString("Valor_6"));
		Document doc = (Document) args[9];
		
		/** Digitar N�mero de Cuenta */
		text_numero_cuenta(ANY, LOADED).waitForExistence();
		text_numero_cuenta(ANY, LOADED).setText(rs.getString("NumeroCuenta"));

		/* Diligenciamiento de datos de la cuenta */
		ITestDataTable orderTable2 = (ITestDataTable) table_htmlTable_0(ANY, LOADED).getTestData("contents");

		for (int i = 0; i < arregloCampo.size(); i++) 
		{
			for (int row = 0; row < orderTable2.getRowCount(); row++) 
			{
				int col = 0;

				if (orderTable2.getCell(row, col).toString().equals(arregloCampo.get(i))) 
				{
					TestObject[] radios2 = table_htmlTable_0(ANY, LOADED).find(atDescendant(".class", "Html.INPUT.text"));

					new GuiTestObject(radios2[row - 2]).click(); sleep(1);
					browser_htmlBrowser(table_htmlTable_0(ANY, LOADED), DEFAULT_FLAGS).inputKeys(arregloValor.get(i)); sleep(1);
				}
			}
		}
		
		sleep(4);
		
		/** Imagen 4 */
		form_ma_digitacion_recForm().waitForExistence();
		
		/* Log Detallado */
		addTexto("Paquete: " + args[2] + " - Cuenta: " + args[8] + " - Imagen4" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = form_ma_digitacion_recForm(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "TercerNivel_Paq" + args[2] + "_Imagen4", doc);

		/** Guardar */
		button_guardarbutton().click();	sleep(3);
		button_htmlDialogButtonAceptar().waitForExistence();
		button_htmlDialogButtonAceptar().click();

		
		/** Imagen 5 */
		document_sistemanacionaldereca().waitForExistence();
		
		/* Log Detallado */
		addTexto("Paquete: " + args[2] + " - Cuenta: " + args[8] + " - Imagen5" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = document_sistemanacionaldereca(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "TercerNivel_Paq" + args[2] + "_Imagen5", doc); sleep(10);
		
		
		/** Guardar */
		button_guardarbutton().click(); sleep(3);
		button_htmlDialogButtonAceptar().waitForExistence();
		button_htmlDialogButtonAceptar().click();

		
		/** Imagen 6 */
		document_sistemanacionaldereca().waitForExistence();
		
		/* Log Detallado */
		addTexto("Paquete: " + args[2] + " - Cuenta: " + args[8] + " - Imagen6" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = document_sistemanacionaldereca(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "TercerNivel_Paq" + args[2] + "_Imagen6", doc); sleep(10);
	}
}