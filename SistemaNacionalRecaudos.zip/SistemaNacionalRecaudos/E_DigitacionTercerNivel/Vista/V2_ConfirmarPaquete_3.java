package E_DigitacionTercerNivel.Vista;
import java.awt.image.RenderedImage;
import resources.E_DigitacionTercerNivel.Vista.V2_ConfirmarPaquete_3Helper;
import com.lowagie.text.Document;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V2_ConfirmarPaquete_3 extends V2_ConfirmarPaquete_3Helper
{
	/** INICIALIZACI�N DE VARIABLES: */

	// Inicializacion de archivo para Log
	RenderedImage imagen;

	public void testMain(Object[] args) 
	{
		Document doc = (Document) args[9];
		
		/** Imagen 2 */
		form_ma_digitacion_recForm().waitForExistence();
		
		/* Log Detallado */
		addTexto("Paquete: " + args[2] + " - Cuenta: " + args[8] + " - Imagen2" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = form_ma_digitacion_recForm(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "TercerNivel_Paq" + args[2] + "_Imagen2", doc);
		
		/* Paso de Pantalla */
		image_editar().waitForExistence();
		image_editar().click();
	}
}