package C_DigitacionPrimerNivel.Controlador;
import java.io.IOException;
import java.sql.SQLException;
import resources.C_DigitacionPrimerNivel.Controlador.Controlador_Nivel1Helper;
import com.lowagie.text.DocumentException;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class Controlador_Nivel1 extends Controlador_Nivel1Helper
{

	public void testMain(Object[] args) throws IOException, DocumentException, SQLException 
	{
		/* Ingreso m�dulo primer nivel */
		if (button__Digitaci�nPrimerNivelb().ensureObjectIsVisible())
			button__Digitaci�nPrimerNivelb(ANY, LOADED).click();
		else {
			button_digitadoRbutton().click();
			button__Digitaci�nPrimerNivelb().click();
		}

		/* Secuencia Vistas Digitaci�n Primer Nivel */
		callScript("C_DigitacionPrimerNivel.Vista.V1_SeleccionarPaquete_1", args);
		callScript("C_DigitacionPrimerNivel.Vista.V2_AdicionarCuenta_1", args);
	} 
}