package C_DigitacionPrimerNivel.Vista;
import java.awt.image.RenderedImage;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import resources.C_DigitacionPrimerNivel.Vista.V2_AdicionarCuenta_1Helper;
import com.lowagie.text.Document;
import com.rational.test.ft.object.interfaces.GuiTestObject;
import com.rational.test.ft.object.interfaces.TestObject;
import com.rational.test.ft.vp.ITestDataTable;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V2_AdicionarCuenta_1 extends V2_AdicionarCuenta_1Helper
{
	/** INICIALIZACI�N DE VARIABLES: */

	/* Inicializacion de archivo para Log */
	RenderedImage imagen;

	/* Arreglos */
	ArrayList<String> arregloCampo = new ArrayList<String>();
	ArrayList<String> arregloValor = new ArrayList<String>();

	public void testMain(Object[] args) throws SQLException 
	{
		Document doc = (Document) args[9];

		/**
		 *  Conexi�n a la Base de Datos
		 *   */

		/* Consulta de la informaci�n */
		ResultSet rs = Consulta("SELECT * FROM SNR.Cuentas WHERE IDCuenta = " + args[3]);
		rs.next();

		arregloCampo.add(rs.getString("Campo_0"));
		arregloCampo.add(rs.getString("Campo_1"));
		arregloCampo.add(rs.getString("Campo_2"));
		arregloCampo.add(rs.getString("Campo_3"));
		arregloCampo.add(rs.getString("Campo_4"));
		arregloCampo.add(rs.getString("Campo_5"));
		arregloCampo.add(rs.getString("Campo_6"));

		arregloValor.add(rs.getString("Valor_0"));
		arregloValor.add(rs.getString("Valor_1"));
		arregloValor.add(rs.getString("Valor_2"));
		arregloValor.add(rs.getString("Valor_3"));
		arregloValor.add(rs.getString("Valor_4"));
		arregloValor.add(rs.getString("Valor_5"));
		arregloValor.add(rs.getString("Valor_6"));

		/** Digitar N�mero de Cuenta */
		text_numero_cuenta(ANY, LOADED).waitForExistence();
		text_numero_cuenta(ANY, LOADED).setText((String) args[8]);
		browser_htmlBrowser(document_sistemanacionaldereca(ANY, LOADED), DEFAULT_FLAGS).inputKeys("{TAB}");
		
		// HTML Browser
		browser_htmlBrowser(document_sistemanacionaldereca(),DEFAULT_FLAGS).inputKeys("{TAB}");

		/* Diligenciamiento de datos de la cuenta */

		ITestDataTable orderTable2 = (ITestDataTable) table_htmlTable_1(ANY, LOADED).getTestData("contents");

		for (int i = 0; i < arregloCampo.size(); i++) 
		{
			for (int row = 0; row < orderTable2.getRowCount(); row++) 
			{
				int col = 0;

				if (orderTable2.getCell(row, col).toString().equals(arregloCampo.get(i))) 
				{
					TestObject[] radios2 = table_htmlTable_1(ANY, LOADED).find(atDescendant(".class", "Html.INPUT.text"));

					System.out.println(radios2.length);

					new GuiTestObject(radios2[row - 2]).click(); sleep(1);
					browser_htmlBrowser(table_htmlTable_1(ANY, LOADED), DEFAULT_FLAGS).inputKeys(arregloValor.get(i)); sleep(1);
				}
			}
		}


		/** Imagen 2 */
		/* Log Detallado */
		addTexto("Paquete: " + args[2] + " - Cuenta: " + rs.getString("NumeroCuenta") + " - Imagen2" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = table_htmlTable_1(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "PrimerNivel_Paq" + args[2] + "_Imagen2", doc);

		/** Guardar y salir cerrando paquete */
		if (button_guardarYSalirCerrandoPa(ANY, LOADED).exists())
			button_guardarYSalirCerrandoPa(ANY, LOADED).click();

		button_htmlDialogButtonAceptar(ANY, LOADED).waitForExistence();
		button_htmlDialogButtonAceptar(ANY, LOADED).click(); sleep(2);
	}
}

