package C_DigitacionPrimerNivel.Vista;
import java.awt.image.RenderedImage;
import resources.C_DigitacionPrimerNivel.Vista.V1_SeleccionarPaquete_1Helper;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.vp.*;
import com.lowagie.text.Document;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V1_SeleccionarPaquete_1 extends V1_SeleccionarPaquete_1Helper
{
	/** INICIALIZACI�N DE VARIABLES: */

	/* Inicializacion de archivo para Log */
	RenderedImage imagen;
	
	public void testMain(Object[] args) 
	{
		Document doc = (Document) args[9];
		
		ITestDataTable orderTable = (ITestDataTable) table_summary(ANY, LOADED).getTestData("contents");

		/** Imagen 1 */
		/* Log Detallado */
		addTexto(args[0] + " - " + "Ciudad: " + args[7] + "\n", doc);
		addTexto("Resultado Esperado: " + args[5] + "\n\n", doc);
		addTexto("Paquete: " + args[2] + " - Cuenta: " + args[8] + " - Imagen1" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = table_summary(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "PrimerNivel_Paq" + args[2] + "_Imagen1", doc);


		/** B�squeda paquete */
		for (int row = 1; row < orderTable.getRowCount(); row++) 
		{
			int col = 0;
			if (orderTable.getCell(row, col).toString().equals("" + args[2])) 
			{
				TestObject[] radios = table_summary(ANY, LOADED).find(atDescendant(".class", "Html.IMG"));
				new GuiTestObject(radios[row + 6]).click();
			}
		}
	}
}