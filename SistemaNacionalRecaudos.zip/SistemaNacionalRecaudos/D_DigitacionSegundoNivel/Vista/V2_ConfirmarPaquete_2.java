package D_DigitacionSegundoNivel.Vista;
import java.awt.image.RenderedImage;
import resources.D_DigitacionSegundoNivel.Vista.V2_ConfirmarPaquete_2Helper;
import com.lowagie.text.Document;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V2_ConfirmarPaquete_2 extends V2_ConfirmarPaquete_2Helper
{
	/** INICIALIZACI�N DE VARIABLES: */

	/* Inicializacion de archivo para Log */
	RenderedImage imagen;

	
	public void testMain(Object[] args) 
	{
		Document doc = (Document) args[9];
		
		/** Imagen 2 */
		/* Log Detallado */
		addTexto("Paquete: " + args[2] + " - Cuenta: " + args[8] + " - Imagen2" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = table_summary(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "SegundoNivel_Paq" + args[2] + "_Imagen2", doc); sleep(3);

		/* Seleccionar paquete */
		image_editar().waitForExistence();
		image_editar().click();
	}
}