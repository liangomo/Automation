package D_DigitacionSegundoNivel.Vista;
import java.awt.image.RenderedImage;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import resources.D_DigitacionSegundoNivel.Vista.V3_AdicionarCuenta_2Helper;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.vp.*;
import com.lowagie.text.Document;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class V3_AdicionarCuenta_2 extends V3_AdicionarCuenta_2Helper
{
	/** INICIALIZACI�N DE VARIABLES: */

	/* Inicializacion de archivo para Log */
	RenderedImage imagen;

	/* Arreglos */
	ArrayList<String> arregloCampo = new ArrayList<String>();
	ArrayList<String> arregloValor = new ArrayList<String>();

	public void testMain(Object[] args) throws SQLException 
	{
		Document doc = (Document) args[9];
		
		/**
		 *  Conexi�n a la Base de Datos
		 *   */

		/* Consulta de la informaci�n */
		ResultSet rs = Consulta("SELECT * FROM SNR.Cuentas WHERE IDCuenta = " + args[3]);
		rs.next();

		arregloCampo.add(rs.getString("Campo_0"));
		arregloCampo.add(rs.getString("Campo_1"));
		arregloCampo.add(rs.getString("Campo_2"));
		arregloCampo.add(rs.getString("Campo_3"));
		arregloCampo.add(rs.getString("Campo_4"));
		arregloCampo.add(rs.getString("Campo_5"));
		arregloCampo.add(rs.getString("Campo_6"));

		arregloValor.add(rs.getString("Valor_0"));
		arregloValor.add(rs.getString("Valor_1"));
		arregloValor.add(rs.getString("Valor_2"));
		arregloValor.add(rs.getString("Valor_3"));
		arregloValor.add(rs.getString("Valor_4"));
		arregloValor.add(rs.getString("Valor_5"));
		arregloValor.add(rs.getString("Valor_6"));
		
		/** Digitar N�mero de Cuenta */
		text_numero_cuenta(ANY, LOADED).waitForExistence();
		text_numero_cuenta(ANY, LOADED).setText(rs.getString("NumeroCuenta"));
		browser_htmlBrowser(document_sistemanacionaldereca(ANY, LOADED), DEFAULT_FLAGS).inputKeys("{TAB}");


		/* Diligenciamiento de datos de la cuenta */
		ITestDataTable orderTable2 = (ITestDataTable) table_htmlTable_1(ANY, LOADED).getTestData("contents");

		for (int i = 0; i < arregloCampo.size(); i++) 
		{
			for (int row = 0; row < orderTable2.getRowCount(); row++) 
			{
				int col = 0;

				if (orderTable2.getCell(row, col).toString().equals(arregloCampo.get(i))) 
				{
					TestObject[] radios2 = table_htmlTable_1(ANY, LOADED).find(atDescendant(".class", "Html.INPUT.text"));

					System.out.println(radios2.length);

					new GuiTestObject(radios2[row - 2]).doubleClick(); sleep(1);
					browser_htmlBrowser(table_htmlTable_1(ANY, LOADED), DEFAULT_FLAGS).inputKeys(arregloValor.get(i)); sleep(1);
				}
			}
		}

		sleep(4);

		
		/** Imagen 3 */
		/* Log Detallado */
		addTexto("Paquete: " + args[2] + " - Cuenta: " + rs.getString("NumeroCuenta") + " - Imagen3" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = form_ma_digitacion_recForm(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, "SegundoNivel_Paq" + args[2] + "_Imagen3", doc);


		/** Guardar Comprobante */
		
		if (("" + args[5]).contains("Errada")) {

			button_guardarComprobantebutto().waitForExistence();
			button_guardarComprobantebutto().click();

			sleep(2);
			
			
			/** Imagen 4 */
			/* Log Detallado */
			addTexto("Paquete: " + args[2] + " - Cuenta: " + rs.getString("NumeroCuenta") + " - Imagen4" + "\n", doc);

			/* Capturar im�gen y guardar en PDF */
			imagen = table_htmlTable_0(ANY, LOADED).getScreenSnapshot();
			guardarImagen(imagen, "SegundoNivel_Paq" + args[2] + "_Imagen4", doc); sleep(2);
			
			/* Volver a dar clic en bot�n de Guardar Comprobante */
			button_guardarComprobantebutto().click(); sleep(3);
			
			
			/** Imagen 5 */
			/* Log Detallado */
			addTexto("Paquete: " + args[2] + " - Cuenta: " + rs.getString("NumeroCuenta") + " - Imagen5" + "\n", doc);

			/* Capturar im�gen y guardar en PDF */
			imagen = table_htmlTable_0_2(ANY, LOADED).getScreenSnapshot();
			guardarImagen(imagen, "SegundoNivel_Paq" + args[2] + "_Imagen5", doc); sleep(2);
			
		} else {
			button_guardarComprobantebutto().waitForExistence();
			button_guardarComprobantebutto().click(); sleep(2);
		}
	}
}