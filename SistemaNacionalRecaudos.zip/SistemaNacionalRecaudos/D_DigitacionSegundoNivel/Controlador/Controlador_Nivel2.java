package D_DigitacionSegundoNivel.Controlador;
import java.io.IOException;
import java.sql.SQLException;
import resources.D_DigitacionSegundoNivel.Controlador.Controlador_Nivel2Helper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class Controlador_Nivel2 extends Controlador_Nivel2Helper
{

	public void testMain(Object[] args) throws IOException, SQLException {

		/* Ingreso m�dulo segundo nivel */
		if (button__Digitaci�nSegundoNivel().ensureObjectIsVisible())
			button__Digitaci�nSegundoNivel(ANY, LOADED).click();
		else {
			button_digitadoRbutton().click();
			button__Digitaci�nSegundoNivel().click(); sleep(3);
		}

		/* Secuencia Vistas Digitaci�n Segundo Nivel */
		callScript("D_DigitacionSegundoNivel.Vista.V1_SeleccionarPaquete_2", args);
		callScript("D_DigitacionSegundoNivel.Vista.V2_ConfirmarPaquete_2", args);
		callScript("D_DigitacionSegundoNivel.Vista.V3_AdicionarCuenta_2", args);
	}
}