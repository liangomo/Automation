package B_Digitacion;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import resources.B_Digitacion.DigitacionHelper;
import com.lowagie.text.Document;

public class Digitacion extends DigitacionHelper
{
	/** INICIALIZACI�N DE VARIABLES */

	/* Definici�n de argumentos para tener en cuenta en los callscript */
	Document doc, doc2, doc3;
	boolean band1, band2, band3;
	FileWriter fichero = null;	
	/* Creaci�n PDF */
	String fecha = ObtenerFecha();
	String hora = ObtenerHora();

	/* Arreglos */
	ArrayList<String> arregloCampo = new ArrayList<String>();


	public void testMain(Object[] archivo) throws IOException 
	{
		ResultSet rs;
		/** Creaci�n Carpetas */
		File folder0 = new File("C:\\tmp\\SNR");
		folder0.mkdir();

		File folder1 = new File("C:\\tmp\\SNR\\Imagenes");
		folder1.mkdir();

		File folder2 = new File("C:\\tmp\\SNR\\Digitaci�n Primer Nivel");
		folder2.mkdir();

		File folder3 = new File("C:\\tmp\\SNR\\Digitaci�n Segundo Nivel");
		folder3.mkdir();

		File folder4 = new File("C:\\tmp\\SNR\\Digitaci�n Tercer Nivel");
		folder4.mkdir();

		String archivoCargue = "" + archivo[0];
		
		/* Variable temporal para pasar informacion a los Scripts en los callscript */
		String[] tmp = new String[1];	

		/** Conexi�n a la Base de Datos */

		if (archivoCargue.equals("2")) {
			/* Consulta en la tabla casos de prueba los registros que se deben ejecutar = 1 */
			rs = Consulta("SELECT * FROM SNR.Ciudades A JOIN SNR.CasosPrueba B ON B.IDCiudad = A.IDCiudad "
					+ "JOIN SNR.Cuentas C ON C.IDCuenta = B.IDCuenta " +
					"WHERE CargueArchivos2 = 1 AND Ejecutado = 'NO_EJECUTADO' ORDER BY CodCP");
			tmp[0] = archivoCargue;
			
		} else {
			/* Consulta en la tabla casos de prueba los registros que se deben ejecutar = 1 */
			rs = Consulta("SELECT * FROM SNR.Ciudades A JOIN SNR.CasosPrueba B ON B.IDCiudad = A.IDCiudad "
					+ "JOIN SNR.Cuentas C ON C.IDCuenta = B.IDCuenta " +
					"WHERE Ejecucion = 1 AND Ejecutado = 'NO_EJECUTADO' ORDER BY CodCP");
			tmp[0] = archivoCargue;
		}
		
		Object[] args = new Object[15];

		
		/* Definici�n de argumentos que ser�n llamados en los callscript para identificar 
		 * el caso de prueba, el cliente y la cuenta */

		try 
		{

			while (rs.next()) 
			{
				args[0] = rs.getString("CodCP");
				args[1] = rs.getString("Descripcion");
				args[2] = rs.getInt("Paquete");
				args[3] = rs.getInt("IDCuenta");
				args[4] = rs.getString("Nivel");
				args[5] = rs.getString("ResultadoEsperado");
				args[6] = rs.getInt("IDCiudad");
				args[7] = rs.getString("NombreCiudad");
				args[8] = rs.getString("NumeroCuenta");
				args[10] = rs.getString("Ejecutado");
				args[11] = rs.getString("CPPredecesor");
				args[12] = fecha;
				args[13] = hora;
				args[14] = tmp[0];


				/** INGRESO A LA APLICACI�N */
				
				/* Ingreso con el usuario ya asignado a la ciudad */
				callScript("Z_Utilitarios.Login", args);


				/** CREACI�N INFORME DETALLADO */

				/* Validaci�n Niveles para Digitaci�n */
				if (args[4].equals("1")) {
					if (!band1) 
						doc = createPdf("Detallado_SNR_" + ObtenerMes() +  "_" + fecha + "_" + hora, 
								getSubString((String) rs.getString("Descripcion"),0,23));
					args[9] = doc;
					band1 = true;
					callScript("C_DigitacionPrimerNivel.Controlador.Controlador_Nivel1", args);
				} else if (args[4].equals("2")) {
					if (!band2)
						doc2 = createPdf("Detallado_SNR_" + ObtenerMes() +  "_" + fecha + "_" + hora, 
								getSubString((String) rs.getString("Descripcion"),0,24));
					args[9] = doc2;
					band2 = true;
					callScript("D_DigitacionSegundoNivel.Controlador.Controlador_Nivel2", args);
				} else if (args[4].equals("3")) {
					if (!band3)
						doc3 = createPdf("Detallado_SNR_" + ObtenerMes() +  "_" + fecha + "_" + hora, 
								getSubString((String) rs.getString("Descripcion"),0,23));
					args[9] = doc3;
					band3 = true;
					callScript("E_DigitacionTercerNivel.Controlador.Controlador_Nivel3", args);
				} else {}

				/* Veredicto y Validaci�n */
				callScript("Z_Utilitarios.VerificacionPaquete", args);


				/** SALIR DE LA APLICACI�N */
				callScript("Z_Utilitarios.Logout");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			/* Insertar Resultados en Base de Datos */
			querySQL("INSERT INTO SNR.ConsolidadosEjecucion VALUES('" + "SNR" + "','" + ObtenerA�o() + "','" + ObtenerMes() + "','" 
					+ args[12] +  "','" + args[13] +  "','" + args[0] +  "','" + args[1] +  "','" + args[5] +  "','"  
					+ "FALLIDO" +  "','" + "FALLIDO" + "','" + "C:\\tmp\\SNR\\" + getSubString((String)args[1],0,23) 
					+ "\\Detallado_SNR_" + ObtenerMes() + "_" + args[12] + "_" + args[13] + ".pdf" + "')");

		} finally {
			if (doc != null)
				closePDF(doc);
			if (doc2 != null)
				closePDF(doc2);
			if (doc3 != null)
				closePDF(doc3);
		}
	}

}