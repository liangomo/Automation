package Z_Utilitarios;
import resources.Z_Utilitarios.LogoutHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class Logout extends LogoutHelper
{
	public void testMain(Object[] args) 
	{
		try {
			link_cerrarSesi�n().click();
			sleep(4);
			logInfo("Cierre de sesi�n exitoso");
		} catch(Exception e) {
			logInfo("Se presentaron inconsistencias en el cierre de sesi�n");
		}
	}
}