package Z_Utilitarios;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import com.rational.test.ft.object.interfaces.TestObject;
import com.rational.test.ft.script.RationalTestScript;

/**
 * Description   : Super class for script helper
 * 
 * @author lgomez11
 * @since  enero 17, 2017
 */
public abstract class ClaseAyudante extends RationalTestScript
{

	/* VARIABLES GLOBALES */
	Document documento;
	Paragraph parrafo;

	private Connection Conec = null;
	Statement St;
	int numeroKill = 0;
	Connection conexionBD;
	Statement stamt;
	String[] Datos;
	String Conn = "//AQUILESSQL25\\REPOSITORY";
	protected int i;
	String cont;
	
	/**
	 * METODOS PARA MANEJO DE LOGS (ARCHIVOS .TXT, .PDF y ARCHIVOS .JPG)
	 * */

	// M�todo para la generacion o apertura del archivo 
	public FileWriter generacionArchivo(String rutaArchivo, String nombreArchivo ) throws IOException{

		FileWriter fichero = null;
		fichero = new FileWriter(rutaArchivo+nombreArchivo, true);
		return fichero;
	}

	//M�todo para ingresar cadenas de texto al archivo
	public void InsertarArchivo(FileWriter fichero, String sentencia){

		PrintWriter pw = null;
		pw = new PrintWriter(fichero);
		pw.println(sentencia);
	}

	//M�todo para ingresar cadenas de texto al archivo sin salto de l�nea
	public void ContinuarRegistro(FileWriter fichero, String sentencia){

		PrintWriter pw = null;
		pw = new PrintWriter(fichero);
		pw.print(sentencia);
	}

	// M�todo para cerrar y cuardar el archivo	
	public void cerrarArchivo(FileWriter fichero) throws IOException{

		fichero.close();
	}

	
	/**
	 * 
	 * METODOS PARA EL MANEJO DE HORA, MINUTOS Y SEGUNDOS (FECHAS)
	 * 
	 * */
	
	//M�todo para obtener un substring, especificando inicio y fin
	public String getSubString(String string, int inicio, int fin){
		
		String stringFinal= "";
		stringFinal= string.substring(inicio, fin);
		return stringFinal;
	}

	// M�todo para obtener FECHA en formato, A�oMesDia
	public String ObtenerFecha() {
		String fecha;	
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("yyyyMMdd");
		fecha = formato.format(calendar.getTime());
		return fecha;
	}
	
	// M�todo para obtener FECHA en formato, MesDiaA�o
	public String FechaInicioDia() {
		String fecha;	
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("MMddyyyy");
		fecha = formato.format(calendar.getTime());
		return fecha;
	}

	// M�todo para obtener mes de certificaci�n
		public String ObtenerMes() {
			Calendar miCalendario = Calendar.getInstance();
			int mes; 
			String m;

			if (ObtenerDia() > 20)
				if (miCalendario.get(Calendar.MONTH) == 11)
					mes = 1;
				else
					mes = miCalendario.get(Calendar.MONTH)+2;
			else
				mes = miCalendario.get(Calendar.MONTH) + 1;

			if (mes < 10)
				m = "0" + mes;
			else
				m = "" + mes;

			String mesCertif = "";

			switch (m) {

				case "01": {
					mesCertif = "Enero";
					break;
				} case "02": {
					mesCertif = "Febrero";
					break;
				} case "03": {
					mesCertif = "Marzo";
					break;
				} case "04": {
					mesCertif = "Abril";
					break;
				} case "05": {
					mesCertif = "Mayo";
					break;
				} case "06": {
					mesCertif = "Junio";
					break;
				} case "07": {
					mesCertif = "Julio";
					break;
				} case "08": {
					mesCertif = "Agosto";
					break;
				} case "09": {
					mesCertif = "Septiembre";
					break;
				} case "10": {
					mesCertif = "Octubre";
					break;
				} case "11": {
					mesCertif = "Noviembre";
					break;
				} case "12": {
					mesCertif = "Diciembre";
					break;
				} 
			}
			return mesCertif;
		}

	// M�todo para obteber el d�a actual
	public Integer ObtenerDia() {
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		return diaHoy;
	}
	
	// M�todo para obteber el a�o actual
	public Integer ObtenerA�o() {
		Calendar miCalendario = Calendar.getInstance();
		int a�o = miCalendario.get(Calendar.YEAR);
		return a�o;
	}

	// M�todo para obtener HORA en formato Hora:Minutos:Segundos
	public String ObtenerHora() {
		String hora;	
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("HHmmss");
		calendar.get(Calendar.MONTH);
		hora = formato.format(calendar.getTime());
		return hora;
	}
	

	/**
	 * METODOS PARA MANEJO DE BASE DE DATOS
	 * */

	public void ConnectionDB() {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Conec = DriverManager
					.getConnection(
							"jdbc:sqlserver://AQUILESSQL25\\REPOSITORY;databaseName=BD_AUT_SNR;",
							"usr_AUTSNR", "usr_AUTSNR#2016");

			if (Conec != null) {

				System.out.println("Successfully connected");

			}
		} catch (SQLException excepcionSql) {
			JOptionPane.showMessageDialog(null, excepcionSql.getMessage(),
					"Error en base de datos", JOptionPane.ERROR_MESSAGE);
		}

		catch (ClassNotFoundException claseNoEncontrada) {
			JOptionPane.showMessageDialog(null, claseNoEncontrada.getMessage(),
					"No se encontr� el controlador", JOptionPane.ERROR_MESSAGE);
		}
	}

	// Metodo de ejecucion de insert,update,delete a la base de datos
	public String[] querySQL(String query) {
		// CONTROLA QUE LA CONSULTA NO ESTE NULA O VACIA
		try {
			ConnectionDB();

			stamt = Conec.createStatement();
			// SE ENVIA CODIGO DE INSERCION SQL
			stamt.executeUpdate(query);
			// SE CIERRA CONEXION
			Conec.close();
		}
		// IMPRIME CON CONSOLA EL SI EXISTIO ALGUN ERROR EN LA CONEXION
		catch (Exception e) {
			e.printStackTrace();
		}
		// NO RETORNA NADA
		return Datos;
	}



	// Metodo para las consultas a la base de datos
	public ResultSet Consulta(String sql) {
		ConnectionDB();
		ResultSet res = null;
		try {
			Statement s = Conec.createStatement();
			res = s.executeQuery(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	// FUNCION PARA GUARDAR LAS IMAGENES CAPTURADAS
	public void guardarImagen(RenderedImage image, String Nombre, Document doc) {
		String ruta = "C:\\tmp\\SNR\\Imagenes\\" + Nombre + ".jpg";

		// DECLARA Y CREA EL ARCHIVO CON LA IMAGEN RECIBIDA
		File file = new File(ruta);
		try {
			ImageIO.write(image, "jpg", file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// cutImage(ruta);
		addImage(ruta, doc);
	}

	// METODO QUE CREA UN PDF PARA PRESENTAR LOS RESULTADOS DE LOS SCRIPT
	public Document createPdf(String nombre, String trx) throws DocumentException,
	MalformedURLException, IOException {
		// SE CREA UN DOCUMENTO CON TAMA�O CARTA Y SE ESCOJE LA RUTA Y NOMBRE
		// DEL ARCHIVO
		Document documento = new Document(PageSize.LETTER, 80, 80, 75, 75);
		String archivo = "C:\\tmp\\SNR\\" + trx + "\\" + nombre + ".pdf";
		@SuppressWarnings("unused")
		PdfWriter writer = PdfWriter.getInstance(documento,
				new FileOutputStream(archivo, true));

		// SE LE AGREGA EL TITULO Y AUTOR AL DOCUMENTO
		documento.addTitle("Registro Pruebas de Regresi�n SNR - "
				+ nombre);
		documento
		.addAuthor("Equipo de Automatizaci�n - Direcci�n de Desarrollo Tecnologico");
		documento.open();

		// SE CREA UN PARAGRAFO QUE LLEBA EL ENCABEZADO DEL DOCUMENTO TITULO
		// LETRA GRANDE
		Paragraph titulo = new Paragraph();
		titulo.setAlignment(Paragraph.ALIGN_CENTER);
		titulo.setFont(FontFactory.getFont("Sans", 15, Font.BOLD));
		titulo.add("REGISTRO PRUEBAS DE REGRESION TRANSACCION - " + trx
				+ "\n\n");

		// SE AGREGA EL PARAGRAFO AL DOCUMENTO
		documento.add(titulo);

		return documento;
	}

	/* M�todo para a�adir texto al PDF */
	public void addTexto(String Cadena, Document doc) {
		try {
			Paragraph parrafo = new Paragraph();
			parrafo.setFont(FontFactory.getFont("Sans", 12, Font.NORMAL));
			parrafo.setAlignment(Paragraph.ALIGN_LEFT);
			parrafo.add(Cadena);
			doc.add(parrafo);
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	/* M�todo para agregar una im�gen a un PDF */
	public void addImage(String ruta, Document doc) {
		Image imagen;
		try {
			imagen = Image.getInstance(ruta);
			imagen.setAlignment(Image.ALIGN_CENTER);
			imagen.setUseVariableBorders(true);
			imagen.scalePercent(40);
			doc.add(imagen);
		} catch (BadElementException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	/* M�todo para cerrar PDF */
	public void closePDF(Document doc) {
		doc.close();
	}

	// METODO QUE RECORTA LA IMAGEN A UNAS MEDIDAS PREESTABLESIDAS
	public void cutImage(String ruta) throws IOException {
		File file = new File(ruta);
		BufferedImage bi = ImageIO.read(file);

		if (bi.getWidth() > 937) {
			bi = bi.getSubimage(0, 0, 937, bi.getHeight());
			ImageIO.write(bi, "jpg", file);
		}
	}
	
	

	/**
	 * METODOS PARA ADMINISTRACION 
	 * */

	//M�todo para cerrar navegadores
	public void cerrarNavegadores() 
	{
		/* Buscar objetos de navegador con la funci�n find de Rational Functional Tester 
		 * y almacenarlos en el objeto de prueba */
		TestObject[] browsers = find(atChild(".class", "Html.HtmlBrowser"));
		if (browsers.length == 0) {
			System.out.println("Found no Html.HtmlBrowser");
			return;
		}
		for (TestObject browser : browsers) {
			((com.rational.test.ft.object.interfaces.BrowserTestObject) browser)
			.close();
		}
		// Anular el registro de los objetos de prueba.
		unregister(browsers);
	}

	//M�todo para finalizar proceso IE
	public void MatarProceso() 
	{ 
		System.out.println("------------------------------Kill------------------------");
		try 
		{
			String line;
			Process p = Runtime.getRuntime().exec(System.getenv("windir") +"\\system32\\"+"tasklist.exe");
			BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
			while ((line = input.readLine()) != null) 
			{
				if(line.contains("iexplor"))
				{	
					Runtime.getRuntime().exec("taskkill /im "+ line.substring(0,12));
					numeroKill++;
					if(numeroKill<3){
						MatarProceso();
						sleep(2);
					}	
					else
						Runtime.getRuntime().exec("taskkill /im "+ line.substring(0,12) + "/F");
				}
			}
			input.close();
		} 
		catch (Exception err) 
		{
			err.printStackTrace();
		}
	}
}