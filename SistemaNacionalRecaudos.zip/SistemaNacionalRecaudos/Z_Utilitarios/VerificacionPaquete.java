package Z_Utilitarios;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import resources.Z_Utilitarios.VerificacionPaqueteHelper;
import com.rational.test.ft.vp.*;
import com.lowagie.text.Document;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class VerificacionPaquete extends VerificacionPaqueteHelper
{
	/** INICIALIZACI�N DE VARIABLES: */

	// Variables tipo String
	FileWriter fichero = null;	

	public void testMain(Object[] args) throws SQLException, IOException 
	{
		/* Consulta de la informaci�n */
		ResultSet rs = Consulta("SELECT * FROM SNR.Cuentas WHERE IDCuenta = " + args[3]);
		rs.next();

		/** VALIDACI�N VEREDICTO */
		Document doc = (Document) args[9];
		String veredicto = null,
				resultadoObtenido = null;
		ITestDataTable orderTable = (ITestDataTable) table_summary(ANY, LOADED).getTestData("contents");

		for (int row = 1; row < orderTable.getRowCount(); row++) 
		{
			int col = 0;

			if (orderTable.getCell(row, col).toString().equals("" + args[2])) {
				resultadoObtenido = "Paquete existe a�n";
				veredicto = "FALLIDO";
			}	else {
				resultadoObtenido = "Paquete pasa a siguiente nivel";
				veredicto = "EXITOSO";
			}
		}

		/** INCLUIR EN LOS INFORMES DE RESULTADOS */

		/* Insertar Veredicto en PDF */
		addTexto("VEREDICTO: " + veredicto + "\n\n", doc);

		/* Insertar Resultados en Base de Datos */
		querySQL("INSERT INTO SNR.ConsolidadosEjecucion VALUES('" + "SNR" + "','" + ObtenerA�o() + "','" + ObtenerMes() + "','" 
				+ args[12] +  "','" + args[13] +  "','" + args[0] +  "','" + args[1] +  "','" + args[5] +  "','"  
				+ resultadoObtenido +  "','" + veredicto + "','" + "C:\\tmp\\SNR\\" + getSubString((String)args[1],0,23) 
				+ "\\Detallado_SNR_" + ObtenerMes() + "_" + args[12] + "_" + args[13] + ".pdf" + "')");


		/** ACTUALIZAR ESTADO EN CASOS DE PRUEBA A EJECUTADO */

		/* Actualizar estado del caso de prueba a EJECUTADO en Base de Datos */

		if (args[14].equals("2"))
			querySQL("UPDATE SNR.CasosPrueba SET Ejecutado = 'EJECUTADO_PARCIAL2' WHERE CodCP = '" + args[0] + "'");
		else
			querySQL("UPDATE SNR.CasosPrueba SET Ejecutado = 'EJECUTADO_TOTAL' WHERE CodCP = '" + args[0] + "'");

	}
}