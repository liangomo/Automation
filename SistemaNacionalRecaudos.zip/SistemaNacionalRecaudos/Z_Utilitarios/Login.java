package Z_Utilitarios;
import java.sql.ResultSet;
import java.sql.SQLException;

import resources.Z_Utilitarios.LoginHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class Login extends LoginHelper
{
	public void testMain(Object[] args)
	{
		try 
		{

			/* Terminar los procesos del IE */
			cerrarNavegadores(); sleep(2);
			MatarProceso(); sleep(3);

			/* Seleccionar Nivel para usuario */
			String id;
			if (Integer.parseInt("" + args[4]) <= 2)
				id = "2";
			else
				id = "3";


			/* Validar si el usuario se encuentra en la ciudad  */
			ResultSet rs = Consulta("SELECT * FROM SNR.Login WHERE Nivel = " + id);
			rs.next();
			if (!rs.getString("IDCiudad").equals((String) args[6])) {
				callScript("F_CambioUsuariosCiudad.Controlador.Controlador", args);
			}

			rs = Consulta("SELECT * FROM SNR.Login WHERE IdCiudad = " + args[6] + " AND Nivel = " + id);
			rs.next();


			/** Inicio Aplicaci�n */
			startApp("SNR");


			/** Datos del Login */

			/* Datos */
			text_j_username(ANY, LOADED).waitForExistence();
			browser_htmlBrowser().maximize(); sleep(4);
			text_j_username(ANY, LOADED).click();
			text_j_username(ANY, LOADED).setText(rs.getString("Usuario"));
			browser_htmlBrowser(document_sistemanacionaldereca(ANY,LOADED),DEFAULT_FLAGS).inputKeys("{TAB}");

			text_j_password(ANY, LOADED).setText(rs.getString("Clave"));
			browser_htmlBrowser(document_sistemanacionaldereca(ANY,LOADED),DEFAULT_FLAGS).inputKeys("^{TAB}");

			list_dominio().click();
			browser_htmlBrowser(document_sistemanacionaldereca(ANY,LOADED),DEFAULT_FLAGS).inputKeys(rs.getString("Dominio") + "{TAB}");sleep(3);

			/* Ingresar */
			button_ingresarAlSistemabutton().click();
			table_htmlTable_0().waitForExistence();

			/* Cerrar pesta�a 1 que se abre al ingresar */
			browser_htmlBrowser(document_sistemanacionaldereca2(ANY,LOADED),DEFAULT_FLAGS).inputKeys("^{TAB}");sleep(3);
			browser_htmlBrowser(document_sistemanacionaldereca2(ANY,LOADED),DEFAULT_FLAGS).inputKeys("^w");sleep(2);

		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
}