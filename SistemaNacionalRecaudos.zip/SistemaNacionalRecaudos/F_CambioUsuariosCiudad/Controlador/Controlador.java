package F_CambioUsuariosCiudad.Controlador;
import resources.F_CambioUsuariosCiudad.Controlador.ControladorHelper;

public class Controlador extends ControladorHelper
{

	public void testMain(Object[] args) 
	{
		
		callScript("F_CambioUsuariosCiudad.Vista.V1_Login", args);
		callScript("F_CambioUsuariosCiudad.Vista.V2_ModuloUsuarios", args);
		callScript("F_CambioUsuariosCiudad.Vista.V3_AdminUsuarios", args);
		
		
		/* Actualizar campo en BD para indicar la ciudad en la que qued� asignado el usuario */
		querySQL("UPDATE SNR.Login SET IDCiudad = '" + args[12] + "' WHERE Usuario = '" + args[0] + "' ");
				

	}
}