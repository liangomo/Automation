package F_CambioUsuariosCiudad.Vista;
import resources.F_CambioUsuariosCiudad.Vista.V3_AdminUsuariosHelper;

public class V3_AdminUsuarios extends V3_AdminUsuariosHelper
{

	public void testMain(Object[] args) 
	{

		text_loggin().waitForExistence();
		text_loggin().setText((String) args[0]); 

		button_buscarbutton().click(); sleep(1);

		image_editar().click();
	
		list_cd_suc_expreso().waitForExistence();
		list_cd_suc_expreso().select((String) args[11]);

		list_cadenaPerfil().select((String) args[10]);
		
		button_guardarbutton().click(); sleep(4);
	}
}