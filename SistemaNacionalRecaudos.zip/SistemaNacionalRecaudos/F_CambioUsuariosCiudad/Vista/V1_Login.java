package F_CambioUsuariosCiudad.Vista;
import java.sql.ResultSet;
import java.sql.SQLException;

import resources.F_CambioUsuariosCiudad.Vista.V1_LoginHelper;

public class V1_Login extends V1_LoginHelper
{

	public void testMain(Object[] args) throws SQLException 
	{
		MatarProceso();
		
		startApp("SNR_XPSecurity");
		browser_htmlBrowser().maximize(); sleep(1);
		
		/* Consulta en la tabla Login para hacer cambio de usuario con un perfil SUPERPERFIL XPSECURITY */
		ResultSet rs = Consulta("SELECT * FROM SNR.Login WHERE Perfil = 'SUPERPERFIL XPSECURITY'");
		rs.next();
		
		text_j_username().waitForExistence();
		text_j_username().setText(rs.getString("Usuario"));
		
		text_j_password().waitForExistence();
		text_j_password().setText(rs.getString("Clave"));
		
		list_dominio().click();
		browser_htmlBrowser(document_xpsecurity(),DEFAULT_FLAGS).inputKeys(rs.getString("Dominio") + "{TAB}"); sleep(1);
		
		
		button_ingresarAlSistemabutton().click();		
	}
}