package F_CambioUsuariosCiudad.Vista;
import resources.F_CambioUsuariosCiudad.Vista.V2_ModuloUsuariosHelper;

public class V2_ModuloUsuarios extends V2_ModuloUsuariosHelper
{

	public void testMain(Object[] args) 
	{
		/* Ingreso m�dulo primer nivel */
		if (button_usuariosbutton().ensureObjectIsVisible())
			button_usuariosbutton(ANY, LOADED).click();
		else {
			button_opcionesDelSistemabutto().click();
			button_par�metrosb�sicoSbutton().click();
		}
	}
}