import java.io.File;
import java.io.FileWriter;
import java.sql.ResultSet;
import resources.LanzadorHelper;
import com.lowagie.text.Document;

public class Lanzador extends LanzadorHelper
{
	/* Definici�n de argumentos para tener en cuenta en los callscript */
	Document doc, doc2, doc3;
	FileWriter fichero = null;	

	public void testMain(Object[] args) 
	{
		/** CREACI�N CARPETAS PARA LOS INFORMES DE RESULTADOS */
		File folder0 = new File("C:\\tmp\\SNR");
		folder0.mkdir();

		File folder1 = new File("C:\\tmp\\SNR\\Imagenes");
		folder1.mkdir();

		File folder2 = new File("C:\\tmp\\SNR\\Inicio de D�a");
		folder2.mkdir();


		/** SUBIR ARCHIVOS AL FTP COMO INSUMO PARA LA EJECUCI�N */

		/* Ajuste de fecha en archivos CAPNOCPARCIAL para subir al FTP */
		callScript("A_InicioDia.Vista.V1_AjusteFechaArchivo");

		/* Cargue de Archivos al FTP */
		callScript("A_InicioDia.Vista.V2_InicioDiaEjecutable");


		/** Definici�n de argumentos que ser�n llamados en los callscript para identificar 
		 * los usuarios, ciudades y niveles */

		try 
		{

			/* CONTADOR PARA LAS 6 CIUDADES - Para asignar ciudades por usuario */
			for (int contCiudad=1; contCiudad <= 6; contCiudad++) {

				/** Realizar ciclo 3 veces teniendo en cuenta los 3 archivos cargados */
				for (int contArch=1; contArch <= 3; contArch++) {

					int contUser = 1;

					/** CONEXI�N A LA BASE DE DATOS */

					/* Consulta en la tabla Login y Ciudades los registros cuyo usuario sea Nivel 3 */
					ResultSet rs = Consulta("SELECT * FROM SNR.Login L JOIN SNR.Ciudades C ON C.IDCiudad = L.IDCiudad " +
							"WHERE Nivel = 3 ORDER BY IDLogin");
					args = new Object[13];

					while (rs.next()) {

						/* Variables para la creaci�n del PDF */
						String fecha = ObtenerFecha();
						String hora = ObtenerHora();

						/* Definici�n de argumentos */
						args[0] = rs.getString("Usuario");
						args[1] = rs.getString("Clave");
						args[2] = rs.getString("Dominio");
						args[3] = rs.getString("NombreCiudad");
						args[4] = rs.getString("Nivel");
						args[5] = rs.getString("DigitadorCiudad");
						args[7] = fecha;
						args[8] = hora;
						args[9] = rs.getString("IDCiudad");
						args[10] = rs.getString("Perfil");


						/* Validar si ya se ha cargado algun archivo */
						if (rs.getString("ArchivoCargado").equals("1"))
							contArch = 1;
						else if (rs.getString("ArchivoCargado").equals("2"))
							contArch = 2;
						else 
							contArch = 3;


						/** SECUENCIA DE EJECUCI�N */

						/* Validar si el usuario se encuentra en la ciudad  */
						if (contCiudad != Integer.valueOf((String) args[9])) {

							/* Consulta tabla Ciudades y traer la ciudad correspondiente al contador del ciclo */
							ResultSet cons = Consulta("SELECT * FROM SNR.Ciudades WHERE IDCiudad = '" + contCiudad + "'");
							cons.next();
							args[11] = cons.getString("NombreCiudad");
							args[12] = contCiudad;

							/* Realizar el cambio de ciudad al usuario */
							callScript("F_CambioUsuariosCiudad.Controlador.Controlador", args);
						}


						/* Login usuarios de Tercer Nivel */
						if (!rs.getString("ArchivoCargado").equals("4"))
							callScript("A_InicioDia.Vista.V3_Login", args);


						if (contArch == 1) {

							if (contUser == 1) {

								/* Validaci�n Niveles para Digitaci�n */

								doc = createPdf("InicioDia_SNR_" + "CargueArchivo1" + "_" + fecha + "_" + hora, "Inicio de D�a");
								System.out.println(doc == null);
								args[6] = doc;

								/* Ingreso como Administrador para INICIO DE DIA */
								callScript("A_InicioDia.Vista.V4_InicioDia", args);
							}

							callScript("A_InicioDia.Vista.V7_VerificacionCargueArchivo", args);

							/* Actualizar campo en BD para indicar que finaliz� el cargue archivo 1 y pasa al 2 */
							querySQL("UPDATE SNR.Login SET ArchivoCargado = '2' WHERE Usuario = '" + args[0] + "'");


						} else if (!rs.getString("ArchivoCargado").equals("4")) {

							if (contArch==2 && contUser==1) {
								/* Validaci�n Niveles para Digitaci�n */
								doc2 = createPdf("InicioDia_SNR_" + "CargueArchivo2" + "_" + fecha + "_" + hora, "Inicio de D�a");
								args[6] = doc2;

								callScript("A_InicioDia.Vista.V8_CargueArchivoAdicional", args);

							} else if (contArch==3 && contUser==1) {
								/* Validaci�n Niveles para Digitaci�n */
								doc3 = createPdf("InicioDia_SNR_" + "CargueArchivoTotal" + "_" + fecha + "_" + hora, "Inicio de D�a");
								args[6] = doc3;

								callScript("A_InicioDia.Vista.V9_CargueArchivoTotal", args);
							}


							/* Inicio como Coordinador para ASIGNACI�N DE PAQUETES */
							callScript("A_InicioDia.Vista.V5_AsignacionPaquetes", args);

							/* Contin�a como Coordinador para ENTREGA DE PAQUETES FISICOS */
							callScript("A_InicioDia.Vista.V6_EntregaPaquetes", args);


							if (contArch == 2)

								/* Actualizar campo en BD para indicar que finaliz� el cargue archivo 2 y pasa al 3 */
								querySQL("UPDATE SNR.Login SET ArchivoCargado = '3' WHERE Usuario = '" + args[0] + "'");

							else
								/* Actualizar campo en BD para indicar que finaliz� el cargue archivo 2 y pasa al total (3) */
								querySQL("UPDATE SNR.Login SET ArchivoCargado = '4' WHERE Usuario = '" + args[0] + "'");
						}

						if (rs.getString("ArchivoCargado").equals("4"))
							break;
						else
							contUser++;
					}

					if (contArch == 2 || contArch ==3) {
						args[0] = contArch;
						callScript("B_Digitacion.Digitacion", args);
					}
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();

		} finally {
			if (doc != null)
				closePDF(doc);
			if (doc2 != null)
				closePDF(doc2);
			if (doc3 != null)
				closePDF(doc3);

			folder1.delete();
		}
	}
}