/*DESCRIPCION : MODIFICA EL PERFIL A UN USUARIO*/
/*CREADO POR : TECNOEVOLUCION LTDA*/
/*FECHA 13-03-2015*/
USE DIALOGO;
GO
IF OBJECT_ID ( 'SP_IDM_Modify_Profile', 'P' ) IS NOT NULL 
    DROP PROCEDURE SP_IDM_Modify_Profile;
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

CREATE proc SP_IDM_Modify_Profile

	@empresa			int, --codigo de la empresa para asociar al usuario obligatorio dv10emp1
	@nro_identificacion	float, --numero de identificacion del usuario a crear obligatorio
	@perfil				float,		 --Perfil al cual se asocia el usuario a crear dms_perfiles
	@menu_asociado		char(30),	 --Menu al que tiene permiso para ingresar el usuario a crear  dv23menu o dv23menu1
	@adm_portafolio		varchar(1)	,--Ingreso a inversiones
	@anulacion			int			,--permite anular
	@multisesion		varchar(1)	,--puede abrir varias sesiones del sistema
	@crea_modif_usuario	int			,--Permite crear o modificar usuarios
	@ing_inv			varchar(1)	,--Ingreso a inversiones
	@ing_cus			varchar(1)	,--Ingreso a custodia
	@adm_bd				varchar(1)	,--Administra Base de datos
	@crea_clientes		varchar(1)	,--crea clientes
	@retval				varchar(255) out
as	
begin 
	DECLARE @nombre_usuario varchar(40)
	DECLARE @ll_cantidad		int			--Variable de verificacion.
	DECLARE @menu varchar(30)

	/*Validaciones de campos obligatorios*/
	--Validacion que el codigo de la empresa enviado no sea nulo o sea 0
	if (@empresa is null or @empresa <= 0)
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50001,'EMPRESA')
		print @retval
		return 1
	end
	--Validacion que la empresa enviada exista en el aplicativo.
	if (select count(0) from dv10emp1 where cod_emp_int = @empresa ) = 0
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50009,'NO EXISTE') +' La empresa no existe. '+ CONVERT(VARCHAR(10),@empresa)
		print @retval
		return 1
	end

	if (@nro_identificacion is null or @nro_identificacion <= 0)
	begin	
		SET @retval = usuarios_dial.f_error_dialogo(50002,'IDENTIFICACION') + 'Identicaci�n no valida. ' + convert(varchar(20),@nro_identificacion )
		print @retval
		return 1
	end

	if (@perfil is null or @perfil <= 0)
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50005,'PERFIL')
		print @retval
		return 1
	end

	if (@perfil is null or @perfil <= 0)
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50005,'PERFIL')
		print @retval
		return 1
	end


	select @ll_cantidad = count(0) from dbo.dv11usr1 where dv11_empresa = @empresa and identificacion = @nro_identificacion

	if @ll_cantidad > 0 
	begin
		if (@perfil <> 0)
		begin
			select @ll_cantidad = count(0) from dbo.dms_perfiles where perfil_codigo = @perfil
			if @ll_cantidad = 0
			begin
				SET @retval = usuarios_dial.f_error_dialogo(50005,'EXISTE') +' '+ @perfil
				print @retval
				return 1
			end

			update dbo.dv11usr1
			set nivel = @perfil, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuario_dial.f_error_dialogo(50010,'ACTUALIZA')  + ' ' + convert(varchar(15),@nro_identificacion) + ' Perfil. ' + @perfil
					print @retval 
					return 1
				end
		end

		if @menu_asociado <> ''
		begin
			if @empresa = 7  	
				begin
					select @menu = menu from dv23menu 
					where menu  in (select menu from dv23menu1 where nivel = CONVERT(INT, @menu_asociado ))
				end
			else
				if @empresa = 71
				begin
					if @menu_asociado = '1' 
						set @menu = 'm_cus_principal'
					if @menu_asociado = '2' 
						set @menu = 'm_cus_principal_n2'
					if @menu_asociado = '4' 
						set @menu = 'm_cus_principal_n4'
				end	

			update dbo.dv11usr1
			set dv11_menu = @menu, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' Menu. ' + @menu
					print @retval
					return 1
				end		
		end

		if @adm_portafolio <> ''
		begin
			update dbo.dv11usr1
			set admon_portafolio = @adm_portafolio, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' Ingreso a Inversiones.'
					print @retval
					return 1
				end		
		end

		if @anulacion >= 0 and @anulacion < 2 
		begin
			update dbo.dv11usr1
			set sw_anulacion = @anulacion, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@anulacion) + ' Anulaci�n.'
					print @retval
					return 1
				end		
		end

		if @multisesion <> '' 
		begin
			update dbo.dv11usr1
			set multisesion = @multisesion, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' Multisesi�n.'
					print @retval
					return 1
				end		
		end

		if @crea_modif_usuario <>''
		begin
			update dbo.dv11usr1
			set autorizacion_admon = @crea_modif_usuario, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' Multisesi�n.'
					print @retval
					return 1
				end		
		end

		if @ing_inv <> ''
		begin
			update dbo.dv11usr1
			set crear_inver = @ing_inv, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' Ingreso a Inversiones.'
					print @retval
					return 1
				end		
		end

		if @ing_cus <> ''
		begin
			update dbo.dv11usr1
			set autoriza_custodia = @ing_cus, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' Custodia.'
					print @retval
					return 1
				end		
		end

		if @adm_bd <> ''
		begin
			update dbo.dv11usr1
			set sw_admon_base = @adm_bd, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario + ' Tel�fono.'
					print @retval
					return 1
				end
		end

		if @crea_clientes <> ''
		begin
			update dbo.dv11usr1
			set crear_cliente = @crea_clientes, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario + ' Creacion Clientes.' 
					print @retval
					return 1
				end		
		end
	end
	else
		begin
			SET @retval = usuarios_dial.f_error_dialogo(50009,'NO EXISTE ') + 'El usuario.'
			print @retval
			return 1
		end
end