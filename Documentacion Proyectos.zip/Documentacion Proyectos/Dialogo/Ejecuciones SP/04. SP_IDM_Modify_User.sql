/*DESCRIPCION : MODIFICA DATOS DEL USUARIO*/
/*CREADO POR : TECNOEVOLUCION LTDA*/
/*FECHA 13-03-2015*/
USE DIALOGO;
GO
IF OBJECT_ID ( 'SP_IDM_Modify_User', 'P' ) IS NOT NULL 
    DROP PROCEDURE SP_IDM_Modify_User;
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

CREATE proc SP_IDM_Modify_User

	@empresa			int, --codigo de la empresa para asociar al usuario obligatorio dv10emp1
	@nro_identificacion	float, --numero de identificacion del usuario a crear obligatorio
	@primer_nombre		varchar(20), --primer nombre del usuario a crear campo obligatorio
	@segundo_nombre		varchar(20), --segundo nombre del usuario a crear
	@primer_apellido	varchar(20), --primer apellido del usuario a crear campo obligatorio
	@segundo_apellido	varchar(20), --segundo apellido del usuario a crear
	@centro_costo		int,		 --Centro de costo al que pertenece el usuario a crear dv30suc1
	@estado_usuario		char(2)	,	 --Codigo de estado del usuario para este debe llegar en 1 CREADO
	@area				varchar(30),  --Area a la cual pertenece el usuario
	@telefono			float		, --nro telefonico de contacto del usuario
	@extension			int			,--Extension del usuario
	@cargo				int			,--Cargos dfpcrg16
	@ciudad				int			,--Ciudades dv04ciu1
	@max_hora_ing		varchar(5)	,--Hora hasta que el usuario puede ingresar al sistema
	@tiempo_inactividad int			,--Tiempo en que el sistema esta activo por usuario
	@retval				varchar(255) output
as
begin 
	DECLARE @nombre_usuario varchar(40)
	DECLARE @ll_cantidad		int			--Variable de verificacion.
	/*Validaciones de campos obligatorios*/
	--Validacion que el codigo de la empresa enviado no sea nulo o sea 0
	if (@empresa is null or @empresa <= 0)
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50001,'EMPRESA')
		print @retval
		return 1
	end
	--Validacion que la empresa enviada exista en el aplicativo.
	if (select count(0) from dv10emp1 where cod_emp_int = @empresa ) = 0
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50009,'NO EXISTE') +' La empresa '+ @empresa
		print @retval
		return 1
	end

	if (@nro_identificacion is null or @nro_identificacion <= 0)
	begin	
		SET @retval = usuarios_dial.f_error_dialogo(50002,'IDENTIFICACION')
		print @retval
		return 1
	end

	if (@primer_nombre is null or @primer_nombre = '')
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50003,'PRIMER NOMBRE')
		print @retval
		return 1
	end

	if (@primer_apellido is null or @primer_apellido= '')
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50004,'PRIMER APELLIDO')
		print @retval
		return 1
	end

	if (@estado_usuario is null or @estado_usuario = ''  )
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50007,'ESTADO')
		print @retval
		return 1
	end
--	declare @ll_cantidad int
--	declare @empresa int, @nro_identificacion float
--	set @empresa = 7 
--	set @nro_identificacion = 14321759
	
	select @ll_cantidad = count(0) from dbo.dv11usr1 where dv11_empresa = @empresa and identificacion = @nro_identificacion

	if @ll_cantidad > 0 
	begin
		if (@primer_nombre <> '' or @segundo_nombre <> '' or @primer_apellido <> '' or @segundo_apellido <> '')
		begin
			if @primer_nombre <> ''
				set @primer_nombre = @primer_nombre + ' '
		
			if @segundo_nombre <> ''
				set @segundo_nombre = @segundo_nombre + ' '

			if @primer_apellido <> ''
				set @primer_apellido = @primer_apellido + ' '

			SET @nombre_usuario = rtrim(ltrim(isnull(@primer_nombre,' ') + isnull(@segundo_nombre,' ') + isnull(@primer_apellido,' ') + isnull(@segundo_apellido,' ')))

			update dbo.dv11usr1
			set nombre = upper(@nombre_usuario), fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuario_dial.f_error_dialogo(50010,'ACTUALIZA')  + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario 
					print @retval 
					return 1
				end
		end

		if @centro_costo <> 0
		begin
			update dbo.dv11usr1
			set dv11_centro_costo = @centro_costo, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario + ' Centro Costo.'
					print @retval
					return 1
				end		
		end

		if @estado_usuario <> '1'
		begin
			update dbo.dv11usr1
			set estado_usuario = @estado_usuario, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario + ' Estado usuario.'
					print @retval
					return 1
				end		
		end

		if @area <> ''
		begin
			update dbo.dv11usr1
			set nombre_area = @area, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario + ' �rea.'
					print @retval
					return 1
				end		
		end

		if @telefono <> 0
		begin
			update dbo.dv11usr1
			set telefono = @telefono, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario + ' Tel�fono.'
					print @retval
					return 1
				end
		end

		if @cargo <> 0
		begin
			update dbo.dv11usr1
			set func_cargo = @cargo, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario + ' Cargo.' 
					print @retval
					return 1
				end		
		end

		if @ciudad <> 0
		begin
			update dbo.dv11usr1
			set codigo_ciudad = @ciudad, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario + ' Ciudad.' 
					print @retval
					return 1
				end		
		end

		if @tiempo_inactividad <> 0
		begin
			update dbo.dv11usr1
			set tiempo_espera = @tiempo_inactividad, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario + ' Tiempo de inactividad.'
					print @retval
					return 1
				end		
		end

		if @max_hora_ing <> ''
		begin
			update dbo.dv11usr1
			set hora_ingreso = @max_hora_ing, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuarios_dial.f_error_dialogo(50010,'ACTUALIZA' ) + ' ' + convert(varchar(15),@nro_identificacion) + ' ' + @nombre_usuario + ' Hora de ingreso.'
					print @retval
					return 1
				end		
		end
	end
	else
		begin
			SET @retval = usuarios_dial.f_error_dialogo(50009,'NO EXISTE ') + 'El usuario.'
			print @retval
			return 1
		end
end
