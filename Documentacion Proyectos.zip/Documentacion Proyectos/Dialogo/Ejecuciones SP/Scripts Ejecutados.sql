/* Crear Usuario */
USE DIALOGO 
EXEC [USUARIOS_DIAL].[SP_IDM_New_User]
	@empresa = 7		,
	@nro_identificacion	= 96842367,
	@primer_nombre = 'Maria'	,
	@segundo_nombre	= 'Esperanza'	,
	@primer_apellido = 'Villegas'	,
	@segundo_apellido = 'Rodriguez'	,
	@perfil		= 5	,
	@centro_costo	= 1025	,
	@menu_asociado	= 5	,
	@estado_usuario = 1		,
	@area		= 'CENTRO DE VALORES'		,
	@telefono	= 33220032		,
	@extension	= 137		,
	@cargo		= 5		,
	@ciudad			= 4	,
	@contrasena		= 'Dialogo123**'	,
	@ing_inv	= 'S'		,
	@ing_cus	= 'N'		,
	@adm_bd		= 'N'		,
	@crea_clientes	= ''	,
	@adm_portafolio	= ''	,
	@anulacion		= ''	,
	@multisesion	= ''	,
	@crea_modif_usuario	= '',
	@tiempo_inactividad= '' ,
	@max_hora_ing	= ''	,
	@retval		= ''		,
	@usuario_alterno	= ''
	
	
/* Modificar Usuario */
USE DIALOGO 
EXEC [SP_IDM_Modify_User]
	@empresa = 7		,
	@nro_identificacion	= 5896485100,
	@primer_nombre = 'Maria'	,
	@segundo_nombre	= 'Esperanza'	,
	@primer_apellido = 'Villegas'	,
	@segundo_apellido = 'Rodriguez'	,
	--	@perfil		= 6	,
	@centro_costo	= 1025	,
	--	@menu_asociado	= 5	,
	@estado_usuario = 1		,
	@area		= 'Contabilidad'		,
	@telefono	= 5555555		,
	@extension	= 2222	,	
	@cargo		= 5		,
	@ciudad			= 4	,
	--	@contrasena		= 'Dialogo123**'	,
	--	@ing_inv	= 'S'		,
	--	@ing_cus	= 'N'		,
	--  @adm_bd		= 'N'		,
	--	@crea_clientes	= ''	,
	--	@adm_portafolio	= ''	,
	--	@anulacion		= ''	,
	--	@multisesion	= ''	,
	--	@crea_modif_usuario	= '',
	@tiempo_inactividad= '' ,
	@max_hora_ing	= ''	,
	@retval		= ''		
	--	@usuario_alterno	= ''	
	
/** Activaci�n Usuarios */	
	-- Inversiones
USE DIALOGO 
EXEC SP_IDM_EnableDisable_User
	@empresa = 7		,
	@nro_identificacion	= 5896485100,
	@estado_usuario = 5		,
	@retval		= ''			

	-- Custodia 
USE DIALOGO 
EXEC SP_IDM_EnableDisable_User
	@empresa = 71		,
	@nro_identificacion	= 5624828,
	@estado_usuario = 5		,
	@retval		= ''	


/* Modificar Perfil */
USE DIALOGO 
EXEC SP_IDM_Modify_Profile
	@empresa = 71		,
	@nro_identificacion	= 5624828,
	@perfil		= 3,
	@menu_asociado	= 5,
	@ing_inv	= 'S'		,
	@ing_cus	= 'N'		,
	@adm_bd		= 'N'		,
	@crea_clientes	= ''	,
	@adm_portafolio	= '',
	@anulacion		= '',	
	@multisesion	= '',	
	@crea_modif_usuario	= '',
	@retval		= ''		
	
	
	
/* Cambio de Contrase�a */
USE DIALOGO 
EXEC SP_IDM_ChangeUserPassword
	@empresa = 71		,
	@nro_identificacion	= 5624828,
	@contrasena		= 'Dialogo456**'	,
	@estado_usuario = 5			,
	@retval		= ''	


select * from dbo.dv11usr1
where identificacion = '96842367'

select *--nombre, passw, nivel, dv11_empresa, estado_usuario, identificacion, crear_inver, autoriza_custodia
from dbo.dv11usr1
ORDER BY  fecha DESC

select * from dms_usuario_perfiles
where COD_USUARIO = '5896485100'

delete from dbo.dv11usr1
where cod_usuario IN ('AEVR', 'DIVR', 'ANVR')

SELECT DISTINCT COD_PERFIL
FROM dms_usuario_perfiles