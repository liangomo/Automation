/*DESCRIPCION : CREACION DE LA VISTA PARA CONSULTA*/
/*CREADO POR : TECNOEVOLUCION LTDA*/
/*FECHA 13-03-2015*/
CREATE VIEW vista_seguridad
AS  (  SELECT  d.cod_emp , 
			u.cod_usuario,          
			u.identificacion,           
			u.nombre ,           
			u.estado_usuario,
			d.fecha fecha_ult_acceso,
			u.nivel perfil,
			u.dv11_menu,
			d.login ,           
			u.cod_usuario as usuario_alterno,
			u.admon_portafolio,
			u.sw_anulacion as anulacion,
			u.multisesion,
			u.autorizacion_admon as crea_modif_usuario,
			u.crear_cliente,
			u.crear_inver as ingreso_inversiones, 
			u.autoriza_custodia,
			d.fecha,
			d.hora ,   
			d.id_terminal ,   
			d.codigo_respuesta ,     
			d.nombre_reporte ,      
			d.nombre_objeto 
			
	FROM dlgaudit d join dv11usr1 u ON d.login = u.usuario_base  
	where u.dv11_empresa = d.cod_emp)
/*
declare @cod_emp int
declare @fecha_ini datetime
declare @fecha_fin datetime

select @cod_emp = 0
select @fecha_ini = '01-jun-2014'
select @fecha_fin = '01-jul-2014'

select * from vista_seguridad where cod_emp = case @cod_emp when 0 then cod_emp else @cod_emp end 
and fecha>= @fecha_ini
and fecha < @fecha_fin

*/