/*DESCRIPCION : FUNCION UTILIZADA DESDE LOS SP PARA RETORNAR EL VALOR DE LOS ERRORES*/
/*CREADO POR : TECNOEVOLUCION LTDA*/
/*FECHA 13-03-2015*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Carlos A Castellanos
-- Create date: 19-02-2015 
-- Description:	Seleccion del error para DIALOGO - IDM
-- =============================================
ALTER FUNCTION F_ERROR_DIALOGO (@codigo float, @nombre_error varchar(50))  

RETURNS varchar(255)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(255)

	-- Add the T-SQL statements to compute the return value here
		select @ResultVar = descripcion_error from dbo.DMS_ERROR_MVTO
		where cod_error = @codigo
		and nombre_error = @nombre_error

	-- Return the result of the function
	RETURN @ResultVar

END
GO