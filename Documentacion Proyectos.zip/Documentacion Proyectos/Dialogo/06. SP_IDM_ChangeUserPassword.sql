/*DESCRIPCION : CAMBIA EL ESTADO DEL USUARIO A ACTIVO*/
/*CREADO POR : TECNOEVOLUCION LTDA*/
/*FECHA 13-03-2015*/

USE DialogoIFRS;
GO
IF OBJECT_ID ( 'SP_IDM_ChangeUserPassword', 'P' ) IS NOT NULL 
    DROP PROCEDURE SP_IDM_ChangeUserPassword;
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

CREATE proc SP_IDM_ChangeUserPassword

	@empresa			int, --codigo de la empresa para asociar al usuario obligatorio dv10emp1
	@nro_identificacion	float, --numero de identificacion del usuario a crear obligatorio
	@contrasena			varchar(20)	,--Se recibe en claro
	@estado_usuario		char(2),	--Codigo de estado del usuario para este debe llegar en 5 activo
	@retval				varchar(255) out
as	
begin 

	/*Validaciones de campos obligatorios*/
	--Validacion que el codigo de la empresa enviado no sea nulo o sea 0
	DECLARE @ll_cantidad INT

	if (@empresa is null or @empresa <= 0)
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50001,'EMPRESA')
		print @retval
		return 1
	end
	--Validacion que la empresa enviada exista en el aplicativo.
	select @ll_cantidad = count(0) from dv10emp1 where cod_emp_int = @empresa  
	if @ll_cantidad = 0
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50009,'NO EXISTE') +' La empresa no existe. '+ CONVERT(VARCHAR(10),@empresa)
		print @retval
		return 1
	end

	if (@nro_identificacion is null or @nro_identificacion <= 0)
	begin	
		SET @retval = usuarios_dial.f_error_dialogo(50002,'IDENTIFICACION') + 'Identicaci�n no valida. ' + convert(varchar(20),@nro_identificacion )
		print @retval
		return 1
	end

	if (@contrasena is null or @contrasena = '')
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50011,'CONTRASE�A')
		print @retval
		return 1
	end

	if @estado_usuario <> '5'
	begin
		SET @retval = usuarios_dial.f_error_dialogo(50007,'ESTADO') + ' El estado debe ser Activo.'
		print @retval
		return 1
	end

	select @ll_cantidad = count(0) from dbo.dv11usr1 where dv11_empresa = @empresa and identificacion = @nro_identificacion

	if @ll_cantidad > 0 
	begin
		if (@contrasena <> '' or @contrasena is not null)
		begin
			update dbo.dv11usr1
			set passw = @contrasena, estado_usuario = @estado_usuario, fecha_modificacion = getdate()
			where dv11_empresa = @empresa
			and identificacion = @nro_identificacion

			IF @@ROWCOUNT = 0
				begin
					set @retval = usuario_dial.f_error_dialogo(50010,'ACTUALIZA')  + ' ' + convert(varchar(15),@nro_identificacion) + ' Contrase�a.' 
					print @retval 
					return 1
				end
		end

	end
	else
		begin
			SET @retval = usuarios_dial.f_error_dialogo(50009,'NO EXISTE ') + 'El usuario.'
			print @retval
			return 1
		end
end
