package login.test;

import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import homePage.paginas.HomePage;
import login.paginas.Login;
import miMovistarHome.paginas.MiMovistarHome;
import model.DispositivoPrueba;
import model.Estados;

public class TestLogin {

	AdminDocPdf objAdminDocPdf;
	Properties prop = new Properties();
	Estados veredicto;

	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	Login login = new Login(objConfigAux);
	MiMovistarHome miMov = new MiMovistarHome(objConfigAux);
	HomePage home = new HomePage(objConfigAux);

	@BeforeSuite
	public void setup() throws IOException, InterruptedException {
		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);

		objConfigAux.getChrome(prop.getProperty("UrlBase"));
	}

	/**
	 * CASOS DE PRUEBA
	 */
	@Test(priority = 1)
	public void ingresarProductoPospago()
			throws InterruptedException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"LoginExitosoPospago", DispositivoPrueba.WEB, "LOGIN: Exitoso");

			login.loginMain();
			home.getBodyFrameDefaultContent();
			home.clicLnkProducto("Pospago 8872");
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), home.getImgImagesPersona()));
			objAdminDocPdf.generaEvidencia("Ingreso Pospago 8872",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 2)
	public void ingresarProductoCtaControl()
			throws InterruptedException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"LoginExitosoCtaControl", DispositivoPrueba.WEB, "LOGIN: Exitoso");

			login.loginMain();
			home.getBodyFrameDefaultContent();
			home.clicLnkProducto("Principal CtaCtrl 47");
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), home.getImgImagesPersona()));
			objAdminDocPdf.generaEvidencia("Ingreso Principal CtaCtrl 47",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 3)
	public void ingresarProductoPrepago()
			throws InterruptedException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"LoginExitosoPrepago", DispositivoPrueba.WEB, "LOGIN: Exitoso");

			login.loginMain();
			home.getBodyFrameDefaultContent();
			home.clicLnkProducto("Principal Prepago 08");
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), home.getImgImagesPersona()));
			objAdminDocPdf.generaEvidencia("Ingreso Principal Prepago 08",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 4)
	public void ingresarLoginFallido()
			throws InterruptedException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"LoginFallido", DispositivoPrueba.WEB, "LOGIN: Fallido");

			login.loginFallido();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterTest
	public void finalizeTest() throws MalformedURLException, IOException, com.lowagie.text.DocumentException {
		// objAdminDocPdf.crearDocumento(Estados.SUCCESS);
	}

	@AfterSuite
	public void tearDown() {
		objConfigAux.getDriver().quit();
	}
}