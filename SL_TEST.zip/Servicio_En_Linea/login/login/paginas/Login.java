package login.paginas;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import miMovistarHome.paginas.MiMovistarHome;

public class Login {

	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	MiMovistarHome miMov = new MiMovistarHome(objConfigAux);
	
	/** LISTA ELEMENTOS */
	By txtMail = By.id("formValidar");
	By txtPassword = By.id("Password");
	By btnSubmit = By.cssSelector("input.submit");
	By lblLoginFallido = By.id("fancyMessage");
	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");

	/* Constructor */
	public Login(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}

	
	/** EVENTOS (ACCIONES) */

	public void setTxtMail(String mail) {
		this.objConfigAux.getDriver().findElement(txtMail).clear();
		this.objConfigAux.getDriver().findElement(txtMail).sendKeys(mail);
	}

	public boolean setTxtMailExist() {
		return (txtMail) != null;
	}

	public void setTxtPassword(String password) {
		this.objConfigAux.getDriver().findElement(txtPassword).clear();
		this.objConfigAux.getDriver().findElement(txtPassword).sendKeys(password);
	}

	public void clickBtnSubmit() {
		this.objConfigAux.getDriver().findElement(btnSubmit).click();
	}

	public String getLblLoginFallido() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), lblLoginFallido);
		return this.objConfigAux.getDriver().findElement(lblLoginFallido).getText();
	}

	
	/** METODOS */

	public void execLogin(String vCodUsuario, String vCodContrase�a) throws InterruptedException {

		this.setTxtMail(vCodUsuario);
		this.setTxtPassword(vCodContrase�a);
		this.clickBtnSubmit();
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), miMov.getBtnHomePage());
	}

	public void loginMain() throws InterruptedException, IOException {

		setTxtMail("autom.pruebas@gmail.com");
		setTxtPassword("Telefonica.2");
		objAdminDocPdf.generaEvidencia("Ingreso Principal", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickBtnSubmit();
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), miMov.getBtnHomePage()));
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), imgPhotoUser));
		objAdminDocPdf.generaEvidencia("Ingreso Principal Exitoso",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	public void loginFallido() throws InterruptedException, IOException {

		setTxtMail("pruebasecommerce@gmail.com");
		setTxtPassword("Pruebas");
		objAdminDocPdf.generaEvidencia("Ingreso Principal Fallido",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickBtnSubmit();
		String mensajeFallido = "El usuario o contrasena ingresados son incorrectos.";
		assertEquals(getLblLoginFallido(), mensajeFallido);
		objAdminDocPdf.generaEvidencia("Ingreso con mensaje fallido",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}