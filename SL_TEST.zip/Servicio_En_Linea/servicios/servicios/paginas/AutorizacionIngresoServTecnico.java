package servicios.paginas;

public class AutorizacionIngresoServTecnico {

}
