package servicios.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import homePage.paginas.HomePage;

public class TiendaDeContenidos {

	/** 
	 * LISTA ELEMENTOS
	 * */

	ObjetosConfigAux objConfigAux;
	AdminDocPdf objAdminDocPdf;
	HomePage home = new HomePage(objConfigAux);
	By linkTiendaDeContenidos = By.linkText("Tienda de Contenidos");
	By imgMovistarStore = By.xpath("//*[@id='form1']/header/div/a[1]/img");
	
	public TiendaDeContenidos(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}
	
	
	/** 
	 * EVENTOS (ACCIONES) EN LOS OBJETOS
	 * */
	
	public void clickLinkTiendaDeContenidos() {
		this.objConfigAux.getDriver().findElement(linkTiendaDeContenidos).click();
	}
	
	public By getImgMovistarStore() {
		return (imgMovistarStore);
	}
	
	/**
	 * METODOS
	 */

	public void ingresarTiendaDeContenidos() throws InterruptedException, AWTException, IOException {

		home.clicklinkServicios();
		clickLinkTiendaDeContenidos();

		objConfigAux.cambiarVentana();
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  getImgMovistarStore()));
		objAdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		home.keyPressCerrarPestana();
		objConfigAux.cambiarVentanaAnterior();
	}
	
}