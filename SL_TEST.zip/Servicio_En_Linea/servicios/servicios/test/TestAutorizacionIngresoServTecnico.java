package servicios.test;

public class TestAutorizacionIngresoServTecnico {

}
