package consultas.tests;

import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import consultas.paginas.ConsumoALaFecha;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import homePage.paginas.HomePage;
import login.paginas.Login;
import miMovistarHome.paginas.MiMovistarHome;
import model.DispositivoPrueba;
import model.Estados;

public class TestConsumoALaFecha {

	AdminDocPdf objAdminDocPdf;
	Properties prop = new Properties();
	Estados veredicto;

	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	Login login = new Login(objConfigAux);
	MiMovistarHome miMov = new MiMovistarHome(objConfigAux);
	HomePage home = new HomePage(objConfigAux);
	ConsumoALaFecha cons = new ConsumoALaFecha(objConfigAux);

	@BeforeSuite
	public void setup() throws IOException, InterruptedException {
		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);

		objConfigAux.getChrome(prop.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux);
		objLogin.execLogin(prop.getProperty("Usuario"), prop.getProperty("Contrasenia"));
	}

	/**
	 * CASOS DE PRUEBA
	 */

	@Test(priority = 1)
	public void ingresarConsumoALaFechaPospago()
			throws InterruptedException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"ConsultarConsumoALaFechaPospago", DispositivoPrueba.WEB, "CONSULTAS: Consumos a la fecha");

			miMov.clickBtnHomePage();
			home.clicLnkProducto("Pospago 8872");

			objAdminDocPdf.generaEvidencia("Ingreso Pospago 8872", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			home.clickLinkConsultas();
			cons.clickLinkConsumosPROD();
			assertTrue(cons.getBody().contains("Consumo de Voz"));
			assertTrue(cons.getBody().contains("Consumo de Mensajes de Texto"));
			objAdminDocPdf.generaEvidencia("Ingreso Consumos a la fecha",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			cons.execValidarLinkVolverConsumoALaFecha("Pospago");
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 2)
	public void ingresarConsumoALaFechaCtaControl()
			throws InterruptedException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"ConsultarConsumoALaFechaCtaControl", DispositivoPrueba.WEB, "CONSULTAS: Consumos a la fecha");

			miMov.clickBtnHomePage();
			home.clicLnkProducto("Principal CtaCtrl 47");

			objAdminDocPdf.generaEvidencia("Ingreso Principal CtaCtrl 47",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			home.clickLinkConsultas();
			cons.clickLinkConsumosPROD();
			home.getBodyFrameContentPlaceHolder();
			assertTrue(cons.getBody().contains("Tu saldo disponible del plan"));
			assertTrue(cons.getBody().contains("Tus recargas"));
			assertTrue(cons.getBody().contains("Tu Saldo de Paquetes contratados"));
			objAdminDocPdf.generaEvidencia("Ingreso Consumos a la fecha",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			cons.execValidarLinkVolverConsumoALaFecha("CtaControl");

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 3)
	public void ingresarConsumoALaFechaPrepago()
			throws InterruptedException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"ConsultarConsumoALaFechaPrepago", DispositivoPrueba.WEB, "CONSULTAS: Consumos a la fecha");

			miMov.clickBtnHomePage();
			home.clicLnkProducto("Principal Prepago 08");

			objAdminDocPdf.generaEvidencia("Ingreso Principal Prepago 08",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			home.clickLinkConsultas();
			cons.clickLinkConsumosPROD();
			home.getBodyFrameContentPlaceHolder();
			assertTrue(cons.getBody().contains("Tus recargas para usarlas en cualquier servicio"));
			objAdminDocPdf.generaEvidencia("Ingreso Consumos a la fecha",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			cons.execValidarLinkVolverConsumoALaFecha("Prepago");
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterTest
	public void finalizeTest() throws MalformedURLException, IOException, com.lowagie.text.DocumentException {
		// objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterSuite
	public void tearDown() {
		// objConfigAux.getDriver().quit();
	}
}