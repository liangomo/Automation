package consultas.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.itextpdf.text.DocumentException;

import consultas.paginas.ConsultarContrato_Object;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import general.HomePage;
import general.Login;
import login.objects.Login_Object;
import login.objects.Login_Sisga_Object;
import model.DispositivoPrueba;
import telefoniaMovil_Home.objects.Home_Object;
import utilities.Helper;

public class ConsultarContrato_Test {
	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties propiedades = new Properties();
	
	Helper help =  new Helper();
	Login_Object login = new Login_Object(help);
	Home_Object home = new Home_Object(help);
	ConsultarContrato_Object cont = new ConsultarContrato_Object(help);
	Login_Sisga_Object sisga = new Login_Sisga_Object(help);

	FileWriter fichero;
	String fecha = help.ObtenerFecha();
	String hora = help.ObtenerHora();

	String img = "";
	String veredicto = "";
	String nombrePDF = "";
	String navegador = "";
	String rutaArchivos = "C:\\Evidencia SL\\";

	String urlPruebasSisga = "http://sisga12:8031/#wbogsue";
	//	String urlPruebas = "http://midev.movistar.co/";
	//	String urlProduccion = "http://mi.movistar.co/";

	@BeforeSuite
	public void setup() throws IOException {
		propiedades = new Properties();
		InputStream entrada = new FileInputStream("Config.properties");
		propiedades.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(propiedades.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(propiedades.getProperty("Usuario"), propiedades.getProperty("Contrasenia"));
	}

	/** 
	 * CASOS DE PRUEBA
	 * */


	@Test (priority = 1)
	public void ingresarSolicitudContratoPospago() throws InterruptedException, AWTException, DocumentException {

		try {
			img = "Pospago";
			nombrePDF = hora + "_" + navegador + "_SolicitarContrato_Pospago";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);
			//		home.clicLnkProducto("Principal Pospago 89");

			sisga.setTxtNumCelular("3155826432");
			sisga.clickBtnInicioSesion(); Thread.sleep(12000);

			/* SI ES IE */
			//			help.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			help.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);


			help.getCapturaImagen("ingresarSolicitudCont_" + img);
			ingresarSolicitudContrato();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}

	@Test (priority = 2)
	public void consultarHistoricoCambiosPospago() throws InterruptedException, DocumentException {

		try {
			img = "Pospago";
			nombrePDF = hora + "_" + navegador + "_HistoricoCambios_Pospago";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);

			help.getCapturaImagen("consultarHistorico_" + img);

			consultarHistoricoCambios();

			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}

	@Test (priority = 3)
	public void ingresarSolicitudContratoCtaControl() throws InterruptedException, AWTException, DocumentException {

		try {
			img = "CtaControl";
			nombrePDF = hora + "_" + navegador + "_SolicitarContrato_CtaControl";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);
			//			home.clicLnkProducto("Principal CtaCtrl 47");

			help.getFirefox(urlPruebasSisga);
			sisga.setTxtDirectorio("SEL_WEBCONSUMOS_PORTAL");

			sisga.setTxtNumCelular("3175751967");
			sisga.clickBtnInicioSesion(); Thread.sleep(12000);

			/* SI ES IE */
			//			help.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			help.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);

			help.getCapturaImagen("ingresarSolicitudCont_" + img);
			ingresarSolicitudContrato();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}


	@Test (priority = 4)
	public void consultarHistoricoCambiosCtaControl() throws InterruptedException, DocumentException {

		try {
			img = "CtaControl";
			nombrePDF = hora + "_" + navegador + "_HistoricoCambios_CtaControl";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);

			help.getCapturaImagen("consultarHistorico_" + img);
			consultarHistoricoCambios();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}

	//	@Test (priority = 5)
	//	public void descargarCondicionesServicioPrepago() {
	//
	//		home.clicLnkProducto("Principal Prepago 08");
	//		descargarCondicionesServicio();
	//	}


	/** 
	 * MÉTODOS
	 * */

	public void ingresarSolicitudContrato() throws InterruptedException, AWTException {

		home.clickLinkConsultas(); Thread.sleep(5000);
		cont.clickLinkConsultarContrato(); Thread.sleep(3000);

		home.getBodyFrameContentPlaceHolder();
		cont.clickBtnSolicitarContrato();
		cont.sendTxtIntroduceEmail("autom.pruebas@gmail.com");  Thread.sleep(4000);
		help.getCapturaImagen("consultarContrato_" + img);

		cont.clickBtnEnviar();  Thread.sleep(4000);
		assertTrue(cont.getLblSolicitudEnviada().equals("Se ha enviado tu solicitud."));
		help.getCapturaImagen("envioContrato" + img);

		cont.clickBtnVolver();  Thread.sleep(4000);
		assertTrue(help.buscarObjeto(cont.getLblContratoUnico()));
		help.getCapturaImagen("volverContrato" + img);
	}

	public void consultarHistoricoCambios() throws InterruptedException {

		Thread.sleep(3000);
		cont.clickBtnHistoricoCambios();  Thread.sleep(4000);
		assertTrue(cont.getLblHistoricoCambios().equals("El histórico de cambios de tu línea a partir del "
				+ "1 de junio de 2015 es:"));
		help.getCapturaImagen("consultaHistorico" + img);

		cont.clickBtnVolver();  Thread.sleep(4000);
		assertTrue(help.buscarObjeto(cont.getLblContratoUnico()));
		help.getCapturaImagen("volverHistorico" + img);
	}

	public void descargarCondicionesServicio() {

		home.clickLinkConsultas();
		cont.clickLinkConsultarContrato();
		home.getBodyFrameContentPlaceHolder();
		assertEquals(cont.getLblCondicionesServicio(), "Condiciones generales del servicio en modalidad prepago");

		cont.clickLinkDescarga();

		////VALIDACION DESCARGAS
	}
}