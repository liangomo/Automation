package consultas.tests;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import consultas.paginas.FacturaDigital_Object;
import login.objects.Login_Object;
import model.DispositivoPrueba;
import model.Estados;
import telefoniaMovil_Home.objects.Home_Object;
import utilities.Helper;

import evidencia.doc.pdf.AdminDocPdf;
import general.HomePage;
import general.Login;
import control.elementos.ObjetosConfigAux;

public class FacturaDigital_Test {
	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties propiedades = new Properties();
	
	AdminDocPdf objAdminDocPdf;
	Properties propiedades = new Properties();
	Estados veredicto;
	ObjetosConfigAux objObjetosConfigAux = new ObjetosConfigAux();

	Obj help =  new Helper();
	Login_Object login = new Login_Object(help);
	Home_Object home = new Home_Object(help);
	FacturaDigital_Object fact = new FacturaDigital_Object(help);


    String url = "http://mi.movistar.co/";
		

	@BeforeSuite
	public void setup() throws IOException {
		propiedades = new Properties();
		InputStream entrada = new FileInputStream("Config.properties");
		propiedades.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(propiedades.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(propiedades.getProperty("Usuario"), propiedades.getProperty("Contrasenia"));
	}


	/**
	 * CASOS DE PRUEBA
	 */

	@Test(priority = 1)
	public void ingresarFacturaPospago() throws InterruptedException {

		try {
			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "Actualización de datos", DispositivoPrueba.WEB);

			home.clickIcnHome();
			Thread.sleep(3000);
			home.getBodyFrameDefaultContent();

			home.clicLnkProducto("Principal Pospago 89");

			objAdminDocPdf.generaEvidencia("Ingreso Principal Pospago 89",
					Shutterbug.shootPage(help.getDriver()).getImage());
			ingresoFactura();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
	}

	@Test (priority = 2)
	public void verificarSubmoduloPospago() throws InterruptedException {

		try {
			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "Actualización de datos", DispositivoPrueba.WEB);

			verificarSubmodulo();
			
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		} 
	}

	@Test (priority = 3)
	public void verificarPaginacionPospago() throws InterruptedException  {

		try {
			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "Verificar Paginacion Pospago", DispositivoPrueba.WEB);
			
			verificarPaginacion();
			
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		} 
	}

	@Test (priority = 4)
	public void validarInformacionPospago() throws InterruptedException  {

		try {
			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "Validar Informacion Pospago", DispositivoPrueba.WEB);

			objAdminDocPdf.generaEvidencia("Valida Informacion",
					Shutterbug.shootPage(help.getDriver()).getImage());

			String nitCedula = fact.getSpanNitCedula();
			String telefono = fact.getSpanTelefono();
			String clienteNo = fact.getSpanClienteNo();
			String facturaVenta = fact.getSpanFacturaVenta();
			String fechaExpedicion = fact.getSpanFechaExpedicion();
			String facturaMes= fact.getSpanFacturaMes();
			String fechaProximaFactura = fact.getSpanFechaProximaFactura();
			String numeroParaPagos = fact.getSpanNumeroParaPagos();
			String fechaLimitePago = fact.getSpanFechaLimitePago();
			String totalPagar = fact.getSpanTotalPagar();

			assertTrue(nitCedula.contains("1600"));
			assertTrue(telefono.contains("3188277289"));
			assertTrue(clienteNo.contains("30891357"));
			assertNotNull(facturaVenta);
			assertNotNull(fechaExpedicion);
			assertNotNull(facturaMes);
			assertNotNull(fechaProximaFactura);
			assertTrue(numeroParaPagos.contains("30891357"));
			assertNotNull(fechaLimitePago);
			assertNotNull(totalPagar);


			String cargosFacturados = fact.getSpanCargosFacturados();
			String valorImpuestos = fact.getSpanValorImpuestos();

			assertTrue(cargosFacturados.contains("Detalle de Cargos Facturados"));
			assertTrue(valorImpuestos.contains("Valor con Impuestos"));
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		} 
	}

	@Test (priority = 5)
	public void ingresarFacturaCtaControl() throws InterruptedException {

		try {
			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "Ingresar Factura Cuenta Control", DispositivoPrueba.WEB);
			
			home.clickIcnHome();
			Thread.sleep(3000);
			home.getBodyFrameDefaultContent();
			
			home.clicLnkProducto("Principal CtaCtrl 47");

			objAdminDocPdf.generaEvidencia("Ingreso Factura Digital",
					Shutterbug.shootPage(help.getDriver()).getImage());
			
			ingresoFactura();
			
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
	}

	@Test (priority = 6)
	public void verificarSubmoduloCtaControl() throws InterruptedException  {

		try {
			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "Verificar Sub Modulo Cuenta Control", DispositivoPrueba.WEB);
			
			verificarSubmodulo();
			
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
	}

	@Test (priority = 7) // (dependsOnMethods = { "ingresoFacturaPospago" })
	public void verificarPaginacionCtaControl() throws InterruptedException  {

		try {
			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "Verificar Paginacion Cuenta Control", DispositivoPrueba.WEB);
			
			verificarPaginacionCta();
			
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		} 
	}

	@Test (priority = 8)
	public void validarInformacionCtaControl() throws InterruptedException  {

		try {
			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "Validar Informacin Cuenta Control", DispositivoPrueba.WEB);
			
			validarInformacion();

			String nitCedula = fact.getSpanNitCedula();
			String telefono = fact.getSpanTelefono();
			String clienteNo = fact.getSpanClienteNo();
			String facturaVenta = fact.getSpanFacturaVenta();
			String fechaExpedicion = fact.getSpanFechaExpedicion();
			String facturaMes= fact.getSpanFacturaMes();
			String fechaProximaFactura = fact.getSpanFechaProximaFactura();
			String numeroParaPagos = fact.getSpanNumeroParaPagos();
			String fechaLimitePago = fact.getSpanFechaLimitePago();
			String totalPagar = fact.getSpanTotalPagar();

			assertTrue(nitCedula.contains("37322739"));
			assertTrue(telefono.contains("3174363547"));
			assertTrue(clienteNo.contains("21896234"));
			assertNotNull(facturaVenta);
			assertNotNull(fechaExpedicion);
			assertNotNull(facturaMes);
			assertNotNull(fechaProximaFactura);
			assertTrue(numeroParaPagos.contains("21896234"));
			assertNotNull(fechaLimitePago);
			assertNotNull(totalPagar);

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		} 
	}


	
	
	/** 
	 * MÉTODOS
	 * @throws IOException 
	 * */

	public void ingresoFactura() throws InterruptedException, IOException {

		home.clickLinkConsultas();
		fact.clickLinkFacturaPROD();

		help.cambiarVentana();
		fact.getBodyFramePresenta();
		assertTrue(help.buscarObjeto(fact.getBarTitulo()));
		objAdminDocPdf.generaEvidencia("Ingreso Principal Pospago 89", Shutterbug.shootPage(help.getDriver()).getImage());

		fact.clickImgCerrar();
		assertTrue(help.buscarObjeto(fact.getImgFacturaDigital()));

	}

	public void verificarSubmodulo() throws InterruptedException, IOException {

		if (help.buscarObjeto(fact.getImgFacturaDigital())) {

			fact.clickImgNovedades();
			Thread.sleep(8000);
			assertTrue(help.buscarObjeto(fact.getBarTitulo()));
			objAdminDocPdf.generaEvidencia("Verifica Novedades", Shutterbug.shootPage(help.getDriver()).getImage());
			fact.clickImgCerrar();

			fact.clickImgImprimir();
			Thread.sleep(8000);
			assertTrue(help.buscarObjeto(fact.getBarTitulo()));
			objAdminDocPdf.generaEvidencia("Verifica Imprimir", Shutterbug.shootPage(help.getDriver()).getImage());
			fact.clickImgCerrar();
			Thread.sleep(8000);

			fact.clickImgExportarFact();
			Thread.sleep(8000);
			assertTrue(help.buscarObjeto(fact.getBarTitulo()));
			objAdminDocPdf.generaEvidencia("Exportar Factura", Shutterbug.shootPage(help.getDriver()).getImage());
			fact.clickImgCerrar();
			Thread.sleep(8000);

			fact.clickImgInfoGrafica();
			Thread.sleep(8000);
			assertTrue(help.buscarObjeto(fact.getSpanDetalleInfoGrafica()));
			objAdminDocPdf.generaEvidencia("Informacino grafica", Shutterbug.shootPage(help.getDriver()).getImage());

			fact.clickImgAdminCorreos();
			Thread.sleep(8000);
			assertTrue(help.buscarObjeto(fact.getBarTitulo()));
			objAdminDocPdf.generaEvidencia("Administrar Correos", Shutterbug.shootPage(help.getDriver()).getImage());
			fact.clickImgCerrar();
			Thread.sleep(8000);
		}
	}

	public void verificarPaginacion() throws InterruptedException, IOException {

		if (help.buscarObjeto(fact.getImgFacturaDigital())) {

			fact.getBodyFrameFactura();
			assertTrue(fact.getBody().contains("Señor(a):"));
			objAdminDocPdf.generaEvidencia("Verifica Ingreso Factura",
					Shutterbug.shootPage(help.getDriver()).getImage());
			Thread.sleep(8000);

			help.cambiarVentana();
			fact.getBodyFramePresenta();
			fact.clickImgSiguientePag();  Thread.sleep(8000);
			fact.getBodyFrameFactura();
			assertTrue(fact.getBody().contains("Nit ó Cédula"));
			objAdminDocPdf.generaEvidencia("Verificar Siguiente Pagina",
					Shutterbug.shootPage(help.getDriver()).getImage());

			help.cambiarVentana();
			fact.getBodyFramePresenta();
			fact.clickImgAnteriorPag(); Thread.sleep(8000);
			fact.getBodyFrameFactura();
			assertTrue(fact.getBody().contains("Señor(a)")); 
			objAdminDocPdf.generaEvidencia("Verificar Anterior Pagina",
					Shutterbug.shootPage(help.getDriver()).getImage());

			help.cambiarVentana();
			fact.getBodyFramePresenta();
			fact.clickImgUltimaPag(); 
			fact.clickImgUltimaPag();
			Thread.sleep(8000);
			objAdminDocPdf.generaEvidencia("Verificar Ultima Pagina",
					Shutterbug.shootPage(help.getDriver()).getImage());
			fact.getBodyAlertAccept();

			help.cambiarVentana();
			fact.getBodyFramePresenta();
			fact.clickImgPrimeraPag();
			Thread.sleep(8000);
			fact.getBodyFrameFactura();
			assertTrue(fact.getBody().contains("Señor(a):")); 
			objAdminDocPdf.generaEvidencia("Verificar Primera Pagina",
					Shutterbug.shootPage(help.getDriver()).getImage());

			help.cambiarVentana();
			fact.getBodyFramePresenta();
		}
	}

	public void verificarPaginacionCta() throws InterruptedException, IOException {

		if (help.buscarObjeto(fact.getImgFacturaDigital())) {

			fact.getBodyFrameFactura();
			assertTrue(fact.getBody().contains("Señor(a):")); 
			objAdminDocPdf.generaEvidencia("Verificar Ingreso Factura",
					Shutterbug.shootPage(help.getDriver()).getImage());
			Thread.sleep(8000);

			help.cambiarVentana();
			fact.getBodyFramePresenta();
			fact.clickImgSiguientePag();
			Thread.sleep(8000);
			fact.getBodyFrameFactura();
			assertTrue(fact.getBody().contains("Nit ó Cédula")); //
			objAdminDocPdf.generaEvidencia("Verificar Siguiente Pagina",
					Shutterbug.shootPage(help.getDriver()).getImage());

			help.cambiarVentana();
			fact.getBodyFramePresenta();
			fact.clickImgAnteriorPag();
			Thread.sleep(8000);
			fact.getBodyFrameFactura();
			assertTrue(fact.getBody().contains("Señor(a):")); //
			objAdminDocPdf.generaEvidencia("Verificar Pagina Anterior",
					Shutterbug.shootPage(help.getDriver()).getImage());

			help.cambiarVentana();
			fact.getBodyFramePresenta();
		}
	}

	public void validarInformacion() throws InterruptedException, IOException {

		if (help.buscarObjeto(fact.getImgFacturaDigital())) {
			fact.clickImgSiguientePag();  Thread.sleep(8000);
			fact.getBodyFrameFactura();
		}
		objAdminDocPdf.generaEvidencia("Validar Informacion",
				Shutterbug.shootPage(help.getDriver()).getImage());
	}	
}