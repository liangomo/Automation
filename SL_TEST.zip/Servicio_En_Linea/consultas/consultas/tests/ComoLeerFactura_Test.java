package consultas.tests;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import general.HomePage;
import general.Login;
import model.DispositivoPrueba;
import model.Estados;
import telefoniaMovil_Home.objects.Home_Object;
import telefoniaMovil_consultas.objects.ComoLeerFactura_Object;

public class ComoLeerFactura_Test {
	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties propiedades = new Properties();

	@BeforeSuite
	public void setup() throws IOException {
		InputStream entrada = new FileInputStream("Config.properties");
		propiedades.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(propiedades.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(propiedades.getProperty("Usuario"), propiedades.getProperty("Contrasenia"));
	}

	/** 
	 * CASOS DE PRUEBA
	 * */

	@Test (priority = 1)
	public void ingresarLeerFacturaPospago() throws InterruptedException, AWTException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);
			
			objHomePage = new HomePage(objConfigAux.getDriver());
			objHomePage.clicBtnHomePage();
			objHomePage.clicLnkProducto("3178642577 posp");


			objConfigAux.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
						objConfigAux.getDriver().switchTo().alert().accept();
						Thread.sleep(40000);

			objAdminDocPdf.generaEvidencia("Seleccion valor para recargar ", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			ingresarLeerFactura();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
	}

	// @Test (priority = 2)
	public void ingresarLeerFacturaCtaControl() throws InterruptedException, AWTException, MalformedURLException, IOException {

		try {

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);

			//			home.clickIcnHome(); Thread.sleep(3000);
			//			home.getBodyFrameDefaultContent();
			//			home.clicLnkProducto("3155826432 Pospago"); // home.clicLnkProducto("Principal CtaCtrl 47");

			help.getSafari(urlPruebasSisga);
		

			//			objConfigAux.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			objConfigAux.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);

			objAdminDocPdf.generaEvidencia("Seleccion valor para recargar ", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			ingresarLeerFactura();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
	}

	public void ingresarLeerFactura() throws InterruptedException, AWTException {

		home.clickLinkConsultas(); Thread.sleep(3000);
		leer.clickLinkComoLeerFactura(); Thread.sleep(3000);

		help.cambiarVentana();
		assertEquals(leer.getLblConoceTuFactura(), "Conoce tu factura");
		objAdminDocPdf.generaEvidencia("Seleccion valor para recargar ", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		home.keyPressCerrarPestaña();
		help.cambiarVentanaAnterior(); Thread.sleep(2000);
	}

	@AfterTest
	public void finalizeTest() throws MalformedURLException, IOException, com.lowagie.text.DocumentException {
		objAdminDocPdf.crearDocumento(Estados.SUCCESS);
	}

	@AfterSuite
	public void tearDown() {
		objConfigAux.getDriver().quit();
	}

}