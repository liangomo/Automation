package consultas.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.itextpdf.text.DocumentException;

import consultas.paginas.ConsultaServicios_Object;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import general.HomePage;
import general.Login;
import login.objects.Login_Object;
import login.objects.Login_Sisga_Object;
import telefoniaMovil_Home.objects.Home_Object;
import utilities.Helper;

public class ConsultaServicios_Test {
	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties propiedades = new Properties();
	
	Helper help = new Helper();
	Login_Object login = new Login_Object(help);
	Home_Object home = new Home_Object(help);
	ConsultaServicios_Object serv = new ConsultaServicios_Object(help);
	Login_Sisga_Object sisga = new Login_Sisga_Object(help);

	FileWriter fichero;
	String fecha = help.ObtenerFecha();
	String hora = help.ObtenerHora();

	String img = "";
	String veredicto = "";
	String nombrePDF = "";
	String navegador = "";
	String rutaArchivos = "C:\\Evidencia SL\\";

	String urlPruebasSisga = "http://sisga12:8031/#wbogsue";
	//	String urlPruebas = "http://midev.movistar.co/";
	//	String urlProduccion = "http://mi.movistar.co/";

	@BeforeSuite
	public void setup() throws IOException {
		propiedades = new Properties();
		InputStream entrada = new FileInputStream("Config.properties");
		propiedades.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(propiedades.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(propiedades.getProperty("Usuario"), propiedades.getProperty("Contrasenia"));
	}


	/** 
	 * CASOS DE PRUEBA
	 * */

	@Test (priority = 1)
	public void validarActivacionServicioPospago() throws InterruptedException, AWTException {

		home.clicLnkProducto("Principal Pospago 89");
		validarActivacionServicio();
	}

	//	@Test (priority = 3)
	//	public void validarActivacionServicioCtaControl() throws InterruptedException, AWTException {
	//
	//		home.clicLnkProducto("Principal CtaCtrl 47");
	//		validarActivacionServicio();
	//	}

	@Test (priority = 2)
	public void activarServicioCtaControl() throws InterruptedException {

		activarServicio();
	}

	//	@Test (priority = 4)
	//	public void activarServicioPospago() throws InterruptedException {
	//
	//		activarServicio();
	//	}


	/** 
	 * MÉTODOS
	 * */

	public void validarActivacionServicio() {

		home.clickLinkConsultas();
		serv.clickLinkConsultaServicios();

		serv.clickBtnActivacionServicio();
		assertEquals(serv.getLblConsultaServicios(), "Consulta de Servicios");

		serv.clickLinkVolverCuenta();
		assertEquals(serv.getLblTelefoniaMovil(), "Telefonía móvil");
	}

	public void activarServicio() throws InterruptedException {

		help.cambiarVentanaAnterior();

		home.getBodyFrameLegacyContainer();
		serv.setCmbTipoServicio("Servicio de Datos");

		serv.clickRadioDetalleServicio(); Thread.sleep(2000);
		assertNotNull(serv.getTxtDescripcionServicio());

		serv.clickBtnSiguiente();
		assertEquals(serv.getLblPregutaActivacion(), "¿Deseas activar este servicio inmediatamente?");
	}
}