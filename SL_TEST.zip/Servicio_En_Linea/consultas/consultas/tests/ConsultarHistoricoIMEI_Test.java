package consultas.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.itextpdf.text.DocumentException;

import consultas.paginas.ConsultarHistoricoIMEI_Object;
import consultas.paginas.DetalleConsumos_Object;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import general.HomePage;
import general.Login;
import login.objects.Login_Object;
import login.objects.Login_Sisga_Object;
import model.DispositivoPrueba;
import telefoniaMovil_Home.objects.Home_Object;
import utilities.Helper;

public class ConsultarHistoricoIMEI_Test {
	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties propiedades = new Properties();
	
	Helper help = new Helper();
	Login_Object login = new Login_Object(help);
	Home_Object home = new Home_Object(help);
	DetalleConsumos_Object detalle = new DetalleConsumos_Object(help);
	ConsultarHistoricoIMEI_Object imei = new ConsultarHistoricoIMEI_Object(help);
	Login_Sisga_Object sisga = new Login_Sisga_Object(help);

	FileWriter fichero;
	String fecha = help.ObtenerFecha();
	String hora = help.ObtenerHora();

	String img = "";
	String veredicto = "";
	String nombrePDF = "";
	String navegador = "";
	String rutaArchivos = "C:\\Evidencia SL\\";

	String urlPruebasSisga = "http://sisga12:8031/#wbogsue";
	//	String urlPruebas = "http://midev.movistar.co/";
	//	String urlProduccion = "http://mi.movistar.co/";

	@BeforeSuite
	public void setup() throws IOException {
		propiedades = new Properties();
		InputStream entrada = new FileInputStream("Config.properties");
		propiedades.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(propiedades.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(propiedades.getProperty("Usuario"), propiedades.getProperty("Contrasenia"));
	}

	/** 
	 * CASOS DE PRUEBA
	 * */

	//	@Test (priority = 1)
	public void consultarHistoricoIMEIPospago() throws InterruptedException, AWTException, DocumentException {

		try {
			img = "Pospago";
			nombrePDF = hora + "_" + navegador + "_ConsultaHistoricoIMEI_Pospago";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);

			//		home.clicLnkProducto("Principal Pospago 89");

			sisga.setTxtNumCelular("3155826432");
			sisga.clickBtnInicioSesion(); Thread.sleep(4000);

			/* SI ES IE */
			//			help.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			help.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);

			help.getCapturaImagen("consultarHistoricoIMEI_" + img);
			consultarHistoricoIMEI();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}

	//	@Test (priority = 2)
	public void validarLinksPospago() throws InterruptedException, AWTException, DocumentException {
		try {
			img = "Pospago";
			nombrePDF = hora + "_" + navegador + "_LinksHistoricoIMEI_Pospago";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);

			//		home.clicLnkProducto("Principal Pospago 89");

			help.getChrome(urlPruebasSisga);
			sisga.setTxtDirectorio("SEL_WEBCONSUMOS_PORTAL");

			sisga.setTxtNumCelular("3155826432");
			sisga.clickBtnInicioSesion(); Thread.sleep(4000);

			/* SI ES IE */
			//			help.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			help.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);

			help.getCapturaImagen("linksHistoricoIMEI_" + img);
			validarLinks();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}

	//	@Test (priority = 3)
	public void consultarHistoricoIMEICtaControl() throws InterruptedException, AWTException, DocumentException {

		try {
			img = "CtaControl";
			nombrePDF = hora + "_" + navegador + "_ConsultaHistoricoIMEI_CtaControl";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);

			//		home.clicLnkProducto("Principal CtaCtrl 47");

			help.getChrome(urlPruebasSisga);
			sisga.setTxtDirectorio("SEL_WEBCONSUMOS_PORTAL");

			sisga.setTxtNumCelular("3175751967");
			sisga.clickBtnInicioSesion(); Thread.sleep(4000);

			/* SI ES IE */
			//			help.getDriver().switchTo().alert().accept();
			if (help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			help.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);

			help.getCapturaImagen("consultarHistoricoIMEI_" + img);
			consultarHistoricoIMEI();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}

	//	@Test (priority = 4)
	public void validarLinksCtaControl() throws InterruptedException, AWTException, DocumentException {

		try {
			img = "CtaControl";
			nombrePDF = hora + "_" + navegador + "_LinksHistoricoIMEI_CtaControl";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);

			//		home.clicLnkProducto("Principal CtaCtrl 47");

			help.getChrome(urlPruebasSisga);
			sisga.setTxtDirectorio("SEL_WEBCONSUMOS_PORTAL");

			sisga.setTxtNumCelular("3175751967");
			sisga.clickBtnInicioSesion(); Thread.sleep(4000);

			/* SI ES IE */
			//			help.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			help.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);

			help.getCapturaImagen("linksHistoricoIMEI_" + img);
			validarLinks();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}

	@Test (priority = 5)
	public void consultarHistoricoIMEIPrepago() throws InterruptedException, AWTException, DocumentException {

		try {
			img = "Prepago";
			nombrePDF = hora + "_" + navegador + "_ConsultaHistoricoIMEI_Prepago";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);

			//		home.clicLnkProducto("Principal Prepago 08");

			//			help.getChrome(urlPruebasSisga);
			//			sisga.setTxtDirectorio("SEL_WEBCONSUMOS_PORTAL");

			sisga.setTxtNumCelular("3178387213");
			sisga.clickBtnInicioSesion(); Thread.sleep(4000);

			/* SI ES IE */
			//			help.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			help.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);

			help.getCapturaImagen("consultarHistoricoIMEI_" + img);
			consultarHistoricoIMEI();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}

	@Test (priority = 6)
	public void validarLinksPrepago() throws InterruptedException, AWTException, DocumentException {

		try {
			img = "Prepago";
			nombrePDF = hora + "_" + navegador + "_LinksHistoricoIMEI_Prepago";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);

			//		home.clicLnkProducto("Principal Prepago 08");

			help.getChrome(urlPruebasSisga);
			sisga.setTxtDirectorio("SEL_WEBCONSUMOS_PORTAL");

			sisga.setTxtNumCelular("3178387213");
			sisga.clickBtnInicioSesion(); Thread.sleep(4000);

			/* SI ES IE */
			//			help.getDriver().switchTo().alert().accept();
			if (help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			help.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);

			help.getCapturaImagen("linksHistoricoIMEI_" + img);
			validarLinks();
			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}


	/** 
	 * MÉTODOS
	 * */

	public void consultarHistoricoIMEI() throws InterruptedException, AWTException {

		home.clickLinkConsultas();
		imei.clickLinkConsultarHistorico(); Thread.sleep(2000);

		imei.clickImgImprimir();
		help.cambiarVentana();
		home.getBodyFrameDefaultContent();
		assertEquals(imei.getBtnImprimir(), "Imprimir");
		help.getCapturaImagen("imprimir" + img);
		imei.clickBtnCancelar(); Thread.sleep(2000);
		help.getCapturaImagen("btnCancelar" + img);

		//		help.cambiarVentanaAnterior();
		//		home.getBodyFrameDefaultContent();
		//		imei.clickImgDescargar();
		//		home.keyPressUrlDescargas(); Thread.sleep(2000);
		//		// VALIDACIÓN DESCARGA
		//		help.cambiarVentana();
		//		home.keyPressCerrarPestaña();

		help.cambiarVentanaAnterior();
		imei.clickLinkVolverCuenta();
		assertTrue(help.buscarObjeto(home.getImgPhotoUser()));
		help.getCapturaImagen("volverCuenta" + img);
	}

	public void validarLinks() throws InterruptedException, AWTException {

		home.clickLinkConsultas();
		imei.clickLinkConsultarHistorico(); Thread.sleep(2000);

		imei.clickLinkSaberIMEI(); Thread.sleep(2000);
		help.cambiarVentanaAnterior();
		assertTrue(help.buscarObjeto(imei.getCboxClose()));
		help.getCapturaImagen("saberIMEI" + img);
		imei.clickCboxClose();

		help.cambiarVentanaAnterior();
		imei.clickLinkMovistarCo();
		assertTrue(help.buscarObjeto(imei.getImgMovistarCo()));
		help.getCapturaImagen("movistarCO" + img);
	}
}