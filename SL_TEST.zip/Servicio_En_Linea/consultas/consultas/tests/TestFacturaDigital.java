package consultas.tests;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import consultas.paginas.FacturaDigital;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import homePage.paginas.HomePage;
import login.paginas.Login;
import miMovistarHome.paginas.MiMovistarHome;
import model.DispositivoPrueba;
import model.Estados;

public class TestFacturaDigital {

	AdminDocPdf objAdminDocPdf;
	Properties prop = new Properties();
	Estados veredicto;

	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	Login login = new Login(objConfigAux);
	MiMovistarHome miMov = new MiMovistarHome(objConfigAux);
	HomePage home = new HomePage(objConfigAux);
	FacturaDigital fact = new FacturaDigital(objConfigAux);

	@BeforeSuite
	public void setup() throws IOException, InterruptedException {
		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);

		objConfigAux.getChrome(prop.getProperty("UrlBase"));
		Login objLogin = new Login(objConfigAux);
		objLogin.execLogin(prop.getProperty("Usuario"), prop.getProperty("Contrasenia"));
	}

	/**
	 * CASOS DE PRUEBA
	 */

	@Test(priority = 1)
	public void ingresarFacturaPospago() throws InterruptedException, IOException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"IngresoFacturaPospago", DispositivoPrueba.WEB, "CONSULTAS: Factura Digital");

			miMov.clickBtnHomePage();
			home.clicLnkProducto("Principal CtaCtrl 47");

			objAdminDocPdf.generaEvidencia("Ingreso Pospago 8872",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			home.clickLinkConsultas();
			fact.execIngresoFactura();

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 2)
	public void verificarSubmoduloPospago() throws InterruptedException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"VerificarSubmodulosPospago", DispositivoPrueba.WEB, "CONSULTAS: Factura Digital");

			fact.execVerificarSubmodulo();

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 3)
	public void verificarPaginacionPospago() throws InterruptedException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"VerificarPaginacionPospago", DispositivoPrueba.WEB, "CONSULTAS: Factura Digital");

			fact.execVerificarPaginacion();

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 4)
	public void validarInformacionPospago() throws InterruptedException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"ValidarInformacionPospago", DispositivoPrueba.WEB, "CONSULTAS: Factura Digital");

			objAdminDocPdf.generaEvidencia("Valida Informacion", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			String nitCedula = fact.getSpanNitCedula();
			String telefono = fact.getSpanTelefono();
			String clienteNo = fact.getSpanClienteNo();
			String facturaVenta = fact.getSpanFacturaVenta();
			String fechaExpedicion = fact.getSpanFechaExpedicion();
			String facturaMes = fact.getSpanFacturaMes();
			String fechaProximaFactura = fact.getSpanFechaProximaFactura();
			String numeroParaPagos = fact.getSpanNumeroParaPagos();
			String fechaLimitePago = fact.getSpanFechaLimitePago();
			String totalPagar = fact.getSpanTotalPagar();

			assertTrue(nitCedula.contains("1600"));
			assertTrue(telefono.contains("3188277289"));
			assertTrue(clienteNo.contains("30891357"));
			assertNotNull(facturaVenta);
			assertNotNull(fechaExpedicion);
			assertNotNull(facturaMes);
			assertNotNull(fechaProximaFactura);
			assertTrue(numeroParaPagos.contains("30891357"));
			assertNotNull(fechaLimitePago);
			assertNotNull(totalPagar);

			String cargosFacturados = fact.getSpanCargosFacturados();
			String valorImpuestos = fact.getSpanValorImpuestos();

			assertTrue(cargosFacturados.contains("Detalle de Cargos Facturados"));
			assertTrue(valorImpuestos.contains("Valor con Impuestos"));
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 5)
	public void ingresarFacturaCtaControl() throws InterruptedException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"IngresoFacturaCtaControl", DispositivoPrueba.WEB, "CONSULTAS: Factura Digital");

			miMov.clickBtnHomePage();
			home.getBodyFrameDefaultContent();

			home.clicLnkProducto("Principal CtaCtrl 47");

			objAdminDocPdf.generaEvidencia("Ingreso Factura Digital",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			fact.execIngresoFactura();

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 6)
	public void verificarSubmoduloCtaControl() throws InterruptedException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"VerificarSubmodulosCtaControl", DispositivoPrueba.WEB, "CONSULTAS: Factura Digital");

			fact.execVerificarSubmodulo();

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 7)
	public void verificarPaginacionCtaControl() throws InterruptedException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"VerificarPaginacionCtaControl", DispositivoPrueba.WEB, "CONSULTAS: Factura Digital");

			fact.execVerificarPaginacionCta();

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 8)
	public void validarInformacionCtaControl() throws InterruptedException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"ValidarInformacionCtaControl", DispositivoPrueba.WEB, "CONSULTAS: Factura Digital");

			fact.execValidarInformacion();

			String nitCedula = fact.getSpanNitCedula();
			String telefono = fact.getSpanTelefono();
			String clienteNo = fact.getSpanClienteNo();
			String facturaVenta = fact.getSpanFacturaVenta();
			String fechaExpedicion = fact.getSpanFechaExpedicion();
			String facturaMes = fact.getSpanFacturaMes();
			String fechaProximaFactura = fact.getSpanFechaProximaFactura();
			String numeroParaPagos = fact.getSpanNumeroParaPagos();
			String fechaLimitePago = fact.getSpanFechaLimitePago();
			String totalPagar = fact.getSpanTotalPagar();

			assertTrue(nitCedula.contains("37322739"));
			assertTrue(telefono.contains("3174363547"));
			assertTrue(clienteNo.contains("21896234"));
			assertNotNull(facturaVenta);
			assertNotNull(fechaExpedicion);
			assertNotNull(facturaMes);
			assertNotNull(fechaProximaFactura);
			assertTrue(numeroParaPagos.contains("21896234"));
			assertNotNull(fechaLimitePago);
			assertNotNull(totalPagar);

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterTest
	public void finalizeTest() throws MalformedURLException, IOException, com.lowagie.text.DocumentException {
		// objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterSuite
	public void tearDown() {
		objConfigAux.getDriver().quit();
	}
}