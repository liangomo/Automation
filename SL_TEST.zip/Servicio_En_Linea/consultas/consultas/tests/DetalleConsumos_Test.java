package consultas.tests;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.itextpdf.text.DocumentException;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import general.HomePage;
import general.Login;
import login.objects.Login_Object;
import login.objects.Login_Sisga_Object;
import telefoniaMovil_Home.objects.Home_Object;
import telefoniaMovil_consultas.objects.ConsumoALaFecha_Object;
import telefoniaMovil_consultas.objects.DetalleConsumos_Object;
import utilities.Helper;

public class DetalleConsumos_Test {
	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties propiedades = new Properties();
	
	Helper help =  new Helper();
	Login_Object login = new Login_Object(help);
	Home_Object home = new Home_Object(help);
	ConsumoALaFecha_Object cons = new ConsumoALaFecha_Object(help);
	DetalleConsumos_Object detalle = new DetalleConsumos_Object(help);
	Login_Sisga_Object sisga = new Login_Sisga_Object(help);

	FileWriter fichero;
	String fecha = help.ObtenerFecha();
	String hora = help.ObtenerHora();

	String img = "";
	String veredicto = "";
	String nombrePDF = "";
	String navegador = "";
	String rutaArchivos = "C:\\Evidencia SL\\";

	String urlPruebasSisga = "http://sisga12:8031/#wbogsue";
	//	String urlPruebas = "http://midev.movistar.co/";
	//	String urlProduccion = "http://mi.movistar.co/";

	@BeforeSuite
	public void setup() throws IOException {
		propiedades = new Properties();
		InputStream entrada = new FileInputStream("Config.properties");
		propiedades.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(propiedades.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(propiedades.getProperty("Usuario"), propiedades.getProperty("Contrasenia"));
	}


	/** 
	 * CASOS DE PRUEBA
	 * */

	//	@Test (priority = 1)
	//	public void revisarDetalleConsumosPospago() throws InterruptedException, AWTException {
	//
	//		home.clicLnkProducto("Principal Pospago 89");
	//		revisarDetalleConsumos();
	//	}

	//	@Test (priority = 3)
	//	public void revisarDetalleConsumosCtaControl() throws InterruptedException, AWTException {
	//
	//		home.clicLnkProducto("Principal CtaCtrl 47");
	//		revisarDetalleConsumos();
	//	}
	//
	@Test (priority = 5)
	public void revisarDetalleConsumosPrepago() throws InterruptedException, AWTException {

		home.clicLnkProducto("Principal Prepago 08");
		revisarDetalleConsumos();
	}

	//	@Test (priority = 2)
	//	public void validarLlamadasCaidasPospago() throws InterruptedException, AWTException {
	//
	//		validarLlamadasCaidas();
	//	}

	//	@Test (priority = 4)
	//	public void validarLlamadasCaidasCtaControl() throws InterruptedException, AWTException {
	//
	//		validarLlamadasCaidas();
	//	}

	//	@Test (priority = 6)
	//	public void validarLlamadasCaidasPrepago() throws InterruptedException, AWTException {
	//
	//		validarLlamadasCaidas();
	//	}


	/** 
	 * MÉTODOS
	 * */

	public void revisarDetalleConsumos() throws InterruptedException, AWTException {

		home.clickLinkConsultas();
		detalle.clickLinkDetalle();

		home.getBodyFrameContentPlaceHolder();
		assertTrue(cons.getBody().contains("Detalles de Consumo"));

		detalle.selectTipoConsumo("SMS"); Thread.sleep(3000);

		/////VALIDACION TABLA

		detalle.clickLinkBorrarFiltros();
		assertTrue(cons.getBody().contains("Tipo de consumos"));

		detalle.clickLinkDescargar();
		/////VALIDACION ARCHIVO DESCARGADO    "chrome://downloads/"
		home.keyPressUrlDescargas(); Thread.sleep(2000);
		// VALIDACIÓN DESCARGA
		help.cambiarVentana();
		home.keyPressCerrarPestaña();

		//		detalle.getHrefArchivoDescargado3();
		//
		//		System.out.println("111111" + detalle.getHrefArchivoDescargado());
		//		System.out.println("222222" + detalle.getHrefArchivoDescargado2());
		//
		//		assertTrue(help.buscarObjeto(detalle.getLinkArchivoConsumosCSV()));

		help.cambiarVentanaAnterior();
		home.getBodyFrameLegacyContainer();
		home.getBodyFrameContentPlaceHolder();
		detalle.clickLinkVolver();

		home.getBodyFrameLegacyContainer();
		assertTrue(cons.getBody().contains("Telefonía móvil"));

	}

	public void validarLlamadasCaidas() throws InterruptedException, AWTException {

		if (cons.getBody().contains("Telefonía móvil")) {
			home.clickLinkConsultas();
			detalle.clickLinkDetalle();
			home.getBodyFrameContentPlaceHolder();
		} else if (cons.getBody().contains("Detalles de Consumo")) {
			Thread.sleep(3000);
			detalle.clickLinkLlamadasCaidas(); 
			assertTrue(cons.getBody().contains("Consulta llamadas caídas"));

			// "Durante este mes no presentas llamadas caídas, puedes seleccionar otro mes para consultar."
			System.out.println(detalle.getAlertLlamadas()); 
		}
	}
}