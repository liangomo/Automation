package consultas.tests;

import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.itextpdf.text.DocumentException;

import consultas.paginas.ConsumoALaFecha_Object;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import general.HomePage;
import general.Login;
import login.objects.Login_Object;
import login.objects.Login_Sisga_Object;
import model.DispositivoPrueba;
import telefoniaMovil_Home.objects.Home_Object;
import utilities.Helper;

public class ConsumoALaFecha_Test {
	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties propiedades = new Properties();
	
	Helper help =  new Helper();
	Login_Object login = new Login_Object(help);
	Home_Object home = new Home_Object(help);
	ConsumoALaFecha_Object cons = new ConsumoALaFecha_Object(help);
	Login_Sisga_Object sisga = new Login_Sisga_Object(help);

	FileWriter fichero;
	String fecha = help.ObtenerFecha();
	String hora = help.ObtenerHora();

	String img = "";
	String veredicto = "";
	String nombrePDF = "";
	String navegador = "";
	String rutaArchivos = "C:\\Evidencia SL\\";

	String urlPruebasSisga = "http://sisga12:8031/#wbogsue";
	//	String urlPruebas = "http://midev.movistar.co/";
	//	String urlProduccion = "http://mi.movistar.co/";

	@BeforeSuite
	public void setup() throws IOException {
		propiedades = new Properties();
		InputStream entrada = new FileInputStream("Config.properties");
		propiedades.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(propiedades.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(propiedades.getProperty("Usuario"), propiedades.getProperty("Contrasenia"));
	}


	/** 
	 * CASOS DE PRUEBA
	 * */

	@Test (priority = 1)
	public void ingresarConsumoALaFechaPospago() throws InterruptedException, DocumentException {

		try {
			img = "Pospago";
			nombrePDF = hora + "_" + navegador + "_ConsumoALaFecha_Pospago";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);
			//			home.clicLnkProducto("Principal Pospago 89");

			sisga.setTxtNumCelular("3155826432");
			sisga.clickBtnInicioSesion(); Thread.sleep(4000);

			/* SI ES IE */
			//		help.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//		help.getDriver().switchTo().alert().accept();
			//		Thread.sleep(40000);


			help.getCapturaImagen("ingresarTelMovCF_" + img);
			ingresarConsumoALaFecha();
			assertTrue(cons.getBody().contains("Consumo de Voz"));
			assertTrue(cons.getBody().contains("Consumo de Mensajes de Texto"));
			help.getCapturaImagen("ingresarConsumosFecha_" + img);

			cons.clickLinkDetalleConsumo();
			validarLinksConsumoALaFecha();

			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}

	@Test (priority = 2)
	public void ingresarConsumoALaFechaCtaControl() throws InterruptedException, DocumentException {

		try {
			img = "CtaControl";
			nombrePDF = hora + "_" + navegador + "_ConsumoALaFecha_CtaControl";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);
			//			home.clicLnkProducto("Principal CtaCtrl 47");

			help.getChrome(urlPruebasSisga);
			sisga.setTxtDirectorio("SEL_WEBCONSUMOS_PORTAL");

			sisga.setTxtNumCelular("3175751967");
			sisga.clickBtnInicioSesion(); Thread.sleep(7000);

			/* SI ES IE */
			//			help.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			help.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);

			help.getCapturaImagen("ingresarTelMovCF_" + img);
			ingresarConsumoALaFecha();
			home.getBodyFrameContentPlaceHolder();
			assertTrue(cons.getBody().contains("Tu saldo disponible del plan"));
			assertTrue(cons.getBody().contains("Tus recargas"));
			assertTrue(cons.getBody().contains("Tu Saldo de Paquetes contratados"));
			help.getCapturaImagen("ingresarConsumosFecha_" + img);

			cons.clickLinkDetalleConsumo();
			home.getBodyFrameLegacyContainer();
			validarLinksConsumoALaFecha();

			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}

	@Test (priority = 3)
	public void ingresarConsumoALaFechaPrepago() throws InterruptedException, DocumentException {

		try {
			img = "Prepago";
			nombrePDF = hora + "_" + navegador + "_ConsumoALaFecha_Prepago";

			objAdminDocPdf = new AdminDocPdf(propiedades.getProperty("NombreArea"),
					propiedades.getProperty("NombreAplicacion"), "", DispositivoPrueba.WEB);
			//		home.clicLnkProducto("Principal Prepago 08");

			help.getChrome(urlPruebasSisga);
			sisga.setTxtDirectorio("SEL_WEBCONSUMOS_PORTAL");

			sisga.setTxtNumCelular("3175751967");
			sisga.clickBtnInicioSesion(); Thread.sleep(7000);

			/* SI ES IE */
			//			help.getDriver().switchTo().alert().accept();
			if(help.buscarObjeto(home.getLinkCertificado()))
				home.clickLinkCertificado();
			//			help.getDriver().switchTo().alert().accept();
			//			Thread.sleep(40000);

			help.getCapturaImagen("ingresarTelMovCF_" + img);
			ingresarConsumoALaFecha();
			home.getBodyFrameContentPlaceHolder();
			assertTrue(cons.getBody().contains("Tus recargas para usarlas en cualquier servicio"));
			help.getCapturaImagen("ingresarConsumosFecha_" + img);

			cons.clickLinkDetalleConsumo();
			home.getBodyFrameLegacyContainer();
			validarLinksConsumoALaFecha();

			veredicto = "EXITOSO";
		} catch (Exception e) {
			veredicto = "FALLIDO";
		} finally {
			help.setTextoPDF("VEREDICTO: " + veredicto);
			help.closePDF();
		}
	}


	/** 
	 * MÉTODOS
	 * */

	public void ingresarConsumoALaFecha() throws InterruptedException {

		home.clickLinkConsultas();
		//		cons.clickLinkConsumosPROD();
		cons.clickLinkConsumosPruebas();
	}

	public void validarLinksConsumoALaFecha() throws InterruptedException {

		home.getBodyFrameContentPlaceHolder();
		assertTrue(cons.getBody().contains("Detalles de Consumo"));
		help.getCapturaImagen("detalleConsumo" + img);

		cons.clickLinkVolverDetalle();
		home.getBodyFrameLegacyContainer();
		assertTrue(cons.getBody().contains("Telefonía móvil"));
		help.getCapturaImagen("volverDetalle" + img);
	}
}