package consultas.tests;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import consultas.paginas.DetalleConsumos;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import homePage.paginas.HomePage;
import login.paginas.Login;
import miMovistarHome.paginas.MiMovistarHome;
import model.DispositivoPrueba;
import model.Estados;

public class TestDetalleConsumos {

	AdminDocPdf objAdminDocPdf;
	Properties prop = new Properties();
	Estados veredicto;

	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	Login login = new Login(objConfigAux);
	MiMovistarHome miMov = new MiMovistarHome(objConfigAux);
	HomePage home = new HomePage(objConfigAux);
	DetalleConsumos detalle = new DetalleConsumos(objConfigAux);

	@BeforeSuite
	public void setup() throws IOException, InterruptedException {
		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);

		objConfigAux.getChrome(prop.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux);
		objLogin.execLogin(prop.getProperty("Usuario"), prop.getProperty("Contrasenia"));
	}

	/**
	 * CASOS DE PRUEBA
	 */

	@Test(priority = 1)
	public void revisarDetalleConsumosPospago()
			throws InterruptedException, AWTException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"DetalleConsumosPospago", DispositivoPrueba.WEB, "CONSULTAS: Detalle de consumos");

			home.getBodyFrameDefaultContent();
			home.clicLnkProducto("Pospago 8872");

			objAdminDocPdf.generaEvidencia("Ingreso Pospago 8872",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			detalle.execRevisarDetalleConsumos();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 2)
	public void validarLlamadasCaidasPospago()
			throws InterruptedException, AWTException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"LlamadasCaidasPospago", DispositivoPrueba.WEB, "CONSULTAS: Detalle de consumos");

			objAdminDocPdf.generaEvidencia("Opcion para validar llamadas caidas",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			detalle.execValidarLlamadasCaidas();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 3)
	public void revisarDetalleConsumosCtaControl()
			throws InterruptedException, AWTException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"DetalleConsumosCtaControl", DispositivoPrueba.WEB, "CONSULTAS: Detalle de consumos");

			home.getBodyFrameDefaultContent();
			home.clicLnkProducto("Principal CtaCtrl 47");

			objAdminDocPdf.generaEvidencia("Ingreso Principal CtaCtrl 47",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			detalle.execRevisarDetalleConsumos();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 4)
	public void validarLlamadasCaidasCtaControl()
			throws InterruptedException, AWTException, IOException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"LlamadasCaidasCtaControl", DispositivoPrueba.WEB, "CONSULTAS: Detalle de consumos");

			objAdminDocPdf.generaEvidencia("Opcion para validar llamadas caidas",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			detalle.execValidarLlamadasCaidas();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 5)
	public void revisarDetalleConsumosPrepago()
			throws InterruptedException, AWTException, MalformedURLException, DocumentException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"DetalleConsumosPrepago", DispositivoPrueba.WEB, "CONSULTAS: Detalle de consumos");

			home.getBodyFrameDefaultContent();
			home.clicLnkProducto("Principal Prepago 08");

			objAdminDocPdf.generaEvidencia("Ingreso Principal Prepago 08",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			detalle.execRevisarDetalleConsumos();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 6)
	public void validarLlamadasCaidasPrepago()
			throws InterruptedException, AWTException, IOException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"LlamadasCaidasPrepago", DispositivoPrueba.WEB, "CONSULTAS: Detalle de consumos");

			objAdminDocPdf.generaEvidencia("Opcion para validar llamadas caidas",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			detalle.execValidarLlamadasCaidas();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterTest
	public void finalizeTest() throws MalformedURLException, IOException, com.lowagie.text.DocumentException {
		// objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterSuite
	public void tearDown() {
		objConfigAux.getDriver().quit();
	}
}