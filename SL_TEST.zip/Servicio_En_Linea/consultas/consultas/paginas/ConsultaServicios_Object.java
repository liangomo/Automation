package consultas.paginas;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import utilities.Helper;

public class ConsultaServicios_Object {
	
	/** 
	 * LISTA ELEMENTOS
	 * */
	
	Helper help;
	By linkConsultaServicios = By.linkText("Consulta de servicios");
	By btnActivacionServicio = By.id("ctl00_ContentPlaceHolder1_btnActivarServicios_Click");
	By lblConsultaServicios = By.xpath("//*[@id=\"contenido\"]/div[2]/div[2]/table/tbody/tr[2]/td/table/tbody/tr[1]/td/div/div");
	By linkVolverCuenta = By.id("ctl00_ContentPlaceHolder1_volverMC");
	By lblTelefoniaMovil = By.xpath("//*[@id=\"top_contenido\"]/h1");
	By cmbTipoServicio = By.id("ctl00_ContentPlaceHolder1_cmbTipoServicio");
	By radioDetalleServicio = By.id("ctl00_ContentPlaceHolder1_lstDetalleServicio_0");
	By txtDescripcionServicio = By.name("ctl00$ContentPlaceHolder1$txtDescripcion");
	By btnSiguiente = By.id("ctl00_ContentPlaceHolder1_lnkSiguiente");
	By lblPregutaActivacion = By.xpath("//*[@id=\"Table7\"]/tbody/tr[3]/td/div[2]/strong");
	
	
	public ConsultaServicios_Object(Helper help) {
		this.help = help;
	}
	
	
	/** 
	 * EVENTOS (ACCIONES) EN LOS OBJETOS
	 * */
	
	public void clickLinkConsultaServicios() {
		this.help.getDriver().findElement(linkConsultaServicios).click();
	}

	public void clickBtnActivacionServicio() {
		this.help.getDriver().findElement(btnActivacionServicio).click();
	}
	
	public String getLblConsultaServicios() {
		return this.help.getDriver().findElement(lblConsultaServicios).getText();
	}
	
	public void clickLinkVolverCuenta() {
		this.help.getDriver().findElement(linkVolverCuenta).click();
	}
	
	public String getLblTelefoniaMovil() {
		return this.help.getDriver().findElement(lblTelefoniaMovil).getText();
	}
	
	public void setCmbTipoServicio(String tipoServicio)
	{
		Select dropdown = new Select(this.help.getDriver().findElement(cmbTipoServicio));
		dropdown.selectByVisibleText(tipoServicio);
	}
	
	public void clickRadioDetalleServicio() {
		this.help.getDriver().findElement(radioDetalleServicio).click();
	}
	
	public String getTxtDescripcionServicio() {
		return this.help.getDriver().findElement(txtDescripcionServicio).getText();
	}
	
	public void clickBtnSiguiente() {
		this.help.getDriver().findElement(btnSiguiente).click();
	}
	
	public String getLblPregutaActivacion() {
		return this.help.getDriver().findElement(lblPregutaActivacion).getText();
	}
}