package consultas.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class DetalleConsumos {

	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	ConsumoALaFecha cons;
	
	/** LISTA ELEMENTOS */
	By linkConsultas = By.id("idLiMenu1");
	By linkDetalle = By.linkText("Detalle de consumos");
	By selectTipoConsumos = By.id("cmbtipcons");
	By linkBorrarFiltros = By.linkText("Borrar filtros");
	By linkDescargar = By.linkText("Descargar");
	By linkArchivoConsumosCSV = By.linkText("Consumos.csv");
	By linkVolver = By.linkText("Volver");
	By linkLlamadas = By.linkText("Llamadas ca�das");
	By alertLlamadas = By.xpath("//*[@id=\"contiene_paginas\"]/div/article");

	By linkPrueba1 = By.xpath("//*[@id=\"url\"]");
	By linkPrueba2 = By.xpath("//*[@id=\"file-link\"]");
	By link = By.xpath("//*[@id=\"centeredContent\"]");

	/* Constructor */
	public DetalleConsumos(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}


	/** EVENTOS (ACCIONES) EN LOS OBJETOS */
	
	public void clickLinkConsultas() throws InterruptedException {
		this.objConfigAux.getDriver().switchTo().frame("LegacyContainer");
		this.objConfigAux.getDriver().findElement(linkConsultas).click();
	}

	public void clickLinkDetalle() {
		this.objConfigAux.getDriver().findElement(linkDetalle).click();
	}

	public void selectTipoConsumo(String tipoConsumo) {
		Select dropdown = new Select(this.objConfigAux.getDriver().findElement(selectTipoConsumos));
		dropdown.selectByVisibleText(tipoConsumo);
	}

	public String getTipoConsumo() {
		String selectedOption = new Select(this.objConfigAux.getDriver().findElement(selectTipoConsumos)).getFirstSelectedOption().getText();
		return selectedOption;
	}

	public void clickLinkBorrarFiltros() {
		this.objConfigAux.getDriver().findElement(linkBorrarFiltros).click();
	}

	public void clickLinkDescargar() {
		this.objConfigAux.getDriver().findElement(linkDescargar).click();
	}

	public By getLinkArchivoConsumosCSV() {
		return (linkArchivoConsumosCSV);
	}


	public void clickLinkVolver() {
		this.objConfigAux.getDriver().findElement(linkVolver).click();
	}

	public void clickLinkLlamadasCaidas() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), linkLlamadas);
		this.objConfigAux.getDriver().findElement(linkLlamadas).click();
	}

	public String getAlertLlamadas() {
		return this.objConfigAux.getDriver().findElement(alertLlamadas).getText();
	}


	public String getHrefArchivoDescargado() {
		return this.objConfigAux.getDriver().findElement(linkPrueba1).getAttribute("href");
	}

	public String getHrefArchivoDescargado2() {
		return this.objConfigAux.getDriver().findElement(linkPrueba2).getAttribute("href");
	}

	public void getHrefArchivoDescargado3() {
		this.objConfigAux.getDriver().findElement(link).sendKeys("AAAA");
	}


	/** METODOS */

	public void execRevisarDetalleConsumos() throws InterruptedException, AWTException, IOException {

		clickLinkConsultas();
		clickLinkDetalle();

		this.objConfigAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertTrue(cons.getBody().contains("Detalles de Consumo"));
		objAdminDocPdf.generaEvidencia("Ingreso al modulo", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		selectTipoConsumo("SMS");
		objAdminDocPdf.generaEvidencia("Resultado busqueda", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickLinkBorrarFiltros();
		assertTrue(cons.getBody().contains("Tipo de consumos"));
		objAdminDocPdf.generaEvidencia("Borrar filtros", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickLinkDescargar();
		///// VALIDACION ARCHIVO DESCARGADO "chrome://downloads/"
		keyPressUrlDescargas();
		Thread.sleep(2000);
		// VALIDACION DESCARGA
		objConfigAux.cambiarVentana();
		keyPressCerrarPestana();

		// detalle.getHrefArchivoDescargado3();
		//
		// System.out.println("111111" + detalle.getHrefArchivoDescargado());
		// System.out.println("222222" + detalle.getHrefArchivoDescargado2());
		//
		// assertTrue(objConfigAux.buscarObjeto(detalle.getLinkArchivoConsumosCSV()));

		objConfigAux.cambiarVentanaAnterior();
		this.objConfigAux.getDriver().switchTo().frame("LegacyContainer");
		this.objConfigAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		clickLinkVolver();

		this.objConfigAux.getDriver().switchTo().frame("LegacyContainer");
		assertTrue(cons.getBody().contains("Telefon�a m�vil"));
		objAdminDocPdf.generaEvidencia("Opcion link volver", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

	}

	public void execValidarLlamadasCaidas() throws InterruptedException, AWTException, IOException {

		if (cons.getBody().contains("Telefon�a m�vil")) {
			clickLinkConsultas();
			clickLinkDetalle();
			this.objConfigAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		} else if (cons.getBody().contains("Detalles de Consumo")) {
			clickLinkLlamadasCaidas();
			assertTrue(cons.getBody().contains("Consulta llamadas ca�das"));
			objAdminDocPdf.generaEvidencia("Ingreso llamadas caidas",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			// "Durante este mes no presentas llamadas ca�das, puedes
			// seleccionar otro mes para consultar."
			System.out.println(getAlertLlamadas());
		}
	}
	
	public void keyPressUrlDescargas() throws AWTException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_J);
		robot.keyPress(KeyEvent.VK_CONTROL);
	}
	
	public void keyPressCerrarPestana() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_W);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_W);
	}
}