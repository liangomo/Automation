package consultas.paginas;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class ConsultarContrato {

	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	AdminDocPdf objAdminDocPdf;
	
	/** LISTA ELEMENTOS */
	By linkConsultarContrato = By.linkText("Consultar Contrato");
	By lblContratoUnico = By.xpath("/html/body/div/div[1]/div/h1");

	By btnSolicitarContrato = By.linkText("Solicitar contrato");
	By txtIntroduceEmail = By.id("actualiza_mail");
	By btnEnviar = By.linkText("Enviar");
	By lblSolicitudEnviada = By.xpath("/html/body/div/div[2]/p");
	By btnVolver = By.linkText("Volver");

	By btnHistoricoCambios = By.linkText("Consultar hist�rico de cambios");
	By lblHistoricoCambios = By.xpath("//*[@id=\"contenedor_tabla_pospago\"]/p");

	By lblCondicionesServicio = By.xpath("/html/body/div/div[1]/div/h1");
	By linkDescarga = By.linkText("Descarga condiciones de servicio");

	/* Constructor */
	public ConsultarContrato(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}
	

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkConsultarContrato() {
		this.objConfigAux.getDriver().findElement(linkConsultarContrato).click();
	}

	public By getLblContratoUnico() {
		return (lblContratoUnico);
	}

	public void clickBtnSolicitarContrato() {
		this.objConfigAux.getDriver().findElement(btnSolicitarContrato).click();
	}

	public void sendTxtIntroduceEmail(String email) {
		this.objConfigAux.getDriver().findElement(txtIntroduceEmail).clear();
		this.objConfigAux.getDriver().findElement(txtIntroduceEmail).sendKeys(email);
	}

	public void clickBtnEnviar() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), btnEnviar);
		this.objConfigAux.getDriver().findElement(btnEnviar).click();
	}

	public String getLblSolicitudEnviada() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), lblSolicitudEnviada);
		return this.objConfigAux.getDriver().findElement(lblSolicitudEnviada).getText();
	}

	public void clickBtnVolver() {
		this.objConfigAux.getDriver().findElement(btnVolver).click();
	}

	public void clickBtnHistoricoCambios() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), btnHistoricoCambios);
		this.objConfigAux.getDriver().findElement(btnHistoricoCambios).click();
	}

	public String getLblHistoricoCambios() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), lblHistoricoCambios);
		return this.objConfigAux.getDriver().findElement(lblHistoricoCambios).getText();
	}

	public String getLblCondicionesServicio() {
		return this.objConfigAux.getDriver().findElement(lblCondicionesServicio).getText();
	}

	public void clickLinkDescarga() {
		this.objConfigAux.getDriver().findElement(linkDescarga).click();
	}

	
	/** METODOS */

	public void execIngresarSolicitudContrato() throws InterruptedException, AWTException, IOException {

		clickLinkConsultarContrato();

		this.objConfigAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		clickBtnSolicitarContrato();
		sendTxtIntroduceEmail("autom.pruebas@gmail.com");
		objAdminDocPdf.generaEvidencia("Ingreso al m�dulo e introducir email",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickBtnEnviar();
		assertTrue(getLblSolicitudEnviada().equals("Se ha enviado tu solicitud."));
		objAdminDocPdf.generaEvidencia("Envio Contrato", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickBtnVolver();
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getLblContratoUnico()));
		objAdminDocPdf.generaEvidencia("Volver Contrato", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	public void execConsultarHistoricoCambios() throws InterruptedException, IOException {

		clickBtnHistoricoCambios();
		assertTrue(getLblHistoricoCambios()
				.equals("El historico de cambios de tu l�nea a partir del " + "1 de junio de 2015 es:"));
		objAdminDocPdf.generaEvidencia("Consulta Historico", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickBtnVolver();
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getLblContratoUnico()));
		objAdminDocPdf.generaEvidencia("Volver Historico", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	public void execDescargarCondicionesServicio() throws IOException, InterruptedException {

		clickLinkConsultarContrato();
		this.objConfigAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertEquals(getLblCondicionesServicio(), "Condiciones generales del servicio en modalidad prepago");
		objAdminDocPdf.generaEvidencia("Ingreso Modulo", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickLinkDescarga();

		//// VALIDACION DESCARGAS
	}
}