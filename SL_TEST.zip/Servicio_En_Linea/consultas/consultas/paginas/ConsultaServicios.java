package consultas.paginas;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class ConsultaServicios {

	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	AdminDocPdf objAdminDocPdf;

	/** LISTA ELEMENTOS */
	By linkConsultaServicios = By.linkText("Consulta de servicios");
	By btnActivacionServicio = By.id("ctl00_ContentPlaceHolder1_btnActivarServicios_Click");
	By lblConsServ = By.xpath("//*[@id='contenido']/div[2]/div[2]/table/tbody/tr[2]/td/table/tbody/tr[1]/td/div/div");
	By linkVolverCuenta = By.id("ctl00_ContentPlaceHolder1_volverMC");
	By lblTelefoniaMovil = By.xpath("//*[@id=\"top_contenido\"]/h1");
	By cmbTipoServicio = By.id("ctl00_ContentPlaceHolder1_cmbTipoServicio");
	By radioDetalleServicio = By.id("ctl00_ContentPlaceHolder1_lstDetalleServicio_0");
	By txtDescripcionServicio = By.name("ctl00$ContentPlaceHolder1$txtDescripcion");
	By btnSiguiente = By.id("ctl00_ContentPlaceHolder1_lnkSiguiente");
	By lblPregutaActivacion = By.xpath("//*[@id=\"Table7\"]/tbody/tr[3]/td/div[2]/strong");

	/* Constructor */
	public ConsultaServicios(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}

	
	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkConsultaServicios() {
		this.objConfigAux.getDriver().findElement(linkConsultaServicios).click();
	}

	public void clickBtnActivacionServicio() {
		this.objConfigAux.getDriver().findElement(btnActivacionServicio).click();
	}

	public String getLblConsultaServicios() {
		return this.objConfigAux.getDriver().findElement(lblConsServ).getText();
	}

	public void clickLinkVolverCuenta() {
		this.objConfigAux.getDriver().findElement(linkVolverCuenta).click();
	}

	public String getLblTelefoniaMovil() {
		return this.objConfigAux.getDriver().findElement(lblTelefoniaMovil).getText();
	}

	public void setCmbTipoServicio(String tipoServicio) {
		Select dropdown = new Select(this.objConfigAux.getDriver().findElement(cmbTipoServicio));
		dropdown.selectByVisibleText(tipoServicio);
	}

	public void clickRadioDetalleServicio() {
		this.objConfigAux.getDriver().findElement(radioDetalleServicio).click();
	}

	public String getTxtDescripcionServicio() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), txtDescripcionServicio);
		return this.objConfigAux.getDriver().findElement(txtDescripcionServicio).getText();
	}

	public void clickBtnSiguiente() {
		this.objConfigAux.getDriver().findElement(btnSiguiente).click();
	}

	public String getLblPregutaActivacion() {
		return this.objConfigAux.getDriver().findElement(lblPregutaActivacion).getText();
	}

	
	/** METODOS */

	public void execValidarActivacionServicio() throws IOException, InterruptedException {

		clickLinkConsultaServicios();

		clickBtnActivacionServicio();
		assertEquals(getLblConsultaServicios(), "Consulta de Servicios");
		objAdminDocPdf.generaEvidencia("Opcion Activacion de Servicio",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickLinkVolverCuenta();
		assertEquals(getLblTelefoniaMovil(), "Telefon�a m�vil");
		objAdminDocPdf.generaEvidencia("Opcion volver a la cuenta",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	public void execSeleccionarDetalleServicio() throws InterruptedException, IOException {

		objConfigAux.cambiarVentanaAnterior();

		this.objConfigAux.getDriver().switchTo().frame("LegacyContainer");
		setCmbTipoServicio("Servicio de Datos");

		clickRadioDetalleServicio();
		assertNotNull(getTxtDescripcionServicio());
		objAdminDocPdf.generaEvidencia("Opcion para ver el detalle del servicio",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickBtnSiguiente();
		assertEquals(getLblPregutaActivacion(), "�Deseas activar este servicio inmediatamente?");
		objAdminDocPdf.generaEvidencia("Clic en boton siguiente",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}