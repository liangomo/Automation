package consultas.paginas;

import org.openqa.selenium.By;

import utilities.Helper;

public class ConsultarHistoricoIMEI_Object {

	/** 
	 * LISTA ELEMENTOS
	 * */
	
	Helper help;
	By linkConsultarHistorico = By.linkText("Consulta Historico IMEI");
	By imgImprimir = By.id("Imprimir");
	By btnImprimir = By.xpath("//*[@id=\"print-header\"]/div/button[1]");
	By btnCancelar = By.xpath("//*[@id=\"print-header\"]/div/button[2]");
	By imgDescargar = By.id("Descargar");
	By linkVolverCuenta = By.id("VolverCuenta");

	By linkSaberIMEI = By.xpath("//*[@id=\"boton_interogacion\"]");
	By cboxClose = By.id("cboxClose");
	
	By linkMovistarCo = By.id("Movistar");
	By imgMovistarCo = By.xpath("//*[@id=\"footer_2016\"]/div[1]/div/div[2]/div[1]/a/img");
	
	
	public ConsultarHistoricoIMEI_Object(Helper help) {
		this.help = help; 
	}
	
	
	/** 
	 * EVENTOS (ACCIONES) EN LOS OBJETOS
	 * */
	
	public void clickLinkConsultarHistorico() {
		this.help.getDriver().findElement(linkConsultarHistorico).click();
	}
	
	public void clickImgImprimir() {
		this.help.getDriver().findElement(imgImprimir).click();
	}
	
	public String getBtnImprimir() {
		return this.help.getDriver().findElement(btnImprimir).getText();
	}
	
	public void clickBtnCancelar() {
		this.help.getDriver().findElement(btnCancelar).click();
	}
	
	public void clickImgDescargar() {
		this.help.getDriver().findElement(imgDescargar).click();
	}
	
	public void clickLinkVolverCuenta() {
		this.help.getDriver().findElement(linkVolverCuenta).click();
	}
	
	public void clickLinkSaberIMEI() {
		this.help.getDriver().findElement(linkSaberIMEI).click();
	}
	
	public By getCboxClose() {
		return (cboxClose);
	}
	
	public void clickCboxClose() {
		this.help.getDriver().findElement(cboxClose).click();
	}
	
	public void clickLinkMovistarCo() {
		this.help.getDriver().findElement(linkMovistarCo).click();
	}
	
	public By getImgMovistarCo() {
		return (imgMovistarCo);
	}
}
