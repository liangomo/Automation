package consultas.paginas;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class ConsultarHistoricoIMEI {

	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	AdminDocPdf objAdminDocPdf;
	
	/** LISTA ELEMENTOS */
	By linkConsultarHistorico = By.linkText("Consulta Historico IMEI");
	By imgImprimir = By.id("Imprimir");
	By btnImprimir = By.xpath("//*[@id=\"print-header\"]/div/button[1]");
	By btnCancelar = By.xpath("//*[@id=\"print-header\"]/div/button[2]");
	By imgDescargar = By.id("Descargar");
	By linkVolverCuenta = By.id("VolverCuenta");

	By linkSaberIMEI = By.xpath("//*[@id=\"boton_interogacion\"]");
	By cboxClose = By.id("cboxClose");

	By linkMovistarCo = By.id("Movistar");
	By imgMovistarCo = By.xpath("//*[@id=\"footer_2016\"]/div[1]/div/div[2]/div[1]/a/img");
	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");

	/* Constructor */
	public ConsultarHistoricoIMEI(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}

	
	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkConsultarHistorico() {
		this.objConfigAux.getDriver().findElement(linkConsultarHistorico).click();
	}

	public void clickImgImprimir() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), imgImprimir);
		this.objConfigAux.getDriver().findElement(imgImprimir).click();
	}

	public String getBtnImprimir() {
		return this.objConfigAux.getDriver().findElement(btnImprimir).getText();
	}

	public void clickBtnCancelar() {
		this.objConfigAux.getDriver().findElement(btnCancelar).click();
	}

	public void clickImgDescargar() {
		this.objConfigAux.getDriver().findElement(imgDescargar).click();
	}

	public void clickLinkVolverCuenta() {
		this.objConfigAux.getDriver().findElement(linkVolverCuenta).click();
	}

	public void clickLinkSaberIMEI() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), linkSaberIMEI);
		this.objConfigAux.getDriver().findElement(linkSaberIMEI).click();
	}

	public By getCboxClose() {
		return (cboxClose);
	}

	public void clickCboxClose() {
		this.objConfigAux.getDriver().findElement(cboxClose).click();
	}

	public void clickLinkMovistarCo() {
		this.objConfigAux.getDriver().findElement(linkMovistarCo).click();
	}

	public By getImgMovistarCo() {
		return (imgMovistarCo);
	}

	public By getImgPhotoUser() {
		return (imgPhotoUser);
	}

	
	/** METODOS */

	public void execConsultarHistoricoIMEI() throws InterruptedException, AWTException, IOException {

		clickLinkConsultarHistorico();
		clickImgImprimir();
		objConfigAux.cambiarVentana();
		this.objConfigAux.getDriver().switchTo().defaultContent();
		assertEquals(getBtnImprimir(), "Imprimir");
		objAdminDocPdf.generaEvidencia("Opcion Imprimir", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickBtnCancelar();
		objAdminDocPdf.generaEvidencia("Opcion Cancelar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		// objConfigAux.cambiarVentanaAnterior();
		// home.getBodyFrameDefaultContent();
		// imei.clickImgDescargar();
		// home.keyPressUrlDescargas();
		// // VALIDACION DESCARGA
		// objConfigAux.cambiarVentana();
		// home.keyPressCerrarPestana();

		objConfigAux.cambiarVentanaAnterior();
		clickLinkVolverCuenta();
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getImgPhotoUser()));
		objAdminDocPdf.generaEvidencia("Opcion Volver Cuenta", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	public void execValidarLinks() throws InterruptedException, AWTException, IOException {

		clickLinkConsultarHistorico();
		clickLinkSaberIMEI();
		objConfigAux.cambiarVentanaAnterior();
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getCboxClose()));
		objAdminDocPdf.generaEvidencia("Link Saber IMEI", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		clickCboxClose();

		objConfigAux.cambiarVentanaAnterior();
		clickLinkMovistarCo();
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getImgMovistarCo()));
		objAdminDocPdf.generaEvidencia("Opcion movistarCO", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}