package consultas.paginas;


import org.openqa.selenium.By;

import utilities.Helper;

public class ConsultarContrato_Object {
	
	/** 
	 * LISTA ELEMENTOS
	 * */
	
	Helper help;
	By linkConsultarContrato = By.linkText("Consultar Contrato");
	By lblContratoUnico = By.xpath("/html/body/div/div[1]/div/h1");
	
	By btnSolicitarContrato = By.linkText("Solicitar contrato");
	By txtIntroduceEmail = By.id("actualiza_mail");
	By btnEnviar = By.linkText("Enviar");
	By lblSolicitudEnviada = By.xpath("/html/body/div/div[2]/p");
	By btnVolver = By.linkText("Volver");

	By btnHistoricoCambios = By.linkText("Consultar histórico de cambios");
	By lblHistoricoCambios = By.xpath("//*[@id=\"contenedor_tabla_pospago\"]/p");
	
	By lblCondicionesServicio = By.xpath("/html/body/div/div[1]/div/h1");
	By linkDescarga = By.linkText("Descarga condiciones de servicio");
	
	public ConsultarContrato_Object(Helper help) {
		this.help = help; 
	}
	
	
	/** 
	 * EVENTOS (ACCIONES) EN LOS OBJETOS
	 * */
	
	public void clickLinkConsultarContrato() {
		this.help.getDriver().findElement(linkConsultarContrato).click();
	}
	
	public By getLblContratoUnico() {
		return (lblContratoUnico);
	}
	
	public void clickBtnSolicitarContrato() {
		this.help.getDriver().findElement(btnSolicitarContrato).click();
	}
	
	public void sendTxtIntroduceEmail(String email) {
		this.help.getDriver().findElement(txtIntroduceEmail).clear();
		this.help.getDriver().findElement(txtIntroduceEmail).sendKeys(email);
	}
	
	public void clickBtnEnviar() {
		this.help.getDriver().findElement(btnEnviar).click();
	}
	
	public String getLblSolicitudEnviada() {
		return this.help.getDriver().findElement(lblSolicitudEnviada).getText();
	}
	
	public void clickBtnVolver() {
		this.help.getDriver().findElement(btnVolver).click();
	}
	
	
	public void clickBtnHistoricoCambios() {
		this.help.getDriver().findElement(btnHistoricoCambios).click();
	}
	
	public String getLblHistoricoCambios() {
			return this.help.getDriver().findElement(lblHistoricoCambios).getText();
	}
	
	public String getLblCondicionesServicio() {
		return this.help.getDriver().findElement(lblCondicionesServicio).getText();
	}
	
	public void clickLinkDescarga() {
		this.help.getDriver().findElement(linkDescarga).click();
	}
}