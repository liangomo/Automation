package consultas.paginas;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class ConsultaPagosRecargas {

	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	
	/** LISTA ELEMENTOS */
	By linkPagosRecargas = By.linkText("Consulta tus pagos y recargas");
	By tblPrimerNoPago = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_contenidoTabla\"]/div[2]/div[1]/h4");
	By txtNumPagoDetalle = By.id("ctl00_ContentPlaceHolder1_TxtPedido");
	By btnEnviar = By.id("ctl00_ContentPlaceHolder1_BtnEnvio");
	By lblPedido = By.id("ctl00_ContentPlaceHolder1_LblPedido");
	By lblResultadoTrx = By.id("ctl00_ContentPlaceHolder1_LblResultado");

	/* Constructor */
	public ConsultaPagosRecargas(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}

	
	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkPagosRecargas() {
		this.objConfigAux.getDriver().findElement(linkPagosRecargas).click();
	}

	public String getTblPrimerNoPago() {
		return this.objConfigAux.getDriver().findElement(tblPrimerNoPago).getText();
	}

	public void setTxtNumPagoDetalle(String numPagoDetalle) {
		this.objConfigAux.getDriver().findElement(txtNumPagoDetalle).sendKeys(numPagoDetalle);
	}

	public void clickBtnEnviar() {
		this.objConfigAux.getDriver().findElement(btnEnviar).click();
	}

	public String getLblPedido() {
		return this.objConfigAux.getDriver().findElement(lblPedido).getText();
	}

	public By byLblResultadoTrx() {
		return (lblResultadoTrx);
	}

	public String getLblResultadoTrx() {
		return this.objConfigAux.getDriver().findElement(lblResultadoTrx).getText();
	}

	
	/** METODOS */

	public void execConsultarPagosYRecargas() throws InterruptedException, IOException {

		clickLinkPagosRecargas();

		String primerNoPago = getTblPrimerNoPago();
		setTxtNumPagoDetalle(primerNoPago);
		objAdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickBtnEnviar();
		assertEquals(primerNoPago, getLblPedido());
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), byLblResultadoTrx()));
		objAdminDocPdf.generaEvidencia("Envio pago o recarga", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}