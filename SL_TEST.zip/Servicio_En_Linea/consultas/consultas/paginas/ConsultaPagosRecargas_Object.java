package consultas.paginas;

import org.openqa.selenium.By;

import utilities.Helper;

public class ConsultaPagosRecargas_Object {
	
	/** 
	 * LISTA ELEMENTOS
	 * */
	
	Helper help;
	By linkPagosRecargas = By.linkText("Consulta tus pagos y recargas");
	By tblPrimerNoPago = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_contenidoTabla\"]/div[2]/div[1]/h4");
	By txtNumPagoDetalle = By.id("ctl00_ContentPlaceHolder1_TxtPedido");
	By btnEnviar = By.id("ctl00_ContentPlaceHolder1_BtnEnvio");
	By lblPedido = By.id("ctl00_ContentPlaceHolder1_LblPedido");
	By lblResultadoTrx = By.id("ctl00_ContentPlaceHolder1_LblResultado");
	
	
	public ConsultaPagosRecargas_Object(Helper help) {
		this.help = help;
	}

	/** 
	 * EVENTOS (ACCIONES) EN LOS OBJETOS
	 * */

	public void clickLinkPagosRecargas() {
		this.help.getDriver().findElement(linkPagosRecargas).click();
	}
	
	public String getTblPrimerNoPago() {
		return this.help.getDriver().findElement(tblPrimerNoPago).getText();
	}
	
	public void setTxtNumPagoDetalle(String numPagoDetalle) {
		this.help.getDriver().findElement(txtNumPagoDetalle).sendKeys(numPagoDetalle);
	}
	
	public void clickBtnEnviar() {
		this.help.getDriver().findElement(btnEnviar).click();
	}
	
	public String getLblPedido() {
		return this.help.getDriver().findElement(lblPedido).getText();
	}
	
	public By byLblResultadoTrx() {
		return (lblResultadoTrx);
	}
	
	public String getLblResultadoTrx() {
		return this.help.getDriver().findElement(lblResultadoTrx).getText();
	}

}