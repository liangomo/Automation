package consultas.paginas;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;

import org.openqa.selenium.By;

import telefoniaMovil_Home.objects.Home_Object;
import utilities.Helper;

public class ComoLeerFactura_Object {
	
	/** 
	 * LISTA ELEMENTOS
	 * */

	Helper help;
	Home_Object home = new Home_Object(help);
	By linkComoLeerFactura = By.linkText("Cómo leer mi factura");
	By lblConoceTuFactura = By.xpath("//*[@id=\"conoceFactura\"]/div/div[1]/h2");
	
	
	public ComoLeerFactura_Object(Helper help) {
		this.help = help; 
	}
	
	
	/** 
	 * EVENTOS (ACCIONES) EN LOS OBJETOS
	 * */
	
	public void clickLinkComoLeerFactura() {
		this.help.getDriver().findElement(linkComoLeerFactura).click();
	}
	
	public String getLblConoceTuFactura() {
		return this.help.getDriver().findElement(lblConoceTuFactura).getText();
	}
	
	
	/** 
	 * MÉTODOS
	 * */
	
	public void ingresarLeerFactura() throws InterruptedException, AWTException {

		Thread.sleep(2000);
		home.clickLinkConsultas(); Thread.sleep(2000);
		clickLinkComoLeerFactura(); Thread.sleep(3000);
		
		help.cambiarVentana();
		assertEquals(getLblConoceTuFactura(), "Conoce tu factura"); Thread.sleep(5000);
//		home.keyPressCerrarPestaña();
		
		home.keyPressCerrarVentana();
		help.cambiarVentanaAnterior(); Thread.sleep(2000);
	}
}