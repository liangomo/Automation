package consultas.paginas;

import org.openqa.selenium.By;
import utilities.Helper;

public class ConsumoALaFecha_Object {
	
	/** 
	 * LISTA ELEMENTOS
	 * */
	
	Helper help;
	By linkConsumosPROD = By.linkText("Consumos a la fecha");
	By linkConsumosPruebas = By.linkText("Resumen de Consumos");
	By body = By.tagName("body");
	By lblSaldoDisponible = By.xpath("//*[@id=\"contenedorTbl\"]/div[1]");
	By linkDetalleConsumo = By.linkText("aquí");
	By lblDetalleConsumo = By.xpath("//*[@id=\"top_contenido\"]/h1");
	By linkVolverDetalle = By.linkText("Volver");

	public ConsumoALaFecha_Object(Helper help) {
		this.help = help;
	}

	
	/** 
	 * EVENTOS (ACCIONES) EN LOS OBJETOS
	 * */
	
	public void clickLinkConsumosPROD() {
		this.help.getDriver().findElement(linkConsumosPROD).click();
	}
	
	public void clickLinkConsumosPruebas() {
		this.help.getDriver().findElement(linkConsumosPruebas).click();
	}
	
	public String getBody() {
		return this.help.getDriver().findElement(body).getText();
	}
	
	public String getLblSaldoDisponible() {
		return this.help.getDriver().findElement(lblSaldoDisponible).getText();
	}
	
	public void clickLinkDetalleConsumo() {
		this.help.getDriver().findElement(linkDetalleConsumo).click();
	}	
	
	public String getLblDetalleConsumo() {
		return this.help.getDriver().findElement(lblDetalleConsumo).getText();
	}
	
	public void clickLinkVolverDetalle() throws InterruptedException {
		this.help.getDriver().findElement(linkVolverDetalle).click();
	}

}