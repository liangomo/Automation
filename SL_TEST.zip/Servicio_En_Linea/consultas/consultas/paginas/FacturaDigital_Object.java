package consultas.paginas;

import org.openqa.selenium.By;

import utilities.Helper;

public class FacturaDigital_Object {

	/** 
	 * LISTA ELEMENTOS
	 * */

	Helper help;
	By linkFacturaPROD = By.linkText("Factura Digital");
	By linkFacturaPruebas = By.linkText("Factura y Contrato Digital");
	By body = By.tagName("body");
	By barTitulo = By.id("barTitulo");
	By imgCerrar = By.id("btnXCerrar");
	By imgFacturaDigital = By.xpath("/html/body/center/table[2]/tbody/tr[2]/td/img");

	By imgNovedades = By.xpath("//*[@id=\"imgMenu1\"]");
	By imgImprimir = By.xpath("//*[@id=\"imgMenu2\"]");
	By imgExportarFactura = By.xpath("//*[@id=\"imgMenu3\"]");
	By imgInfoGrafica = By.xpath("//*[@id=\"imgMenu4\"]");
	By spanDetalleInfoGrafica = By.xpath("//*[@id=\"nomBr\"]");
	By imgAdminCorreos = By.xpath("//*[@id=\"imgMenu5\"]");

	By spanNombreCliente = By.xpath("/html/body/div[2]/span");

	By imgPrimeraPag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[2]/img");
	By imgAnteriorPag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[4]/img");
	By imgSiguientePag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[6]/img");
	By imgUltimaPag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[8]/img");

	By spanNitCedula = By.xpath("/html/body/div[18]/span");
	By spanTelefono = By.xpath("/html/body/div[20]/span");
	By spanClienteNo = By.xpath("/html/body/div[22]/span");
	By spanFacturaVenta = By.xpath("/html/body/div[24]/span");
	By spanFechaExpedicion = By.xpath("/html/body/div[26]/span");
	By spanFacturaMes = By.xpath("/html/body/div[28]/span");
	By spanFechaProximaFactura = By.xpath("/html/body/div[36]/span");
	By spanNumeroParaPagos = By.xpath("/html/body/div[39]/span");
	By spanFechaLimitePago = By.xpath("/html/body/div[41]/span");
	By spanTotalPagar = By.xpath("/html/body/div[43]/span");

	By spanCargosFacturados = By.xpath("/html/body/div[3]/span");
	By spanValorImpuestos = By.xpath("/html/body/div[4]/span");


	public FacturaDigital_Object(Helper help) {
		this.help = help;
	}


	/** 
	 * EVENTOS (ACCIONES) EN LOS OBJETOS
	 * */

	public void clickLinkFacturaPROD() {
		this.help.getDriver().findElement(linkFacturaPROD).click();
	}

	public void clickLinkFacturaPruebas() {
		this.help.getDriver().findElement(linkFacturaPruebas).click();
	}

	public String getBody() {
		return this.help.getDriver().findElement(body).getText();
	}

	public void getBodyFramePresenta() {
		this.help.getDriver().switchTo().frame("presenta");
	}

	public void getBodyAlertAccept() {
		this.help.getDriver().switchTo().alert().accept();
	}


	public void getBodyFrameFactura() {
		this.help.getDriver().switchTo().frame("factura");
	}

	public By getBarTitulo() {
		return (barTitulo);
	}

	public void clickImgCerrar() {
		this.help.getDriver().findElement(imgCerrar).click();
	}

	public By getImgFacturaDigital () {
		return (imgFacturaDigital);
	}

	public void clickImgNovedades() {
		this.help.getDriver().findElement(imgNovedades).click();
	}

	public void clickImgImprimir() {
		this.help.getDriver().findElement(imgImprimir).click();
	}

	public void clickImgExportarFact() {
		this.help.getDriver().findElement(imgExportarFactura).click();
	}

	public void clickImgInfoGrafica() {
		this.help.getDriver().findElement(imgInfoGrafica).click();
	}

	public By getSpanDetalleInfoGrafica() {
		return (spanDetalleInfoGrafica);
	}

	public void clickImgAdminCorreos() {
		this.help.getDriver().findElement(imgAdminCorreos).click();
	}


	public By getSpanNombreCliente() {
		return (spanNombreCliente);
	}

	public void clickImgPrimeraPag() {
		this.help.getDriver().findElement(imgPrimeraPag).click();
	}

	public void clickImgAnteriorPag() {
		this.help.getDriver().findElement(imgAnteriorPag).click();
	}

	public void clickImgSiguientePag() {
		this.help.getDriver().findElement(imgSiguientePag).click();
	}

	public void clickImgUltimaPag() {
		this.help.getDriver().findElement(imgUltimaPag).click();
	}


	public String getSpanNitCedula() {
		return this.help.getDriver().findElement(spanNitCedula).getText();
	}

	public String getSpanTelefono() {
		return this.help.getDriver().findElement(spanTelefono).getText();
	}

	public String getSpanClienteNo() {
		return this.help.getDriver().findElement(spanClienteNo).getText();
	}

	public String getSpanFacturaVenta() {
		return this.help.getDriver().findElement(spanFacturaVenta).getText();
	}

	public String getSpanFechaExpedicion() {
		return this.help.getDriver().findElement(spanFechaExpedicion).getText();
	}

	public String getSpanFacturaMes() {
		return this.help.getDriver().findElement(spanFacturaMes).getText();
	}

	public String getSpanFechaProximaFactura() {
		return this.help.getDriver().findElement(spanFechaProximaFactura).getText();
	}

	public String getSpanNumeroParaPagos() {
		return this.help.getDriver().findElement(spanNumeroParaPagos).getText();
	}

	public String getSpanFechaLimitePago() {
		return this.help.getDriver().findElement(spanFechaLimitePago).getText();
	}

	public String getSpanTotalPagar() {
		return this.help.getDriver().findElement(spanTotalPagar).getText();
	}


	public String getSpanCargosFacturados() {
		return this.help.getDriver().findElement(spanCargosFacturados).getText();
	}

	public String getSpanValorImpuestos() {
		return this.help.getDriver().findElement(spanValorImpuestos).getText();
	}
}