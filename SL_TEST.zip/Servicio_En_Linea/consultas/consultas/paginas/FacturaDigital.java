package consultas.paginas;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class FacturaDigital {

	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	
	/** LISTA ELEMENTOS */
	By linkFacturaPROD = By.linkText("Factura Digital");
	By linkFacturaPruebas = By.linkText("Factura y Contrato Digital");
	By body = By.tagName("body");
	By barTitulo = By.id("barTitulo");
	By imgCerrar = By.id("btnXCerrar");
	By imgFacturaDigital = By.xpath("/html/body/center/table[2]/tbody/tr[2]/td/img");

	By imgNovedades = By.xpath("//*[@id=\"imgMenu1\"]");
	By imgImprimir = By.xpath("//*[@id=\"imgMenu2\"]");
	By imgExportarFactura = By.xpath("//*[@id=\"imgMenu3\"]");
	By imgInfoGrafica = By.xpath("//*[@id=\"imgMenu4\"]");
	By spanDetalleInfoGrafica = By.xpath("//*[@id=\"nomBr\"]");
	By imgAdminCorreos = By.xpath("//*[@id=\"imgMenu5\"]");

	By spanNombreCliente = By.xpath("/html/body/div[2]/span");

	By imgPrimeraPag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[2]/img");
	By imgAnteriorPag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[4]/img");
	By imgSiguientePag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[6]/img");
	By imgUltimaPag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[8]/img");

	By spanNitCedula = By.xpath("/html/body/div[18]/span");
	By spanTelefono = By.xpath("/html/body/div[20]/span");
	By spanClienteNo = By.xpath("/html/body/div[22]/span");
	By spanFacturaVenta = By.xpath("/html/body/div[24]/span");
	By spanFechaExpedicion = By.xpath("/html/body/div[26]/span");
	By spanFacturaMes = By.xpath("/html/body/div[28]/span");
	By spanFechaProximaFactura = By.xpath("/html/body/div[36]/span");
	By spanNumeroParaPagos = By.xpath("/html/body/div[39]/span");
	By spanFechaLimitePago = By.xpath("/html/body/div[41]/span");
	By spanTotalPagar = By.xpath("/html/body/div[43]/span");

	By spanCargosFacturados = By.xpath("/html/body/div[3]/span");
	By spanValorImpuestos = By.xpath("/html/body/div[4]/span");

	/* Constructor */
	public FacturaDigital(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}
	

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkFacturaPROD() {
		this.objConfigAux.getDriver().findElement(linkFacturaPROD).click();
	}

	public void clickLinkFacturaPruebas() {
		this.objConfigAux.getDriver().findElement(linkFacturaPruebas).click();
	}

	public String getBody() {
		return this.objConfigAux.getDriver().findElement(body).getText();
	}

	public void getBodyFramePresenta() {
		this.objConfigAux.getDriver().switchTo().frame("presenta");
	}

	public void getBodyAlertAccept() {
		this.objConfigAux.getDriver().switchTo().alert().accept();
	}


	public void getBodyFrameFactura() {
		this.objConfigAux.getDriver().switchTo().frame("factura");
	}

	public By getBarTitulo() {
		return (barTitulo);
	}

	public void clickImgCerrar() {
		this.objConfigAux.getDriver().findElement(imgCerrar).click();
	}

	public By getImgFacturaDigital () {
		return (imgFacturaDigital);
	}

	public void clickImgNovedades() {
		this.objConfigAux.getDriver().findElement(imgNovedades).click();
	}

	public void clickImgImprimir() {
		this.objConfigAux.getDriver().findElement(imgImprimir).click();
	}

	public void clickImgExportarFact() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), imgExportarFactura);
		this.objConfigAux.getDriver().findElement(imgExportarFactura).click();
	}

	public void clickImgInfoGrafica() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), imgInfoGrafica);
		this.objConfigAux.getDriver().findElement(imgInfoGrafica).click();
	}

	public By getSpanDetalleInfoGrafica() {
		return (spanDetalleInfoGrafica);
	}

	public void clickImgAdminCorreos() {
		this.objConfigAux.getDriver().findElement(imgAdminCorreos).click();
	}


	public By getSpanNombreCliente() {
		return (spanNombreCliente);
	}

	public void clickImgPrimeraPag() {
		this.objConfigAux.getDriver().findElement(imgPrimeraPag).click();
	}

	public void clickImgAnteriorPag() {
		this.objConfigAux.getDriver().findElement(imgAnteriorPag).click();
	}

	public void clickImgSiguientePag() {
		this.objConfigAux.getDriver().findElement(imgSiguientePag).click();
	}

	public void clickImgUltimaPag() {
		this.objConfigAux.getDriver().findElement(imgUltimaPag).click();
	}


	public String getSpanNitCedula() {
		return this.objConfigAux.getDriver().findElement(spanNitCedula).getText();
	}

	public String getSpanTelefono() {
		return this.objConfigAux.getDriver().findElement(spanTelefono).getText();
	}

	public String getSpanClienteNo() {
		return this.objConfigAux.getDriver().findElement(spanClienteNo).getText();
	}

	public String getSpanFacturaVenta() {
		return this.objConfigAux.getDriver().findElement(spanFacturaVenta).getText();
	}

	public String getSpanFechaExpedicion() {
		return this.objConfigAux.getDriver().findElement(spanFechaExpedicion).getText();
	}

	public String getSpanFacturaMes() {
		return this.objConfigAux.getDriver().findElement(spanFacturaMes).getText();
	}

	public String getSpanFechaProximaFactura() {
		return this.objConfigAux.getDriver().findElement(spanFechaProximaFactura).getText();
	}

	public String getSpanNumeroParaPagos() {
		return this.objConfigAux.getDriver().findElement(spanNumeroParaPagos).getText();
	}

	public String getSpanFechaLimitePago() {
		return this.objConfigAux.getDriver().findElement(spanFechaLimitePago).getText();
	}

	public String getSpanTotalPagar() {
		return this.objConfigAux.getDriver().findElement(spanTotalPagar).getText();
	}


	public String getSpanCargosFacturados() {
		return this.objConfigAux.getDriver().findElement(spanCargosFacturados).getText();
	}

	public String getSpanValorImpuestos() {
		return this.objConfigAux.getDriver().findElement(spanValorImpuestos).getText();
	}
	
	
	/** METODOS */

	public void execIngresoFactura() throws InterruptedException, IOException {

		clickLinkFacturaPROD();

		objConfigAux.cambiarVentana();
		getBodyFramePresenta();
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getBarTitulo()));
		objAdminDocPdf.generaEvidencia("Ingreso Pospago 8872", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		clickImgCerrar();
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getImgFacturaDigital()));
	}

	public void execVerificarSubmodulo() throws InterruptedException, IOException {

		if (objConfigAux.EsperaElemento(objConfigAux.getDriver(), getImgFacturaDigital())) {

			clickImgNovedades();
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getBarTitulo()));
			objAdminDocPdf.generaEvidencia("Verifica Novedades", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgImprimir();
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getBarTitulo()));
			objAdminDocPdf.generaEvidencia("Verifica Imprimir", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgExportarFact();
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getBarTitulo()));
			objAdminDocPdf.generaEvidencia("Exportar Factura", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgInfoGrafica();
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getSpanDetalleInfoGrafica()));
			objAdminDocPdf.generaEvidencia("Informacino grafica", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			clickImgAdminCorreos();
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(), getBarTitulo()));
			objAdminDocPdf.generaEvidencia("Administrar Correos", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			clickImgCerrar();
		}
	}

	
	public void execVerificarPaginacion() throws InterruptedException, IOException {

		if (objConfigAux.EsperaElemento(objConfigAux.getDriver(), getImgFacturaDigital())) {

			getBodyFrameFactura();
			assertTrue(getBody().contains("Senor(a):"));
			objAdminDocPdf.generaEvidencia("Verifica Ingreso Factura",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			objConfigAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgSiguientePag();
			getBodyFrameFactura();
			assertTrue(getBody().contains("Nit � C�dula"));
			objAdminDocPdf.generaEvidencia("Verificar Siguiente Pagina",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			objConfigAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgAnteriorPag();
			getBodyFrameFactura();
			assertTrue(getBody().contains("Senor(a)")); 
			objAdminDocPdf.generaEvidencia("Verificar Anterior Pagina",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			objConfigAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgUltimaPag(); 
			clickImgUltimaPag();
			objAdminDocPdf.generaEvidencia("Verificar Ultima Pagina",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			getBodyAlertAccept();

			objConfigAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgPrimeraPag();
			getBodyFrameFactura();
			assertTrue(getBody().contains("Senor(a):")); 
			objAdminDocPdf.generaEvidencia("Verificar Primera Pagina",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			objConfigAux.cambiarVentana();
			getBodyFramePresenta();
		}
	}

	public void execVerificarPaginacionCta() throws InterruptedException, IOException {

		if (objConfigAux.EsperaElemento(objConfigAux.getDriver(), getImgFacturaDigital())) {

			getBodyFrameFactura();
			assertTrue(getBody().contains("Senor(a):")); 
			objAdminDocPdf.generaEvidencia("Verificar Ingreso Factura",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			objConfigAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgSiguientePag();
			getBodyFrameFactura();
			assertTrue(getBody().contains("Nit � Cédula")); //
			objAdminDocPdf.generaEvidencia("Verificar Siguiente Pagina",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			objConfigAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgAnteriorPag();
			getBodyFrameFactura();
			assertTrue(getBody().contains("Senor(a):")); //
			objAdminDocPdf.generaEvidencia("Verificar Pagina Anterior",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			objConfigAux.cambiarVentana();
			getBodyFramePresenta();
		}
	}

	public void execValidarInformacion() throws InterruptedException, IOException {

		if (objConfigAux.EsperaElemento(objConfigAux.getDriver(), getImgFacturaDigital())) {
			clickImgSiguientePag();
			getBodyFrameFactura();
		}
		objAdminDocPdf.generaEvidencia("Validar Informacion",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}	
}