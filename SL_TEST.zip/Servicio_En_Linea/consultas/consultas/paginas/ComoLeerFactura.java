package consultas.paginas;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class ComoLeerFactura {
	
	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	AdminDocPdf objAdminDocPdf;
	
	/** LISTA ELEMENTOS */
	By linkComoLeerFactura = By.linkText("C�mo leer mi factura");
	By lblConoceTuFactura = By.xpath("//*[@id=\"conoceFactura\"]/div/div[1]/h2");
	
	/* Constructor */
	public ComoLeerFactura(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}
	

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */
	
	public void clickLinkComoLeerFactura() {
		this.objConfigAux.getDriver().findElement(linkComoLeerFactura).click();
	}
	
	public String getLblConoceTuFactura() {
		return this.objConfigAux.getDriver().findElement(lblConoceTuFactura).getText();
	}
	
	
	/** METODOS */

	public void execIngresarLeerFactura() throws InterruptedException, AWTException, IOException {

		clickLinkComoLeerFactura();

		objConfigAux.cambiarVentana();
		assertEquals(getLblConoceTuFactura(), "Conoce tu factura");
		objAdminDocPdf.generaEvidencia("Ingreso al m�dulo", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		keyPressCerrarPestana();

		keyPressCerrarVentana();
		objConfigAux.cambiarVentanaAnterior();
	}
	
	public void keyPressCerrarPestana() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_W);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_W);
	}
	
	public void keyPressCerrarVentana() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_F4);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_ALT);
		robot.keyRelease(KeyEvent.VK_F4);
	}
}