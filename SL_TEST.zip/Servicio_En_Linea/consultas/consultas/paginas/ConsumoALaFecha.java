package consultas.paginas;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class ConsumoALaFecha {
	
	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	AdminDocPdf objAdminDocPdf;
	
	/** LISTA ELEMENTOS */
	By linkConsumosPROD = By.linkText("Consumos a la fecha");
	By linkConsumosPruebas = By.linkText("Resumen de Consumos");
	By body = By.tagName("body");
	By lblSaldoDisponible = By.xpath("//*[@id=\"contenedorTbl\"]/div[1]");
	By linkDetalleConsumo = By.linkText("aqu�");
	By lblDetalleConsumo = By.xpath("//*[@id=\"top_contenido\"]/h1");
	By linkVolverDetalle = By.linkText("Volver");

	/* Constructor */
	public ConsumoALaFecha(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}
	
	
	/** EVENTOS (ACCIONES) EN LOS OBJETOS */
	
	public void clickLinkConsumosPROD() {
		this.objConfigAux.getDriver().findElement(linkConsumosPROD).click();
	}
	
	public void clickLinkConsumosPruebas() {
		this.objConfigAux.getDriver().findElement(linkConsumosPruebas).click();
	}
	
	public String getBody() {
		return this.objConfigAux.getDriver().findElement(body).getText();
	}
	
	public String getLblSaldoDisponible() {
		return this.objConfigAux.getDriver().findElement(lblSaldoDisponible).getText();
	}
	
	public void clickLinkDetalleConsumo() {
		this.objConfigAux.getDriver().findElement(linkDetalleConsumo).click();
	}	
	
	public String getLblDetalleConsumo() {
		return this.objConfigAux.getDriver().findElement(lblDetalleConsumo).getText();
	}
	
	public void clickLinkVolverDetalle() throws InterruptedException {
		this.objConfigAux.getDriver().findElement(linkVolverDetalle).click();
	}
	
	
	/** METODOS */

	public void execValidarLinkVolverConsumoALaFecha(String tipoProd) throws InterruptedException, IOException {

		clickLinkDetalleConsumo();
		
		if (!tipoProd.equals("Pospago"))
		this.objConfigAux.getDriver().switchTo().frame("LegacyContainer");
		
		this.objConfigAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertTrue(getBody().contains("Detalles de Consumo"));
		objAdminDocPdf.generaEvidencia("Validacion detalle de consumo",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		
		clickLinkVolverDetalle();
		this.objConfigAux.getDriver().switchTo().frame("LegacyContainer");
		assertTrue(getBody().contains("Telefon�a m�vil"));
		objAdminDocPdf.generaEvidencia("Validacion link volver detalle",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}