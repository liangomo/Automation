package general;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import control.elementos.ObjetosConfigAux;

public class HomePage {

	WebDriver driver;
	ObjetosConfigAux objConfigAux;

	By btnHomePage = By.xpath("//*[@id='li-home']");
	By lnkProducto = By.xpath("//*[@class='mCSB_container']/div/ul/a");
	By contenedor = By.xpath("//*[@id='mCSB_1_container']");
	float px = 0;

	/* Constructor */
	public HomePage(ObjetosConfigAux objConfigAux) {
		this.driver = objConfigAux.getDriver();
		this.objConfigAux = objConfigAux;
	}

	// Eventos
	public void clicLnkProducto(String pLnkProducto) {
		List<WebElement> listaProducto = driver.findElements(lnkProducto);
		try {
			boolean reintentar = true;
			for (int i = 0; i <= listaProducto.size(); i++) {
				reintentar = true;
				while (reintentar) {
					if (listaProducto.get(i).isDisplayed()) {
						reintentar = false;

						if (listaProducto.get(i).getText().toString().equals(pLnkProducto)) {
							listaProducto.get(i).click();
							i=listaProducto.size() +1;
							
						}
					} else {
						downLstLineas();
					}
				}
			}
		} catch (Exception e) {
		}
	}

	public void clickBtnHomePage() {
		String handle = driver.getWindowHandle();
		driver.switchTo().window(handle);
		driver.findElement(btnHomePage).click();
	}

	// Metodos
	private void downLstLineas() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(contenedor);
		px = px - 45;
		js.executeScript("arguments[0].setAttribute('style', 'position: relative; top: " + px + "px; left: 0px;')",
		element);
	}

}
