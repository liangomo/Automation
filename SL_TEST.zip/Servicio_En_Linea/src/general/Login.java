package general;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login {

	WebDriver driver;


	By txtUsuario = By.xpath("//*[@id='formValidar']");
	By txtContrase�a = By.id("Password");
	By btnAceptar = By.id("area_boton");

	public Login (WebDriver driver){
		this.driver = driver;
	}

	public void txtUsuario(String vCodUsuario) {
		driver.findElement(txtUsuario).clear();
		driver.findElement(txtUsuario).sendKeys(vCodUsuario);
	}

	public void txtContrase�a(String vCodContrase�a) {
		driver.findElement(txtContrase�a).clear();
		driver.findElement(txtContrase�a).sendKeys(vCodContrase�a);
	}
	public void clicbtnAceptar() {
		driver.findElement(btnAceptar).click();

	}

	public void execLogin(String vCodUsuario, String vCodContrase�a) {

		this.txtUsuario(vCodUsuario);
		this.txtContrase�a(vCodContrase�a);
		this.clicbtnAceptar();
	}
}
