package general;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import transacciones.tests.TestActualizacionDeDatos;

@RunWith(Suite.class)
@SuiteClasses({ TestActualizacionDeDatos.class })

public class MainTestSL {

  public static void main(String[] args) {
   
  }
}
