package transacciones.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import control.elementos.ObjetosConfigAux;
import general.HomePage;
import general.Login;
import model.DispositivoPrueba;
import model.Estados;
import transacciones.paginas.PagoDeSaldo;
import evidencia.doc.pdf.AdminDocPdf;

public class TestPagoDeSaldo {

	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties prop = new Properties();
	Estados veredicto;

	@BeforeSuite
	public void setup() throws IOException, InterruptedException {
		prop = new Properties();
		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(prop.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(prop.getProperty("Usuario"), prop.getProperty("Contrasenia"));
	}

	@Test
	public void pagoSaldo() throws InterruptedException, IOException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"PagoDeSaldo_", DispositivoPrueba.WEB, "TRANSACCIONES - Pago de Saldo");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("3166210523 posp");
			objAdminDocPdf.generaEvidencia("Pagina Principal", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			PagoDeSaldo objPagoDeSaldo = new PagoDeSaldo(objConfigAux);
			Map<String, String> mParametros = new HashMap<String, String>();
			mParametros.put("ValorAPagar", "2000");
			mParametros.put("EntidadFinanciera", "BANCO AGRARIO");
			objPagoDeSaldo.execPagoSaldo(mParametros);
			objAdminDocPdf.generaEvidencia("Seleccion valor para recargar ",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objPagoDeSaldo.clicBtnHacerPago();
			objPagoDeSaldo.clicBtnPagar();
			objAdminDocPdf.generaEvidencia("Fin prueba", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void pago_Saldo() throws IOException, InterruptedException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"PagoDeSaldo_", DispositivoPrueba.WEB, "TRANSACCIONES - Pago de Saldo");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("3178642577 posp");

			objAdminDocPdf.generaEvidencia("Pagina Principal", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			PagoDeSaldo objPagoDeSaldoCtaCtrl = new PagoDeSaldo(objConfigAux);
			Map<String, String> mParametros2 = new HashMap<String, String>();

			objPagoDeSaldoCtaCtrl.ClicAqui();
			mParametros2.put("ValorAPagar", "2000");
			mParametros2.put("EntidadFinanciera", "BANCO AGRARIO");
			objPagoDeSaldoCtaCtrl.execPagosaldo(mParametros2);
			objAdminDocPdf.generaEvidencia("Seleccion valor para recargar ",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objPagoDeSaldoCtaCtrl.clicBtnHacerPago();
			objPagoDeSaldoCtaCtrl.clicBtnPagar();
			objAdminDocPdf.generaEvidencia("Fin prueba", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterTest
	public void finalizeTest() throws MalformedURLException, DocumentException, IOException {
		// objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterSuite
	public void tearDown() {
		objConfigAux.getDriver().quit();
	}
}
