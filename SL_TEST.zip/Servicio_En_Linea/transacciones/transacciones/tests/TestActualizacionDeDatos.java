package transacciones.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import general.HomePage;
import general.Login;
import model.DispositivoPrueba;
import model.Estados;
import transacciones.paginas.ActualizacionDeDatos;

public class TestActualizacionDeDatos {
	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties prop = new Properties();
	Estados veredicto;

	@BeforeSuite
	public void setup(String Navegador) throws IOException, InterruptedException {
		prop = new Properties();
		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(prop.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(prop.getProperty("Usuario"), prop.getProperty("Contrasenia"));
	}

	@Test
	public void validarActualizacionDatosPospago() throws IOException, InterruptedException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"Actualizaci�nDatos_Pospago", DispositivoPrueba.WEB, "TRANSACCIONES - Actualizacion de Datos");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Pospago 8872");
			objAdminDocPdf.generaEvidencia("Pagina Principal",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			objAdminDocPdf.generaEvidencia("Ingreso producto Pospago",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			ActualizacionDeDatos objActualizacionDeDatos = new ActualizacionDeDatos(objConfigAux);

			Map<String, String> mParametros = new HashMap<String, String>();
			mParametros.put("codDepartamento", "ATLANTICO");
			mParametros.put("codCiudad", "BARRANQUILLA");
			mParametros.put("codBarrio", "ALTOS DEL PRADO-BARRANQ.SUR");
			mParametros.put("TipoDireccion", "CARRERA");
			mParametros.put("codDireccion", "2 13 13");
			mParametros.put("codObservacion", "Hola a todos");
			mParametros.put("txtCtaCorreo", "everis@gmail.com");

			objActualizacionDeDatos.execActualizacionDeDatos(mParametros);

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void verificarOpcionVolverPospago() throws IOException, InterruptedException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"ActualizacionDatos_OpcionVolver_Pospago", DispositivoPrueba.WEB,
					"TRANSACCIONES - Actualizacion de Datos");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Pospago 8872");
			objAdminDocPdf.generaEvidencia("Ingreso producto Pospago",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			ActualizacionDeDatos objActualizacionDeDatos = new ActualizacionDeDatos(objConfigAux);
			objActualizacionDeDatos.execOpcionVolver();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void validarActualizacionDatosCtaControl() throws IOException, InterruptedException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"Actualizaci�nDatos_CtaControl", DispositivoPrueba.WEB, "TRANSACCIONES - Actualizacion de Datos");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Principal CtaCtrl 47");
			objAdminDocPdf.generaEvidencia("Ingreso producto Cuenta Control",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			ActualizacionDeDatos objActualizacionDeDatos = new ActualizacionDeDatos(objConfigAux);

			Map<String, String> mParametros = new HashMap<String, String>();
			mParametros.put("codDepartamento", "ATLANTICO");
			mParametros.put("codCiudad", "BARRANQUILLA");
			mParametros.put("codBarrio", "ALTOS DEL PRADO-BARRANQ.SUR");
			mParametros.put("TipoDireccion", "CARRERA");
			mParametros.put("codDireccion", "2 13 13");
			mParametros.put("codObservacion", "Hola a todos");
			mParametros.put("txtCtaCorreo", "everis@gmail.com");

			objActualizacionDeDatos.execActualizacionDeDatos(mParametros);
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void verificarOpcionVolverCtaControl() throws IOException, InterruptedException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"ActualizacionDatos_OpcionVolver_CtaControl", DispositivoPrueba.WEB,
					"TRANSACCIONES - Actualizacion de Datos");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Principal CtaCtrl 47");
			objAdminDocPdf.generaEvidencia("Ingreso producto Cuenta Control",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			ActualizacionDeDatos objActualizacionDeDatos = new ActualizacionDeDatos(objConfigAux);
			objActualizacionDeDatos.execOpcionVolver();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterTest
	public void finalizeTest() throws MalformedURLException, DocumentException, IOException {
		// objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterSuite
	public void tearDown() {
		objConfigAux.getDriver().quit();
	}
}