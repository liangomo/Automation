package transacciones.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import general.HomePage;
import general.Login;
import model.DispositivoPrueba;
import model.Estados;
import transacciones.paginas.RecargasEnLinea;

public class TestRecargasEnLinea {

	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties prop = new Properties();
	Estados veredicto;

	@BeforeSuite
	public void setup() throws IOException, InterruptedException {
		prop = new Properties();
		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(prop.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(prop.getProperty("Usuario"), prop.getProperty("Contrasenia"));
	}

	@Test
	public void validacionRecargaEnLineaPospago() throws InterruptedException, IOException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"RecargasEnLinea_Pospago", DispositivoPrueba.WEB, "TRANSACCIONES - Recargas en Linea con PSE");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Pospago 8872");

			objAdminDocPdf.generaEvidencia("Ingreso producto Pospago",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			RecargasEnLinea objRecargasEnLinea = new RecargasEnLinea(objConfigAux);
			Map<String, String> mParametros = new HashMap<String, String>();
			mParametros.put("ValorRecarga", "2000");
			mParametros.put("NumeroCelular", "3152627191");
			mParametros.put("EntidadFinanciera", "BANCO AGRARIO");
			objAdminDocPdf.generaEvidencia("Ingreso de Datos",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.BtnRecarga();
			objAdminDocPdf.generaEvidencia("Recargar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.execValidarBotonPagar(mParametros);
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void validacionOpcionCancelarPospago() throws InterruptedException, IOException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"RecargasEnLinea_Cancelar_Pospago", DispositivoPrueba.WEB,
					"TRANSACCIONES - Recargas en Linea con PSE");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Pospago 8872");

			objAdminDocPdf.generaEvidencia("Ingreso producto Pospago",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			RecargasEnLinea objRecargasEnLinea = new RecargasEnLinea(objConfigAux);
			Map<String, String> mParametros = new HashMap<String, String>();
			mParametros.put("ValorRecarga", "2000");
			mParametros.put("NumeroCelular", "3152627191");
			mParametros.put("EntidadFinanciera", "BANCO AGRARIO");
			objAdminDocPdf.generaEvidencia("Ingreso de Datos",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.BtnRecarga();
			objAdminDocPdf.generaEvidencia("Recargar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.execValidarBotonCancelar(mParametros);
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void validacionRecargaEnLineaCtaControl() throws InterruptedException, IOException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"RecargasEnLinea_CtaControl", DispositivoPrueba.WEB, "TRANSACCIONES - Recargas en Linea con PSE");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Principal CtaCtrl 47");

			objAdminDocPdf.generaEvidencia("Ingreso producto CtaControl",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			RecargasEnLinea objRecargasEnLinea = new RecargasEnLinea(objConfigAux);
			Map<String, String> mParametros = new HashMap<String, String>();
			mParametros.put("ValorRecarga", "2000");
			mParametros.put("NumeroCelular", "3152627191");
			mParametros.put("EntidadFinanciera", "BANCO AGRARIO");
			objAdminDocPdf.generaEvidencia("Ingreso de Datos",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.BtnRecarga();
			objAdminDocPdf.generaEvidencia("Recargar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.execValidarBotonPagar(mParametros);
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void validacionOpcionCancelarCtaControl() throws InterruptedException, IOException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"RecargasEnLinea_Cancelar_CtaControl", DispositivoPrueba.WEB,
					"TRANSACCIONES - Recargas en Linea con PSE");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Principal CtaCtrl 47");

			objAdminDocPdf.generaEvidencia("Ingreso producto CtaControl",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			RecargasEnLinea objRecargasEnLinea = new RecargasEnLinea(objConfigAux);
			Map<String, String> mParametros = new HashMap<String, String>();
			mParametros.put("ValorRecarga", "2000");
			mParametros.put("NumeroCelular", "3152627191");
			mParametros.put("EntidadFinanciera", "BANCO AGRARIO");
			objAdminDocPdf.generaEvidencia("Ingreso de Datos",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.BtnRecarga();
			objAdminDocPdf.generaEvidencia("Recargar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.execValidarBotonCancelar(mParametros);
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void validacionRecargaEnLineaPrepago() throws InterruptedException, IOException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"RecargasEnLinea_Prepago", DispositivoPrueba.WEB, "TRANSACCIONES - Recargas en Linea con PSE");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Principal Prepago 08");

			objAdminDocPdf.generaEvidencia("Ingreso producto Prepago",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			RecargasEnLinea objRecargasEnLinea = new RecargasEnLinea(objConfigAux);
			Map<String, String> mParametros = new HashMap<String, String>();
			mParametros.put("ValorRecarga", "2000");
			mParametros.put("NumeroCelular", "3152627191");
			mParametros.put("EntidadFinanciera", "BANCO AGRARIO");
			objAdminDocPdf.generaEvidencia("Ingreso de Datos",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.BtnRecarga();
			objAdminDocPdf.generaEvidencia("Recargar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.execValidarBotonPagar(mParametros);
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void validacionOpcionCancelarPrepago() throws InterruptedException, IOException, DocumentException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"RecargasEnLinea_Cancelar_Prepago", DispositivoPrueba.WEB,
					"TRANSACCIONES - Recargas en Linea con PSE");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Principal Prepago 08");

			objAdminDocPdf.generaEvidencia("Ingreso producto Prepago",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			RecargasEnLinea objRecargasEnLinea = new RecargasEnLinea(objConfigAux);
			Map<String, String> mParametros = new HashMap<String, String>();
			mParametros.put("ValorRecarga", "2000");
			mParametros.put("NumeroCelular", "3152627191");
			mParametros.put("EntidadFinanciera", "BANCO AGRARIO");
			objAdminDocPdf.generaEvidencia("Ingreso de Datos",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.BtnRecarga();
			objAdminDocPdf.generaEvidencia("Recargar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
			objRecargasEnLinea.execValidarBotonCancelar(mParametros);
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterTest
	public void finalizeTest() throws MalformedURLException, DocumentException, IOException {
		// objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterSuite
	public void tearDown() {
		objConfigAux.getDriver().quit();
	}
}
