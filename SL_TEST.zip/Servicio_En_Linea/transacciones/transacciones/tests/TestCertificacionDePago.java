package transacciones.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import general.HomePage;
import general.Login;
import model.DispositivoPrueba;
import model.Estados;
import transacciones.paginas.CertificacionDePagosalDia;

public class TestCertificacionDePago {
	HomePage objHomePage;
	AdminDocPdf objAdminDocPdf;
	ObjetosConfigAux objConfigAux;
	Properties prop = new Properties();
	Estados veredicto;

	@BeforeSuite
	public void setup() throws IOException, InterruptedException {
		prop = new Properties();
		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);

		objConfigAux = new ObjetosConfigAux();
		objConfigAux.getChrome(prop.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux.getDriver());
		objLogin.execLogin(prop.getProperty("Usuario"), prop.getProperty("Contrasenia"));
	}

	@Test
	public void pagosAlDiaOpcionImprimirVolverPospago() throws IOException, InterruptedException, DocumentException {

//		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"CertifPagosAlDia_Imprimir_Pospago", DispositivoPrueba.WEB,
					"TRANSACCIONES - Certificaci�n de pagos al d�a");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Pospago 8872");
			objAdminDocPdf.generaEvidencia("Pagina Principal Pospago",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			CertificacionDePagosalDia objCertificacionPagosAlDia = new CertificacionDePagosalDia(objConfigAux);
			objCertificacionPagosAlDia.execOpcionImprimirVolver();
			veredicto = Estados.SUCCESS;
//		} catch (Exception e) {
//			veredicto = Estados.FAILED;
//		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void pagosAlDiaOpcionVolverPospago() throws IOException, InterruptedException, DocumentException {

//		try {
			objAdminDocPdf = new AdminDocPdf("Jefatura de aseguramiento tecnico", "Servicio en linea",
					"CertifPagosAlDia_Volver_Pospago", DispositivoPrueba.WEB,
					"TRANSACCIONES - Certificaci�n de pagos al d�a");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Pospago 8872");
			objAdminDocPdf.generaEvidencia("Pagina Principal Pospago",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			CertificacionDePagosalDia objCertificacionPagosAlDia = new CertificacionDePagosalDia(objConfigAux);
			objCertificacionPagosAlDia.execOpcionVolver();
			veredicto = Estados.SUCCESS;
//		} catch (Exception e) {
//			veredicto = Estados.FAILED;
//		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void pagosAlDiaOpcionImprimirVolverCtaControl() throws IOException, InterruptedException, DocumentException {

//		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaAT"), prop.getProperty("NombreApp"),
					"CertifPagosAlDia_Imprimir_CtaControl", DispositivoPrueba.WEB,
					"TRANSACCIONES - Certificaci�n de pagos al d�a");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Principal CtaCtrl 47");
			objAdminDocPdf.generaEvidencia("Pagina Principal CtaControl",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			CertificacionDePagosalDia objCertificacionPagosAlDia = new CertificacionDePagosalDia(objConfigAux);

			objCertificacionPagosAlDia.execOpcionImprimirVolver();
			veredicto = Estados.SUCCESS;
//		} catch (Exception e) {
//			veredicto = Estados.FAILED;
//		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test
	public void pagosAlDiaOpcionVolverCtaControl() throws IOException, InterruptedException, DocumentException {

//		try {
			objAdminDocPdf = new AdminDocPdf("Jefatura de aseguramiento tecnico", "Servicio en linea",
					"CertifPagosAlDia_Volver_CtaControl", DispositivoPrueba.WEB,
					"TRANSACCIONES - Certificaci�n de pagos al d�a");

			objHomePage = new HomePage(objConfigAux);
			objHomePage.clickBtnHomePage();
			objHomePage.clicLnkProducto("Principal CtaCtrl 47");
			objAdminDocPdf.generaEvidencia("Pagina Principal CtaControl",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			CertificacionDePagosalDia objCertificacionPagosAlDia = new CertificacionDePagosalDia(objConfigAux);
			objCertificacionPagosAlDia.execOpcionVolver();
			veredicto = Estados.SUCCESS;
//		} catch (Exception e) {
//			veredicto = Estados.FAILED;
//		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterTest
	public void finalizeTest() throws MalformedURLException, DocumentException, IOException {
		// objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterSuite
	public void tearDown() {
		objConfigAux.getDriver().quit();
	}
}
