package transacciones.paginas;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import control.elementos.ObjetosConfigAux;

public class PagoDeSaldo {

	WebDriver driver;
	ObjetosConfigAux objConfigAux;
	float px = 0;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.xpath("//*[@id='idLiMenu2']/a");
	By btnAqui = By.xpath("//*[@id='area_1']/article/div/div[3]/p/a");
	By txtValorAPagar = By.id("ctl00_ContentPlaceHolder1_TxtValorPago");
	By txtEntidadFinanciera = By.id("ctl00_ContentPlaceHolder1_CmbEntidad");
	By btnHacerPago = By.id("ctl00_ContentPlaceHolder1_btnPagar");
	By btnPagar = By.id("ctl00_ContentPlaceHolder1_btnPagar");
	By iframe = By.xpath("//*[@id='LegacyContainer']");
	By opcionesMenu = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li");
	By lstLineas = By.xpath("//*[@id='mCSB_1_container']");

	/* Constructor */
	public PagoDeSaldo(ObjetosConfigAux objConfigAux) {
		this.driver = objConfigAux.getDriver();
		this.objConfigAux = objConfigAux;
	}


	/** EVENTOS (ACCIONES) EN LOS OBJETOS */
	
	public void swichtIframe() {
		driver.switchTo().frame(driver.findElement(iframe));
	}

	public void clicTransacciones() throws InterruptedException {
		driver.findElement(btnTransacciones).click();
	}

	public void ClicAqui() {
		driver.findElement(btnAqui).click();
	}

	public void setCodValorAPagar(String sCodValorAPagar) {
		driver.findElement(txtValorAPagar).clear();
		driver.findElement(txtValorAPagar).sendKeys(sCodValorAPagar);
	}

	public void clicEntidadFinanciera(String pCodEntidadFinanciera) {
		new Select(driver.findElement(txtEntidadFinanciera)).selectByVisibleText(pCodEntidadFinanciera);
	}

	public void clicBtnHacerPago() {
		driver.findElement(btnHacerPago).click();
	}

	public void clicBtnPagar() {
		driver.findElement(btnPagar).click();
	}
	
	
	/** METODOS */
	
	public void setOpcionesMenu(String pOpcion) throws InterruptedException {
		List<WebElement> wOpcionesMenu = driver.findElements(opcionesMenu);

		for (int i = 0; i <= wOpcionesMenu.size(); i++) {
			try {
				wOpcionesMenu.get(i).findElement(By.linkText(pOpcion)).click();
				i = wOpcionesMenu.size() + 1;
			} catch (Exception e) {

			}
		}
	}
	
	public void downLstLineas() throws InterruptedException {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(lstLineas);
		px = px - 33;
		js.executeScript("arguments[0].setAttribute('style', 'position: relative; top: " + px + "px; left: 0px;')",
				element);
	}

	@SuppressWarnings("rawtypes")
	public void execPagoSaldo(Map pPagoDeSaldo) throws InterruptedException {
		this.swichtIframe();
		this.clicTransacciones();
		this.setOpcionesMenu("Pago del saldo");
		this.setCodValorAPagar(pPagoDeSaldo.get("ValorAPagar").toString());
		this.clicEntidadFinanciera(pPagoDeSaldo.get("EntidadFinanciera").toString());
	}

	@SuppressWarnings("rawtypes")
	public void execPagosaldo(Map pPagoDeSaldo) throws InterruptedException {
		this.swichtIframe();
		this.clicTransacciones();
		this.setOpcionesMenu("Pago del saldo");
		this.ClicAqui();
		this.setCodValorAPagar(pPagoDeSaldo.get("ValorAPagar").toString());
		this.clicEntidadFinanciera(pPagoDeSaldo.get("EntidadFinanciera").toString());
	}
}