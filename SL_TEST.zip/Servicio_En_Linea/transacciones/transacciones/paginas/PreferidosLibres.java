package transacciones.paginas;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class PreferidosLibres {

	WebDriver driver;
	ObjetosConfigAux objConfigAux;
	AdminDocPdf objAdminDocPdf;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.xpath("//*[@id='idLiMenu2']/a");
	By btnPreferidosLibres = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li[1]/a");
	By btnVolver = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_volverMC']");
	By btnConsultarCualquierOperador = By.xpath(
			"//*[@id='ctl00_ContentPlaceHolder1_Listas']/tbody/tr[1]/td/table/tbody/tr[3]/td/table/tbody/tr/td[2]/a");
	By BtnAgregar = By.id("ctl00_ContentPlaceHolder1_lba2");
	By txtNumPreferido = By.id("ctl00_ContentPlaceHolder1_txtCelular1");
	By txtNombre = By.id("ctl00_ContentPlaceHolder1_txtNomPre1");
	By btnAgregar = By.id("ctl00_ContentPlaceHolder1_lnkAgregar");

	// PREFERIDO ILIMITADO MOVISTAR
	By btnPreferidoIlimiMovistar = By.xpath(
			"//*[@id='ctl00_ContentPlaceHolder1_Listas']/tbody/tr[2]/td/table/tbody/tr[3]/td/table/tbody/tr/td[2]/a");
	By btnAgregarMovistar = By.id("ctl00_ContentPlaceHolder1_lba1");

	// PREFERIDO INTERNACIONAL
	By btnPreferidoInternacional = By.xpath(
			"//*[@id='ctl00_ContentPlaceHolder1_Listas']/tbody/tr[3]/td/table/tbody/tr[3]/td/table/tbody/tr/td[2]/a");

	/* Constructor */
	public PreferidosLibres(ObjetosConfigAux objConfigAux) {
		this.driver = objConfigAux.getDriver();
		this.objConfigAux = objConfigAux;
	}


	/** EVENTOS (ACCIONES) EN LOS OBJETOS */
	
	public void btnTransacciones() {
		driver.findElement(btnTransacciones).click();
	}

	public void btnPreferidosLibres() {
		driver.findElement(btnPreferidosLibres).click();
	}

	public void BtnVolver() {
		driver.findElement(btnVolver).click();
	}

	public void btnAgregar() {
		driver.findElement(btnAgregar).click();
	}

	public void BtnAgregar() {
		driver.findElement(BtnAgregar).click();
	}

	public void txtNombre(String pCodNombre) {
		driver.findElement(txtNombre).clear();
		new Select(driver.findElement(txtNombre)).selectByVisibleText(pCodNombre);
	}

	public void BtnConsultarCualquierOperador() {
		driver.findElement(btnConsultarCualquierOperador).click();
	}

	public void txtNumPreferido(String pNumPreferido) {
		driver.findElement(txtNumPreferido).clear();
		new Select(driver.findElement(txtNumPreferido)).selectByVisibleText(pNumPreferido);
	}

	public void BtnPreferidoIlimiMovistar() {
		driver.findElement(btnPreferidoIlimiMovistar).click();
	}

	public void BtnPreferidoInternacional() {
		driver.findElement(btnPreferidoInternacional).click();
	}

	
	/** METODOS */

	public void execValidarOpcionVolver() throws IOException {
		this.btnTransacciones();
		this.btnPreferidosLibres();
		objAdminDocPdf.generaEvidencia("Ingreso al modulo", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.BtnVolver();
		objAdminDocPdf.generaEvidencia("Validacion opcion volver",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	@SuppressWarnings("rawtypes")
	public void execValidacionCualquierOperador(Map pPreferidosLibres) throws IOException {

		this.btnTransacciones();
		this.btnPreferidosLibres();
		this.BtnConsultarCualquierOperador();
		objAdminDocPdf.generaEvidencia("Ingreso a modulo consulta Cualquier Operador",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.BtnAgregar();
		this.txtNumPreferido(pPreferidosLibres.get("NumeroPreferido").toString());
		this.txtNombre(pPreferidosLibres.get("Nombre").toString());
		objAdminDocPdf.generaEvidencia("Ingreso de datos", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.btnAgregar();
		objAdminDocPdf.generaEvidencia("Validacion Agregar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	@SuppressWarnings("rawtypes")
	public void execValidacionPreferidoMovistar(Map pPreferidosLibres) throws IOException {

		this.btnTransacciones();
		this.btnPreferidosLibres();
		this.BtnPreferidoIlimiMovistar();
		objAdminDocPdf.generaEvidencia("Ingreso a modulo Preferido Ilimitado Movistar",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.BtnAgregar();
		this.txtNumPreferido(pPreferidosLibres.get("NumeroPreferido").toString());
		this.txtNombre(pPreferidosLibres.get("Nombre").toString());
		objAdminDocPdf.generaEvidencia("Ingreso de datos", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.btnAgregar();
		objAdminDocPdf.generaEvidencia("Validacion Agregar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	@SuppressWarnings("rawtypes")
	public void execValidacionPreferidoInternacional(Map pPreferidosLibres) throws IOException {

		this.btnTransacciones();
		this.btnPreferidosLibres();
		this.BtnPreferidoInternacional();
		objAdminDocPdf.generaEvidencia("Ingreso a modulo Preferido Internacional",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.BtnAgregar();
		this.txtNumPreferido(pPreferidosLibres.get("NumeroPreferido").toString());
		this.txtNombre(pPreferidosLibres.get("Nombre").toString());
		objAdminDocPdf.generaEvidencia("Ingreso de datos", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.btnAgregar();
		objAdminDocPdf.generaEvidencia("Validacion Agregar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}