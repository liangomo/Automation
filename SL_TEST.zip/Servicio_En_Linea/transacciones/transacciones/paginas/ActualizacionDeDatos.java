package transacciones.paginas;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class ActualizacionDeDatos {

	WebDriver driver;
	ObjetosConfigAux objConfigAux;
	AdminDocPdf objAdminDocPdf;
	float px = 0;
	
	/** LISTA ELEMENTOS */
	By btnTransacciones = By.xpath("//*[@id='idLiMenu2']/a");
	By btnActualizacionDeDatos = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li[6]/a");
	By btnVolver = By.xpath("//*[@id='area_1']/article[5]/a[2]");
	By txtCtaCorreo = By.id("ctl00_ContentPlaceHolder1_tbEmail");
	By btnModificar = By.id("ctl00_ContentPlaceHolder1_btnModificaMailFE");
	By txtDepartamento = By.id("ctl00_ContentPlaceHolder1_ddlDepto");
	By txtBarrio = By.id("ctl00_ContentPlaceHolder1_ddlComuna");
	By txtCiudad = By.id("ctl00_ContentPlaceHolder1_ddlCiudad");
	By txtTipoDireccion = By.id("ctl00_ContentPlaceHolder1_ddTipoCalle");
	By txtDireccion = By.id("ctl00_ContentPlaceHolder1_txtDireccion");
	By btnConfirmar = By.id("ctl00_ContentPlaceHolder1_btnAceptar");
	By txtObservacion = By.id("ctl00_ContentPlaceHolder1_txtObservacion");
	By btnContinuar = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_lnkEnviar']");
	By opcionesMenu = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li");
	By lstLineas = By.xpath("//*[@id='mCSB_1_container']");
	By iframe = By.xpath("//*[@id='LegacyContainer']");

	/* Constructor */
	public ActualizacionDeDatos(ObjetosConfigAux objConfigAux) {
		this.driver = objConfigAux.getDriver();
		this.objConfigAux = objConfigAux;
	}


	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void swichtIframe() {
		driver.switchTo().frame(driver.findElement(iframe));
	}

	public void btnCodTransacciones() {
		driver.findElement(btnTransacciones).click();
	}

	public void btnActualizacionDeDatos() {
		driver.findElement(btnActualizacionDeDatos).click();
	}

	public void BtnVolver() {
		driver.findElement(btnVolver).click();
	}

	public void txtBarrio(String pCodBarrio) {
		new Select(driver.findElement(txtBarrio)).selectByVisibleText(pCodBarrio);
	}

	public void txtCiudad(String pcodCiudad) {
		new Select(driver.findElement(txtCiudad)).selectByVisibleText(pcodCiudad);
	}

	public void txtDepartamento(String pCodDepartamento) {
		new Select(driver.findElement(txtDepartamento)).selectByVisibleText(pCodDepartamento);
	}

	public void txtTipoDireccion(String pTipoDireccion) {
		new Select(driver.findElement(txtTipoDireccion)).selectByVisibleText(pTipoDireccion);
	}

	public void txtDireccion(String pCodDireccion) {
		driver.findElement(txtDireccion).clear();
		new Select(driver.findElement(txtTipoDireccion)).selectByVisibleText(pCodDireccion);
	}

	public void BtnContinuar() {
		driver.findElement(btnContinuar).click();
	}

	public void BtnModificar() {
		driver.findElement(btnModificar).click();
	}

	public void txtObservacion(String sCodObservacion) {
		driver.findElement(txtObservacion).clear();
		driver.findElement(txtObservacion).sendKeys(sCodObservacion);
	}

	public void TxtCtaCorreo(String sTxtCtaCorreo) {
		driver.findElement(txtCtaCorreo).clear();
		driver.findElement(txtCtaCorreo).sendKeys(sTxtCtaCorreo);
	}

	public void BtnConfirmar() {
		driver.findElement(btnConfirmar).click();
	}

	
	/** METODOS */
	
	public void setOpcionesMenu(String pOpcion) {
		List<WebElement> wOpcionesMenu = driver.findElements(opcionesMenu);

		for (int i = 0; i <= wOpcionesMenu.size(); i++) {
			try {
				wOpcionesMenu.get(i).findElement(By.linkText(pOpcion)).click();
				i = wOpcionesMenu.size() + 1;
			} catch (Exception e) {

			}
		}
	}
	
	public void downLstLineas() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(lstLineas);
		px = px - 33;
		js.executeScript("arguments[0].setAttribute('style', 'position: relative; top: " + px + "px; left: 0px;')",
				element);
	}
	
	public void execOpcionVolver() throws InterruptedException, IOException {

		this.swichtIframe();
		this.btnCodTransacciones();
		this.btnActualizacionDeDatos();
		this.BtnVolver();
		objAdminDocPdf.generaEvidencia("Validacion Opcion Volver",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	@SuppressWarnings("rawtypes")
	public void execActualizacionDeDatos(Map pActualizacionDeDatosPospago) throws InterruptedException, IOException {

		this.swichtIframe();
		this.btnCodTransacciones();
		this.btnActualizacionDeDatos();
		this.txtDepartamento(pActualizacionDeDatosPospago.get("codDepartamento").toString());
		this.txtCiudad(pActualizacionDeDatosPospago.get("codCiudad").toString());
		this.txtBarrio(pActualizacionDeDatosPospago.get("codBarrio").toString());
		this.txtTipoDireccion(pActualizacionDeDatosPospago.get("TipoDireccion").toString());
		this.txtDireccion(pActualizacionDeDatosPospago.get("codDireccion").toString());
		this.txtObservacion(pActualizacionDeDatosPospago.get("codObservacion").toString());
		this.TxtCtaCorreo(pActualizacionDeDatosPospago.get("txtCtaCorreo").toString());
		objAdminDocPdf.generaEvidencia("Ingreso de Datos", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		
		this.BtnContinuar();
		objAdminDocPdf.generaEvidencia("Validacion Boton Continuar",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		
		this.BtnConfirmar();
		objAdminDocPdf.generaEvidencia("Validacion Boton Confirmar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}