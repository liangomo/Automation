package transacciones.paginas;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class RegistraTuEquipo {

	WebDriver driver;
	ObjetosConfigAux objConfigAux;
	AdminDocPdf objAdminDocPdf;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.id("Transacciones");
	By btnRegistraTuEquipo = By.xpath("//*[@id='idLiMenu']/div/div/ul/li[6]/a");

	/* Constructor */
	public RegistraTuEquipo(ObjetosConfigAux objConfigAux) {
		this.driver = objConfigAux.getDriver();
		this.objConfigAux = objConfigAux;
	}
	

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */
	
	public void btnTransacciones() {
		driver.findElement(btnTransacciones).click();
	}

	public void btnRegistraTuEquipo() {
		driver.findElement(btnRegistraTuEquipo).click();
	}
	
	
	/** METODOS */

	public void execRegitraTuEquipo() throws InterruptedException, IOException {

		this.btnTransacciones();
		this.btnRegistraTuEquipo();
		objAdminDocPdf.generaEvidencia("Ingreso al Modulo", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}