package transacciones.paginas;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class Superpreferidos {

	WebDriver driver;
	ObjetosConfigAux objConfigAux;
	AdminDocPdf objAdminDocPdf;
	float px = 0;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.xpath("//*[@id='idLiMenu2']/a");
	By btnSuperpreferidos = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li[1]/a");
	By btnAgregar = By.id("ctl00_ContentPlaceHolder1_lba1");
	By btnVolver = By.id("ctl00_ContentPlaceHolder1_lnkVolver");
	By opcionesMenu = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li");
	By lstLineas = By.xpath("//*[@id='mCSB_1_container']");
	By iframe = By.xpath("//*[@id='LegacyContainer']");

	/* Constructor */
	public Superpreferidos(ObjetosConfigAux objConfigAux) {
		this.driver = objConfigAux.getDriver();
		this.objConfigAux = objConfigAux;
	}

	
	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void swichtIframe() {
		driver.switchTo().frame(driver.findElement(iframe));
	}

	public void btnCodTransacciones() {
		driver.findElement(btnTransacciones).click();
	}

	public void btnCodSuperpreferidos() {
		driver.findElement(btnSuperpreferidos).click();
	}

	public void BtnAgregar() {
		driver.findElement(btnAgregar).click();
	}

	public void BtnVolver() {
		driver.findElement(btnVolver).click();
	}

	
	/** METODOS */
	
	public void setOpcionesMenu(String pOpcion) {
		List<WebElement> wOpcionesMenu = driver.findElements(opcionesMenu);

		for (int i = 0; i <= wOpcionesMenu.size(); i++) {
			try {
				wOpcionesMenu.get(i).findElement(By.linkText(pOpcion)).click();
				i = wOpcionesMenu.size() + 1;
			} catch (Exception e) {

			}
		}
	}
	
	public void downLstLineas() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(lstLineas);
		px = px - 33;
		js.executeScript("arguments[0].setAttribute('style', 'position: relative; top: " + px + "px; left: 0px;')",
				element);
	}
	
	public void execSuperPreferidos() throws IOException {

		this.swichtIframe();
		this.btnCodTransacciones();
		this.btnCodSuperpreferidos();
		objAdminDocPdf.generaEvidencia("Ingreso Modulo", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.BtnAgregar();
		objAdminDocPdf.generaEvidencia("Opcion Agregar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.BtnVolver();
		objAdminDocPdf.generaEvidencia("Opcion Volver", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}