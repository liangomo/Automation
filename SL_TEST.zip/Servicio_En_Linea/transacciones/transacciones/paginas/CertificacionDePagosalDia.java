package transacciones.paginas;

import java.io.IOException;
import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;


public class CertificacionDePagosalDia {

	WebDriver driver;
	ObjetosConfigAux objConfigAux;
	AdminDocPdf objAdminDocPdf;
	float px = 0;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.xpath("//*[@id='idLiMenu2']/a");
	By btnCertificacionPagosAlDia = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li[4]/a");
	By btnVolver = By.xpath("//*[@id='area_1']/article[4]/a");
	By lnkCertificadoPagoAlDia = By.id("ctl00_ContentPlaceHolder1_lnkAqui");
	By btnImprimir = By.xpath("//*[@id='form1']/blockquote/table[6]/tbody/tr/td[1]/a");
	By btnVolver2 = By.id("ctl00_ContentPlaceHolder1_volverMC");
	By iframe = By.xpath("//*[@id='LegacyContainer']");
	By opcionesMenu = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li");
	By lstLineas = By.xpath("//*[@id='mCSB_1_container']");
	By btnPagodeSaldo = By.xpath("//*[@id='LabelPagoPazYSalvo']/a/span");

	/* Constructor */
	public CertificacionDePagosalDia(ObjetosConfigAux objConfigAux) {
		this.driver = objConfigAux.getDriver();
		this.objConfigAux = objConfigAux;
	}


	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void swichtIframe() {
		driver.switchTo().frame(driver.findElement(iframe));
	}

	public void btnTransacciones() {
		driver.findElement(btnTransacciones).click();
	}

	public void btnCertificacionPagosAlDia() {
		driver.findElement(btnCertificacionPagosAlDia).click();
	}

	public void BtnVolver() {
		driver.findElement(btnVolver).click();
	}
	
	public void LnkCertificadoPagoAlDia() {
		driver.findElement(lnkCertificadoPagoAlDia).click();
	}
	
	public void BtnImprimir() {
		driver.findElement(btnImprimir).click();
	}

	public void BtnVolver2() {
		driver.findElement(btnVolver2).click();
	}
	
	
	/** METODOS */
	
	public void setOpcionesMenu(String pOpcion) {
		List<WebElement> wOpcionesMenu = driver.findElements(opcionesMenu);

		for (int i = 0; i <= wOpcionesMenu.size(); i++) {
			try {
				wOpcionesMenu.get(i).findElement(By.linkText(pOpcion)).click();
				i = wOpcionesMenu.size() + 1;
			} catch (Exception e) {

			}
		}
	}
	
	public void downLstLineas() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(lstLineas);
		px = px - 33;
		js.executeScript("arguments[0].setAttribute('style', 'position: relative; top: " + px + "px; left: 0px;')",
				element);
	}
	
	public void execOpcionImprimirVolver() throws IOException {
		this.btnTransacciones();
		this.btnCertificacionPagosAlDia();
		this.LnkCertificadoPagoAlDia();
		this.BtnImprimir();
		objAdminDocPdf.generaEvidencia("Validaci�n Boton Imprimir", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		
		this.BtnVolver2();
		objAdminDocPdf.generaEvidencia("Validaci�n Opcion Volver", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	public void execOpcionVolver() throws IOException {
		this.btnTransacciones();
		this.btnCertificacionPagosAlDia();
		this.BtnVolver();
		objAdminDocPdf.generaEvidencia("Validaci�n Opcion Volver", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}