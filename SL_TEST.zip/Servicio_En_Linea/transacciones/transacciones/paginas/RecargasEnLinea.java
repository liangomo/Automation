package transacciones.paginas;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;

public class RecargasEnLinea {

	WebDriver driver;
	ObjetosConfigAux objConfigAux;
	AdminDocPdf objAdminDocPdf;
	float px = 0;

	/** LISTA ELEMENTOS */
	By btnTransacciones = By.xpath("//*[@id='idLiMenu2']/a");
	By btnRecargasEnL�neaConPSE = By.xpath("//*[@id='idLiMenu2']/div/div/ul/li[3]/a");
	By txtValorRecarga = By.id("ctl00_ContentPlaceHolder1_TxtValorPago");
	By txtNumCelular = By.id("ctl00_ContentPlaceHolder1_txtNumCelular");
	By txtEntFinanciera = By.id("ctl00_ContentPlaceHolder1_CmbEntidad");
	By btnRecarga = By.id("ctl00_ContentPlaceHolder1_btnRecargar");
	By btnPagar = By.id("ctl00_ContentPlaceHolder1_btnPagar");
	By btnCancelar = By.id("ctl00_ContentPlaceHolder1_btnDeclina");
	By iframe = By.xpath("//*[@id='LegacyContainer']");
	By lstLineas = By.xpath("//*[@id='mCSB_1_container']");

	/* Constructor */
	public RecargasEnLinea(ObjetosConfigAux objConfigAux) {
		this.driver = objConfigAux.getDriver();
		this.objConfigAux = objConfigAux;
	}


	/** EVENTOS (ACCIONES) EN LOS OBJETOS */
	
	public void swichtIframe() {
		driver.switchTo().frame(driver.findElement(iframe));
	}

	public void btnTransacciones() {
		driver.findElement(btnTransacciones).click();
	}

	public void btnRecargasEnL�neaConPSE() {
		driver.findElement(btnRecargasEnL�neaConPSE).click();
	}

	public void txtValorRecarga(String pCodValorRecarga) {
		driver.findElement(txtValorRecarga).clear();
		driver.findElement(txtValorRecarga).sendKeys(pCodValorRecarga);
	}

	public void txtNumCelular(String pCodNumCelular) {
		driver.findElement(txtNumCelular).clear();
		driver.findElement(txtNumCelular).sendKeys(pCodNumCelular);
	}

	public void txtEntFinanciera(String pcodEntFinanciera) {
		new Select(driver.findElement(txtEntFinanciera)).selectByVisibleText(pcodEntFinanciera);

	}

	public void BtnRecarga() {
		driver.findElement(btnRecarga).click();
	}

	public void BtnPagar() {
		driver.findElement(btnPagar).click();
	}

	public void BtnCancelar() {
		driver.findElement(btnCancelar).click();
	}

	
	/** METODOS */
	
	public void downLstLineas() throws InterruptedException {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(lstLineas);
		px = px - 33;
		js.executeScript("arguments[0].setAttribute('style', 'position: relative; top: " + px + "px; left: 0px;')",
				element);
	}
	
	@SuppressWarnings("rawtypes")
	public void execValidarBotonPagar(Map pRecargasEnL�nea) throws InterruptedException, IOException {

		this.txtValorRecarga(pRecargasEnL�nea.get("ValorRecarga").toString());
		this.txtNumCelular(pRecargasEnL�nea.get("NumeroCelular").toString());
		this.txtEntFinanciera(pRecargasEnL�nea.get("EntidadFinanciera").toString());
		objAdminDocPdf.generaEvidencia("Ingreso valores recarga",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.BtnPagar();
		objAdminDocPdf.generaEvidencia("Opcion Pagar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	@SuppressWarnings("rawtypes")
	public void execValidarBotonCancelar(Map pRecargasEnL�nea) throws InterruptedException, IOException {

		this.txtValorRecarga(pRecargasEnL�nea.get("ValorRecarga").toString());
		this.txtNumCelular(pRecargasEnL�nea.get("NumeroCelular").toString());
		this.txtEntFinanciera(pRecargasEnL�nea.get("EntidadFinanciera").toString());
		objAdminDocPdf.generaEvidencia("Ingreso valores recarga", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		this.BtnCancelar();
		objAdminDocPdf.generaEvidencia("Opcion Cancelar", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}
}