package homePage.test;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import homePage.paginas.HomePage;
import login.paginas.Login;
import miMovistarHome.paginas.MiMovistarHome;
import model.DispositivoPrueba;
import model.Estados;

public class TestHomePage {

	AdminDocPdf objAdminDocPdf;
	Properties prop = new Properties();
	Estados veredicto;

	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	Login login = new Login(objConfigAux);
	MiMovistarHome miMov = new MiMovistarHome(objConfigAux);
	HomePage home = new HomePage(objConfigAux);

	@BeforeSuite
	public void setup() throws IOException, InterruptedException {
		InputStream entrada = new FileInputStream("Config.properties");
		prop.load(entrada);

		objConfigAux.getChrome(prop.getProperty("UrlBase"));

		Login objLogin = new Login(objConfigAux);
		objLogin.execLogin(prop.getProperty("Usuario"), prop.getProperty("Contrasenia"));
	}

	/**
	 * CASOS DE PRUEBA
	 */

	@Test(priority = 1)
	public void ingresarTelMovHomePospago()
			throws InterruptedException, AWTException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"IngresoTelefoniaMovilPospago", DispositivoPrueba.WEB, "TELEFONIA MOVIL: Home");

			home.getBodyFrameDefaultContent();
			home.clicLnkProducto("Pospago 8872");

			objAdminDocPdf.generaEvidencia("Ingreso Pospago 8872",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			homeMain();

			String nombreCliente = home.getLblNombreClienteProd();

			home.getBodyFrameLegacyContainer();
			String numCelular = home.getLblNumCelular();
			String direccion = home.getLblDireccion();
			String ciudad = home.getLblCiudad();

			assertTrue(nombreCliente.equals("Lineas Optimizacion Sl"));
			assertTrue(numCelular.equals("3188277289"));
			assertTrue(direccion.equals("Direcci�n: DG MORATO"));
			assertTrue(ciudad.equals("Ciudad: ABEJORRAL"));

			objAdminDocPdf.generaEvidencia("Ingreso Telefonia movil Home producto",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			home.getBodyFrameDefaultContent();
			home.clickLinkOtraLinea();
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgPhotoUser()));
			objAdminDocPdf.generaEvidencia("Clic link otra linea", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 2)
	public void validarBannerLinksPospago()
			throws InterruptedException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"ValidacionBannerLinksPospago", DispositivoPrueba.WEB, "TELEFONIA MOVIL: Home");

			objAdminDocPdf.generaEvidencia("Ingreso Principal", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			homeBannerPospago();
			homeLinks();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 3)
	public void ingresarTelMovHomeCtaControl()
			throws InterruptedException, AWTException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"IngresoTelefoniaMovilCtaControl", DispositivoPrueba.WEB, "TELEFONIA MOVIL: Home");

			home.getBodyFrameDefaultContent();
			home.clicLnkProducto("Principal CtaCtrl 47");

			objAdminDocPdf.generaEvidencia("Ingreso Principal CtaCtrl 47",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			homeMain();

			String nombreCliente = home.getLblNombreClienteProd();

			home.getBodyFrameLegacyContainer();
			String numCelular = home.getLblNumCelular();
			String direccion = home.getLblDireccion();
			String ciudad = home.getLblCiudad();

			assertTrue(nombreCliente.equals("Lineas Optimizacion Sl "));
			assertTrue(numCelular.equals("3168355147"));
			assertTrue(direccion.equals("Direcci�n: DG MORATO"));
			assertTrue(ciudad.equals("Ciudad: ABEJORRAL"));

			objAdminDocPdf.generaEvidencia("Ingreso Telefonia movil Home producto",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			home.getBodyFrameDefaultContent();
			home.clickLinkOtraLinea();
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgPhotoUser()));
			objAdminDocPdf.generaEvidencia("Clic link otra linea", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 4)
	public void validarBannerLinksCtaControl()
			throws InterruptedException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"ValidacionBannerLinksCtaControl", DispositivoPrueba.WEB, "TELEFONIA MOVIL: Home");

			objAdminDocPdf.generaEvidencia("Ingreso Principal", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			homeBannerCtaControl();
			homeLinks();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 5)
	public void ingresarTelMovHomePrepago()
			throws InterruptedException, AWTException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"IngresoTelefoniaMovilPrepago", DispositivoPrueba.WEB, "TELEFONIA MOVIL: Home");

			home.getBodyFrameDefaultContent();
			home.clicLnkProducto("Principal Prepago 08");

			objAdminDocPdf.generaEvidencia("Ingreso Principal Prepago 08",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			homeMain();

			String nombreCliente = home.getLblNombreClienteProd();

			home.getBodyFrameLegacyContainer();
			String numCelular = home.getLblNumCelular();

			assertTrue(nombreCliente.equals("Libardo Sanchez Millan"));
			assertTrue(numCelular.equals("3213415008"));

			objAdminDocPdf.generaEvidencia("Ingreso Telefonia movil Home producto",
					Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			home.getBodyFrameDefaultContent();
			home.clickLinkOtraLinea();
			assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgPhotoUser()));
			objAdminDocPdf.generaEvidencia("Clic link otra linea", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@Test(priority = 6)
	public void validarBannerLinksPrepago()
			throws InterruptedException, DocumentException, MalformedURLException, IOException {

		try {
			objAdminDocPdf = new AdminDocPdf(prop.getProperty("NombreAreaPYS"), prop.getProperty("NombreApp"),
					"ValidacionBannerLinksPrepago", DispositivoPrueba.WEB, "TELEFONIA MOVIL: Home");

			objAdminDocPdf.generaEvidencia("Ingreso Principal", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

			homeBannerPrepago();
			homeLinks();
			veredicto = Estados.SUCCESS;
		} catch (Exception e) {
			veredicto = Estados.FAILED;
		}
		objAdminDocPdf.crearDocumento(veredicto);
	}

	@AfterTest
	public void finalizeTest() throws MalformedURLException, IOException, com.lowagie.text.DocumentException {
		// objAdminDocPdf.crearDocumento(Estados.SUCCESS);
	}

	@AfterSuite
	public void tearDown() {
		objConfigAux.getDriver().quit();
	}

	/**
	 * METODOS
	 */

	public void homeMain() throws InterruptedException, AWTException, IOException {

		Integer caracter = Integer.valueOf(home.getLblNombreCliente().length());
		assertTrue(home.getBody().contains("Hola"));
		assertTrue(home.getBody().contains("para ingresar a otra"));
		assertTrue(caracter > 1);
		objAdminDocPdf.generaEvidencia("Validacion home", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	public void homeBannerPospago() throws InterruptedException, AWTException, IOException {

		home.getBodyFrameLegacyContainer();

		/* Banner en movimiento */
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerFacturaDigitalPospago()));
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerPagosOnlinePospago()));
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerRenoRepoPospago()));
		objAdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		/* Banner Factura Digital */
		home.clicklinkSiguiente();

		if (objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerFacturaDigitalPospago())) {
			home.clickImgBannerFacturaDigitalPospago();
		} else {
			home.clicklinkSiguiente();
			if (objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerFacturaDigitalPospago())) {
				home.clickImgBannerFacturaDigitalPospago();
			} else {
				home.clicklinkSiguiente();
				home.clickImgBannerFacturaDigitalPospago();
			}
		}

		assertTrue(home.getLblRecargaOnlinePrep().contains("Puedes recargar desde cualquier celular Movistar"));
		objAdminDocPdf.generaEvidencia("Validacion link banner factura digital",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		/* Banner Pagos Online */
		objConfigAux.getDriver().navigate().back();
		home.clicklinkSiguiente();

		if (objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerPagosOnlinePospago())) {
			home.clickImgBannerPagosOnlinePospago();
		} else {
			home.clicklinkSiguiente();
			if (objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerPagosOnlinePospago())) {
				home.clickImgBannerPagosOnlinePospago();
			} else {
				home.clicklinkSiguiente();
				home.clickImgBannerPagosOnlinePospago();
			}
		}

		home.getBodyFrameLegacyContainer();
		home.clickImgBannerPagosOnlinePospago();
		home.getBodyFramePaqInternet();
		assertTrue(home.getLblPaquetesInternetPrep().contains("Paquetes de Internet"));
		objAdminDocPdf.generaEvidencia("Validacion link banner pagos online",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		objConfigAux.getDriver().navigate().back();

		/* Banner Renovacion Reposicion */
		home.clicklinkSiguiente();

		if (objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerRenoRepoPospago())) {
			home.clickImgBannerRenoRepoPospago();
		} else {
			home.clicklinkSiguiente();
			if (objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerRenoRepoPospago())) {
				home.clickImgBannerRenoRepoPospago();
			} else {
				home.clicklinkSiguiente();
				home.clickImgBannerRenoRepoPospago();
			}
		}

		assertTrue(home.getLblRenoRepoPospago().contains("Consulta, Renovaci�n y Reposici�n"));
		objAdminDocPdf.generaEvidencia("Validacion link banner renovacion reposicion",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	public void homeBannerCtaControl() throws InterruptedException, AWTException, IOException {

		home.getBodyFrameLegacyContainer();

		/* Banner en movimiento */
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerPagosOnlineCtaControl()));
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerRenoRepoCtaControl()));
		objAdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		/* Banner Pagos Online */
		objConfigAux.getDriver().navigate().back();
		home.clicklinkSiguiente();

		if (objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerPagosOnlinePospago())) {
			home.clickImgBannerPagosOnlinePospago();
		} else {
			home.clicklinkSiguiente();
			home.clickImgBannerPagosOnlinePospago();
		}

		home.getBodyFrameLegacyContainer();
		home.clickImgBannerPagosOnlinePospago();
		home.getBodyFramePaqInternet();
		assertTrue(home.getLblPaquetesInternetPrep().contains("Paquetes de Internet"));
		objAdminDocPdf.generaEvidencia("Validacion link banner pagos online",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		objConfigAux.getDriver().navigate().back();

		/* Banner Renovacion Reposicion */
		home.clicklinkSiguiente();

		if (objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerRenoRepoPospago())) {
			home.clickImgBannerRenoRepoPospago();
		} else {
			home.clicklinkSiguiente();
			home.clickImgBannerRenoRepoPospago();
		}

		assertTrue(home.getLblRenoRepoPospago().contains("Consulta, Renovaci�n y Reposici�n"));
		objAdminDocPdf.generaEvidencia("Validacion link banner renovacion reposicion",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
	}

	public void homeBannerPrepago() throws InterruptedException, AWTException, IOException {

		home.getBodyFrameLegacyContainer();

		/* Banner en movimiento */
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerFactura_IntPrepago()));
		assertTrue(objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerDetalle_RecargasPrep()));
		objAdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		/* Banner Recargas */
		home.clicklinkSiguiente();

		if (objConfigAux.EsperaElemento(objConfigAux.getDriver(),  home.getImgBannerDetalle_RecargasPrep())) {
			home.clickImgBannerDetalle_RecargasPrep();
		} else {
			home.clicklinkSiguiente();
			home.clickImgBannerDetalle_RecargasPrep();
		}

		assertTrue(home.getLblRecargaOnlinePrep().contains("Puedes recargar desde cualquier celular Movistar"));
		objAdminDocPdf.generaEvidencia("Validacion link banner recargas",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());

		/* Banner Internet Prepago */
		objConfigAux.getDriver().navigate().back();

		home.getBodyFrameLegacyContainer();
		home.clickImgBannerFactura_IntPrepago();

		home.getBodyFramePaqInternet();
		assertTrue(home.getLblPaquetesInternetPrep().contains("Paquetes de Internet"));
		objAdminDocPdf.generaEvidencia("Validacion link banner internet",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		objConfigAux.getDriver().navigate().back();
	}

	public void homeLinks() throws InterruptedException, AWTException, IOException {

		/* Validaci�n opci�n Chat Servicio */
		home.getBodyFrameLegacyContainer();
		home.clickImgChatServicio();
		objConfigAux.cambiarVentanaAnterior();
		home.getBodyFrameChat();
		assertTrue(home.getLblChat().equals("Chat"));
		objAdminDocPdf.generaEvidencia("Validacion opcion Chat de Servicio",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		home.keyPressCerrarPestana();

		/* Validaci�n opci�n Imprimir */
		objConfigAux.cambiarVentanaAnterior();
		home.getBodyFrameLegacyContainer();
		home.clickImgImprimir();
		objConfigAux.cambiarVentana();
		home.getBodyFrameDefaultContent();
		assertTrue(home.getBtnImprimir().equals("Imprimir"));
		objAdminDocPdf.generaEvidencia("Validacion opcion Imprimir", Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		home.clickBtnCancelar();

		/* Validacion opcion Facebook */
		objConfigAux.cambiarVentanaAnterior();
		home.getBodyFrameLegacyContainer();
		home.clickImgFacebook();
		objConfigAux.cambiarVentanaAnterior();
		assertTrue(home.getLblHomeLinkFacebook().equals("Facebook"));
		objAdminDocPdf.generaEvidencia("Validacion opcion de Facebook",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		home.keyPressCerrarVentana();

		/* Validacion opcion Twitter */
		objConfigAux.cambiarVentanaAnterior();
		home.getBodyFrameLegacyContainer();
		home.getBodyFrameTwitter();
		home.clickImgTwittear();
		objConfigAux.cambiarVentana();
		assertTrue(home.getBtnSesionTwitter().equals("Reg�strate"));
		objAdminDocPdf.generaEvidencia("Validacion opcion de Twitter",
				Shutterbug.shootPage(objConfigAux.getDriver()).getImage());
		home.keyPressCerrarVentana();
	}
}