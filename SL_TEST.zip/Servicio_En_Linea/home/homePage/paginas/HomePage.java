package homePage.paginas;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import control.elementos.ObjetosConfigAux;

public class HomePage {

	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	float px = 0;
	
	/** LISTA ELEMENTOS */
	By linkCertificado = By.id("overridelink");
	By lnkProducto = By.xpath("//*[@class='mCSB_container']/div/ul/a");
	By contenedor = By.xpath("//*[@id='mCSB_1_container']");

	By body = By.tagName("body");
	By iframe = By.xpath("//*[@id='LegacyContainer']");
	By lblNombreCliente = By.xpath("//*[@id=\"content\"]/section/div[1]/div/div[1]/p[1]/span[1]");
	By lblApellidoCliente = By.xpath("//*[@id=\"content\"]/section/div[1]/div/div[1]/p[1]/span[2]");
	
	By lblNumCelular = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_NumeroCelular\"]");
	By lblNombreClienteProd = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_divInfoContacto']/h3");
	By lblDireccion = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_divInfoContacto\"]/p[1]");
	By lblCiudad = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_divInfoContacto\"]/p[2]");

	By linkOtraLinea = By.linkText("click aqu�");
	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");
	By imgImagesPersona = By.xpath("//*[@id='top_contenido']/h1");
	
	By linkSiguiente = By.xpath("//*[@id=\"slides\"]/a[2]");
	
	By imgBannerFactura_IntPrepago = By.cssSelector("#slides > div > div > a:nth-child(1) > img");
	By imgBannerDetalle_RecargasPrepago = By.cssSelector("#slides > div > div > a:nth-child(2) > img");
	By lblPaquetesInternetPrep = By.id("LblTituloGrande");
	By lblRecargaOnlinePrep = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_divRecargaPSE\"]/p[1]");
	By btnVolver = By.id("BtnVolver");
	
	By imgBannerFacturaDigitalPospago = By.cssSelector("#slides > div > div > a:nth-child(1) > img");
	By imgBannerPagosOnlinePospago = By.cssSelector("#slides > div > div > a:nth-child(2) > img");
	By imgBannerRenoRepoPospago = By.cssSelector("#slides > div > div > a:nth-child(3) > img");
	By lblFacturaDigitalPospago = By.xpath("//*[@id='contenedor_principal']/header/div/h1"); // Mi Movistar
	By lblPagosOnlinePospago = By.xpath("//*[@id='area_1']/header/h2");  // Realiza tu pago ---sale acept
	By lblRenoRepoPospago = By.xpath("//*[@id='contenedorRR']/table[1]/tbody/tr/td/div/div");  // Consulta, Renovaci�n y Reposici�n  (CONTIENE)
	
	By imgBannerPagosOnlineCtaControl = By.cssSelector("#slides > div > div > a:nth-child(1) > img");
	By imgBannerRenoRepoCtaControl = By.cssSelector("#slides > div > div > a:nth-child(2) > img");
	By lblPagosOnlineCtaControl = By.xpath("//*[@id='area_1']/header/h2");  // Realiza tu pago ---sale acept
	By lblRenoRepoCtaControl = By.xpath("//*[@id='contenedorRR']/table[1]/tbody/tr/td/div/div");  // Consulta, Renovaci�n y Reposici�n  (CONTIENE)
	
	By imgChatServicio = By.id("ctl00_lnChat");
	By lblChat = By.xpath("//*[@id=\"contenedor\"]/div[1]/section/header/h1");

	By imgImprimir = By.cssSelector("span.ladop");
	By btnImprimir = By.xpath("//*[@id=\"print-header\"]/div/button[1]");
	By btnCancelar = By.xpath("//*[@id=\"print-header\"]/div/button[2]");
	
	By imgFacebook = By.cssSelector("a.contiene_facebook > img");
	By lblHomeLinkFacebook = By.xpath("//*[@id=\"homelink\"]");
	
	By imgTwittear = By.id("l");
	By btnRegistrateTwitter = By.xpath("//*[@id=\"not-logged-in\"]/a");
	
	By linkConsultas = By.id("idLiMenu1");
	By linkTransacciones = By.linkText("Transacciones");
	By linkServicios = By.linkText("Servicios");
	
	/* Constructor */
	public HomePage(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}
	
	
	/** EVENTOS (ACCIONES) */
	
	public By getLinkCertificado() {
		return (linkCertificado);
	}
	
	public void clickLinkCertificado() {
		this.objConfigAux.getDriver().findElement(linkCertificado).click();
	}
	
	public String getBody() {
		return this.objConfigAux.getDriver().findElement(body).getText();
	}
	
	public String getLblNumCelular() {
		return this.objConfigAux.getDriver().findElement(lblNumCelular).getText();
	}
	
	public String getLblNombreCliente() {
		return this.objConfigAux.getDriver().findElement(lblNombreCliente).getText();
	}
	
	public String getLblApellidoCliente() {
		return this.objConfigAux.getDriver().findElement(lblApellidoCliente).getText();
	}
	
	public String getLblNombreClienteProd() {
		return this.objConfigAux.getDriver().findElement(lblNombreClienteProd).getText();
	}
	
	public String getLblDireccion() {
		return this.objConfigAux.getDriver().findElement(lblDireccion).getText();
	}
	
	public String getLblCiudad() {
		return this.objConfigAux.getDriver().findElement(lblCiudad).getText();
	}

	public void clickLinkOtraLinea() {
		this.objConfigAux.getDriver().findElement(linkOtraLinea).click();
	}

	
	public By getImgPhotoUser() {
		return (imgPhotoUser);
	}
	
	public By getImgImagesPersona() {
		return (imgImagesPersona);
	}
	
	public void clicklinkSiguiente() {
		this.objConfigAux.getDriver().findElement(linkSiguiente).click();
	}

	
	public By getImgBannerFactura_IntPrepago() {
		return (imgBannerFactura_IntPrepago);
	}

	public void clickImgBannerFactura_IntPrepago() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), imgBannerFactura_IntPrepago);
		this.objConfigAux.getDriver().findElement(imgBannerFactura_IntPrepago).click();
	}
	
	public String getLblPaquetesInternetPrep() {
		return this.objConfigAux.getDriver().findElement(lblPaquetesInternetPrep).getText();
	}
	
	public By getImgBannerDetalle_RecargasPrep() {
		return (imgBannerDetalle_RecargasPrepago);
	}
	
	public void clickImgBannerDetalle_RecargasPrep() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), imgBannerDetalle_RecargasPrepago);
		this.objConfigAux.getDriver().findElement(imgBannerDetalle_RecargasPrepago).click();
	}
	
	public String getLblRecargaOnlinePrep() {
		return this.objConfigAux.getDriver().findElement(lblRecargaOnlinePrep).getText();
	}
	

	public By getImgBannerFacturaDigitalPospago() {
		return (imgBannerFacturaDigitalPospago);
	}

	public void clickImgBannerFacturaDigitalPospago() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), imgBannerFacturaDigitalPospago);
		this.objConfigAux.getDriver().findElement(imgBannerFacturaDigitalPospago).click();
	}
	
	public String getLblFacturaDigitalPospago() {
		return this.objConfigAux.getDriver().findElement(lblFacturaDigitalPospago).getText();
	}
	
	public By getImgBannerPagosOnlinePospago() {
		return (imgBannerPagosOnlinePospago);
	}
	
	public void clickImgBannerPagosOnlinePospago() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), imgBannerPagosOnlinePospago);
		this.objConfigAux.getDriver().findElement(imgBannerPagosOnlinePospago).click();
	}
	
	public String getLblPagosOnlinePospago() {
		return this.objConfigAux.getDriver().findElement(lblPagosOnlinePospago).getText();
	}
	
	public By getImgBannerRenoRepoPospago() {
		return (imgBannerRenoRepoPospago);
	}

	public void clickImgBannerRenoRepoPospago() {
		objConfigAux.EsperaElemento(objConfigAux.getDriver(), imgBannerRenoRepoPospago);
		this.objConfigAux.getDriver().findElement(imgBannerRenoRepoPospago).click();
	}
	
	public String getLblRenoRepoPospago() {
		return this.objConfigAux.getDriver().findElement(lblRenoRepoPospago).getText();
	}
	

	public By getImgBannerPagosOnlineCtaControl() {
		return (imgBannerPagosOnlineCtaControl);
	}
	
	public void clickImgBannerPagosOnlineCtaControl() {
		this.objConfigAux.getDriver().findElement(imgBannerPagosOnlineCtaControl).click();
	}
	
	public String getLblPagosOnlineCtaControl() {
		return this.objConfigAux.getDriver().findElement(lblPagosOnlineCtaControl).getText();
	}
	
	public By getImgBannerRenoRepoCtaControl() {
		return (imgBannerRenoRepoCtaControl);
	}

	public void clickImgBannerRenoRepoCtaControl() {
		this.objConfigAux.getDriver().findElement(imgBannerRenoRepoCtaControl).click();
	}
	
	public String getLblRenoRepoCtaControl() {
		return this.objConfigAux.getDriver().findElement(lblRenoRepoCtaControl).getText();
	}
	

	public By getBtnVolver() {
		return(btnVolver);
	}
	
	public void clickBtnVolver() {
		this.objConfigAux.getDriver().findElement(btnVolver).click();
	}

	
	public void clickImgChatServicio() {
		this.objConfigAux.getDriver().findElement(imgChatServicio).click();
	}
	
	public String getLblChat() {
		return this.objConfigAux.getDriver().findElement(lblChat).getText();
	}
	
	public void clickImgImprimir() {
		this.objConfigAux.getDriver().findElement(imgImprimir).click();
	}
	
	public String getBtnImprimir() {
		return this.objConfigAux.getDriver().findElement(btnImprimir).getText();
	}
	
	public void clickBtnCancelar() {
		this.objConfigAux.getDriver().findElement(btnCancelar).click();
	}
	
	public void clickImgFacebook() {
		this.objConfigAux.getDriver().findElement(imgFacebook).click();
	}
	
	public String getLblHomeLinkFacebook() {
		return this.objConfigAux.getDriver().findElement(lblHomeLinkFacebook).getText();
	}
	
	public void clickImgTwittear() {
		this.objConfigAux.getDriver().findElement(imgTwittear).click();
	}
	
	public String getBtnSesionTwitter() {
		return this.objConfigAux.getDriver().findElement(btnRegistrateTwitter).getText();
	}
	
	
	public void clickLinkConsultas() throws InterruptedException {
		getBodyFrameLegacyContainer();
		this.objConfigAux.getDriver().findElement(linkConsultas).click();
	}
	
	public void clickLinkTransacciones() {
		getBodyFrameLegacyContainer();
		this.objConfigAux.getDriver().findElement(linkTransacciones).click();
	}
	
	public void clicklinkServicios() {
		getBodyFrameLegacyContainer();
		this.objConfigAux.getDriver().findElement(linkServicios).click();
	}
	
	
	public void clicLnkProducto(String pLnkProducto) {
		List<WebElement> listaProducto = objConfigAux.getDriver().findElements(lnkProducto);
		try {
			boolean reintentar = true;
			for (int i = 0; i <= listaProducto.size(); i++) {
				reintentar = true;
				while (reintentar) {
					if (listaProducto.get(i).isDisplayed()) {
						reintentar = false;

						if (listaProducto.get(i).getText().toString().equals(pLnkProducto)) {
							listaProducto.get(i).click();
						}
					} else {
						downLstLineas();
					}
				}
			}
		} catch (Exception e) {
		}
	}


	/** METODOS */
	
	private void downLstLineas() throws InterruptedException {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) objConfigAux.getDriver();
		WebElement element = objConfigAux.getDriver().findElement(contenedor);
		px = px - 92;
		js.executeScript("arguments[0].setAttribute('style', 'position: relative; top: " + px + "px; left: 0px;')",
				element);
	}
	
	public void getBodyFrameDefaultContent() {
		this.objConfigAux.getDriver().switchTo().defaultContent();
	}
	
	public void getBodyFrameLegacyContainer() {
		this.objConfigAux.getDriver().switchTo().frame("LegacyContainer");
	}
	
	public void getBodyFrameContentPlaceHolder() {
		this.objConfigAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
	}
	
	public void getBodyFrameChat() {
		this.objConfigAux.getDriver().switchTo().frame("main");
	}
	
	public void getBodyFrameTwitter() {
		this.objConfigAux.getDriver().switchTo().frame("twitter-widget-0");
	}
	
	public void getBodyFramePaqInternet() {
		this.objConfigAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_SSO");
	}
	
	public void keyPressUrlDescargas() throws AWTException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_J);
		robot.keyPress(KeyEvent.VK_CONTROL);
	}
	
	public void keyPressCerrarPestana() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_W);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_W);
	}
	
	public void keyPressCerrarVentana() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_F4);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_ALT);
		robot.keyRelease(KeyEvent.VK_F4);
	}
}