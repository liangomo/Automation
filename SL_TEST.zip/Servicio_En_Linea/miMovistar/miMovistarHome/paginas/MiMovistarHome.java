package miMovistarHome.paginas;

import org.openqa.selenium.By;

import control.elementos.ObjetosConfigAux;

public class MiMovistarHome {
	
	ObjetosConfigAux objConfigAux = new ObjetosConfigAux();
	
	/** LISTA ELEMENTOS	*/
	By btnHomePage = By.xpath("//*[@id='li-home']");
	
	/* Constructor */
	public MiMovistarHome(ObjetosConfigAux objConfigAux) {
		this.objConfigAux = objConfigAux;
	}
	
	
	/** EVENTOS (ACCIONES) */
	
	public void clickBtnHomePage() {
//		String handle = objConfigAux.getDriver().getWindowHandle();
//		objConfigAux.getDriver().switchTo().window(handle);
		objConfigAux.getDriver().findElement(btnHomePage).click();
		objConfigAux.getDriver().findElement(btnHomePage).click();
	}
	
	public By getBtnHomePage() {
		return (btnHomePage);
	}
}