
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import resources.Generacion_Muestra_AhorrosHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
import dbc.Utilitarios;
/**
 * Description   : Functional Test Script
 * @author Gorteg1
 */


public class Generacion_Muestra_Ahorros extends Generacion_Muestra_AhorrosHelper
{
	FileInputStream LeerArchivo_CuentasBuscadas, LeerArchivo_Pricicpal; 
	DataInputStream EntradaArchivoCB, EntradaArchivoPrin;												
	BufferedReader TemporalArchivoCB, TemporalArchivoPrin;	
	ArrayList<String> lista, lista2;
	int movCredito, movDebito;
	String no_cuenta;
	FileWriter fichero;
	PrintWriter pw;
	Utilitarios util;
	//Rango variable de ejecucion de la prueba 
	//Cantidad de Movimientos Debito y Credito Superiores a:
	int rango = 80;
	
	
	public void testMain(Object[] args) throws IOException
	{
		lista = new ArrayList<String>();
		lista2 = new ArrayList<String>();
		util = new Utilitarios();// 
		int mes = dpInt("Mes");
	
		try {
			LeerArchivo_CuentasBuscadas = new FileInputStream("D:\\MediosMagneticos\\AhorrosMensual\\CuentasBuscadas.txt");
		} catch (Exception e) {
			return;
		}
													
		EntradaArchivoCB = new DataInputStream(LeerArchivo_CuentasBuscadas);				
		TemporalArchivoCB = new BufferedReader(new InputStreamReader(EntradaArchivoCB));
		
		String Registro = "";
		while ((Registro = TemporalArchivoCB.readLine()) != null)												
		{
			lista2.add(Registro);
		}
		
		try {
			LeerArchivo_Pricicpal = new FileInputStream(dpString("RutaArchivoMM_Aho"));
		} catch (Exception e) {
			return;
		}
													
		EntradaArchivoPrin = new DataInputStream(LeerArchivo_Pricicpal);				
		TemporalArchivoPrin = new BufferedReader(new InputStreamReader(EntradaArchivoPrin));
	
		String Registro2 = "";
		while ((Registro2 = TemporalArchivoPrin.readLine()) != null)												
		{
			if(!Registro2.toString().substring(0, 1).equals(" ") && !Registro2.toString().substring(0, 1).equals("S") ){
				if((Registro2.substring(277, 278).equals(" ")))
					Registro2= util.CorregirNUll(Registro2);
				
				no_cuenta = Registro2.substring(330, 340);
				movCredito = Integer.parseInt(util.getNoMov(Registro2.substring(600, 618)));
				movDebito = Integer.parseInt(util.getNoMov(Registro2.substring(748, 766)));
			
				if(movCredito+movDebito >= rango && !lista2.contains(no_cuenta))
					lista.add(no_cuenta);
			}
		}
		
		try {
			fichero = new FileWriter("D:\\MediosMagneticos\\AhorrosMensual\\CuentasBuscadas.txt", true);
			pw = new PrintWriter(fichero);
		} catch (IOException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		
		pintaCuentas(lista);
	}
	
	private void pintaCuentas(ArrayList<String> cuentas2) {
		
		for(int i =0; i<cuentas2.size(); i++){
			
			pw.println(cuentas2.get(i));
		}
		pw.flush();
		pw.close();
		
	}
}


