import dbc.*;

import resources.PoblarDB_CteHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;


/**
 * Description   : Functional Test Script
 * @author JGUTIE1
 */
public class PoblarDB_Cte extends PoblarDB_CteHelper
{
	String no_cuenta, fecha_transaccion, codigo_transaccion, trasancion, saldo, mestrans;
	ArrayList<String> lista = new ArrayList<String>();
	FileInputStream LeerArchivo_CuentasBuscadas, LeerArchivo_Pricicpal; 
	DataInputStream EntradaArchivoCB, EntradaArchivoPrin;												
	BufferedReader TemporalArchivoCB, TemporalArchivoPrin;																		
	DBconnection cxn;
	Utilitarios util;
	
	public void testMain(Object[] args) throws IOException 
	{
		LeerArchivo_CuentasBuscadas = new FileInputStream("D:\\MediosMagneticos\\CorrienteMensual\\CuentasBuscadas.txt");
		EntradaArchivoCB = new DataInputStream(LeerArchivo_CuentasBuscadas);												
		TemporalArchivoCB = new BufferedReader(new InputStreamReader(EntradaArchivoCB));
		
		if(!dpString("RutaArchivoExt").equals("")){
			try {
				LeerArchivo_Pricicpal = new FileInputStream(dpString("RutaArchivoExt"));
			} catch (Exception e) {
				// TODO: handle exception
			}
														
			EntradaArchivoPrin = new DataInputStream(LeerArchivo_Pricicpal);					
			TemporalArchivoPrin = new BufferedReader(new InputStreamReader(EntradaArchivoPrin));
							
			cxn = new DBconnection();// Instanciamos la clase conexion  
			util = new Utilitarios();// 
			
			poblarCuentasBuscadas();
			
			try {
				poblarTablaFiltrada();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	public void poblarCuentasBuscadas() throws IOException {
		
		String Registro = "";
		while ((Registro = TemporalArchivoCB.readLine()) != null)												
		{
			lista.add(Registro.toString());
		}
	}
	
	public void poblarTablaFiltrada() throws IOException, SQLException {
		
		String Registro2 = "";
		while ((Registro2 = TemporalArchivoPrin.readLine()) != null)												
		{
			if(Registro2.toString().substring(0, 1).equals("2")){
				no_cuenta = Registro2.toString().substring(6, 15);
				fecha_transaccion = Registro2.toString().substring(15, 23);
				codigo_transaccion = Registro2.toString().substring(23, 27);
				trasancion = util.getDecimales(Registro2.toString().substring(185, 201));
				saldo = util.getDecimales(Registro2.toString().substring(201, 217));
				mestrans =   Registro2.toString().substring(15, 17);
					
				//Condicional que limita el cargue del archivo a la cuenas que 
				//encuentre el el archivo Cuentas buscadas 		
				
					//if(lista.contains(no_cuenta)){
						
						String msg =cxn.ejecutar("INSERT INTO Mensual_Ext_2014_Cte VALUES ('" + no_cuenta  
								+"','"+ util.GetFecha(fecha_transaccion) +"','"+ codigo_transaccion +"'," + trasancion + ","+ saldo + ","+ mestrans +")");
					//}
			}
		}
	}
}	