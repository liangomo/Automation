package Anuales;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;

import resources.Anuales.RegistroControlAhorros_AnualHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class RegistroControlAhorros_Anual extends RegistroControlAhorros_AnualHelper
{
	/**
	 * @since  2017/03/06
	 * @author GORTEG1
	 */
	FileReader file;
	BufferedReader buffer;
	String cadena, nomArchivo, extension, linea;
	int x;
	BigInteger pago, retp, rcree, rasumc, retp2, pnded, rcree2, rasumc2, ipro, dev, imp, iva, sal, sal2; 
	BigInteger Regpago, Regretp, Regrcree, Regrasumc, Regretp2, Regpnded, Regrcree2, Regrasumc2, Regipro, Regdev, Regimp, Regiva, Regsal, Regsal2;
	
	public void testMain(Object[] args) 
	{
		
		cadena = "D:\\MediosMagneticos\\AhorrosAnual\\";
		nomArchivo = "ANUALAHORROS";
		extension = ".txt";
		
		pago = new BigInteger("0"); 
		retp = new BigInteger("0"); 
		rcree = new BigInteger("0"); 
		rasumc = new BigInteger("0"); 
		retp2 = new BigInteger("0"); 
		pnded = new BigInteger("0"); 
		rcree2 = new BigInteger("0"); 
		rasumc2 = new BigInteger("0"); 
		ipro = new BigInteger("0"); 
		dev = new BigInteger("0"); 
		imp = new BigInteger("0"); 
		iva = new BigInteger("0"); 
		sal = new BigInteger("0"); 
		sal2 = new BigInteger("0"); 
		
		
		try {
			
			file = new FileReader(cadena + nomArchivo + extension);
			buffer = new BufferedReader(file);
			
			while((linea = buffer.readLine())!= null)
			{
				if(!linea.substring(0, 2).equals("ST"))
				{
					pago = pago.add(new BigInteger(linea.substring(415,431))); 
					retp = retp.add(new BigInteger(linea.substring(452,468))); 
					rcree = rcree.add(new BigInteger(linea.substring(489,505))); 
					rasumc = rasumc.add(new BigInteger(linea.substring(526,542))); 
					retp2 = retp2.add(new BigInteger(linea.substring(563,579))); 
					pnded = pnded.add(new BigInteger(linea.substring(600,616))); 
					rcree2 = rcree2.add(new BigInteger(linea.substring(637,653))); 
					rasumc2 = rasumc2.add(new BigInteger(linea.substring(674,690))); 
					ipro = ipro.add(new BigInteger(linea.substring(711,727))); 
					dev = dev.add(new BigInteger(linea.substring(748,764))); 
					imp = imp.add(new BigInteger(linea.substring(785,801))); 
					iva = iva.add(new BigInteger(linea.substring(822,838))); 
					sal = sal.add(new BigInteger(linea.substring(859,875))); 
					sal2 = sal2.add(new BigInteger(linea.substring(896,912))); 

				}
				else
				{
					Regpago  = new BigInteger(linea.substring(85,101)); 
					Regretp = new BigInteger(linea.substring(122,138)); 
					Regrcree = new BigInteger(linea.substring(159,175)); 
					Regrasumc = new BigInteger(linea.substring(196,212)); 
					Regretp2 = new BigInteger(linea.substring(233,249)); 
					Regpnded = new BigInteger(linea.substring(270,286)); 
					Regrcree2 = new BigInteger(linea.substring(307,323)); 
					Regrasumc2 = new BigInteger(linea.substring(344,360)); 
					Regipro = new BigInteger(linea.substring(381,397)); 
					Regdev = new BigInteger(linea.substring(418,434)); 
					Regimp = new BigInteger(linea.substring(455,471)); 
					Regiva = new BigInteger(linea.substring(492,508)); 
					Regsal = new BigInteger(linea.substring(529,545)); 
					Regsal2 = new BigInteger(linea.substring(566,582)); 
				}
						
			}
			
			System.out.println("PAGO " + pago + "-" + Regpago);
			System.out.println("retp " + retp + "-" + Regretp);
			System.out.println("rcree " + rcree + "-" + Regrcree);
			System.out.println("rasumc " + rasumc + "-" + Regrasumc);
			System.out.println("retp2 " + retp2 + "-" + Regretp2);
			System.out.println("pnded " + pnded + "-" + Regpnded);
			System.out.println("rcree2 " + rcree2 + "-" + Regrcree2);
			System.out.println("rasumc2 " + rasumc2 + "-" + Regrasumc2);
			System.out.println("ipro " + ipro + "-" + Regipro);
			System.out.println("dev " + dev + "-" + Regdev);
			System.out.println("imp " + imp + "-" + Regimp);
			System.out.println("iva " + iva + "-" + Regiva);
			System.out.println("sal " + sal + "-" + Regsal);
			System.out.println("sal2 " + sal2 + "-" + Regsal2);

		} catch (FileNotFoundException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		
	}
}

