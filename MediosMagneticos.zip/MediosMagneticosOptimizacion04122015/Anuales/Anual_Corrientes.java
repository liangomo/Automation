package Anuales;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import resources.Anuales.Anual_CorrientesHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.value.managers.VectorValue;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Anual_Corrientes extends Anual_CorrientesHelper
{
	
	String line;
	long VarRetefuente, cree, comisionescte, intSobregiros, intPagados, Iva, impTimbre, GMF;
	int Clineas = 0, Ccuentas = 0;
	String[] Transacciones = new String[115];
	int CantFiles = 0;
	File dir = new File("D:\\MediosMagneticos\\CorrientesAnual\\");
	String[] ficheros = dir.list();
	int Vector[];
	long[] Mcuentas = new long[2779503];
	long[] Mcuentas2 = new long[2779503];
	Long Dimension;
	int Pos = 0;
	int Dif = 0;
	VectorValue vector = new VectorValue();
//	DBconnection cxn;
	
	public void testMain(Object[] args) throws ClassNotFoundException, SQLException, IOException 
	{
		
//		cxn = new DBconnection();
				
				FileWriter fichero = null;
				fichero = new FileWriter("D:\\MediosMagneticos\\CorrientesAnual\\Resultados.txt");
				PrintWriter pw = null;
				pw = new PrintWriter(fichero);
				
				ContarTiposTransacciones();
				ContarArchivos();
				LeerTransacciones();
				LlenarVectorCuentas();
				pw.println("Cuentas Corrientes");
				pw.println("Cuenta," + "Retefuente,"+"CREE,"+"ComisionesCte,"+"IntSob,"+"Intpag,"+"Iva,"+"ImpTim,"+"GMF,");
				retefuente(pw);
				pw.close();

			}

			public void LeerTransacciones() {
				for (int i = 0; i < ficheros.length; i++) {
					try {
						BufferedReader br = new BufferedReader(new FileReader(dir
								+ "\\" + "FiltradoFinal.txt"));
						// ejecuta un ciclo por la cantidad de lineas del archivo
						while ((line = br.readLine()) != null) {
							// Valida que la linea del archivo empiece por cc para
							// evitar las lineas resumen
							if (line.substring(1, 3).equals("CC")) {
								Clineas = Clineas + 1;
							}
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}

			public void LlenarVectorCuentas() throws SQLException {
				for (int i = 0; i < ficheros.length; i++) {
					try {
						BufferedReader br = new BufferedReader(new FileReader(dir
								+ "\\" + "FiltradoFinal.txt"));
						while ((line = br.readLine()) != null) {
							int Linea;
							int result;
							if (line.substring(0, 3).equals("2CC")) {
								Linea = Integer.parseInt(line.substring(6, 15));
								result = BuscarEnMcuentas(Linea);
								if (result == 100) {
									Mcuentas2[Dif] = (Mcuentas2[Dif] + Long
											.parseLong(line.substring(185, 199)));
								} else {
//									cxn.ejecutar("INSERT INTO Cuentas(M1, M2)" + "VALUES("+Linea+","+ line.substring(185,199)+")");
							        
									Mcuentas[Dif] = Linea;
									Mcuentas2[Dif] = Long.parseLong(line.substring(185,
											199));
									Ccuentas = Ccuentas + 1;
								}
								
								
								
							}
						}
						System.out.println("Cantidad de Insersiones: "+Ccuentas);
					} catch (IOException e) {
						e.printStackTrace();
					}

				}

			}

			public void retefuente(PrintWriter pw) throws SQLException {
			
				for (int d = 0; d < Ccuentas; d++) {
					if(Mcuentas[d]!=0)	
					{
					for (int i = 0; i < ficheros.length; i++) {
						try {
							BufferedReader br = new BufferedReader(new FileReader(dir
									+ "\\" + "FiltradoFinal.txt"));
							while ((line = br.readLine()) != null) {
								if (line.substring(0, 3).equals("2CC")) {
									if (Mcuentas[d] == Long.parseLong(line.substring(6,
											15))) {
										if (line.substring(23, 27).equals("0002")) {
											VarRetefuente = VarRetefuente
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0005")) {
											VarRetefuente = VarRetefuente
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0048")) {
											VarRetefuente = VarRetefuente
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0052")) {
											VarRetefuente = VarRetefuente
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0517")) {
											VarRetefuente = VarRetefuente
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0520")) {
											VarRetefuente = VarRetefuente
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0679")) {
											VarRetefuente = VarRetefuente
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0723")) {
											VarRetefuente = VarRetefuente
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0730")) {
											VarRetefuente = VarRetefuente
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0731")) {
											VarRetefuente = VarRetefuente
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("GT21")) {
											VarRetefuente = VarRetefuente
													+ Long.parseLong(line.substring(
															185, 199));
										}
										// Aqui inicia la validacion para CREE Corriente
										if (line.substring(23, 27).equals("0971")) {
											cree = cree
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0973")) {
											cree = cree
													- Long.parseLong(line.substring(
															185, 199));
										}
										// Aqui inicia la validacion para comisiones de
										// cta Corriente
										if (line.substring(23, 27).equals("0009")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0033")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0034")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0035")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0045")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0057")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0059")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0086")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0087")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0101")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0102")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0103")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0104")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0105")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0110")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0114")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0134")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0150")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0159")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0182")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0183")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0184")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0186")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0189")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0191")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0193")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0212")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0215")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0231")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0232")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0236")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0238")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0252")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0253")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0257")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0259")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0280")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0296")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0298")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0311")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0312")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0314")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0330")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0338")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0339")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0357")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0364")) {
											comisionescte = comisionescte
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0470")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0471")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0475")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0485")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0502")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0503")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0550")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0555")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0572")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0575")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0581")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0586")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0590")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0595")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0597")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0602")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0606")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0619")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0636")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0639")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0642")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0643")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0644")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0647")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0648")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0657")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0660")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0663")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0667")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0669")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0671")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0674")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0699")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0700")) {
											comisionescte = comisionescte
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0701")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0709")) {
											comisionescte = comisionescte
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0712")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0714")) {
											comisionescte = comisionescte
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0716")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0718")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0728")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0729")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0743")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0745")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0748")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0752")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0754")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0776")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0777")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0778")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0779")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0781")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0798")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0799")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0800")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0848")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0849")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0855")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0910")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0918")) {
											comisionescte = comisionescte
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0922")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0926")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0928")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0930")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0952")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0953")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0954")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0958")) {
											comisionescte = comisionescte
													+ Long.parseLong(line.substring(
															185, 199));
										}
										// Aqui inicia el analsis de las transacciones
										// de intereses sobregiros

										if (line.substring(23, 27).equals("0031")) {
											intSobregiros = intSobregiros
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0041")) {
											intSobregiros = intSobregiros
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("GT22")) {
											intSobregiros = intSobregiros
													+ Long.parseLong(line.substring(
															185, 199));
										}

										// Aqui inicia el analisis de las transacciones
										// de intereses pagados

										if (line.substring(23, 27).equals("0028")) {
											intPagados = intPagados
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0678")) {
											intPagados = intPagados
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("GT13")) {
											intPagados = intPagados
													+ Long.parseLong(line.substring(
															185, 199));
										}

										// Aqui inicia el analisis de las transacciones
										// de iva

										if (line.substring(23, 27).equals("0007")) {
											Iva = Iva
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0008")) {
											Iva = Iva
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0270")) {
											Iva = Iva
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0285")) {
											Iva = Iva
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0508")) {
											Iva = Iva
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0628")) {
											Iva = Iva
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0938")) {
											Iva = Iva
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("GT26")) {
											Iva = Iva
													+ Long.parseLong(line.substring(
															185, 199));
										}

										// Aqui inicia el analisis de las transacciones
										// de inpTimbre

										if (line.substring(23, 27).equals("0509")) {
											impTimbre = impTimbre
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0516")) {
											impTimbre = impTimbre
													+ Long.parseLong(line.substring(
															185, 199));
										}

										// Aqui inicia el analisis de las transacciones
										// de GMF

										if (line.substring(23, 27).equals("GT09")) {
											GMF = GMF
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0515")) {
											GMF = GMF
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0940")) {
											GMF = GMF
													+ Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0518")) {
											GMF = GMF
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("GT10")) {
											GMF = GMF
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0860")) {
											GMF = GMF
													- Long.parseLong(line.substring(
															185, 199));
										} else if (line.substring(23, 27)
												.equals("0939")) {
											GMF = GMF
													- Long.parseLong(line.substring(
															185, 199));
										}

									}
								}
							}
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					
					pw.println(Mcuentas[d]+","		 
							+ VarRetefuente+","	 
							+ cree+","
							+ comisionescte+","
							+ intSobregiros+","
							+ intPagados+","
							+ Iva+","
							+ impTimbre+","
							+ GMF);
				VarRetefuente = 0;
				cree = 0;
				comisionescte = 0;
				intSobregiros = 0;
				intPagados = 0;
				Iva = 0;
				impTimbre = 0;
				GMF = 0;
						
//						cxn.ejecutar("INSERT INTO Resultados(Cuenta, ValorRetefuente, Cree, ComisCorriente, IntSobregiros, IntPagados, Iva, ImpTimbre, Gmf)" + 
//								"VALUES("+Mcuentas[d]+","+ VarRetefuente+","
//								+cree+","+comisionescte+","+intSobregiros+","+intPagados+","+Iva+","+impTimbre+","+GMF+")");
					VarRetefuente = 0;
					cree = 0;
					comisionescte = 0;
					intSobregiros = 0;
					intPagados = 0;
					Iva = 0;
					impTimbre = 0;
					GMF = 0;
				}
				}

			}

			public int BuscarEnMcuentas(int Linea) {
				int Indice1 = 0;
				int NotF = 0;

				for (int i = 0; i <= Mcuentas.length; i++) {
					if (Mcuentas[i] == 0) {
						Dif = i;
						i = Mcuentas.length + 1;
						Indice1 = 200;
					} else if (Mcuentas[i] == Linea) {
						Indice1 = 100;
						Dif = i;
						i = Mcuentas.length;

					} else {
						Indice1 = 200;

					}

				}
				return Indice1;
			}

			public void ContarTiposTransacciones() {
				int Cant = 0;
				for (int i = 0; i <= 114; i++) {
					if (Transacciones[i] != "")
						Cant = Cant + 1;

				}
			}

			public void ContarArchivos() {

				if (ficheros == null)
					System.out.println("No hay ficheros en el directorio especificado");
				else {
					for (int x = 0; x < ficheros.length; x++) {
						CantFiles = CantFiles + 1;
						System.out.println("Cantidad Archivos Encontrados: "+CantFiles);
					}

				}
			}

		}



