package Anuales;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import resources.Anuales.Anual_AhorrosHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.value.managers.VectorValue;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Anual_Ahorros extends Anual_AhorrosHelper
{
	
	String cadena, nomArchivo, extension, line, Codtrans;
	BigInteger cree, comisiones, intPagados, iva, retefuente, gmf, trans;
	BigInteger creeMed, comisionesMed, intPagadosMed, ivaMed, retefuenteMed;
	FileReader file, fileMed;
	BufferedReader buffer, bufferMed;
	FileWriter fichero;
	PrintWriter pw;
	boolean validacionMedios, validacionCampos_0;  
	ArrayList<String> cuentas = new ArrayList<String>();
	ArrayList<String> rtr = new ArrayList<String>();
	ArrayList<String> rts = new ArrayList<String>();
	ArrayList<String> creer = new ArrayList<String>();
	ArrayList<String> crees = new ArrayList<String>();
	ArrayList<String> icr = new ArrayList<String>();
	ArrayList<String> ics = new ArrayList<String>();
	ArrayList<String> ipr = new ArrayList<String>();
	ArrayList<String> ips = new ArrayList<String>();
	ArrayList<String> ivr = new ArrayList<String>();
	ArrayList<String> ivs = new ArrayList<String>();
	ArrayList<String> gmfr = new ArrayList<String>();
	ArrayList<String> gmfs = new ArrayList<String>();
	
	public void testMain(Object[] args) throws ClassNotFoundException, SQLException, IOException
	{
		//Relacion por Cod Transaccion CREE
		crees.add("0971");
		creer.add("0973");
		//Relacion por Cod Transaccion IC COMISIONES
		icr.add("0364"); icr.add("0700");
		icr.add("0709"); icr.add("0714");
		icr.add("0918"); ics.add("0009");
		ics.add("0009");ics.add("0033");ics.add("0034");ics.add("0035");ics.add("0036");
		ics.add("0057");ics.add("0059");ics.add("0086");ics.add("0087");ics.add("0101");
		ics.add("0102");ics.add("0103");ics.add("0104");ics.add("0105");ics.add("0110");
		ics.add("0114");ics.add("0150");ics.add("0159");ics.add("0182");ics.add("0183");
		ics.add("0184");ics.add("0186");ics.add("0189");ics.add("0191");ics.add("0193");
		ics.add("0212");ics.add("0215");ics.add("0296");ics.add("0298");ics.add("0311");
		ics.add("0312");ics.add("0314");ics.add("0330");ics.add("0338");ics.add("0339");
		ics.add("0357");ics.add("0470");ics.add("0471");ics.add("0475");ics.add("0485");
		ics.add("0502");ics.add("0503");ics.add("0550");ics.add("0555");ics.add("0572");
		ics.add("0575");ics.add("0581");ics.add("0586");ics.add("0590");ics.add("0595");
		ics.add("0597");ics.add("0606");ics.add("0619");ics.add("0627");ics.add("0639");
		ics.add("0642");ics.add("0643");ics.add("0644");ics.add("0647");ics.add("0648");
		ics.add("0657");ics.add("0660");ics.add("0663");ics.add("0667");ics.add("0669");
		ics.add("0671");ics.add("0674");ics.add("0677");ics.add("0699");ics.add("0701");
		ics.add("0712");ics.add("0716");ics.add("0718");ics.add("0728");ics.add("0729");
		ics.add("0743");ics.add("0745");ics.add("0748");ics.add("0752");ics.add("0754");
		ics.add("0776");ics.add("0777");ics.add("0778");ics.add("0779");ics.add("0781");
		ics.add("0797");ics.add("0798");ics.add("0799");ics.add("0800");ics.add("0848");
		ics.add("0849");ics.add("0855");ics.add("0910");ics.add("0922");ics.add("0926");
		ics.add("0928");ics.add("0930");ics.add("GT17");ics.add("GT18");ics.add("GT19");
		ics.add("GT21");
		//Relacion por Cod Transaccion IP Intereses Pagados
		ipr.add("0042"); ipr.add("GT11");
		ips.add("0041"); ips.add("0678");
		ips.add("GT01"); ips.add("GT13");
		//Relacion por Cod Transaccion IVR IVA
		ivr.add("0008"); ivr.add("0736");
		ivr.add("0938"); ivs.add("0007");
		ivs.add("0508"); ivs.add("0628");
		ivs.add("0735"); ivs.add("GT08");
		//Relacion por Cod Transaccion RT Retefuente
		rtr.add("0048"); rtr.add("0051"); rtr.add("0723"); 
		rtr.add("0731"); rtr.add("GT12"); rts.add("0052");
		rts.add("0517"); rts.add("0679");
		rts.add("0730"); rts.add("GT06");
		rts.add("GT14");
		//Relacion por Cod Transaccion GMF Gravamen Financiero
		gmfs.add("0515"); gmfs.add("0940");
		gmfs.add("GT09"); gmfr.add("0043");
		gmfr.add("0518"); gmfr.add("0860");
		gmfr.add("0939"); gmfr.add("GT10");
		
				
		cadena = "D:\\MediosMagneticos\\AhorrosAnual\\";
		nomArchivo = "FiltradoFinal";
		extension = ".txt";
				
		try {
			
			file = new FileReader(cadena + nomArchivo + extension);
			buffer = new BufferedReader(file);
			fichero = new FileWriter(cadena + "Resultados" + extension);
			pw = new PrintWriter(fichero);
			
			pintaCuentas("CUENTA; CREE; COMISIONES; INT_PAGADOS; IVA; RETEFUENTE; GMF; VALIDACION_MEDIOS; VALIDACION_CAMPOS_0");
			
			line = "";
			while((line = buffer.readLine())!= null)
			{
				if (line.substring(1, 3).equals("AH")) {
					if(!cuentas.contains(line.substring(6,16)))
						cuentas.add(line.substring(6,16));
				}
			}
			        
			for (String cuenta : cuentas) {
				AnalisarCuenta(cuenta);
			}
			
			pw.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
			
	public void AnalisarCuenta(String cuenta) {
		
		cree = new BigInteger("0"); 
		comisiones= new BigInteger("0"); 
		intPagados = new BigInteger("0");  
		iva = new BigInteger("0"); 
		retefuente = new BigInteger("0");
		gmf = new BigInteger("0");
		validacionCampos_0 = false;
		validacionMedios = false;
					
		try {
			
			file.close();
			buffer.close();
			file = new FileReader(cadena + nomArchivo + extension);
			buffer = new BufferedReader(file);
			
			while((line = buffer.readLine())!= null)
			{
				if (line.substring(1, 3).equals("AH")) 
				{
					if(line.substring(6,16).equals(cuenta)){
						Codtrans = line.substring(24, 28);
						trans = new BigInteger(line.substring(187,200));
				
						//Operaciones Retefuente
						if(rts.contains(Codtrans))
							retefuente = retefuente.add(trans); 
						else if(rtr.contains(Codtrans))
							retefuente = retefuente.subtract(trans); 
						//Operaciones CREE
						else if(crees.contains(Codtrans))
							cree = cree.add(trans); 
						else if(creer.contains(Codtrans))
							cree = cree.subtract(trans); 
						//Opreciones Comisiones
						else if(ics.contains(Codtrans))
							comisiones =comisiones.add(trans); 
						else if(icr.contains(Codtrans))
							comisiones =comisiones.subtract(trans); 
						//Operaciones Intereses Pagados
						else if(ips.contains(Codtrans))
							intPagados = intPagados.add(trans); 
						else if(ipr.contains(Codtrans))
							intPagados = intPagados.subtract(trans); 
						//Operaciones IVA 
						else if(ivs.contains(Codtrans))
							iva = iva.add(trans); 
						else if(ivr.contains(Codtrans))
							iva = iva.subtract(trans); 
						else if(gmfs.contains(Codtrans))
							gmf = gmf.add(trans); 
						else
							gmf = gmf.subtract(trans);
					}
				}
			}
					
			fileMed = new FileReader(cadena + "MediosFiltrado" + extension);
			bufferMed = new BufferedReader(fileMed);
					
			while((line = bufferMed.readLine())!= null)
			{
				if(line.substring(330,340).equals(cuenta))
				{
					creeMed  = new BigInteger(line.substring(489,505));
					comisionesMed = new BigInteger(line.substring(711,727));
					intPagadosMed = new BigInteger(line.substring(415,431));
					ivaMed = new BigInteger(line.substring(785,801));
					retefuenteMed = new BigInteger(line.substring(452,468));
					
					if(line.substring(526,544).equals("000000000000000000")){
						if(line.substring(563,581).equals("000000000000000000")){
							if(line.substring(600,618).equals("000000000000000000")){
								if(line.substring(637,655).equals("000000000000000000")){
									if(line.substring(674,692).equals("000000000000000000")){
										
										if(line.substring(859,877).equals("000000000000000000") && !line.substring(896,914).equals("000000000000000000"))
											validacionCampos_0 = true;
										if(!line.substring(859,877).equals("000000000000000000") && line.substring(896,914).equals("000000000000000000"))
											validacionCampos_0 = true;
									}
								}
							}
						}
					}
				}
			}
			
			if(cree.equals(creeMed)){
				if(comisiones.equals(comisionesMed)){
					if(intPagados.equals(intPagadosMed)){
						if(iva.equals(ivaMed)){
							if(retefuente.equals(retefuenteMed))
								validacionMedios = true;
						}
					}
				}
			}
			
			pintaCuentas(cuenta + ";" + cree + ";" + comisiones + ";" + intPagados + ";" + iva + ";" + retefuente + ";" + gmf + ";" + validacionMedios + ";" + validacionCampos_0);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
			
	private void pintaCuentas(String cadena) {
		pw.println(cadena);		
	}
}
				