package Firmas;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import resources.Firmas.ST_FirmasSTHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */

public class ST_FirmasST extends ST_FirmasSTHelper
{
	
	String Ident_1, Ident_2, Cuenta_1, Cuenta_2;
	String ruta1, ruta2;
	int cantidad, aux, porcentaje;
	DBconnection cxn;
	ResultSet resultado2;
	ArrayList<Integer> Porcentajes = new ArrayList<Integer>();
		
	public void testMain(Object[] args) throws IOException, SQLException
	{
		cxn = new DBconnection();
		ruta1 = "D:\\MediosMagneticos\\Firmas Ahorros\\" + dpString("SegundosTitulares");
		ruta2 = "D:\\MediosMagneticos\\Firmas Ahorros\\" + dpString("FirmasAutorizadas");
		porcentaje =10;
		aux = 1;
			
		cxn.ejecutar("DELETE " +
				"FROM PT_FirmasST");
		
		PoblarDBFirmas(ruta1);
		System.out.println("DB Poblada");
		
		FileInputStream fstream = new FileInputStream(ruta2);
		DataInputStream in = new DataInputStream(fstream);
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		
		String strLine= "";
		while ((strLine = br.readLine()) != null) {
			if(!strLine.substring(0, 2).equals("ST")){
				cantidad++;
			}
		}
		for(int i = 1; i<=10; i++) Porcentajes.add(cantidad/i);
		
		FileInputStream fstream2 = new FileInputStream(ruta2);
		DataInputStream in2 = new DataInputStream(fstream2);
		BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
		
		while ((strLine = br2.readLine()) != null) {
			if(!strLine.substring(0, 2).equals("ST")){
				Cuenta_1 = strLine.substring(2,20);
				Ident_1 = strLine.substring(28, 48);
				if(Porcentajes.contains(aux)){
					System.out.println("Ejecucion al " + porcentaje + "%");
					porcentaje += 10;
				}
				aux++;
				resultado2 = cxn.Consulta("SELECT COUNT(*) " +
						"FROM PT_FirmasST " +
						"WHERE Cuenta= '" + Cuenta_1 +  "' and Identificacion= '" + Ident_1 + "'");
			
				resultado2.next();
				if(resultado2.getInt(1)!=0)
					LogPrimerTitularVSFirmasIM("Identificaci�n : " + Ident_1 + " - Cuenta : " + Cuenta_1 );
			}
		}
	}
			
	public void LogPrimerTitularVSFirmasIM(String listar) 														
	{ 		
		System.out.println("Firma autorizada encontrada en segundos titulares");
		try    													
		{
			PrintStream Salida = new PrintStream(new FileOutputStream("D:\\MediosMagneticos\\Firmas Ahorros\\" + dpString("Mes") + "_Repetidos_SegundoTitularST.TXT",true));
			Salida.println(listar);												
			Salida.close();												
		} 													
		catch (FileNotFoundException e) 													
		{													
			e.printStackTrace();												
		}													
	}
	
	public void PoblarDBFirmas(String ruta) throws IOException{
		
		FileInputStream fstream1 = new FileInputStream(ruta);
		DataInputStream in1 = new DataInputStream(fstream1);
		BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
		
		
		String strLine1;
		while ((strLine1 = br1.readLine()) != null) {
			if(!strLine1.substring(0, 2).equals("ST")){
				Cuenta_2 = strLine1.substring(2, 20);
				Ident_2 = strLine1.substring(28, 48);
					
				String msg =cxn.ejecutar("INSERT INTO PT_FirmasST VALUES ('" + Cuenta_2 +  
						"','"+ Ident_2 + "')");
			}
		}
		
	}
}



