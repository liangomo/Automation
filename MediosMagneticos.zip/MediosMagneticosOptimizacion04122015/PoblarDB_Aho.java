import dbc.*;

import resources.PoblarDB_AhoHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;


/**
 * Description   : Functional Test Script
 * @author JGUTIE1
 */
public class PoblarDB_Aho extends PoblarDB_AhoHelper
{
	String no_cuenta, fecha_transaccion, codigo_transaccion, trasancion, saldo, mestrans;
	
	ArrayList<String> lista;
	ArrayList<String> lista1;
	ArrayList<String> lista2;
	ArrayList<String> lista3;
	ArrayList<String> lista4;
	ArrayList<String> lista5;
	ArrayList<String> lista6;
	ArrayList<String> lista7;
	ArrayList<String> lista8;
	ArrayList<String> lista9;
	
	FileInputStream LeerArchivo_CuentasBuscadas, LeerArchivo_Pricicpal; 
	DataInputStream EntradaArchivoCB, EntradaArchivoPrin;												
	BufferedReader TemporalArchivoCB, TemporalArchivoPrin;																		
	DBconnection cxn;
	Utilitarios util;
	
	public void testMain(Object[] args) throws IOException 
	{
		int mes = dpInt("Mes");
		
		lista = new ArrayList<String>();
		lista1 = new ArrayList<String>();
		lista2 = new ArrayList<String>();
		lista3 = new ArrayList<String>();
		lista4 = new ArrayList<String>();
		lista5 = new ArrayList<String>();
		lista6 = new ArrayList<String>();
		lista7 = new ArrayList<String>();
		lista8 = new ArrayList<String>();
		lista9 = new ArrayList<String>();
			
		LeerArchivo_CuentasBuscadas = new FileInputStream("D:\\MediosMagneticos\\AhorrosMensual\\CuentasBuscadas.txt");
		EntradaArchivoCB = new DataInputStream(LeerArchivo_CuentasBuscadas);												
		TemporalArchivoCB = new BufferedReader(new InputStreamReader(EntradaArchivoCB));
		

		if(!dpString("RutaArchivoExt_Aho").equals("")){
			try {
				LeerArchivo_Pricicpal = new FileInputStream(dpString("RutaArchivoExt_Aho"));	
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
						
		EntradaArchivoPrin = new DataInputStream(LeerArchivo_Pricicpal);											
		TemporalArchivoPrin = new BufferedReader(new InputStreamReader(EntradaArchivoPrin));
						
		cxn = new DBconnection();// llamamos a la clase conexion  
		util = new Utilitarios();// 
		
		poblarCuentasBuscadas();
		
		try {
			poblarTablaFiltrada();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void poblarCuentasBuscadas() throws IOException {
		
		String Registro = "";
		int num= 0;
		
		while ((Registro = TemporalArchivoCB.readLine()) != null)												
		{
			num =Integer.parseInt(Registro.substring(1,2));
			switch (num) {
			case (0):
				lista.add(Registro);
				break;
			case (1):
				lista1.add(Registro);
				break;
			case (2):
				lista2.add(Registro);
				break;
			case (3):
				lista3.add(Registro);
				break;
			case (4):
				lista4.add(Registro);
				break;
			case (5):
				lista5.add(Registro);
				break;
			case (6):
				lista6.add(Registro);
				break;
			case (7):
				lista7.add(Registro);
				break;
			case (8):
				lista8.add(Registro);
				break;
			default:
				lista9.add(Registro);
				break;
			}
		
		}
	}
	
	public void poblarTablaFiltrada() throws IOException, SQLException {
		
		int numero= 0;
		String Registro2 = "";
		while ((Registro2 = TemporalArchivoPrin.readLine()) != null)												
		{
		if(Registro2.toString().substring(0, 1).equals("2")){
			
			boolean existe= false;	
			no_cuenta = Registro2.toString().substring(6, 16);
			fecha_transaccion = Registro2.toString().substring(16, 24);
			codigo_transaccion = Registro2.toString().substring(24, 28);
			trasancion = util.getDecimales(Registro2.toString().substring(186, 202));				
			saldo = util.getDecimales(Registro2.toString().substring(202, 218));
			mestrans =   Registro2.toString().substring(16, 18);
				
				//Condicional que limita el cargue del archivo a la cuenas que 
				//Encuentre el el archivo Cuentas buscadas 		
						
				numero =Integer.parseInt(Registro2.substring(7,8));
				switch (numero) {
				case (0):
					if(lista.contains(no_cuenta)) existe=true;
					break;
				case (1):
					if(lista1.contains(no_cuenta)) existe=true;
					break;
				case (2):
					if(lista2.contains(no_cuenta)) existe=true;
					break;
				case (3):
					if(lista3.contains(no_cuenta)) existe=true;
					break;
				case (4):
					if(lista4.contains(no_cuenta)) existe=true;
					break;
				case (5):
					if(lista5.contains(no_cuenta)) existe=true;
					break;
				case (6):
					if(lista6.contains(no_cuenta)) existe=true;
					break;
				case (7):
					if(lista7.contains(no_cuenta)) existe=true;
					break;
				case (8):
					if(lista8.contains(no_cuenta)) existe=true;
					break;
				default:
					if(lista9.contains(no_cuenta)) existe=true;
					break;
				}
				
				if(existe==true){
					
					cxn.ejecutar("INSERT INTO Mensual_Ext_2014_Aho VALUES ('" + no_cuenta  
							+"','"+ util.GetFecha(fecha_transaccion) +"','"+ codigo_transaccion +"'," + trasancion + ","+ saldo + ","+ mestrans +")");
				}
			}
		}
	}
}

