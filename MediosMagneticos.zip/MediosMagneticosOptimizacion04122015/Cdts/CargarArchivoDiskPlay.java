package Cdts;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import resources.Cdts.CargarArchivoDiskPlayHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
/**
 * Description   : Functional Test Script
 * @author gorteg1
 */
public class CargarArchivoDiskPlay extends CargarArchivoDiskPlayHelper
{
	String cadena, new9, new44, new48;
	StringTokenizer st;
	String[] pos = new String[119];
	int num;
	boolean s = true;
	DBconnection cxn;
	
	public void testMain(Object[] args) 
	{
		cxn = new DBconnection();// llamamos a la clase conexion  
		try {
			FileReader f = new FileReader("D:\\MediosMagneticos\\CDTS\\"+ dpString("DiskPlay")+ ".txt");
			BufferedReader b = new BufferedReader(f);
			  while((cadena = b.readLine())!=null) {
				  st = new StringTokenizer(cadena,";");
				  num = 0;
				  new9 = "";
				  new44 = "";
				  new48 = "";
				  while (st.hasMoreTokens()){
					  pos[num] = st.nextToken();
					  num++;
				  }
				  for (int x=0; x <  pos[44].length(); x++) {
					  	if ( pos[44].charAt(x) != ' ')
					  		new44 +=  pos[44].charAt(x);
				  }
				  for (int x=0; x <  pos[48].length(); x++) {
					  if ( pos[48].charAt(x) != ' ')
						  new48 +=  pos[48].charAt(x);
				  }
				  for (int x=0; x <  pos[9].length(); x++) {
					  if ( pos[9].charAt(x) != ' ')
						  new9 +=  pos[9].charAt(x);
				  }
				  cxn.ejecutar("INSERT INTO CDT_DiskPlay " +
						  		"VALUES ('" + pos[0] +"', '" + //Control1
						  		pos[1] + "', '" +  	//Control2
						  		pos[2] + "', '" +	//Control3
						  		pos[3] + "', '" +	//Control4
						  		pos[4] + "', '" +	//NoCuenta
						  		pos[7].substring(1) + "', '" +	//NoIdent
						  		pos[8] + "', '" +	//FechaApertura
						  		new9 + "', '" +		//Nombre_Cuenta
				  				pos[10] + "', '" +    //Producto
						  		pos[11] + "', '" +	//Estado
						  		pos[12] + "', '" +	//Fecha_Ult_Dep
						  		pos[21] + "', " +	//Cta_abono_Int
						  		pos[28] + ", " +	//PLazo
						  		pos[29] + ", '" +	//Periodicidad
						  		pos[30] + "', " + 	//Modalidad
						  		new44 + ", " +		//Tasa_Current
						  		new48 + ", " +		//Int_Brut_Causad
						  		pos[49] + ", " +	//Int_Un_dia
						  		pos[50] + ", '" +	//Int Acum_Mes
						  		pos[53] + "', " +	//Tipo_Retencion
						  		dpString("Mes") + ")"); //Mes

			  }
		        b.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
		// TODO Bloque catch generado autom�ticamente
		e.printStackTrace();
		}
 
	}
}

