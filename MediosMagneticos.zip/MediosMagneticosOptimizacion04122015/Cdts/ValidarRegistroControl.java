package Cdts;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import resources.Cdts.ValidarRegistroControlHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
/**
 * Description   : Functional Test Script
 * @author gorteg1
 */
public class ValidarRegistroControl extends ValidarRegistroControlHelper
{
	DBconnection cxn;
	String cadena;
	double saldoInicialAll, inversionAll, intCausadoAll, intPagadoAll, saldoFinalAll; 
	double saldoInicial, inversion, intCausado, intPagado, saldoFinal; 
	double numRegistrosAll, numRegistros; 
	int mes;
	ArrayList<String> resultados = new ArrayList<>();
	FileWriter fichero;
	PrintWriter pw;
	
	public void testMain(Object[] args) 
	{
		ArrayList<Boolean> listaResultados = new ArrayList<Boolean>();
		ArrayList<String> listaVariables = new ArrayList<String>();
		
		saldoInicialAll = 0;
		inversionAll = 0;
		intCausadoAll =0; intPagadoAll =0; 
		saldoFinalAll = 0;
		numRegistrosAll = 0;
		mes = dpInt("Mes");
		
		cxn = new DBconnection();// llamamos a la clase conexion  
		try {
			fichero = new FileWriter("D:\\MediosMagneticos\\CDTS\\ValidacionRegistroControl.txt", true);
			pw = new PrintWriter(fichero);
			
			FileReader f = new FileReader("D:\\MediosMagneticos\\CDTS\\"+ dpString("Medios")+ ".txt");
			BufferedReader b = new BufferedReader(f);
			
			while((cadena = b.readLine())!=null) {
				if(cadena.substring(0,2).equals("CD")){
					
					numRegistros = Double.parseDouble(cadena.substring(17,24));
					saldoInicial =  Double.parseDouble(cadena.substring(48,64));
					inversion =  Double.parseDouble(cadena.substring(85,101));
					intCausado =  Double.parseDouble(cadena.substring(122,138));
					intPagado =  Double.parseDouble(cadena.substring(159,175));
					saldoFinal =  Double.parseDouble(cadena.substring(196,212));
					
					
				}
				else
				{
					numRegistrosAll++;
					saldoInicialAll += Double.parseDouble(cadena.substring(378,394));
					inversionAll += Double.parseDouble(cadena.substring(415,431)); 
					intCausadoAll += Double.parseDouble(cadena.substring(452,468));
					intPagadoAll += Double.parseDouble(cadena.substring(489,505));
					saldoFinalAll += Double.parseDouble(cadena.substring(526,542));		
				}
			}
			b.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}	  
		
		
		listaVariables.add("No_Registros");
		if(numRegistros - numRegistrosAll >1 || numRegistros - numRegistrosAll <-1)
			listaResultados.add(true);
		else 
			listaResultados.add(false);
		
		listaVariables.add("Saldo_Inicial");
		if(saldoInicial - saldoInicialAll >1 || saldoInicial - saldoInicialAll <-1)
			listaResultados.add(true);
		else 
			listaResultados.add(false);
		
		listaVariables.add("Inversion");
		if(inversion - inversionAll >1 || inversion - inversionAll <-1)
			listaResultados.add(true);
		else 
			listaResultados.add(false);
		
		listaVariables.add("Interes_Causado");
		if(intCausado - intCausadoAll >1 || intCausado - intCausadoAll <-1)
			listaResultados.add(true);
		else 
			listaResultados.add(false);
		
		listaVariables.add("Interes_Pagado");
		if(intPagado - intPagadoAll >1 || intPagado - intPagadoAll <-1)
			listaResultados.add(true);
		else 
			listaResultados.add(false);
		
		listaVariables.add("Saldo_Final");
		if(saldoFinal - saldoFinalAll >1 || saldoFinal - saldoFinalAll<-1)
			listaResultados.add(true);
		else 
			listaResultados.add(false);
		
		if(listaResultados.contains(true))
		{
			resultados.add("Inconsistencia registro de Control del archivo de Medios Magenticos Mes: " + mes );
			resultados.add("Variables Inconsistentes: ");
			for (int i = 0; i < listaResultados.size(); i++) {
				if(listaResultados.get(i)==true)
					resultados.add(listaVariables.get(i));
			}
			
		}
		else
			resultados.add("Registro de Control CORRECTO para archivo Medios Magenticos Mes: " + mes );
		
		pintaCuentas(resultados);
		resultados.clear();
	}
	private void pintaCuentas(ArrayList<String> cuentas2){
		for(int i =0; i<cuentas2.size(); i++){
			
			pw.println(cuentas2.get(i));
		}
		pw.flush();
		pw.close();
		
	}
}
