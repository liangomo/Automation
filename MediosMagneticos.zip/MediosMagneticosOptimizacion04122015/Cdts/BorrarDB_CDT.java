package Cdts;
import resources.Cdts.BorrarDB_CDTHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class BorrarDB_CDT extends BorrarDB_CDTHelper
{
	DBconnection cxn;
	
	public void testMain(Object[] args) 
	{
		cxn = new DBconnection();// Instanciamos la clase conexion  
		
		cxn.ejecutar("DELETE " +
						"FROM CDT_DiskPlay");
		
		cxn.ejecutar("DELETE " +
						"FROM CDT_Inconsitentes");
		
		cxn.ejecutar("DELETE " +
						"FROM CDT_Medios");
		
	}
}

