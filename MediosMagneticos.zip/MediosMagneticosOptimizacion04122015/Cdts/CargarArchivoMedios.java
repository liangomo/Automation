package Cdts;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import resources.Cdts.CargarArchivoMediosHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
/**
 * Description   : Functional Test Script
 * @author gorteg1
 */
public class CargarArchivoMedios extends CargarArchivoMediosHelper
{
	DBconnection cxn;
	String cadena;
	
	public void testMain(Object[] args) 
	{
		cxn = new DBconnection();// llamamos a la clase conexion  
		try {
			FileReader f = new FileReader("D:\\MediosMagneticos\\CDTS\\"+ dpString("Medios")+ ".txt");
			BufferedReader b = new BufferedReader(f);
			while((cadena = b.readLine())!=null) {
				  if(!cadena.substring(0,2).equals("CD")){
					  cxn.ejecutar("INSERT INTO CDT_Medios " +
						  		"VALUES ('" + cadena.substring(326,340) +"', '" + //NoCuenta
						  		cadena.substring(12,22) + "', " +  	//NoIdent
						  		cadena.substring(378,394) + ", " +	//SaldoInicial
						  		cadena.substring(415,431) + ", " +	//Inversion
						  		cadena.substring(452,468) + ", " +	//IntCausado
						  		cadena.substring(489,505) + ", " +	//IntPagado
						  		cadena.substring(526,542) + ", " +	//SaldoFinal
						  		dpString("Mes") + ")"); //Mes
		
				  }
			}
			b.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}	  
	}
}
