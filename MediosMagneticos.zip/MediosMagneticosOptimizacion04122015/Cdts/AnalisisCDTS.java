package Cdts;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import resources.Cdts.AnalisisCDTSHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
import dbc.Utilitarios;
/**
 * Description   : Functional Test Script
 * @author gorteg1
 */
public class AnalisisCDTS extends AnalisisCDTSHelper
{
	DBconnection cxn;
	Utilitarios util;
	ResultSet consultaDiskPlay, consultaMedios;
	BufferedReader TemporalArchivoCB;
	DataInputStream EntradaArchivoCB;
	FileInputStream LeerArchivo_CuentasBuscadas;
	ArrayList<String> lista = new ArrayList<String>();
	String control1, control2, control3, control4, noCuenta, noIdent;
	String fechaApertura, fombre_Cuenta, estado, fecha_Ult_Dep, cta_Abono_Int, modalidad, tipo_Retencion;
	double tasa_Current, int_Brut_Causad, int_Un_Dia, int_Acum_Mes;
	double saldoInicial, inversion, intCausado, intPagado, saldoFinal;
	double intDiarioCalculado, direfenciaIntDiario, intCausadoCalculado;
	double diferenciaIntDiario, diferenciaIntCausad, diferenciaIntPagado, retancionCalculada;
	int mes, a�o;
	
	public void testMain(Object[] args) 
	{
		cxn = new DBconnection();
		util = new Utilitarios();
		mes = Integer.parseInt(dpString("Mes"));
		a�o = 2016;
		
		try {
			LeerArchivo_CuentasBuscadas = new FileInputStream("D:\\MediosMagneticos\\CDTS\\CuentasBuscadas.txt");
			EntradaArchivoCB = new DataInputStream(LeerArchivo_CuentasBuscadas);												
			TemporalArchivoCB = new BufferedReader(new InputStreamReader(EntradaArchivoCB));
			
			String Registro = "";
			while ((Registro = TemporalArchivoCB.readLine()) != null)												
			{
				lista.add(Registro.toString());
			}
			
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}

		consultaDiskPlay = cxn.Consulta("SELECT Control1, Control2, Control3, Control4, NoCuenta, " +
						"NoIdent, FechaApertura, Nombre_Cuenta, Estado, Fecha_Ult_Dep, " +
						"Cta_Abono_Int, Modalidad, Tasa_Current, Int_Brut_Causad, " +
						"Int_Un_Dia, Int_Acum_Mes, Tipo_Retencion, Mes " +
						"FROM CDT_DiskPlay " +
						"WHERE Mes = " + mes);
		
		
		try {
			while(consultaDiskPlay.next()){
				
				control1 = consultaDiskPlay.getString(1);
				control2 = consultaDiskPlay.getString(2);
				control3 = consultaDiskPlay.getString(3);
				control4 = consultaDiskPlay.getString(4);
				noCuenta = consultaDiskPlay.getString(5);
				noIdent = consultaDiskPlay.getString(6);
				fechaApertura = consultaDiskPlay.getString(7); 
				fombre_Cuenta = consultaDiskPlay.getString(8);
				estado = consultaDiskPlay.getString(9);
				fecha_Ult_Dep = consultaDiskPlay.getString(10);
				cta_Abono_Int = consultaDiskPlay.getString(11);
				modalidad = consultaDiskPlay.getString(12);
				tasa_Current = consultaDiskPlay.getDouble(13);
				int_Brut_Causad = consultaDiskPlay.getDouble(14);
				int_Un_Dia = consultaDiskPlay.getDouble(15);
				int_Acum_Mes = consultaDiskPlay.getDouble(16);
				tipo_Retencion = consultaDiskPlay.getString(17);
				
//				if(lista.contains(noCuenta)){
								
					consultaMedios = cxn.Consulta("SELECT SaldoInicial, Inversion, "+
							"IntCausado, IntPagado, SaldoFinal " +
							"FROM CDT_Medios " + 
							"WHERE NoCuenta = '" + noCuenta + "' AND NoIdent = '" + noIdent +"' " +
							"AND Mes = " + mes);
				
					while(consultaMedios.next()){
					
						saldoInicial = consultaMedios.getDouble(1);
						inversion = consultaMedios.getDouble(2);
						intCausado = consultaMedios.getDouble(3);
						intPagado = consultaMedios.getDouble(4);
						saldoFinal = consultaMedios.getDouble(5);
					
						//CALCULOS 
					
						
						if(int_Un_Dia == 00000000000.000000)
							intDiarioCalculado = 0;
						else{
							if(estado.equals("03"))
								intDiarioCalculado = 0;
							else{
								if(estado.equals("06"))
									intDiarioCalculado = 0;
								else{
									if(saldoInicial == inversion)
										intDiarioCalculado = (saldoFinal)* tasa_Current;
									else{
										if(saldoInicial < saldoFinal)
											intDiarioCalculado = (saldoInicial + inversion)* tasa_Current;
										else if(saldoInicial > saldoFinal)
											intDiarioCalculado = (saldoFinal + inversion)* tasa_Current;
										else 
											intDiarioCalculado = (saldoFinal + inversion)* tasa_Current;
									}	
									if(modalidad.equals("M"))
										intDiarioCalculado = intDiarioCalculado/360;
									else{
										if(util.bisiesto(a�o))
											intDiarioCalculado = intDiarioCalculado/365;
										else
											intDiarioCalculado = intDiarioCalculado/366;
									}
								}
							}
						}
						if(intCausado == 0)
							int_Acum_Mes = int_Acum_Mes * 0;
						else
							int_Acum_Mes = int_Acum_Mes * 0.01;
					
						if(intPagado>0)
							intCausadoCalculado = int_Brut_Causad;
						else
							intCausadoCalculado = int_Acum_Mes;
					
						if(tipo_Retencion.equals("0001"))
							retancionCalculada = intPagado * 0;
						else if(tipo_Retencion.equals("0002"))
							retancionCalculada = intPagado * 0.04;
						else if(tipo_Retencion.equals("0003"))
							retancionCalculada = intPagado * 0.35;
						else
							retancionCalculada = 1;
					
						diferenciaIntDiario = intDiarioCalculado - int_Un_Dia;
						diferenciaIntCausad = intCausadoCalculado - intCausado;
					
						if(diferenciaIntDiario > 1 || diferenciaIntDiario < -1 && diferenciaIntCausad >1 || diferenciaIntCausad <-1){
							cxn.ejecutar("INSERT INTO CDT_Inconsitentes " +
								"VALUES ('" + noCuenta + "', " +
								"'" + noIdent + "', " +
								saldoInicial + ", " +
								inversion + ", " +
								intDiarioCalculado + ", " +
								diferenciaIntDiario  + ", " +
								intCausadoCalculado + ", " +
								diferenciaIntCausad + ", " +
								intPagado + ", " +
								retancionCalculada + ", " +
								saldoFinal + ", " +
								"' -* ', " +
								mes +")");
						}
						else if(diferenciaIntDiario > 1 || diferenciaIntDiario < -1){
							cxn.ejecutar("INSERT INTO CDT_Inconsitentes " +
									"VALUES ('" + noCuenta + "', " +
									"'" + noIdent + "', " +
									saldoInicial + ", " +
									inversion + ", " +
									intDiarioCalculado + ", " +
									diferenciaIntDiario  + ", " +
									intCausadoCalculado + ", " +
									diferenciaIntCausad + ", " +
									intPagado + ", " +
									retancionCalculada + ", " +
									saldoFinal + ", " +
									"' -- ', " +
									mes +")");
						}
						else if(diferenciaIntCausad >1 || diferenciaIntCausad <-1){
							cxn.ejecutar("INSERT INTO CDT_Inconsitentes " +
								"VALUES ('" + noCuenta + "', " +
								"'" + noIdent + "', " +
								saldoInicial + ", " +
								inversion + ", " +
								intDiarioCalculado + ", " +
								diferenciaIntDiario  + ", " +
								intCausadoCalculado + ", " +
								diferenciaIntCausad + ", " +
								intPagado + ", " +
								retancionCalculada + ", " +
								saldoFinal + ", " +
								"' ** ', " +
								mes +")");
						}
					
					}
				}
//			}
		} catch (SQLException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		
	}
}

