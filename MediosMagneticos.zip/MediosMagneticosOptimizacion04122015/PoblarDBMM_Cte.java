import dbc.*;

import resources.PoblarDBMM_CteHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;

public class PoblarDBMM_Cte extends PoblarDBMM_CteHelper
{
	String no_cuenta, saldo, saldofinal, media, max, min, valorCredito, MovCredito, promedioCredito, medianaCredito, valorDebito, MovDebito, promedioDebito;
	FileInputStream LeerArchivo_CuentasBuscadas, LeerArchivo_Pricicpal; 
	DataInputStream EntradaArchivoCB, EntradaArchivoPrin;												
	BufferedReader TemporalArchivoCB, TemporalArchivoPrin;																		
	DBconnection cxn;
	Utilitarios util;
	int mes, count;
	ArrayList<String> lista;
	ArrayList<String> lista1;
	ArrayList<String> lista2;
	ArrayList<String> lista3;
	ArrayList<String> lista4;
	ArrayList<String> lista5;
	ArrayList<String> lista6;
	ArrayList<String> lista7;
	ArrayList<String> lista8;
	ArrayList<String> lista9;
	
	
	public void testMain(Object[] args) throws IOException 
	{
		mes = dpInt("Mes");
		
		lista = new ArrayList<String>();
		lista1 = new ArrayList<String>();
		lista2 = new ArrayList<String>();
		lista3 = new ArrayList<String>();
		lista4 = new ArrayList<String>();
		lista5 = new ArrayList<String>();
		lista6 = new ArrayList<String>();
		lista7 = new ArrayList<String>();
		lista8 = new ArrayList<String>();
		lista9 = new ArrayList<String>();
		
		LeerArchivo_CuentasBuscadas = new FileInputStream("D:\\MediosMagneticos\\CorrienteMensual\\CuentasBuscadas"+mes+".txt");
		EntradaArchivoCB = new DataInputStream(LeerArchivo_CuentasBuscadas);												
		TemporalArchivoCB = new BufferedReader(new InputStreamReader(EntradaArchivoCB));
		
		try {
			LeerArchivo_Pricicpal = new FileInputStream(dpString("RutaArchivoMM"));	
		} catch (Exception e) {
			return;
		}
													
		EntradaArchivoPrin = new DataInputStream(LeerArchivo_Pricicpal);				
		TemporalArchivoPrin = new BufferedReader(new InputStreamReader(EntradaArchivoPrin));
								
		cxn = new DBconnection();// llamamos a la clase conexion  
		util = new Utilitarios();// 
		
		poblarCuentasBuscadas();
		try {
			poblarTablaFiltrada();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void poblarCuentasBuscadas() throws IOException {
		
		String Registro = "";
		int num= 0;
		
		while ((Registro = TemporalArchivoCB.readLine()) != null)												
		{
			num =Integer.parseInt(Registro.substring(1,2));
			switch (num) {
			case (0):
				lista.add(Registro);
				break;
			case (1):
				lista1.add(Registro);
				break;
			case (2):
				lista2.add(Registro);
				break;
			case (3):
				lista3.add(Registro);
				break;
			case (4):
				lista4.add(Registro);
				break;
			case (5):
				lista5.add(Registro);
				break;
			case (6):
				lista6.add(Registro);
				break;
			case (7):
				lista7.add(Registro);
				break;
			case (8):
				lista8.add(Registro);
				break;
			default:
				lista9.add(Registro);
				break;
			}
		}
	}
		public void poblarTablaFiltrada() throws IOException, SQLException {
			
			int numero= 0;
			String Registro2 = "";
			while ((Registro2 = TemporalArchivoPrin.readLine()) != null )												
			{
			boolean existe= false;
			//count++;
			if(!Registro2.toString().substring(0, 1).equals(" ") && !Registro2.toString().substring(0, 1).equals("I") ){
				if((Registro2.substring(277, 278).equals(" ")))
					Registro2= util.CorregirNUll(Registro2);

				no_cuenta = Registro2.substring(331, 340);
				saldo = util.getDecimales(Registro2.substring(378, 396));
				saldofinal = util.getDecimales(Registro2.substring(415, 433));
				media = util.getDecimales(Registro2.substring(452, 470));
				max = util.getDecimales(Registro2.substring(489, 507));
				min = util.getDecimales(Registro2.substring(526, 544));
				valorCredito = util.getDecimales(Registro2.substring(563, 581));
				MovCredito = util.getNoMov(Registro2.substring(600, 618));
				promedioCredito = util.getDecimales(Registro2.substring(637, 655));
				medianaCredito = util.getDecimales(Registro2.substring(674, 692));
				valorDebito = util.getDecimales(Registro2.substring(711, 729));
				MovDebito = util.getNoMov(Registro2.substring(748, 766));
				promedioDebito = util.getDecimales(Registro2.substring(785, 803));
				
				numero =Integer.parseInt(Registro2.substring(332,333));
				switch (numero) {
				case (0):
					if(lista.contains(no_cuenta)) existe=true;
					break;
				case (1):
					if(lista1.contains(no_cuenta)) existe=true;
					break;
				case (2):
					if(lista2.contains(no_cuenta)) existe=true;
					break;
				case (3):
					if(lista3.contains(no_cuenta)) existe=true;
					break;
				case (4):
					if(lista4.contains(no_cuenta)) existe=true;
					break;
				case (5):
					if(lista5.contains(no_cuenta)) existe=true;
					break;
				case (6):
					if(lista6.contains(no_cuenta)) existe=true;
					break;
				case (7):
					if(lista7.contains(no_cuenta)) existe=true;
					break;
				case (8):
					if(lista8.contains(no_cuenta)) existe=true;
					break;
				default:
					if(lista9.contains(no_cuenta)) existe=true;
					break;
				}
				
				if(existe==true){
					
					String msg =cxn.ejecutar("INSERT INTO Mensual_MM_2014_Cte VALUES " +
							"('" + no_cuenta +  
							"'," + saldo + ","+ saldofinal +
							"," + media + ","+ max +
							"," + min + ","+ valorCredito +
							"," + MovCredito + ","+ promedioCredito +
							"," + medianaCredito + ","+ valorDebito +
							"," + MovDebito + ","+ promedioDebito +  "," + mes +")");
				//}
		
				}	
			}
			}
		}
}

