import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import resources.Cruce_CteHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
import dbc.Utilitarios;
/**
 * Description   : Functional Test Script
 * @author JGUTIE1
 */
public class Cruce_Cte extends Cruce_CteHelper
{
	DBconnection cxn;
	Utilitarios utiles;
	int a�oConsulta, mes, dia, movcre, nmovdeb,  difmovcre, difnmovdeb, OpEspecial ;
	String no_cuenta,  codigo_transaccion, cuentaAux;
	double diftrasancion, difsaldo, difpsaldof, difmeddia, difsmax, difsmin, difvcred, difprocre, difmedcre, difvmovdeb, difprodeb, difsaldofinal;
	double trasancion, saldo, psaldof, meddia, smax, smin, vcred, procre, medcre, vmovdeb, prodeb, saldofinal;
	boolean especial;
	ArrayList<String> operacionesEspeciales = new ArrayList<String>();
	ArrayList<String> semiEspeciales = new ArrayList<String>();
	FileWriter ArchivoE = null;
	PrintWriter pw = null;
	int pro;
	
	public void testMain(Object[] args) 
	{
		a�oConsulta =0;
		dia =0;
		movcre =0; 
		nmovdeb =0;
		difmovcre =0;
		difnmovdeb =0;
		OpEspecial=0;
		diftrasancion=0;
		difsaldo=0;
		difpsaldof=0;
		difmeddia=0;
		difsmax=0;
		difsmin=0;
		difvcred=0;
		difprocre=0;
		difmedcre=0;
		difvmovdeb=0;
		difprodeb=0;
		difsaldofinal=0;
		
		trasancion=0;
		saldo=0;
		psaldof=0;
		meddia=0;
		smax=0;
		smin=0;
		vcred=0;
		procre=0;
		medcre=0;
		vmovdeb=0;
		prodeb=0;
		saldofinal=0;
		
		semiEspeciales.add("0042");
		semiEspeciales.add("0046");
		semiEspeciales.add("0088");
		semiEspeciales.add("0089");
		
		operacionesEspeciales.add("0015");
		operacionesEspeciales.add("0026");
		operacionesEspeciales.add("0027");
		operacionesEspeciales.add("0037");
		operacionesEspeciales.add("0043");
		operacionesEspeciales.add("0050");
		operacionesEspeciales.add("0060");
		operacionesEspeciales.add("0072");
		operacionesEspeciales.add("0216");
		operacionesEspeciales.add("0220");
		operacionesEspeciales.add("0241");
		operacionesEspeciales.add("0294");
		operacionesEspeciales.add("0313");
		operacionesEspeciales.add("0334");
		operacionesEspeciales.add("0395");
		operacionesEspeciales.add("0396");
		operacionesEspeciales.add("0398");
		operacionesEspeciales.add("0420");
		operacionesEspeciales.add("0424");
		operacionesEspeciales.add("0675");
		operacionesEspeciales.add("0676");
		
		cxn = new DBconnection();
		utiles = new Utilitarios();
		
			a�oConsulta = 2016;
						
			try {
				ArchivoE = new FileWriter("D:\\MediosMagneticos\\CorrienteMensual\\INSUMOS\\Exitoso" + ".txt", true);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			pw = new PrintWriter(ArchivoE);
			
			if(mes != dpInt("Mes")){
				mes = dpInt("Mes");
				cruceDatos(mes);
			}
			pw.close();
	}
	public void cruceDatos(int mesConsultado) {
		
		ResultSet resultado = cxn.Consulta("select No_Cuenta, DAY(Fecha_Transaccion), Cod_Trasaccion, Transacion, Saldo " +
				"from vista" + mesConsultado + " " +
				"ORDER BY  No_Cuenta, Id_Mensual_Ext");

				poblarArreglos(resultado);
	}
	public void poblarArreglos(ResultSet resultado){
		
		double[] saldos = new double[utiles.getDiasMes(a�oConsulta, mes)];
		double[] creditos = new double[utiles.getDiasMes(a�oConsulta, mes)];
		String cuentaAux = " ";
		int diaAux = 0;
		OpEspecial= 0;
		
		
		try {
			while(resultado.next()){
			
				no_cuenta = resultado.getString(1);
				dia = resultado.getInt(2);
				codigo_transaccion = resultado.getString(3);
				trasancion = resultado.getDouble(4);
				saldo = resultado.getDouble(5);
				
				if(cuentaAux.equals(" ")) cuentaAux = no_cuenta;
				
					if(no_cuenta.equals(cuentaAux)){
														
						if(dia == 1){
							saldos[0]=saldo;
							if(!semiEspeciales.contains(codigo_transaccion)){
								if(trasancion > 0)	{
									creditos[dia-1]= creditos[dia-1]+trasancion;
									movcre++;
								}
								if(trasancion < 0) {
									nmovdeb++;
									vmovdeb = vmovdeb + trasancion;
								}
							}
							if(operacionesEspeciales.contains(codigo_transaccion)) OpEspecial++;
						}
						else{
							for(int x = dia-2; x>=diaAux; x--){
									if(saldos[x]==0)saldos[x]=saldo - trasancion;
								}	
							
							if(!semiEspeciales.contains(codigo_transaccion)){
								if(trasancion > 0)	{
									creditos[dia-1]= creditos[dia-1]+trasancion;
									movcre++;
								}
								if(trasancion < 0) {
									nmovdeb++;
									vmovdeb = vmovdeb + trasancion;
								}
							}
							
							saldos[dia -1]=saldo;
							if(operacionesEspeciales.contains(codigo_transaccion)) OpEspecial++;
						}
						diaAux = dia;
					}
	//-----------------------------------------------------------------------------------------------				
				else {
					for (int i = diaAux; i < saldos.length; i++) {
							if(saldos[i]==0) saldos[i]=saldos[i-1];
						} 
					diaAux = 0;
					
						cruceDatos(cuentaAux, saldos, creditos, movcre, nmovdeb, vmovdeb, OpEspecial);
						movcre = 0;
						nmovdeb = 0;
						vmovdeb = 0;
						OpEspecial =0;
						
					for (int i = 0; i < creditos.length; i++) {
						saldos[i]= 0;
						creditos[i]= 0;				
					}
													
					if(dia == 1){
						saldos[0]=saldo;
						
						if(!semiEspeciales.contains(codigo_transaccion)){
							if(trasancion > 0)	{
								creditos[dia-1]= creditos[dia-1]+trasancion;
								movcre++;
							}
							if(trasancion < 0) {
								nmovdeb++;
								vmovdeb = vmovdeb + trasancion;
							}
						}
						if(operacionesEspeciales.contains(codigo_transaccion)) OpEspecial++;
					}
					else{
						for(int x = dia-2; x>=diaAux; x--){
								if(saldos[x]==0)saldos[x]=saldo - trasancion;
							}
							saldos[dia -1]=saldo;
						
						if(!semiEspeciales.contains(codigo_transaccion)){
							if(trasancion > 0)	{
								creditos[dia-1]= creditos[dia-1]+trasancion;
								movcre++;
							}
							if(trasancion < 0) {
								nmovdeb++;
								vmovdeb = vmovdeb + trasancion;
							}	
						}
		
						saldos[dia -1]=saldo;
						
					}
						diaAux = dia;
						cuentaAux = no_cuenta;
						psaldof = 0;
						
						if(operacionesEspeciales.contains(codigo_transaccion)) OpEspecial++;
				}
			}
			
			try {
				for (int i = diaAux; i < saldos.length; i++) {
					if(saldos[i]==0) saldos[i]=saldos[i-1];
				}
			} catch (Exception e) {
				// TODO: handle exception
			}

			cruceDatos(cuentaAux, saldos, creditos, movcre, nmovdeb, vmovdeb, OpEspecial);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void cruceDatos(String noCuneta, double[] saldos, double[] creditos, int nCreditos, int nDebitos, double valoresDebito, int operacionesEsp){
		
		
		int ResultadoNegativo = 0;
		
		saldofinal = saldos[saldos.length-1];
		Arrays.sort(saldos);
		Arrays.sort(creditos);
		
		psaldof = utiles.obtenerSumaArreglo(saldos)/saldos.length;;
		
		if(mes == 2) {
			meddia = saldos[14];
			medcre = creditos[14];
		}
		else {
			meddia = saldos[15];
			medcre = creditos[15];
		}
//		
//		meddia =saldos[15];
		smax = saldos[saldos.length-1];
		smin = saldos[0];
		vcred = utiles.obtenerSumaArreglo(creditos);
		if(nCreditos==0) 
			procre=0;
		else
			procre = vcred/nCreditos;
			
			vmovdeb = Math.abs(valoresDebito);
		
		if(nDebitos==0) 
			prodeb=0;
		else
			prodeb = vmovdeb/nDebitos;
			
	//-------------------------------------------------------------------------------------	

		ResultSet resultado2 = cxn.Consulta("SELECT Saldo, Saldofinal, Media, Max, Min," +
											"ValorCredito, MovCredito, PromedioCredito," +
											"MedianaCredito, ValorDebito, MovDebito, PromedioDebito " +
											"FROM vistaMed" + mes + " " +
											"WHERE No_Cuenta= " + noCuneta +  "and mes= " + mes);
		
		try {
			if(resultado2.next()){
				
				difsaldofinal = resultado2.getDouble(1) - saldofinal;
				difpsaldof = resultado2.getDouble(2) - psaldof;
				difmeddia = resultado2.getDouble(3) - meddia;
				difsmax = resultado2.getDouble(4) - smax;
				difsmin = resultado2.getDouble(5) - smin;
				difvcred = resultado2.getDouble(6) - vcred;
				difmovcre = resultado2.getInt(7) - movcre;
				difprocre = resultado2.getDouble(8) - procre;
				difmedcre = resultado2.getDouble(9) - medcre;
				difvmovdeb = resultado2.getDouble(10) - vmovdeb;
				difnmovdeb = resultado2.getInt(11) - nDebitos;
				difprodeb = resultado2.getDouble(12) - prodeb;

				if (difsaldofinal>=1 || difsaldofinal<=-1) ResultadoNegativo++;
				if (difpsaldof>=1 || difpsaldof<=-1) ResultadoNegativo++;
				if (difmeddia>=1 || difmeddia<=-1) ResultadoNegativo++;
				if (difsmax>=1 || difsmax<=-1) ResultadoNegativo++;
				if (difsmin>=1 || difsmin<=-1) ResultadoNegativo++;
				if (difvcred>=1 || difvcred<=-1) ResultadoNegativo++;
				if (difmovcre>=1 || difmovcre<=-1) ResultadoNegativo++;
				if (difprocre>=1 || difprocre<=-1) ResultadoNegativo++;
				if (difmedcre>=1 || difmedcre<=-1) ResultadoNegativo++;
				if (difvmovdeb>=1 || difvmovdeb<=-1) ResultadoNegativo++;
				if (difnmovdeb>=1 || difnmovdeb<=-1) ResultadoNegativo++;
				if (difprodeb>=1 || difprodeb<=-1) ResultadoNegativo++;
			
				if(ResultadoNegativo > 0) {
					
					
					cxn.ejecutar("INSERT INTO Inconsistentes2014 VALUES ('" + noCuneta +"', "
							+ saldofinal +", "+ difsaldofinal +", " 
							+ psaldof + ", "+ difpsaldof + ", "
							+ meddia + ", "+ difmeddia + ", "
							+ smax + ", "+ difsmax + ", "
							+ smin + ", "+ difsmin + ", "
							+ vcred + ", "+ difvcred + ", "
							+ movcre + ", "+ difmovcre + ", "
							+ procre + ", "+ difprocre + ", "
							+ medcre + ", "+ difmedcre + ", "
							+ vmovdeb + ", "+ difvmovdeb + ", "
							+ nDebitos + ", "+ difnmovdeb + ", "
							+ prodeb + ", "+ difprodeb + ", "
							+ operacionesEsp  + ", "+ mes + ", "
							+ "'' , '')");
							
				}
				else
					pintaExitoso(mes +"-" + noCuneta + "-" + operacionesEsp);
				
					
					
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	public void pintaExitoso(String cadena){

		pw.println(cadena);
		System.gc();
		
	}
}

