package Filtrar_Registros;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import resources.Filtrar_Registros.FiltrarMedios_AhoHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class FiltrarMedios_Aho extends FiltrarMedios_AhoHelper
{

	FileWriter fichero;
	PrintWriter pw;
	FileInputStream leerArchivo_CuentasFiltradas, leerArchivo_Medios;		
	DataInputStream entradaArchivoCF, entradaArchivoMedios;												
	BufferedReader temporalArchivoCF, temporalArchivoMedios;		
	ArrayList<String> listaCuentas = new ArrayList<String>();
	
	public void testMain(Object[] args) throws IOException
	{
		listaCuentas.clear();
		leerArchivo_CuentasFiltradas = new FileInputStream("D:\\MediosMagneticos\\AhorrosMensual\\Cuentas_Filtro.txt");
		entradaArchivoCF = new DataInputStream(leerArchivo_CuentasFiltradas);												
		temporalArchivoCF = new BufferedReader(new InputStreamReader(entradaArchivoCF));
		
		String lineaArchivo = "";
		while ((lineaArchivo = temporalArchivoCF.readLine()) != null)												
		{
			listaCuentas.add(lineaArchivo);
		}
		
				
		fichero = new FileWriter("D:\\MediosMagneticos\\AhorrosMensual\\MediosFitrados" + dpInt("Mes")+ ".txt", true);
		pw = new PrintWriter(fichero);
		
		if(!dpString("RutaArchivoMM_Aho").equals(""))
		{
			leerArchivo_Medios = new FileInputStream(dpString("RutaArchivoMM_Aho"));
			entradaArchivoMedios = new DataInputStream(leerArchivo_Medios);												
			temporalArchivoMedios = new BufferedReader(new InputStreamReader(entradaArchivoMedios));
			
			String lineaArchivoExtracto = "";
			while ((lineaArchivoExtracto = temporalArchivoMedios.readLine()) != null)												
			{
				if(listaCuentas.contains(lineaArchivoExtracto.substring(330, 340))){
					pintaCuentas(lineaArchivoExtracto);
				}
					
			}
			
			pw.flush();
			pw.close();
		}
		
	}
	
	private void pintaCuentas(String cadena) {
		
		pw.print(cadena +"\n");
	}
	
}

