package Filtrar_Registros;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import resources.Filtrar_Registros.FiltrarExtractos_CteHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class FiltrarExtractos_Cte extends FiltrarExtractos_CteHelper
{
	FileWriter fichero;
	PrintWriter pw;
	FileInputStream leerArchivo_CuentasFiltradas, leerArchivo_Extractos;		
	DataInputStream entradaArchivoCF, entradaArchivoExtractos;												
	BufferedReader temporalArchivoCF, temporalArchivoExtractos;		
	ArrayList<String> listaCuentas = new ArrayList<String>();
	 
	public void testMain(Object[] args) throws IOException
	{
		leerArchivo_CuentasFiltradas = new FileInputStream("D:\\MediosMagneticos\\CorrienteMensual\\Cuentas_Filtro.txt");
		entradaArchivoCF = new DataInputStream(leerArchivo_CuentasFiltradas);												
		temporalArchivoCF = new BufferedReader(new InputStreamReader(entradaArchivoCF));
		
		String lineaArchivo = "";
		while ((lineaArchivo = temporalArchivoCF.readLine()) != null)												
		{
			listaCuentas.add(lineaArchivo);
		}
		
		fichero = new FileWriter("D:\\MediosMagneticos\\CorrienteMensual\\ExtractosFitrados_Cte_" + dpInt("Mes")+".txt", true);
		pw = new PrintWriter(fichero);
		
		if(!dpString("RutaArchivoExt").equals(""))
		{
			leerArchivo_Extractos = new FileInputStream(dpString("RutaArchivoExt"));
			entradaArchivoExtractos = new DataInputStream(leerArchivo_Extractos);												
			temporalArchivoExtractos = new BufferedReader(new InputStreamReader(entradaArchivoExtractos));
			
			String lineaArchivoExtracto = "";
			while ((lineaArchivoExtracto = temporalArchivoExtractos.readLine()) != null)												
			{
				if(listaCuentas.contains(lineaArchivoExtracto.substring(6, 15)))
					pintaCuentas(lineaArchivoExtracto.toString());
			}
			
			pw.flush();
			pw.close();
		}
		
	}
	
	private void pintaCuentas(String cadena) {
		
		pw.print(cadena +"\n");
	}
	
}

