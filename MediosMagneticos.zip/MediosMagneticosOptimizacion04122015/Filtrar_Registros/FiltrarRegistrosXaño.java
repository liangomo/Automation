package Filtrar_Registros;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import resources.Filtrar_Registros.FiltrarRegistrosXa�oHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class FiltrarRegistrosXa�o extends FiltrarRegistrosXa�oHelper
{
	/**
	 * @since  2017/03/01
	 * @author GORTEG1
	 */
	
	FileWriter ArchivoE = null;
	PrintWriter pw = null;
	int cantidad;
	String a�o = "2016";
	
	public void testMain(Object[] args) 
	{
		String cadena = "D:\\MediosMagneticos\\CorrientesAnual\\pro\\";
		String nomArchivo = "BO_ENE_N";
		String extension = ".txt";
		
		FileReader file;
		try {
			file = new FileReader(cadena + nomArchivo + extension);
			BufferedReader buffer = new BufferedReader(file);
			ArchivoE = new FileWriter(cadena + nomArchivo + "_Filtrado" + extension, true);
			pw = new PrintWriter(ArchivoE);

			//CICLO QUE CONTROLA LA LECTURA DEL TXT
			String registro = "";
	        while((registro = buffer.readLine())!= null)
	        {
	        	if(registro.substring(19, 23).equals(a�o) && registro.substring(0,1).equals("2"))
	        	{
	        		System.out.println(registro);
	        		pintaNuevo(registro);
	        	}
	                	
	        	cantidad++;
	        }
	        ArchivoE.close();
		} catch (FileNotFoundException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
	
	}

	public void pintaNuevo(String cadena){

		pw.println(cadena);
		System.gc();
		
	}
}
