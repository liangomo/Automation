package Filtrar_Registros;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import resources.Filtrar_Registros.FiltrarExtractosAnual_AhoHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author MSUARE8
 */
public class FiltrarExtractosAnual_Aho extends FiltrarExtractosAnual_AhoHelper
{
	String directorio, registro, no_cuenta;
	FileInputStream leer_CunetasFiltro, leer_Mes;
	FileWriter ArchivoE;
	DataInputStream entradaArchivo;
	BufferedReader archivoTemporal;
	ArrayList<String> listaCuentas, listaFicheros;
	String[] ficheros;
	PrintWriter pw;
	File dir;
	
	public void testMain(Object[] args) 
	{
		directorio = "D:\\MediosMagneticos\\AhorrosAnual\\";
		dir = new File(directorio);
		ficheros= dir.list();
		
		try {
			
			leer_CunetasFiltro = new FileInputStream(directorio + "CuentasFiltro.txt");
			entradaArchivo = new DataInputStream(leer_CunetasFiltro);												
			archivoTemporal = new BufferedReader(new InputStreamReader(entradaArchivo));
			
			registro = "";
			listaCuentas = new ArrayList<>();
			while ((registro = archivoTemporal.readLine()) != null)												
			{
				listaCuentas.add(registro);
			}
						
			listaFicheros = new ArrayList<>();
			for (String x : ficheros) {
				if(!(x.equals("CuentasFiltro.txt")) && !(x.equals("FiltradoFinal.txt")))
					listaFicheros.add(x);
			}
			
			for(int i = 0; i<listaFicheros.size(); i++)
			{
				ArchivoE = new FileWriter(directorio +  "FiltradoFinal.txt", true);
				pw = new PrintWriter(ArchivoE);
				
				System.out.println(directorio + listaFicheros.get(i));
				leer_Mes = new FileInputStream(directorio + listaFicheros.get(i));
				entradaArchivo = new DataInputStream(leer_Mes);												
				archivoTemporal = new BufferedReader(new InputStreamReader(entradaArchivo));
				
				while ((registro = archivoTemporal.readLine()) != null)												
				{
					if(registro.substring(0, 1).equals("2")){
						no_cuenta = registro.substring(6, 16);
						if(registro.substring(20, 24).equals("2016"))
						{
							if(listaCuentas.contains(no_cuenta))
								pintaArchivo(registro);
						}
					}
				}
				pw.close();
				ArchivoE.close();
			}
			
		} catch (FileNotFoundException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
	}
		
	public void pintaArchivo(String cadena){
		pw.println(cadena);
		System.gc();
	}
}	
