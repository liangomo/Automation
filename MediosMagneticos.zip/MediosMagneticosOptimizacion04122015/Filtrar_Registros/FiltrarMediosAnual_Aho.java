package Filtrar_Registros;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import resources.Filtrar_Registros.FiltrarMediosAnual_AhoHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class FiltrarMediosAnual_Aho extends FiltrarMediosAnual_AhoHelper
{
	/**
	 * @since  2017/02/24
	 * @author GORTEG1
	 */
	
	String directorio, registro, no_cuenta;
	FileInputStream leer_MediosAnual, leer_CunetasFiltro;
	DataInputStream entradaArchivo;
	BufferedReader archivoTemporal;
	ArrayList<String> listaCuentas;
	FileWriter ArchivoE;
	PrintWriter pw;
	
	public void testMain(Object[] args) 
	{
		directorio = "D:\\MediosMagneticos\\AhorrosAnual\\";
		
		try {
			
			leer_CunetasFiltro = new FileInputStream(directorio + "CuentasFiltro.txt");
			entradaArchivo = new DataInputStream(leer_CunetasFiltro);												
			archivoTemporal = new BufferedReader(new InputStreamReader(entradaArchivo));
			
			registro = "";
			listaCuentas = new ArrayList<>();
			while ((registro = archivoTemporal.readLine()) != null)												
			{
				listaCuentas.add(registro);
			}
			
			ArchivoE = new FileWriter(directorio +  "MediosFiltrado.txt", true);
			pw = new PrintWriter(ArchivoE);
			
			leer_MediosAnual = new FileInputStream(directorio + "ANUALAHORROS.txt");
			entradaArchivo = new DataInputStream(leer_MediosAnual);												
			archivoTemporal = new BufferedReader(new InputStreamReader(entradaArchivo));
			
			registro = "";
			while ((registro = archivoTemporal.readLine()) != null)												
			{
				no_cuenta = registro.substring(330, 340);
				if(listaCuentas.contains(no_cuenta))
						pintaArchivo(registro);
				
			}
			pw.close();
			ArchivoE.close();
			
		} catch (FileNotFoundException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		
	}

	public void pintaArchivo(String cadena){
	pw.println(cadena);
	System.gc();
	}
}

