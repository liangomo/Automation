
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import resources.ValidacionRegistroControl_CteHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.Utilitarios;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class ValidacionRegistroControl_Cte extends ValidacionRegistroControl_CteHelper
{
	Double saldo, saldofinal, media, max, min, valorCredito, promedioCredito, medianaCredito, valorDebito, promedioDebito;
	Double saldoAll, saldofinalAll, mediaAll, maxAll, minAll, valorCreditoAll, promedioCreditoAll, medianaCreditoAll, valorDebitoAll, promedioDebitoAll;
	int movCredito, movDebito, noRegritros;
	int movCreditoAll, movDebitoAll, noRegritrosAll;
	FileInputStream LeerArchivo_CuentasBuscadas, LeerArchivo_Pricicpal; 
	DataInputStream EntradaArchivoCB, EntradaArchivoPrin;												
	BufferedReader TemporalArchivoCB, TemporalArchivoPrin;		
	Utilitarios util;
	int mes;
	FileWriter fichero;
	PrintWriter pw;
	ArrayList<String> resultados = new ArrayList<>();
	ArrayList<String> negativas = new ArrayList<>();
	
	public void testMain(Object[] args) throws IOException
	{
		saldoAll = 0.0; 
		saldofinalAll = 0.0; 
		mediaAll = 0.0; 
		maxAll = 0.0; 
		minAll = 0.0; 
		valorCreditoAll = 0.0; 
		promedioCreditoAll = 0.0; 
		medianaCreditoAll = 0.0; 
		valorDebitoAll = 0.0; 
		promedioDebitoAll = 0.0;
		movCreditoAll = 0;  
		movDebitoAll = 0;
		noRegritrosAll = 0;
		
		if(!dpString("Mes").equals(""))
			mes = dpInt("Mes");
		util = new Utilitarios();
		
		
		try {
			fichero = new FileWriter("D:\\MediosMagneticos\\CorrienteMensual\\INSUMOS\\ValidacionRegistroControl.txt", true);
			pw = new PrintWriter(fichero);
		} catch (IOException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		
		try{
			LeerArchivo_Pricicpal = new FileInputStream(dpString("RutaArchivoMM"));
		}
		catch(Exception e){
			return;
		}
		
		EntradaArchivoPrin = new DataInputStream(LeerArchivo_Pricicpal);				
		TemporalArchivoPrin = new BufferedReader(new InputStreamReader(EntradaArchivoPrin));
		
		ArrayList<Boolean> listaResultados = new ArrayList<Boolean>();
		ArrayList<String> listaVariables = new ArrayList<String>();
		
		String Registro2 = "";
		while ((Registro2 = TemporalArchivoPrin.readLine()) != null)												
		{		
			boolean existe= false;
			if(!Registro2.toString().substring(0, 1).equals(" ") && !Registro2.toString().substring(0, 1).equals("I") )
			{
//				if((Registro2.substring(277, 278).equals(" ")))
//					Registro2= util.CorregirNUll(Registro2);

				saldoAll += Double.parseDouble(util.getDecimales(Registro2.substring(378, 396)));
				saldofinalAll += Double.parseDouble(util.getDecimales(Registro2.substring(415, 433)));
				mediaAll += Double.parseDouble(util.getDecimales(Registro2.substring(452, 470)));
				maxAll += Double.parseDouble(util.getDecimales(Registro2.substring(489, 507)));
				minAll += Double.parseDouble(util.getDecimales(Registro2.substring(526, 544)));
				valorCreditoAll += Double.parseDouble(util.getDecimales(Registro2.substring(563, 581)));
				movCreditoAll += Integer.parseInt(util.getNoMov(Registro2.substring(600, 618)));
				promedioCreditoAll += Double.parseDouble(util.getDecimales(Registro2.substring(637, 655)));
				medianaCreditoAll +=  Double.parseDouble(util.getDecimales(Registro2.substring(674, 692)));
				valorDebitoAll +=  Double.parseDouble(util.getDecimales(Registro2.substring(711, 729)));
				movDebitoAll += Integer.parseInt(util.getNoMov(Registro2.substring(748, 766)));
				promedioDebitoAll +=  Double.parseDouble(util.getDecimales(Registro2.substring(785, 803)));
				noRegritrosAll ++;
				
				if(Double.parseDouble(util.getDecimales(Registro2.substring(378, 396))) < 0)
					negativas.add("Cuenta: " + Registro2.substring(331, 340) + " Saldo Negativo");
				
				if(Double.parseDouble(util.getDecimales(Registro2.substring(415, 433))) < 0)
					negativas.add("Cuenta: " + Registro2.substring(331, 340) + " Promedio Saldo Final Negativo");
			}
			if(Registro2.substring(0, 1).equals("I"))
			{
				saldo = Double.parseDouble(util.getDecimales(Registro2.substring(48, 66)));
				saldofinal = Double.parseDouble(util.getDecimales(Registro2.substring(85, 103)));
				media = Double.parseDouble(util.getDecimales(Registro2.substring(122, 140)));
				max = Double.parseDouble(util.getDecimales(Registro2.substring(159, 177)));
				min = Double.parseDouble(util.getDecimales(Registro2.substring(196, 214)));
				valorCredito = Double.parseDouble(util.getDecimales(Registro2.substring(233, 251)));
				movCredito = Integer.parseInt(util.getNoMov(Registro2.substring(270, 288)));
				promedioCredito = Double.parseDouble(util.getDecimales(Registro2.substring(307, 325)));
				medianaCredito =  Double.parseDouble(util.getDecimales(Registro2.substring(344, 362)));
				valorDebito =  Double.parseDouble(util.getDecimales(Registro2.substring(381, 399)));
				movDebito = Integer.parseInt(util.getNoMov(Registro2.substring(418, 436)));
				promedioDebito =  Double.parseDouble(util.getDecimales(Registro2.substring(455, 473)));
				noRegritros = Integer.parseInt(Registro2.substring(16, 24));
			}
		}
		listaVariables.add("No_Registros");
				
		if(noRegritros-noRegritrosAll >1 || noRegritros-noRegritrosAll <-1)
			listaResultados.add(true);
		else 
			listaResultados.add(false);
		
		listaVariables.add("Saldo");
		if((saldoAll-saldo)>1 || (saldoAll-saldo)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("Saldofinal");
		if((saldofinalAll-saldofinal)>1 || (saldofinalAll-saldofinal)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("Media");
		if((mediaAll-media)>1 || (mediaAll-media)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("Max");
		if((maxAll-max)>1 || (maxAll-max)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("Min");
		if((minAll-min)>1 || (minAll-min)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("ValorCredito");
		if((valorCreditoAll-valorCredito)>1 || (valorCreditoAll-valorCredito)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("PromedioCredito");
		if((promedioCreditoAll-promedioCredito)>1 || (promedioCreditoAll-promedioCredito)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("MedianaCredito");
		if((medianaCreditoAll-medianaCredito)>1 || (medianaCreditoAll-medianaCredito)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("ValorDebito");
		if((valorDebitoAll-valorDebito)>1 || (valorDebitoAll-valorDebito)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("PromedioDebito");
		if((promedioDebitoAll-promedioDebito)>1 || (promedioDebitoAll-promedioDebito)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("MovCredito");
		if((movCreditoAll-movCredito)>1 || (movCreditoAll-movCredito)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		listaVariables.add("MovDebito");
		if((movDebitoAll-movDebito)>1 || (movDebitoAll-movDebito)<-1)
			listaResultados.add(true);
		else
			listaResultados.add(false);
		
		if(listaResultados.contains(true))
		{
			resultados.add("Inconsistencia registro de Control del archivo de Medios Magenticos Mes: " + mes );
			resultados.add("Variables Inconsistentes: ");
			for (int i = 0; i < listaResultados.size(); i++) {
				if(listaResultados.get(i)==true)
					resultados.add(listaVariables.get(i));
			}
			
		}
		else
			resultados.add("Registro de Control CORRECTO para archivo Medios Magenticos Mes: " + mes );
		
		pintaCuentas(resultados);
		resultados.clear();
		pintaCuentas(negativas);
		negativas.clear();
	}
	
	private void pintaCuentas(ArrayList<String> cuentas2){
		for(int i =0; i<cuentas2.size(); i++){
			
			pw.println(cuentas2.get(i));
		}
		pw.flush();
		pw.close();
		
	}
}

