
import resources.BorrarDB_CorrientesHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
/**
 * Description   : Functional Test Script
 * @author gorteg1
 */
public class BorrarDB_Corrientes extends BorrarDB_CorrientesHelper
{
	/**
	 * Script Name   : <b>BorrarDB</b>
	 * Generated     : <b>21/08/2015 08:40:23</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/08/21
	 * @author gorteg1
	 */
	
	DBconnection cxn;
	
	public void testMain(Object[] args) 
	{
		cxn = new DBconnection();// Instanciamos la clase conexion  
		
		cxn.ejecutar("DELETE " +
						"FROM Mensual_Ext_2014_Cte");

		cxn.ejecutar("DELETE " +
						"FROM Mensual_MM_2014_Cte");

		cxn.ejecutar("DELETE " +
						"FROM Inconsistentes2014");



		cxn.ejecutar("DBCC CHECKIDENT ('Mensual_Ext_2014_Cte', NORESEED)");
		cxn.ejecutar("DBCC CHECKIDENT ('Mensual_Ext_2014_Cte', RESEED, 0)");

		cxn.ejecutar("DBCC CHECKIDENT ('Mensual_MM_2014_Cte', NORESEED)");
		cxn.ejecutar("DBCC CHECKIDENT ('Mensual_MM_2014_Cte', RESEED, 0)");
	}
}

