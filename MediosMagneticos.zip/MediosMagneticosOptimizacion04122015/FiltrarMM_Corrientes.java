
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import resources.FiltrarMM_CorrientesHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
import dbc.Utilitarios;
/**
 * Description   : Functional Test Script
 * @author gorteg1
 */
public class FiltrarMM_Corrientes extends FiltrarMM_CorrientesHelper
{
	DBconnection cxn;
	Utilitarios utiles;
	
	FileWriter fichero;
	PrintWriter pw;
	String no_cuenta, cuentaAux;
	ArrayList<String> cuentas;
	
	public void testMain(Object[] args) 
	{
		cuentas = new ArrayList<>();
		cxn = new DBconnection();
		
		try {
			fichero = new FileWriter("D:\\MediosMagneticos\\CorrienteMensual\\CuentasBuscadas"+ dpString("Mes") +".txt",true);
			pw = new PrintWriter(fichero);
		} catch (IOException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		
		filtroDatos(dpInt("Mes"));
	}
	
	public void filtroDatos(int mesConsultado){
		
		ResultSet resultado = cxn.Consulta("SELECT No_Cuenta " +
												"from vista" + mesConsultado + " " +
													"ORDER BY  No_Cuenta, Id_Mensual_Ext");

		try {
			poblarCuentasBuscadas(resultado);
		} catch (SQLException e) {
			System.out.println("Error en la Consulta DB");
			//System.exit(0);
			e.printStackTrace();
		}
	}
	
public void poblarCuentasBuscadas(ResultSet resultado) throws SQLException{
		
		cuentaAux = " ";
		//if(resultado.getString(1)!="")
		//{
			while(resultado.next()){
				
				no_cuenta = resultado.getString(1).substring(0,9);
							
				if(cuentaAux.equals(" ")){
					cuentas.add(no_cuenta);
					cuentaAux = no_cuenta;
				}
				
				if(!no_cuenta.equals(cuentaAux)){
					cuentas.add(no_cuenta);
					cuentaAux = no_cuenta;
				}
			}
		//}
		pintaCuentas(cuentas);
	}

	private void pintaCuentas(ArrayList<String> cuentas2) {
		
		for(int i =0; i<cuentas2.size(); i++){
			
			pw.println(cuentas2.get(i));
		}
		pw.flush();
		pw.close();
		
	}

	
	
}

