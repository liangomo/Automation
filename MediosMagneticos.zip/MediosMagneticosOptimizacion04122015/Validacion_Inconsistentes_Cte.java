
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import resources.Validacion_Inconsistentes_CteHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import dbc.DBconnection;
import dbc.Utilitarios;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Validacion_Inconsistentes_Cte extends Validacion_Inconsistentes_CteHelper
{
	DBconnection cxn;
	ArrayList<String> operacionesEspeciales = new ArrayList<String>();
	ArrayList<Double> transSospechosas = new ArrayList<Double>();
	
	String No_cuenta, codTrans, convinacion = "";
	double Saldo_Final,	Diferencia_1, Promedio_Saldo, Diferencia_2, Media_Saldo, Diferencia_3, Maximo, Diferencia_4, Minimo, Diferencia_5, Valores_Credito, Diferencia_6;
	int Movimientos_Credito, Diferencia_7;
	double Promedio_Credito, Diferencia_8, Media_Credito, Diferencia_9, Valores_Debito, Diferencia_10;
	int Movimientos_Debito, Diferencia_11, Mes, Oprecaciones_Esp;
	double  Promedio_Debito, Diferencia_12, Pos_validacion, trans;
	ResultSet resultadoExtractos;
	Utilitarios utiles = new Utilitarios();
	String resultadoAnterior;
	
	public void testMain(Object[] args) 
	{
		operacionesEspeciales.add("0015");
		operacionesEspeciales.add("0026");
		operacionesEspeciales.add("0027");
		operacionesEspeciales.add("0037");
		operacionesEspeciales.add("0043");
		operacionesEspeciales.add("0050");
		operacionesEspeciales.add("0060");
		operacionesEspeciales.add("0072");
		operacionesEspeciales.add("0216");
		operacionesEspeciales.add("0220");
		operacionesEspeciales.add("0241");
		operacionesEspeciales.add("0294");
		operacionesEspeciales.add("0313");
		operacionesEspeciales.add("0334");
		operacionesEspeciales.add("0395");
		operacionesEspeciales.add("0396");
		operacionesEspeciales.add("0398");
		operacionesEspeciales.add("0420");
		operacionesEspeciales.add("0424");
		operacionesEspeciales.add("0675");
		operacionesEspeciales.add("0676");
		
		cxn = new DBconnection();
		int a�oConsulta = 2016;
						
		ResultSet resultadoInconsistentes = cxn.Consulta("SELECT * " +
				"FROM Inconsistentes2014 WHERE Pos_validacion = ''");
		try {
			while(resultadoInconsistentes.next()){
				
				No_cuenta = resultadoInconsistentes.getString(1);
				Saldo_Final = resultadoInconsistentes.getDouble(2);
				Diferencia_1 = resultadoInconsistentes.getDouble(3);
				Promedio_Saldo = resultadoInconsistentes.getDouble(4);
				Diferencia_2 = resultadoInconsistentes.getDouble(5);
				Media_Saldo = resultadoInconsistentes.getDouble(6);
				Diferencia_3 = resultadoInconsistentes.getDouble(7);
				Maximo = resultadoInconsistentes.getDouble(8);
				Diferencia_4 = resultadoInconsistentes.getDouble(9);
				Minimo = resultadoInconsistentes.getDouble(10);
				Diferencia_5 = resultadoInconsistentes.getDouble(11);
				Valores_Credito = resultadoInconsistentes.getDouble(12);
				Diferencia_6 = resultadoInconsistentes.getDouble(13);
				Movimientos_Credito = resultadoInconsistentes.getInt(14);
				Diferencia_7 = resultadoInconsistentes.getInt(15);
				Promedio_Credito = resultadoInconsistentes.getDouble(16);
				Diferencia_8 = resultadoInconsistentes.getDouble(17);
				Media_Credito = resultadoInconsistentes.getDouble(18);
				Diferencia_9 = resultadoInconsistentes.getDouble(19);
				Valores_Debito = resultadoInconsistentes.getDouble(20);
				Diferencia_10 = resultadoInconsistentes.getDouble(21);
				Movimientos_Debito = resultadoInconsistentes.getInt(22);
				Diferencia_11 = resultadoInconsistentes.getInt(23);
				Promedio_Debito = resultadoInconsistentes.getDouble(24);
				Diferencia_12 = resultadoInconsistentes.getDouble(25);
				Oprecaciones_Esp = resultadoInconsistentes.getInt(26);
				Mes = resultadoInconsistentes.getInt(27);
				resultadoAnterior = "";
								
				if(Diferencia_7 > 0 || Diferencia_11 > 0){
					UpdatePosVali(No_cuenta, Mes, "FExt");
					resultadoAnterior = "FExt";
				}	
				else{
					if(Oprecaciones_Esp == 0){
						if(Diferencia_7 < 0 || Diferencia_11 < 0){
							UpdatePosVali(No_cuenta, Mes, "Grave");
							resultadoAnterior = "Grave";
						}
					}
					else{
						if(Diferencia_7 < 0){ //Valida diferencia en movimientos Credito
							if(Oprecaciones_Esp > 20 && Diferencia_7 <-1){
								UpdatePosVali(No_cuenta, Mes, "Rango");
								resultadoAnterior = "Rango";
							}
							else{
								resultadoExtractos = cxn.Consulta("SELECT Cod_Trasaccion, Transacion " +
										"FROM vista" + Mes + " " +
										"WHERE No_Cuenta = '" + No_cuenta +"' AND Transacion > 0");
								while(resultadoExtractos.next()){
									codTrans = resultadoExtractos.getString(1);
									trans = resultadoExtractos.getDouble(2);
									if(operacionesEspeciales.contains(codTrans) && trans < (Diferencia_6*-1)+1)
										transSospechosas.add(trans);
									}
									if(Diferencia_7 == -1){
										for (Double x : transSospechosas) {
											if(Diferencia_6 + x < 1 && Diferencia_6 + x > -1){
												UpdatePosVali(No_cuenta, Mes, "Ok");
												resultadoAnterior = "Ok";
											}
										}
									}
									else
									{
										BuscarConvinaciones(transSospechosas, Diferencia_6, Diferencia_7);
										if(convinacion.equals("")){
											UpdatePosVali(No_cuenta, Mes, "Fail");
											resultadoAnterior = "Fail";
										}
										else
										{
											UpdatePosVali(No_cuenta, Mes, "Ok");
											resultadoAnterior = "Ok";
											UpdateTransEsp(No_cuenta, Mes, convinacion);
										}
									}

									convinacion = "";
									transSospechosas.clear();
									}
								}
								if(Diferencia_11 < 0){ //Valida diferencia en movimientos Debito
									
									if(Oprecaciones_Esp > 20 && Diferencia_10 <-1){
										UpdatePosVali(No_cuenta, Mes, "Rango");
										resultadoAnterior = "Rango";
									}
									else{
										resultadoExtractos = cxn.Consulta("SELECT Cod_Trasaccion, Transacion " +
												"FROM vista" + Mes + " " +
												"WHERE No_Cuenta = '" + No_cuenta +"' AND Transacion < 0");
								
										while(resultadoExtractos.next()){
											codTrans = resultadoExtractos.getString(1);
											trans = resultadoExtractos.getDouble(2);
											if(operacionesEspeciales.contains(codTrans)&& trans > (Diferencia_10-1))
												transSospechosas.add(trans);
										}
																			
										if(Diferencia_11 == -1){

											for (Double x : transSospechosas) {
												if(Diferencia_10-x < 1 && Diferencia_10-x > -1){
													UpdatePosVali(No_cuenta, Mes, "Ok");
													resultadoAnterior = "Ok";
												}
											}
										}
										else
										{
											BuscarConvinaciones(transSospechosas, Diferencia_10, Diferencia_11);
											if(convinacion.equals("")){
												UpdatePosVali(No_cuenta, Mes, "Fail");
												resultadoAnterior = "Fail";
											}
											else
											{
												UpdatePosVali(No_cuenta, Mes, "Ok");
												resultadoAnterior = "Ok";
												UpdateTransEsp(No_cuenta, Mes, convinacion);
											}
										}

									convinacion = "";
									transSospechosas.clear();
									}
							}
						}// End OpEspeciales
					
						if(Diferencia_2>= 1 || Diferencia_2<= -1){
							ArrayList<String> listaInconsistente = new ArrayList<String>();
							resultadoExtractos = cxn.Consulta("SELECT DAY(Fecha_Transaccion), " +
									"Transacion, Saldo " +
									"FROM vista" + Mes + " " +
									"WHERE No_Cuenta = '" + No_cuenta +"' " +
									"ORDER BY  No_Cuenta, Id_Mensual_Ext");
						
							try {
								while(resultadoExtractos.next()){
									listaInconsistente.add( 
										resultadoExtractos.getString(1) + "," + 
										resultadoExtractos.getString(2) + "," + 
										resultadoExtractos.getString(3));
								}
							} catch (SQLException e) {
								// TODO Bloque catch generado autom�ticamente
								e.printStackTrace();
							}
							
							ArrayList<String> listaOrdenada = OrdenarLista(listaInconsistente);
							ArrayList<String> listaNuevosSaldos = GenerarNuevoSaldos(listaOrdenada);
							double[] saldos = new double[utiles.getDiasMes(a�oConsulta, Mes)];
							int diaAux = 0;
							
							for (int i = 0; i < saldos.length; i++) {
								saldos[i]= 0;		
							}
						
							for(int i=0; i<listaOrdenada.size(); i++) {
								
								int dia = Integer.parseInt(listaNuevosSaldos.get(i).substring(0, listaNuevosSaldos.get(i).indexOf(",")));
								double saldo = Double.parseDouble(listaNuevosSaldos.get(i).substring(listaNuevosSaldos.get(i).lastIndexOf(",")+1));
								double transaccion = Double.parseDouble(listaNuevosSaldos.get(i).substring(listaNuevosSaldos.get(i).indexOf(",")+1, listaNuevosSaldos.get(i).lastIndexOf(",")));
								
								if(dia == 1)
									saldos[0]=saldo;
								else{
									for(int x = dia-2; x>=diaAux; x--){
										if(saldos[x]==0)saldos[x]=saldo - transaccion;
									}	
									saldos[dia -1]= saldo;
								}
							}
							for (int f = diaAux; f < saldos.length; f++) {
								if(f!=0)
									if(saldos[f]==0) 
										saldos[f]=saldos[f-1];
							} 
							diaAux = 0;
							
							cruceDatos(No_cuenta, saldos, Mes, resultadoAnterior);
						}	
						
						if((Diferencia_10 >= 1 || Diferencia_10 <= -1) && (Diferencia_12 >= 1 || Diferencia_12 <= -1) && Diferencia_11==0){
							
							resultadoExtractos = cxn.Consulta("SELECT Cod_Trasaccion, Transacion " +
									"FROM vista" + Mes + " " +
									"WHERE No_Cuenta = '" + No_cuenta +"'");
							while(resultadoExtractos.next()){
								codTrans = resultadoExtractos.getString(1);
								trans = resultadoExtractos.getDouble(2);
								if(trans == 0)
									UpdatePosVali(No_cuenta, Mes, "Trans_0");
							}
						}
					}
				}
			UpdateIndefinidos();
		} catch (SQLException e) {
					// TODO Bloque catch generado autom�ticamente
					e.printStackTrace();
		}
	}
	
	public void UpdatePosVali(String cuenta, int mesInc, String res){
		
		cxn.ejecutar("UPDATE Inconsistentes2014 " +
						"SET Pos_validacion = '" + res + "' " +
							"WHERE No_cuenta = '" + cuenta + "' AND Mes = " + mesInc +";");
	}
	
	public void UpdateTransEsp(String cuenta, int mesInc, String res){
		
		cxn.ejecutar("UPDATE Inconsistentes2014 " +
						"SET Trans_Esp = '" + res + "' " +
							"WHERE No_cuenta = '" + cuenta + "' AND Mes = " + mesInc +";");
	}
	
	public void UpdateIndefinidos(){
		
		cxn.ejecutar("UPDATE Inconsistentes2014 " +
						"SET Pos_validacion = 'Indef' " +
							"WHERE Pos_validacion = '' ");
	}
	
	
	//METODO QUE BUSCA QUE POSIBLES CONVINACIONES NOS PUEDEN PARA ENCONTRAR CUALES SON 
	//LAS TRANSACIONES QUE NO DEBEN IR
	
	public void BuscarConvinaciones(ArrayList<Double> numbers, Double target, ArrayList<Double> partial, int cantidad) {
		
		if(target<0) target *=-1;
		if(cantidad<0) cantidad *=-1;
	       double s = 0.0;
	       if(partial.size() == cantidad){
	    	   for (double x: partial){
	    		   if(x<0)
	    			   x *=-1;
	    		   s += x;
	    	   }
		       if (s -target < 1 && s - target > -1)
		    	   convinacion += Arrays.toString(partial.toArray());
	      }
	       if (s >= target)
	            return;
	       for(int i=0;i<numbers.size();i++) {
	             ArrayList<Double> remaining = new ArrayList<Double>();
	             Double n = numbers.get(i);
	             for (int j=i+1; j<numbers.size();j++) remaining.add(numbers.get(j));
	             	ArrayList<Double> partial_rec = new ArrayList<Double>(partial);
	             partial_rec.add(n);
	             BuscarConvinaciones(remaining,target,partial_rec, cantidad);
	       }
	}
	
	public void BuscarConvinaciones(ArrayList<Double> numbers, double target, int cant){

		BuscarConvinaciones(numbers,target,new ArrayList<Double>(), cant);
	}
	
	public ArrayList<String> OrdenarLista(ArrayList<String> listaDesodenada)
	{

		String actual = "";
		String anterior = "";
		
		for(int i=1; i<listaDesodenada.size(); i++){
			
			anterior = listaDesodenada.get(i-1);
			actual = listaDesodenada.get(i);
			
			if(Integer.parseInt(anterior.substring(0,listaDesodenada.get(i-1).indexOf(","))) > Integer.parseInt(actual.substring(0,listaDesodenada.get(i).indexOf(",")))){
				listaDesodenada.set(i-1, actual);
				listaDesodenada.set(i, anterior);
				OrdenarLista(listaDesodenada);
			}
		}
		
		return listaDesodenada;
	}
	
	public ArrayList<String> GenerarNuevoSaldos(ArrayList<String> listaDesodenada)
	{
		ArrayList<String> listaaux = new ArrayList<String>();
		for(int i =0; i<listaDesodenada.size(); i++){
		
			int dia = Integer.parseInt(listaDesodenada.get(i).substring(0, listaDesodenada.get(i).indexOf(",")));
			double saldo = Double.parseDouble(listaDesodenada.get(i).substring(listaDesodenada.get(i).lastIndexOf(",")+1));
			double transaccion = Double.parseDouble(listaDesodenada.get(i).substring(listaDesodenada.get(i).indexOf(",")+1, listaDesodenada.get(i).lastIndexOf(",")));
			
			if(i==0)
				listaaux.add(dia + "," + transaccion + "," + saldo);
			else				
				listaaux.add(dia + "," + transaccion + "," + (Double.parseDouble(listaaux.get(i-1).substring(listaaux.get(i-1).lastIndexOf(",")+1))+transaccion));
		}
		
		
		return listaaux;
	}
	

	public void cruceDatos(String noCuneta, double[] saldos, int mes, String anterior){
		
	if(anterior.equals("") || anterior.equals("Ok")){
		
		int ResultadoNegativo = 0;
		double meddia = 0.0;
		double smax = 0.0;
		double smin = 0.0;
		double difsaldofinal = 0.0;
		double difpsaldof = 0.0;
		double difmeddia = 0.0;
		double difsmax = 0.0;
		double difsmin = 0.0;
		
		double saldofinal = saldos[saldos.length-1];
		Arrays.sort(saldos);
			
		double psaldof = utiles.obtenerSumaArreglo(saldos)/saldos.length;;
		
		if(mes == 2)
			meddia = saldos[14];
		else 
			meddia = saldos[15];

		smax = saldos[saldos.length-1];
		smin = saldos[0];
		
		
		ResultSet resultado2 = cxn.Consulta("SELECT Saldo, Saldofinal, Media, Max, Min " +
											"FROM vistaMed" + mes + " " +
											"WHERE No_Cuenta= " + noCuneta +  "and mes= " + mes);
		
		try {
			if(resultado2.next()){
				
				difsaldofinal = resultado2.getDouble(1) - saldofinal;
				difpsaldof = resultado2.getDouble(2) - psaldof;
				difmeddia = resultado2.getDouble(3) - meddia;
				difsmax = resultado2.getDouble(4) - smax;
				difsmin = resultado2.getDouble(5) - smin;
				
//				System.out.println(resultado2.getDouble(1) + " - " + saldofinal + " = " + difsaldofinal);
//				System.out.println(resultado2.getDouble(2) + " - " + psaldof + " = " + difpsaldof);
//				System.out.println(resultado2.getDouble(3) + " - " + meddia + " = " + difmeddia);
//				System.out.println(resultado2.getDouble(4) + " - " + smax + " = " + difsmax);
//				System.out.println(resultado2.getDouble(5) + " - " + smin + " = " + difsmin);
//				
				if (difsaldofinal>=1 || difsaldofinal<=-1) ResultadoNegativo++;
				if (difpsaldof>=1 || difpsaldof<=-1) ResultadoNegativo++;
				if (difmeddia>=1 || difmeddia<=-1) ResultadoNegativo++;
				if (difsmax>=1 || difsmax<=-1) ResultadoNegativo++;
				if (difsmin>=1 || difsmin<=-1) ResultadoNegativo++;
				
				if(ResultadoNegativo == 0)
					UpdatePosVali(noCuneta, mes, "Ok");
				else
					UpdatePosVali(noCuneta, mes, "Fail");
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		}
		
	}

}
