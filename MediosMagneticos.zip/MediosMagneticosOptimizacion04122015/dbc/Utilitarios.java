package dbc;

public class Utilitarios {
	
	public String GetFecha(String fecha){
		
		StringBuffer txt = new StringBuffer(); 

		txt.append(fecha.substring(0,2));  
		txt.append('/');  
		txt.append(fecha.substring(2,4));  
		txt.append('/'); 
		txt.append(fecha.substring(4,8));  
		
		return txt.toString();
	}
	
	public String CorregirNUll(String aux){
		
		return aux.substring(0, 271) + "0" + aux.substring(271);
	}
	
	public String getDecimales(String doble){
		return doble = doble.substring(0, doble.length()-2) + "." 
				+ doble.substring(doble.length()-2); 
	}
	
	public String getNoMov(String entero){
		
		return entero = entero.substring(0, entero.length()-2);
	}
	public int getDiasMes (int a�o, int mes) {
		
		int [] diaA�o = new int[12];
			
			diaA�o[0]= 31;
			diaA�o[1]= 0;
			diaA�o[2]= 31;
			diaA�o[3]= 30;
			diaA�o[4]= 31;
			diaA�o[5]= 30;
			diaA�o[6]= 31;
			diaA�o[7]= 31;
			diaA�o[8]= 30;
			diaA�o[9]= 31;
			diaA�o[10]= 30;
			diaA�o[11]= 31;
			
			if((a�o % 400 == 0) || ((a�o % 100 != 0) && (a�o % 4 == 0))) diaA�o[1]=29;
			else diaA�o[1]=28;
			
			return diaA�o[mes-1];
	}
	public boolean bisiesto(int a�o) {
		
		int [] diaA�o = new int[12];
			
			diaA�o[0]= 31;
			diaA�o[1]= 0;
			diaA�o[2]= 31;
			diaA�o[3]= 30;
			diaA�o[4]= 31;
			diaA�o[5]= 30;
			diaA�o[6]= 31;
			diaA�o[7]= 31;
			diaA�o[8]= 30;
			diaA�o[9]= 31;
			diaA�o[10]= 30;
			diaA�o[11]= 31;
			
			if((a�o % 400 == 0) || ((a�o % 100 != 0) && (a�o % 4 == 0))) diaA�o[1]=29;
			else diaA�o[1]=28;
			
			if(diaA�o[1] == 29)
				return true;
			else
				return false;
	}
	public double obtenerSumaArreglo(double [] arreglo){
		
		double acumulado = 0; 
		for (int i = 0; i < arreglo.length; i++) {
			acumulado = acumulado + arreglo[i];
		}
		return acumulado;
	}
}
