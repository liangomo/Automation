﻿function LoadGuiaLeg() {

    ///----- FUNCIONES DE CONSULTA PARA MOVIL IND. Y CORP. ----///
    $("#UpdatePanel").on("click", "#SclIndSearch_btn, #SclCorpSearch_btn", function () {

        //Limpiar consulta actual
        $("#MainDetalles").addClass("hidden");

        //Se reinician los controles de novedad
        $("#divNovedades").hide();
        $("#IsNovedad").prop("checked", "");
        $("#IsMuestra").prop("checked", "");

        //Se obtienen los parametros de consulta
        var tipoConsulta;
        if ($(event.target).attr("id") == "SclIndSearch_btn")
            tipoConsulta = "Ind";
        else
            tipoConsulta = "Corp";
        var codabonado = ($('input:text[id=NumAbonado]').val());
        var celular = ($('input:text[id=NumCelular]').val());
        var sim = ($('input:text[id=NumSim]').val());
        var imei = ($('input:text[id=NumImei]').val());
        var numID = ($('input:text[id=NumIdent]').val());

        PageMethods.LoadMovilScl(tipoConsulta, codabonado, celular, sim, imei, numID,
            function (resp) {
                showAlert(resp.Msg, resp.TypeAlert, resp.PanelWraper, resp.Hiden);
                if (resp.Msg == "loadView") {
                    $("#UpdateMainDetalles").html(resp.Html);
                    $.each(resp.Data, function (i, v) {
                        $("#MainDetalles").find("#" + i).val(v)
                    })

                    // remueve el hidden y lo muestra.
                    $("#MainDetalles").removeClass("hidden");
                    $("#MainDetalles").show();
                    $("#ListaVentas").addClass("hidden");

                    //llamado al método de visualizar alerta
                    var tipoVenta = "7";
                    var pkVenta = ($('input:text[id=CodAbonado]').val());;

                    PageMethods.ListarAlertasVenta(tipoVenta, pkVenta, function (result) {

                        var numItems = result.length;
                        var $tab = $("#AlertasVenta > tbody").empty().html("<tr><td colspan='1'>Cargando...</td></tr>");
                        if (numItems > 0) {
                            var $row = "";
                            $.each(result, function (i, v) {
                                $row += "<tr>"
                                        + "<td>" + v.Value + "</td>"
                                        + "</tr>";
                            });
                            $tab.empty().append($row);
                            $('#modalAlertasVenta').modal('show');
                        }

                    }, function (error) { console.log(error) });
                }
                else {
                    var $tab = $("#VentasIndScl > tbody").empty().html("<tr><td colspan='11'>Cargando...</td></tr>");
                    var $row = "";
                    $.each(resp.Data, function (i, v) {
                        $row += "<tr>"
                        + "<td>" + DateJsonToFormatNative(v.Fecventa) + "</td>"
                        + "<td>" + v.CodVenta + "</td>"
                        + "<td>" + v.CodAbonado + "</td>"
                        + "<td>" + v.NombreCliente + "</td>"
                        + "<td>" + v.Celular + "</td>"
                        + "<td>" + v.NumIdentCliente + "</td>"
                        + "<td>" + v.SerialImei + "</td>"
                        + "<td>" + v.NumeroIcc + "</td>"
                        + "<td>" + v.CodVendedor + "</td>"
                        + "<td>" + v.NomVendedor + "</td>"
                        + "<td><button type='button' name='SelectFiltroVenta' class='btn btn-info btn-xs' aria-label='Left Align' data-identity='" + v.CodAbonado + "'>  <span class='glyphicon glyphicon-ok' aria-hidden='true'></span> Gestionar </button></td>"
                        + "</tr>";
                    });
                    $tab.empty().append($row);
                    $('#ProductType').
                    /// remueve el hidden y lo muestra.
                    $("#ListaVentas").removeClass("hidden");
                    $("#ListaVentas").show();
                    $("#MainDetalles").addClass("hidden");
                }
            }, function (error) { alert(error); });
        $("#UpdatePanel").on('click', 'button[name="SelectFiltroVenta"]', function () {
            debugger
            var abonado = $(this).data("identity");

            //// mejorar esto ya que 6 lineas arriba está lo mismo
            PageMethods.LoadMovilIndScl(abonado, "", "", "", "",
           function (resp) {
               showAlert(resp.msg, resp.TypeAlert, resp.Wraper, resp.Hiden);
               ListaVentas
               if (resp.Msg == "loadView") {
                   $("#UpdateMainDetalles").html(resp.Html);
                   $.each(resp.Data, function (i, v) {
                       $("#MainDetalles").find("#" + i).val(v)

                   })
                   //console.log("valor load");

                   /// remueve el hidden y lo muestra.
                   $("#MainDetalles").removeClass("hidden");
                   $("#MainDetalles").show();
                   $("#ListaVentas").addClass("hidden");

               }
               else {
                   //console.log("no load");

                   var $tab = $("#VentasIndScl > tbody").empty().html("<tr><td colspan='11'>Cargando...</td></tr>");
                   var $row = "";
                   $.each(resp.Data, function (i, v) {
                       $row += "<tr>"
                                       + "<td>" + DateJsonToFormatNative(v.Fecventa) + "</td>"
                                       + "<td>" + v.CodVenta + "</td>"
                                       + "<td>" + v.CodAbonado + "</td>"
                                       + "<td>" + v.NombreCliente + "</td>"
                                       + "<td>" + v.Celular + "</td>"
                                       + "<td>" + v.NumIdentCliente + "</td>"
                                       + "<td>" + v.SerialImei + "</td>"
                                       + "<td>" + v.NumeroIcc + "</td>"
                                       + "<td>" + v.CodVendedor + "</td>"
                                       + "<td>" + v.NomVendedor + "</td>"
                                       + "<td><button type='button' name='SelectFiltroVenta' class='btn btn-info btn-xs' aria-label='Left Align' data-identity='" + v.CodAbonado + "'>  <span class='glyphicon glyphicon-ok' aria-hidden='true'></span> Gestionar </button></td>"
                                       + "</tr>";
                   });
                   $tab.empty().append($row);

                   /// remueve el hidden y lo muestra.
                   $("#ListaVentas").removeClass("hidden");
                   $("#ListaVentas").show();
                   $("#MainDetalles").addClass("hidden");


               }

           }, function (error) { alert(error); });



        });
    });



    /// funcion para el checkbox de novedad.
    $("#IsNovedad").on('click', function () {

        if ($(this).is(':checked')) {
            /// Value del control que me indica que novedades listar    
            var valor = $("#IsNovedad").val();
            PageMethods.ListarNovedades(valor, function (result) {
                var numItems = result.length;
                var $tab = $("#TabNovedadesInd > tbody").empty().html("<tr><td colspan='2'>Cargando...</td></tr>");
                if (numItems > 0) {
                    var $row = "";
                    $.each(result, function (i, v) {
                        $row += "<tr>"
                                        //+ "<td>" + v.Id + "</td>"
                                        + "<td><input type='checkbox' id='chkNovedad" + i + "' name='chkNovedad" + i + "' value='" + v.Id + "'/></td>"
                                        + "<td>" + v.Value + "</td>"
                                        //+ "<td><button type='button' name='CerrarCaja' class='btn btn-info btn-xs' aria-label='Left Align' data-toggle='modal' data-target='#CajaAlertaInput' data-identity='" + v.NumCaja + "'>  <span class='glyphicon glyphicon-cloud-upload' aria-hidden='true'></span> Cerrar caja </button></td>"
                                        + "</tr>";
                    });
                    $tab.empty().append($row);
                }
                else {
                    $tab.empty().html("<tr><td colspan='2'>¡No existen novedades registradas para Ventas Indiviual Scl!</td></tr>");
                }
            }, function (error) { console.log(error) });
            $("#divNovedades").show();
        } else {
            // Hacer algo si el checkbox ha sido deseleccionado
            $("#divNovedades").hide();
            //alert("El checkbox con valor " + $(this).val() + " ha sido deseleccionado");
        }
    });

    ///----- FUNCIONES DE LEGALIZACION MOVIL INDIVIDUAL. ----///
    $("#LegVentaIndScl_btn").on('click', function () {


        var codAbonado = $("#CodAbonado").val();
        var saldoScl = $("#SaldoScl").val();
        var notas = $('#Notas').val();
        var muestra = false;
        var novedad = false;
        var causales = "";
        if ($("#IsMuestra").is(':checked')) { muestra = true; }
        //obtenemos el id de las causales de novedad

        if ($("#IsNovedad").is(':checked')) {
            novedad = true;
            $("#TabNovedadesInd tbody tr").each(function (fila) {
                $(this).children("td").each(function (columna) {
                    switch (columna) {
                        case 0:
                            if ($("#chkNovedad" + fila).is(':checked')) {
                                if (causales != "")
                                { causales = causales + ","; }
                                causales = causales + $("input:checkbox[name=chkNovedad" + fila + "]:checked").val();
                            }
                            break;
                    }
                    $(this).css("background-color", "#ECF8E0");
                })

            })
        }

        //enviamos datos a nuestro webMethod
        PageMethods.GestionVentaMovilIndScl(codAbonado, saldoScl, notas, muestra, novedad, causales,
           function (response) {
               if (response.TypeAlert == "success")
               {
                   $("button:contains('+ Pospago Ind.')").trigger("click");
               }

               showAlert(response.Msg, response.TypeAlert, response.PanelWraper, response.Hiden);

           }, function (error) { alert(error); });

    });

    ///----- FUNCIONES DE LEGALIZACION MOVIL CORPORATIVA. ----///
    $("#LegVentaCorpScl_btn").on('click', function () {

        /*
                        var codAbonado = $("#CodAbonado").val();
                        var saldoScl = $("#SaldoScl").val();
                        var notas = $('#Notas').val();
                        var muestra = false;
                        var novedad = false;
                        var causales = "";
                        if ($("#IsMuestra").is(':checked')) { muestra = true; }
                        //obtenemos el id de las causales de novedad
        
                        if ($("#IsNovedad").is(':checked')) {
                            novedad = true;
                            $("#TabNovedadesInd tbody tr").each(function (fila) {
                                $(this).children("td").each(function (columna) {
                                    switch (columna) {
                                        case 0:
                                            if ($("#chkNovedad" + fila).is(':checked')) {
                                                if (causales != "")
                                                { causales = causales + ","; }
                                                causales = causales + $("input:checkbox[name=chkNovedad" + fila + "]:checked").val();
                                            }
                                            break;
                                    }
                                    $(this).css("background-color", "#ECF8E0");
                                })
        
                            })
                        }
                        */
        //enviamos datos a nuestro webMethod
        PageMethods.GestionVentaMovilCorpScl(codAbonado, saldoScl, notas, muestra, novedad, causales,
           function (response) {

               showAlert(response.Msg, response.TypeAlert, response.PanelWraper, response.Hiden);


           }, function (error) { alert(error); });

    });

    //------ FUNCIONES DECONSULTA PARA LEGALIZACION FIJA. ----///

    $("#UpdatePanel").on("click", "#AtisSearch_btn", function () {

        //Limpiar consulta actual
        $("#MainDetallesAtisFija").addClass("hidden");

        //Se reinician los controles de novedad
        $("#divNovedades").hide();
        $("#IsNovedad").prop("checked", "");

        var numPeticion = ($('input:text[id=NumPeticionFija]').val());
        if (numPeticion == "") { numPeticion = "0"; }
        var nit = ($('input:text[id=NitFija]').val());

        PageMethods.LoadAtisFija(numPeticion, nit,
            function (response) {
                showAlert(response.Msg, response.TypeAlert, response.PanelWraper, response.Hiden);
                if (response.Msg == "loadView") {
                    $("#UpdateMainDetallesAtisFija").html(response.Html);
                    $.each(response.Data[0], function (i0, v0) {
                        $.each(v0, function (i, v) {
                            $("#MainDetallesAtisFija").find("#" +i).val(v)
                        })
                    })

                    /// remueve el hidden y lo muestra.
                    $("#MainDetallesAtisFija").removeClass("hidden");
                    $("#MainDetallesAtisFija").show();
                    $("#ListaVentasAtisFija").addClass("hidden");

                    //llamado al método de visualizar alerta
                    var tipoVenta = "4";
                    var pkVenta = ($('input:text[id=NumPeticion]').val());;
                    //debugger
                    PageMethods.ListarAlertasVenta(tipoVenta, pkVenta, function (result) {
                        //debugger
                        var numItems = result.length;
                        var $tab = $("#AlertasVenta > tbody").empty().html("<tr><td colspan='1'>Cargando...</td></tr>");
                        if (numItems > 0) {
                            var $row = "";
                            $.each(result, function (i, v) {
                                $row += "<tr>"
                                               + "<td>" + v.Value + "</td>"
                                               + "</tr>";
                            });
                            $tab.empty().append($row);
                            $('#modalAlertasVenta').modal('show');
                        }

                    }, function (error) { console.log(error) });
                }
                else {
                    var $tab = $("#VentasAtisFija > tbody").empty().html("<tr><td colspan='8'>Cargando...</td></tr>");
                    var $row = "";
                    $.each(response.Data, function (i, v) {
                        $row += "<tr>"
                                        + "<td>" + v.NumPeticion + "</td>"
                                        + "<td>" + DateJsonToFormatNative(v.FecAlta) + "</td>"
                                        + "<td>" + v.NombreCliente + "</td>"
                                        + "<td>" + v.NumIdentCliente + "</td>"
                                        + "<td>" + v.Direccion + "</td>"
                                        + "<td>" + v.NomVendedor + "</td>"
                                        + "<td>" + v.Comercializador + "</td>"
                                        + "<td><button type='button' name='SelectFiltroAtisFija' class='btn btn-info btn-xs' aria-label='Left Align' data-identity='" + v.NumPeticion + "'>  <span class='glyphicon glyphicon-ok' aria-hidden='true'></span> Gestionar </button></td>"
                                        + "</tr>";
                    });
                    $tab.empty().append($row);

                    /// remueve el hidden y lo muestra.
                    $("#ListaVentasAtisFija").removeClass("hidden");
                    $("#ListaVentasAtisFija").show();
                    $("#MainDetallesAtisFija").addClass("hidden");
                }

            }, function (error) { alert(error); });


        $("#SelectFiltroVenta").on('click', function () {
            var dato = "nuevo valor";
        });

    });
    // -- marca las novedades seleccionadas  --//
    $("#UpdatePanel").on('click', 'button[name="SelectFiltroAtisFija"]', function () {
        var numPeticion = $(this).data("identity");
        PageMethods.LoadAtisFija(numPeticion, "",
       function (response) {
           showAlert(response.Msg, response.TypeAlert, response.PanelWraper, response.Hiden);
           debugger
           if (response.Msg == "loadView") {
               $("#UpdateMainDetallesAtisFija").html(response.Html);
               $.each(response.Data[0], function (i0, v0) {
                   $.each(v0, function (i, v) {
                       $("#MainDetallesAtisFija").find("#" + i).val(v)
                   })
               })

               /// remueve el hidden y lo muestra.
               $("#MainDetallesAtisFija").removeClass("hidden");
               $("#MainDetallesAtisFija").show();
               $("#ListaVentasAtisFija").addClass("hidden");

           }
       }, function (error) { alert(error); });

    });
    //------ FUNCIONES DE LEGALIZACION FIJA. ----///
    $("#LegVentaAtisFija_btn").on('click', function () {

        var canal = "fisico";
        var num_peticion = $("#NumPeticion").val();
        var calidad = 10;//  preguntar por este dato. //$("#PlanServicio").val();
        var numIdentCliente = $("#NumIdentCliente").val();
        var nomCliente = $("#NombreCliente").val();
        var dirCliente = $("#Direccion").val();
        var numIdentVendedor = $("#NumIdentVendedor").val();
        var notas = $('#Notas').val();
        var muestra = $('#Muestra').val();
        var novedad = false;
        var estado = 2;
        var causales = "";
        //if ($("#IsMuestra").is(':checked')) { muestra = true; }
        ////obtenemos el id de las causales de novedad

        if ($("#IsNovedad").is(':checked')) {
            novedad = true;
            estado = 5;
            $("#TabNovedadesInd tbody tr").each(function (fila) {
                $(this).children("td").each(function (columna) {
                    switch (columna) {
                        case 0:
                            if ($("#chkNovedad" + fila).is(':checked')) {
                                if (causales != "")
                                { causales = causales + ","; }
                                causales = causales + $("input:checkbox[name=chkNovedad" + fila + "]:checked").val();
                            }
                            break;
                    }
                    $(this).css("background-color", "#ECF8E0");
                })

            })
        }

        //enviamos datos a nuestro webMethod
        PageMethods.GestionVentaAtisFija(canal, num_peticion, calidad, numIdentCliente, nomCliente, dirCliente, numIdentVendedor, notas, novedad, estado, causales,
           function (response) {
               showAlert(response.Msg, response.TypeAlert, response.PanelWraper, response.Hiden);
               if (response.TypeAlert == "success") {
                   $("button:contains('+ Fija')").trigger("click");
               }
           }, function (error) { alert(error); });

    });

    ///----- FUNCIONES PARA OPC  ----///

    //-- BUSCAR OPC´S PARA EL FORMATO--/
    $("#UpdatePanel").on("click", "#OpcSearch_btn", function () {

        debugger

        var numFormato = ($('input:text[id=NumFormato]').val());
        var nit = ($('input:text[id=NitOpc]').val());
        var cantidadOpc = ($('input:text[id=CantTotal]').val());
        var codVendedor = ($('input:text[id=CodVendedor]').val());
        var canal = ($('select[id$=ddlCanal]').val());
        var notas = $('#NotasOpc').val();
        var novedad = false;
        var causales = "";
        var ooss = ($('input:text[id=Ooss]').val());
        var numCelular = ($('input:text[id=NumCelular]').val());
        //if ($("#IsMuestra").is(':checked')) { muestra = true; }
        ////obtenemos el id de las causales de novedad
        debugger
        if ($("#IsNovedad").is(':checked')) {
            novedad = true;
            $("#TabNovedadesInd tbody tr").each(function (fila) {
                $(this).children("td").each(function (columna) {
                    switch (columna) {
                        case 0:
                            if ($("#chkNovedad" + fila).is(':checked')) {
                                if (causales != "")
                                { causales = causales + ","; }
                                causales = causales + $("input:checkbox[name=chkNovedad" + fila + "]:checked").val();
                            }
                            break;
                    }
                    $(this).css("background-color", "#ECF8E0");
                })

            })
        }

        PageMethods.LoadOpc(numFormato, nit, cantidadOpc, codVendedor, canal, notas, novedad, causales, ooss, numCelular,
            function (response) {
                showAlert(response.Msg, response.TypeAlert, response.PanelWraper, response.Hiden);
                if (response.PanelWraper == "formatoOk") {

                    this.$("#divTablaOpc").show();
                    var $tab = $("#tablaOpc > tbody").empty().html("<tr><td colspan='17'>Cargando...</td></tr>");

                    // consultamos cuales son las opc que aplican a los filtros.
                    PageMethods.OpcListarIngresoTransaccion(ooss, numCelular, nit,
                        function (result) {
                            var numItems = result.length;

                            if (numItems > 0) {
                                var $row = "";
                                $.each(result, function (i, v) {
                                    $row += "<tr>"
                                                    //+ "<td>" + v.Id + "</td>"
                                                   + "<td><input type='checkbox' id='chkOpc" + i + "' name='chkOpc" + i + "' value='" + v.Id + "'/></td>"
                                                   + "<td>" + v.Ooss + "</td>"
                                                   + "<td>" + v.Celular + "</td>"
                                                   + "<td>" + v.NumIdent + "</td>"
                                                   + "<td>" + v.NomCliente + "</td>"
                                                   + "<td>" + DateJsonToFormatNative(v.FechaAltaServicio) + "</td>"
                                                   + "<td>" + v.Canal + "</td>"
                                                   + "<td>" + v.CodVendedor + "</td>"
                                                   + "<td>" + v.NomVendedor + "</td>"
                                                   + "<td>" + v.NomMaster + "</td>"
                                                   + "<td>" + v.Producto + "</td>"
                                                   + "<td>" + v.DesSs + "</td>"
                                                   + "<td>" + v.TipoOpc + "</td>"
                                                   + "<td>" + v.DifDias + "</td>"
                                                   + "<td>" + v.Rango + "</td>"
                                                   + "<td>" + v.Ingresado + "</td>"
                                                   + "<td><button type='button' name='DetalleOpc' class='btn btn-info btn-xs' aria-label='Left Align' data-identity='" + v.Id + "'>  <span class='	glyphicon glyphicon-plus-sign' aria-hidden='true'></span> Detalles </button></td>"
                                                   + "</tr>";
                                });
                                $tab.empty().append($row);
                                $("#divBtnLegOpc").show();


                                //llamado al método de visualizar alerta
                                var tipoVenta = "5";
                                var pkVenta = "0";
                                debugger
                                PageMethods.ListarAlertasVenta(tipoVenta, pkVenta, function (result) {
                                    var numItems = result.length;
                                    var $tab = $("#AlertasVenta > tbody").empty().html("<tr><td colspan='1'>Cargando...</td></tr>");
                                    if (numItems > 0) {
                                        var $row = "";
                                        $.each(result, function (i, v) {
                                            $row += "<tr>"
                                                           + "<td>" + v.Value + "</td>"
                                                           + "</tr>";
                                        });
                                        $tab.empty().append($row);
                                        $('#modalAlertasVenta').modal('show');
                                    }

                                }, function (error) { console.log(error) });




                            }
                            else {
                                $tab.empty().html("<tr><td colspan='17'>¡No se encontraron datos con estos criterios de búsqueda!</td></tr>");
                            }
                        }, function (error) { console.log(error) });
                }
            }, function (error) { alert(error); });
    });

    $("#UpdatePanel").on('click', 'button[name="DetalleOpc"]', function () {
        debugger
        var idDetalle = $(this).data("identity");
        PageMethods.OpcListarDetalle(idDetalle,
        function (result) {
            var numItems = result.length;
            if (numItems > 0) {
                var $row = "";
                var $tab = $("#tableDetallesOpc > tbody").empty().html("<tr><td colspan='38'>Cargando...</td></tr>");
                $.each(result, function (i, v) {
                    $row += "<tr>"
                                + "<td>" + v.Ooss + "</td>"
                                + "<td>" + v.CodAbonado + "</td>"
                                + "<td>" + v.MesAlta + "</td>"
                                + "<td>" + DateJsonToFormatNative(v.FechaAltaServicio) + "</td>"
                                + "<td>" + v.CodSs + "</td>"
                                + "<td>" + v.DesSs + "</td>"
                                + "<td>" + v.UsuarioActivacionSs + "</td>"
                                + "<td>" + v.CodUsuario + "</td>"
                                + "<td>" + v.CodComisionista + "</td>"
                                + "<td>" + v.TipoComisionista + "</td>"
                                + "<td>" + v.CodPlanServicio + "</td>"
                                + "<td>" + v.DescripcionServicio + "</td>"
                                + "<td>" + v.Costo + "</td>"
                                + "<td>" + v.TipoIdent + "</td>"
                                + "<td>" + v.Celular + "</td>"
                                + "<td>" + v.NumIdent + "</td>"
                                + "<td>" + v.NomCliente + "</td>"
                                + "<td>" + v.Canal + "</td>"
                                + "<td>" + v.CodVendedor + "</td>"
                                + "<td>" + v.NomVendedor + "</td>"
                                + "<td>" + v.NomMaster + "</td>"
                                + "<td>" + v.Producto + "</td>"
                                + "<td>" + v.TipoOpc + "</td>"
                                + "<td>" + v.DifDias + "</td>"
                                + "<td>" + v.Rango + "</td>"
                                + "<td>" + v.CodPlan + "</td>"
                                + "<td>" + v.NombrePlan + "</td>"
                                + "<td>" + v.CargoBasico + "</td>"
                                + "<td>" + v.Equipo + "</td>"
                                + "<td>" + v.SerieImei + "</td>"
                                + "<td>" + v.Zona + "</td>"
                                + "<td>" + v.CodMaster + "</td>"
                                + "<td>" + v.NombreGrupo + "</td>"
                                + "<td>" + v.GrupoSs + "</td>"
                                + "<td>" + v.NumFolio + "</td>"
                                + "<td>" + v.SaldoFactura + "</td>"
                                + "<td>" + v.TipoCliente + "</td>"
                                + "<td>" + v.TablaOrigen + "</td>"
                                + "<td>" + v.Ingresado + "</td>"
                          + "</tr>";
                });
                $tab.empty().append($row);
            }


            /// abrimos el modal.
            $('#modalDetalleOpc').modal('show');

        }, function (error) { console.log(error) });
    });

    $("#OpcLegalizar_btn").on('click', function () {

        var IdOpcTmp = "";
        //if ($("#IsMuestra").is(':checked')) { muestra = true; }
        ////obtenemos el id de las opc a ingresar en el formato 
        $("#tablaOpc tbody tr").each(function (fila) {
            $(this).children("td").each(function (columna) {
                switch (columna) {
                    case 0:
                        if ($("#chkOpc" + fila).is(':checked')) {
                            if (IdOpcTmp != "")
                            { IdOpcTmp = IdOpcTmp + ","; }
                            IdOpcTmp = IdOpcTmp + $("input:checkbox[name=chkOpc" + fila + "]:checked").val();
                        }
                        break;
                }
                $(this).css("background-color", "#ECF8E0");
            })

        })

        //enviamos datos a nuestro webMethod
        PageMethods.GestionVentaOpc(IdOpcTmp,
           function (response) {
               showAlert(response.Msg, response.TypeAlert, response.PanelWraper, response.Hiden);
           }, function (error) { alert(error); });

    });

}

