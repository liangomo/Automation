﻿function estrVentas_InicializarComponentes() {
    $("input[id$='txt_Edit_FecProgramada']").datepicker({
        dateFormat: "yy-mm-dd"
        , minDate: "+0d"
        , maxDate: "+45d"
        , numberOfMonths: 2
        , dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa']
        , monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo',
            'Junio', 'Julio', 'Agosto', 'Septiembre',
            'Octubre', 'Noviembre', 'Diciembre']
        , monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic']
        , changeMonth: true
        , changeYear: true
        , yearRange: "2017:2040"
        , beforeShowDay: function (day) {
            var day = day.getDay();
            return [!(day == 0), ""];
        }
    });
}