﻿function estrVenta_CondicionesUniformes() { }

estrVenta_CondicionesUniformes.inicializarComponentes = function () {
    // Fecha de vencimiento de tarjeta de credito.
    $("input[id$='txtTarjetaCreditoFechaVencimiento']").datepicker({
        dateFormat: "yy-mm-dd",
        defaultDate: "+4d",
        //minDate: "+4d",
        //maxDate: "+45d",
        numberOfMonths: 2,
        dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'],
        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
        monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
        changeMonth: true,
        changeYear: true,
        yearRange: "2015:2040",
    });
};

