﻿function radFormularioUnicoNovedades() { }

radFormularioUnicoNovedades.showValidate = function () {
    if (typeof (Page_ClientValidate) == 'function') {
        Page_ClientValidate();
        return (Page_IsValid);
    }
    else {
        return true;
    }
}

radFormularioUnicoNovedades.tipoContratoPorfecto = function () {
    $("select[id$='ddl_tipo_contrato']").val("");
}

radFormularioUnicoNovedades.inicializarComponentes = function () {
    
    $("input[id$='tx_fecha_venta_cambio']").datepicker({
        dateFormat: "yy-mm-dd",
        defaultDate: "+4d",
        minDate: "+4d",
        maxDate: "+45d",
        numberOfMonths: 2,
        dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'],
        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
        monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
        changeMonth: true,
        changeYear: true,
        yearRange: "2015:2040",
        beforeShowDay: function (day) {
            var day = day.getDay();
            return [!(day == 0 || day == 6), ""];
        }
    });

    $("input[id$='tx_fecha_constitucion']").datepicker({
        dateFormat: "yy-mm-dd", numberOfMonths: 2,
        dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'],
        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
        monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
        maxDate: "-0d",
        changeMonth: true,
        changeYear: true,
        yearRange: "1915:2040"
    });

    var $dialogChangeVendedor = $("div[id$='infoVendedorChangeDiv']").dialog({
        autoOpen: false, closeOnEscape: true, draggable: true,
        modal: true, resizable: true, width: '300px',
        title: 'Asignación de Vendedor',
        buttons: {
            Cancelar: function () {
                $(this).dialog('close');
            }
        },
        open: function (event, ui) {
            $(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
        },
        close: function (event, ui) {
            $("select[id$='ddl_MesaRegional']").val("");
        }
    });

    $dialogChangeVendedor.parent().appendTo($("form:first")).removeClass("hidden");


    $("#vendedor_ChangeBtn").click(function () {
        $dialogChangeVendedor.dialog('open').removeClass("hidden");
        $("input[id$='codVendedorNegocio'").val("");
    });

    $("select[id$='ddl_marcacion_especial'] option:gt(7)").wrapAll("<optgroup label='PRODUCTO ESPECIAL'></optgroup>");
    $("select[id$='ddl_marcacion_especial'] > option:gt(1)").wrapAll("<optgroup label='CONVENIO'></optgroup>");

    $("select[id$='ddl_tipo_ide_cli']").focusout(function () {
        var $tipoContrato = $("select[id$='ddl_tipo_contrato']>");
        if ($tipoContrato.val() != "-1") {
            $tipoContrato.val("-1");
        }
    });

    $("select[id$='ddl_tipo_ide_cli']").change(function () {
        
        $("input[id$='tx_num_ide_cli']").removeClass("validate[required, custom[cedula]]");
        var patronIdentJuridica = /^\d{4,10}-\d{1}$/;
        var patronIdentNatural = /^\d{4,10}$/;
        var tipoIdent = $("select[id$='ddl_tipo_ide_cli'] option:selected").text();
        var listItemsPersonaJuridica = ["CDV", "CDV EXTRANJERIA", "NIT", "NIT EXTRANJERIA"];
        var listItemsPersonaNatural = ["CC", "CEDULA EXTRANJERIA", "H2", "H2 EXTRANJERIA", "PASAPORTE"];
        if (tipoIdent == "-1") {
            numIdent.IsValid = false;
        }
        else if ($.inArray(tipoIdent, listItemsPersonaJuridica) > -1) {
            $("input[id$='tx_num_ide_cli']").removeClass("validate[required, custom[cedula]]");
            $("input[id$='tx_num_ide_cli']").addClass("validate[required, custom[nit]]");
        }
        else if ($.inArray(tipoIdent, listItemsPersonaNatural) > -1) {
            $("input[id$='tx_num_ide_cli']").removeClass("validate[required, custom[nit]]");
            $("input[id$='tx_num_ide_cli']").addClass("validate[required, custom[cedula]]");
        }
    });
}

radFormularioUnicoNovedades.Eval_numIdent = function (source, numIdent) {
    debugger;
    var patronIdentJuridica = /^\d{4,10}-\d{1}$/;
    var patronIdentNatural = /^\d{4,10}$/;
    var tipoIdent = $("select[id$='ddl_tipo_ide_cli'] option:selected").text();
    var listItemsPersonaJuridica = ["CDV", "CDV EXTRANJERIA", "NIT", "NIT EXTRANJERIA"];
    var listItemsPersonaNatural = ["CC", "CEDULA EXTRANJERIA", "H2", "H2 EXTRANJERIA", "PASAPORTE"];
    if (tipoIdent == "-1") {
        numIdent.IsValid = false;
    }
    else if ($.inArray(tipoIdent, listItemsPersonaJuridica) > -1) {
        numIdent.IsValid = patronIdentJuridica.test(numIdent.Value);
        if (!numIdent.IsValid) { $(source).text("La identificación no pertenece a persona jurídica (NIT, CDV)"); }
    }
    else if ($.inArray(tipoIdent, listItemsPersonaNatural) > -1) {
        numIdent.IsValid = patronIdentNatural.test(numIdent.Value);
        if (!numIdent.IsValid) { $(source).text("La identificación no pertenece a persona natural (CC, H2, PASAPORTE)"); }
    }
}

function FechaConstitucion_Eval(sender, FechaConstitucion) {
    var fecha = $("input[id$='tx_fecha_constitucion']").val().trim();
    fecha = Date.parse(fecha);
    var fechaActual = Date.now();
    if (isNaN(fecha) || fecha > fechaActual) {
        FechaConstitucion.IsValid = false;
    }
}