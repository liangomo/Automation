﻿function Eval_numeracionCelular() {
    var lineasProducto = $("input[data-source='numeracion']").size();
    var numeraciones = $("input[data-source='numeracion']").map(function (i, v) { return v.value; });
    var patronNumeracion = /^3[0-5][0-9]\d{7}$/;
    var errores = [];
    var msg = "";
    var isError = false;
    var seriesError = [];
    //Capturo cantidad de series listados del array original
    var duplicadosNumeraciones = numeraciones.length;
    //Quito duplicados de series
    var seriesDistinct = $.unique(numeraciones);
    //Calculo diferencia entre el total de elementos del array original y el del array sin duplicados
    var duplicadosNumeraciones = duplicadosNumeraciones - seriesDistinct.length;

    isError = (numeraciones.length != lineasProducto);

    if (duplicadosNumeraciones > 0) {
        isError = true;
        msg = "Hay " + duplicadosNumeraciones + " duplicados en la lista de numeraciones de celular relacionados! <br/>";
    }
    else if (isError) {
        msg = "La cantidad de equipos relacionados no coincide con la cantidad de líneas solicitadas. Si la última numeración está en blanco, por favor borrela.";
    }
    else {
        $.each(numeraciones, function (i, v) {
            if (!patronNumeracion.test(v)) {
                errores[errores.length] = [i + 1, v];
            };
        });
        isError = (errores.length > 0);
        if (isError) {
            msg = "Los siguientes números de celular no son válidos: <br/>"
            $.each(errores, function (i, v) {
                msg = msg + "Posición: " + v[0] + "-> " + v[1] + "<br/>";
            });
        }
    }
    if (isError) { showAlert(msg, "warning", "panel_tabPortNumeraciones", true); }
    return !isError;
}

function ShowWrapperRepLegalGlobal(sender, value) {
    if ((value == 7) || (value == 2)) {
        var $control = $(sender);
        $("#alertRepLegal").removeClass("hidden").dialog({
            title: 'Información Representante Legal'
            , width: "auto"
            , modal: true
            , buttons: {
                Aceptar: function () {
                    var tipoIdent = $("#RepLegalTipoIdent").val();
                    var numIdent = $("#RepLegalNumIdent").val();
                    var nombres = $("#RepLegalNombre").val();
                    var apellido1 = $("#RepLegalApellido1").val();
                    var apellido2 = $("#RepLegalApellido2").val();
                    var RepLegalTrama = tipoIdent + "-" + numIdent + "-" + nombres + "-" + apellido1 + "-" + apellido2;
                    $("#portApellidoOrigenGlobal").val(RepLegalTrama);
                    $("#portApellidoOrigenGlobal").trigger("keyup");
                    $(this).dialog("close");
                }
                , Cancelar: function () {
                    $control.val("");
                    $control.trigger("change");
                    $(this).dialog("close");
                }
            }
        });
    }
}

function ShowWrapperRepLegal(sender, value) {
    if ((value == 7) ||(value == 2)) {
        var $control = $(sender);
        $("#alertRepLegal").removeClass("hidden").dialog({
            title: 'Información Representante Legal'
            , width: "auto"
            , modal: true
            , buttons: {
                Aceptar: function () {
                    var tipoIdent = $("#RepLegalTipoIdent").val();
                    var numIdent = $("#RepLegalNumIdent").val();
                    var nombres = $("#RepLegalNombre").val();
                    var apellido1 = $("#RepLegalApellido1").val();
                    var apellido2 = $("#RepLegalApellido2").val();
                    var RepLegalTrama = tipoIdent + "-" + numIdent + "-" + nombres + "-" + apellido1 + "-" + apellido2;
                    $control.parent().parent().find("input[data-source='portApellidoOrigenGlobal']").val(RepLegalTrama);
                    $(this).dialog("close");
                }
                , Cancelar: function () {
                    $control.val("");
                    $(this).dialog("close");
                }
            }
        });
    }
}

function Load_PortabilidadNumeraciones() {
    if ($("#portNumeraciones_gr").is(":visible")) {
        $("#numeracionesMasivo_submit").click(function (e) {
            var cadenaArr = $("#numeracionesMasivo").val()
            cadenaArr = cadenaArr.split("\n");
            $.each(cadenaArr, function (i, v) {
                $("input[data-source='numeracion']:eq(" + i + ")").val($.trim(v));
            });
        });
        $("#numeracionesNipMasivo_submit").click(function (e) {
            var cadenaArr = $("#numeracionesNipMasivo").val()
            cadenaArr = cadenaArr.split("\n");
            $.each(cadenaArr, function (i, v) {
                $("input[data-source='numeracion-nip']:eq(" + i + ")").val($.trim(v));
            });
        });

        $("#btn_GuardarNegocio").click(function (e) {
            var IsValidNumeraciones = Eval_numeracionCelular();
            return (IsValidNumeraciones);
        });

        $("#tipoPlanOrigenGlobal").change(function () {
            $("#portNumeraciones_gr select[data-source='plan_origen']").val(this.value);
        });

        $("#OperadorMasivo").change(function () {
            $("#portNumeraciones_gr select[data-source='operador_masivo']").val(this.value);
        });

        $("#portTraspasoGlobal").change(function () {
            $("#portNumeraciones_gr input:checkbox:not(#portTraspasoGlobal)").prop("checked", this.checked);
        });

        $("#portTipoIdentGlobal").change(function () {
            $("#portNumeraciones_gr select[data-source='portTipoIdentGlobal']").val(this.value);
            ShowWrapperRepLegalGlobal(this, this.value);
        });

        $("#portNumeraciones_gr select[data-source='portTipoIdentGlobal']").change(function () {
            ShowWrapperRepLegal(this, this.value);
        });

        $("#portIdentOrigenGlobal, #portNombreOrigenGlobal, #portApellidoOrigenGlobal").keyup(function () {
            $("#portNumeraciones_gr input[data-source='" + this.id + "']").val(this.value);
        });

        $("[data-source='port_traspaso_check']").change(function () {
            var $check = $(this).children()[0];
            var $row = $(this).parents("tr");
            var $cells = $row.children("td:has(*[data-validsource='port_traspaso'])").children("[data-validsource='port_traspaso']");
            $cells.attr("required", "required");
            if (!$check.checked) $cells.removeAttr("required", "required");
        });

        $("#numeracionesReset").click(function(){
            $("input[data-source='numeracion'], #numeracionesMasivo, #numeracionesNipMasivo").val("");
        });
    }    
}