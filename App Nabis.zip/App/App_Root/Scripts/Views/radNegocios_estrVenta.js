﻿function estrVentas_InicializarComponentes() {
    $('.datepicker').datepicker({
        dateFormat: 'yy-mm-dd',
        minDate: '+0D',
        maxDate: '+1Y',
        changeMonth: true,
        changeYear: true,
        numberOfMonths: 2,
        dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'],
        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo',
            'Junio', 'Julio', 'Agosto', 'Septiembre',
            'Octubre', 'Noviembre', 'Diciembre'],
        monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr',
            'May', 'Jun', 'Jul', 'Ago',
            'Sep', 'Oct', 'Nov', 'Dic']
    });

    $("select[id$='tipoProducto'] > option:contains(PREPAGO)").wrapAll("<optgroup label='PREPAGO'></optgroup>");
    $("select[id$='tipoProducto'] > option:contains(POSPAGO)").wrapAll("<optgroup label='POSPAGO'></optgroup>").attr("required", "required");
    $("input[id$='fechaActivacion']").datepicker({
        dateFormat: "yy-mm-dd"
        , minDate: "+0d"
        , maxDate: "+45d"
        , numberOfMonths: 2
        , dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa']
        , monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre',
            'Octubre', 'Noviembre', 'Diciembre']
        , monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic']
        , changeMonth: true
        , changeYear: true
        , yearRange: "2015:2040"
        , beforeShowDay: function (day) {
            var day = day.getDay();
            return [!(day == 0), ""];
        }
    });

    $("#numeracionCelular, #numeracionSimCard, #numeracionEquipos").bind("keyup", function () {
        var IdInput = this.id;
        var numeraciones = ($(this).val() != "") ? ($(this).val().split("\n")) : ([]);
        $("#" + IdInput + "Head").text(numeraciones.length);
    });

    $("input[id$='txtIdKoral']").focusout(function () {
        if ($("input[id$='txtIdKoral']").val() != '') {
            $("input[id$='txtIdPricing']").val('');
        }
        if (($('#canalVenta').val() != 'AGENTES') && (($("input[id$='txtIdPricing']").val() != '') || ($("input[id$='txtIdKoral']").val() != ''))) {
            $('#TipoNegocio_Pnl').show()
            $('#TipoNegocio_ddl').attr('required', 'required')
        }
        else {
            $('#TipoNegocio_ddl').val('')
            $('#TipoNegocio_ddl').removeAttr('required', 'required')
            $('#TipoNegocio_Pnl').hide()            
        }
    });

    $("input[id$='txtIdPricing']").focusout(function () {
        if ($("input[id$='txtIdPricing']").val() != '') {
            $("input[id$='txtIdKoral']").val('');
        }
        if (($('#canalVenta').val() != 'AGENTES') && (($("input[id$='txtIdPricing']").val() != '') || ($("input[id$='txtIdKoral']").val() != ''))) {
            $('#TipoNegocio_Pnl').show()
            $('#TipoNegocio_ddl').attr('required', 'required')
        }
        else {
            $('#TipoNegocio_ddl').val('')
            $('#TipoNegocio_ddl').removeAttr('required', 'required')
            $('#TipoNegocio_Pnl').hide()
        }
    });

    $("input[id$='lineasProducto']").change(function (event) {
        event.preventDefault();
        var rows = $("input[id$='lineasProducto']").val();
        $('.form-textArea').attr("rows", rows);
    });
    $("input[id$='trDNI']").change(function (event) {
        event.preventDefault();
        var rows = $("input[id$='lineasProducto']").val();
        $('.form-textArea').attr("rows", rows);
    });

    $("#DuracionServicios, #planTarifario, select[id$='simCardsReferencias'], select[id$='equiposReferencias'],#planOrigen,#planDestino,#ReferenciaEquipoOrigen").select2();
    $("#WrapperServiciosPlanesAdicionales select").select2();

    $("#numeracionSimCard, #numeracionEquipos").bind("keyup", function () {
        var IdInput = this.id;
        var numeraciones = ($(this).val() != "") ? ($(this).val().split("\n")) : ([]);
        $("#" + IdInput + "Head").text(numeraciones.length);
    });

    $("#numeracionSimCardHead, #numeracionEquiposHead").each(function () {
        var IdNumeracionInput = "#" + this.id.replace("Head", "");
        var numeraciones = ($(IdNumeracionInput).val() != "") ? ($(IdNumeracionInput).val().split("\n")) : ([]);
        $(this).text(numeraciones.length);
    });


    $("#ValorEquipo_tx").change(function () {
        $("#ValorEquipoKoral_tx").val("");
        $("#DctoEquipo").val("");

        $("#ValorEquipo_tx").removeAttr('required');
        $("#ValorEquipoKoral_tx").removeAttr('required');
        $("#DctoEquipo").removeAttr('required');
    });

    $("#ValorEquipoKoral_tx, #DctoEquipo").change(function () {

        if (($("#ValorEquipoKoral_tx").val() != "" || $("#DctoEquipo").val() != "") && ($("#ValorEquipoKoral_tx").val() > 0 || $("#DctoEquipo").val() > 0)) {
            $("#ValorEquipo_tx").attr('required', 'true');
            $("#ValorEquipoKoral_tx").attr('required', 'true');
            $("#DctoEquipo").attr('required', 'true');
        }
        else {
            $("#ValorEquipo_tx").removeAttr('required');
            $("#ValorEquipoKoral_tx").removeAttr('required');
            $("#DctoEquipo").removeAttr('required');
        }
        
        var valorIva = $('#ValorEquipo_tx').data("valoriva");
        var valorEquipoIva = $('#ValorEquipo_tx').data("valorequipoiva");
        var aplicaIva = $('#ValorEquipo_tx').data("aplicaiva");

        var value = parseFloat($.trim(this.value));
        var TagUpdate = $(this).data("tagupdate");
        var valorEquipoNum = parseFloat($("#ValorEquipo_tx").val());
        if (aplicaIva == "S") {
            var valorEquipo = valorEquipoNum / (1 + (valorIva / 100));
        }
        else {
            var valorEquipo = valorEquipoNum;
        }        
        var result = 0;
        if (!isNaN(value) && !isNaN(valorEquipo)) {
            if (valorEquipo > 0 && value > 0) {
                result = (this.id == "DctoEquipo") ? valorEquipo - (valorEquipo * (value / 100)) : (1 - (value / valorEquipo)) * 100;
                result = result % 1 == 0 ? result : result.toFixed(4);
                $("#" + TagUpdate).val((result.toString()).replace(".0000", ""));
            }
            else {
                $("#ValorEquipoKoral_tx").val("");
                $("#ValorEquipo_tx").removeAttr('required');
                $("#ValorEquipoKoral_tx").removeAttr('required');
                $("#DctoEquipo").removeAttr('required');
            }
        }
    });

}

function Eval_PlanesServicios(source, planesServicios) {
    var values = [];
    var duplicado = false;
    $("#planesServiciosDiv select").each(function (index, elem) {
        var value = this.value;
        if (value != "" && value != "-1" && value != "N/A") {
            var indexValue = $.inArray(value, values);
            values[index] = value;
            if (indexValue >= 0) {
                duplicado = (!duplicado) ? (true) : (duplicado);
            }
        }
    });
    planesServicios.IsValid = !duplicado;
}

function Eval_PlanesServiciosPymes(source, planesServicios) {
    var values = [];
    var duplicado = false;

    $("#planesServiciosDiv select[id|='servAdicional']").each(function (index, elem) {
        var value = this.value;
        if (value != "" && value != "-1" && value != "N/A") {
            var indexValue = $.inArray(value, values);
            values[index] = value;
            if (indexValue >= 0) {
                duplicado = (!duplicado) ? (true) : (duplicado);
            }
        }
    });

    $("#planesServiciosDiv select[id|='planAdicional']").each(function (index, elem) {
        var value = this.value;
        if (value != "" && value != "-1" && value != "N/A") {
            var indexValue = $.inArray(value, values);
            values[index] = value;
            if (indexValue >= 0) {
                duplicado = (!duplicado) ? (true) : (duplicado);
            }
        }
    });

    $("#planesServiciosDiv select").each(function (index, elem) {
        var value = this.value;
        if (value != "" && value != "-1" && value != "N/A") {
            if (value == "DATOS") {
                var indexValue = $.inArray(value, values);
                values[index] = value;
                if (indexValue >= 0) {
                    duplicado = (!duplicado) ? (true) : (duplicado);
                }
            }
        }
    });

    planesServicios.IsValid = !duplicado;
}


function Eval_numeracionSimCards(source, numeracionSimCard) {
    var lineasProducto = parseInt($("input[id$='lineasProducto']").val());
    var numeracionesInfo = $("textarea[id$='numeracionSimCard']").val();
    var numeraciones = numeracionesInfo.split("\n");
    var patronNumeracion = /^8957123\d{12}$/;
    var errores = [];
    var msg = "";
    var $consola = $("div[id$='numeracionSimCardConsola']");
    var isError = false;
    var seriesError = [];
    //Capturo cantidad de series listados del array original
    var duplicadosSeries = numeraciones.length;
    //Quito duplicados de series
    var seriesDistinct = $.unique(numeraciones);
    //Calculo diferencia entre el total de elementos del array original y el del array sin duplicados
    var duplicadosSeries = duplicadosSeries - seriesDistinct.length;

    isError = (numeraciones.length != lineasProducto);

    if (duplicadosSeries > 0) {
        isError = true;
        msg = "Hay " + duplicadosSeries + " duplicados en la lista de sim cards relacionados! <br/>";
    }
    else if (isError) {
        msg = "La cantidad de SimCards relacionados no coincide con la cantidad de líneas solicitadas. Si la última numeración está en blanco, por favor borrela.";
    }
    else {
        $.each(numeraciones, function (i, v) {
            if (!patronNumeracion.test(v)) {
                errores[errores.length] = [i + 1, v];
            };
        });
        isError = (errores.length > 0);
        if (isError) {
            msg = "Las siguientes series de sim card no son válidas: <br/>"
            $.each(errores, function (i, v) {
                msg = msg + "Posición: " + v[0] + "-> " + v[1] + "<br/>";
            });
        }
    }
    $(source).html(msg);
    numeracionSimCard.IsValid = !isError;
}

function Eval_numeracionImei(imei) {
    var suma = 0;
    var i = 0;
    for (i; i < imei.length; i++) {
        var tmp = 0;
        var tmpChar = "";
        if (((i + 1) % 2) == 0) {
            tmp = parseInt(imei[i]) * 2;
            tmpChar = tmp.toString();
            tmp = (tmp >= 10) ? (parseInt(tmpChar[0]) + parseInt(tmpChar[1])) : (tmp);
            suma += parseInt(tmp);
        }
        else {
            suma += parseInt(imei[i]);
        }
    }
    return (suma % 10 == 0);
}

function Eval_numeracionEquipos(source, numeracionEquipos) {
    var lineasProducto = parseInt($("input[id$='lineasProducto']").val());
    var numeraciones = $("textarea[id$='numeracionEquipos']").val().split("\n");
    var patronNumeracion = /^\d{15}$/;
    var errores = [];
    var msg = "";
    var isError = false;
    var seriesError = [];
    //Capturo cantidad de series listados del array original
    var duplicadosSeries = numeraciones.length;
    //Quito duplicados de series
    var seriesDistinct = $.unique(numeraciones);
    //Calculo diferencia entre el total de elementos del array original y el del array sin duplicados
    var duplicadosSeries = duplicadosSeries - seriesDistinct.length;

    isError = (numeraciones.length != lineasProducto);

    if (duplicadosSeries > 0) {
        isError = true;
        msg = "Hay " + duplicadosSeries + " duplicados en la lista de imeis relacionados! <br/>";
    }
    else if (isError) {
        msg = "La cantidad de equipos relacionados no coincide con la cantidad de líneas solicitadas. Si la última numeración está en blanco, por favor borrela.";
    }
    else {
        $.each(numeraciones, function (i, v) {
            var PatronIsvalid = patronNumeracion.test(v);
            var NumeracionImeiIsValid = Eval_numeracionImei(v);
            if (!PatronIsvalid) {
                errores[errores.length] = { index: i + 1, imei: v, msg: "Formato Incorrecto" };
            }
            else if (!NumeracionImeiIsValid) {
                errores[errores.length] = { index: i + 1, imei: v, msg: "Imei Inválido" };
            };
        });
        isError = (errores.length > 0);
        if (isError) {
            msg = "Las siguientes series de equipo no son válidas: <br/>"
            $.each(errores, function (i, v) {
                msg = msg + "Posición: " + v.index + " -> " + v.imei + " -> " + v.msg + "<br>";
            });
        }
    }
    $(source).html(msg);
    numeracionEquipos.IsValid = !isError;
}

function Eval_numIdent(source, numIdent) {
    var patronIdentJuridica = /^\d{4,10}-\d{1}$/;
    var patronIdentNatural = /^\d{4,10}$/;
    var tipoIdent = $("select[id$='portTraspTipoIdent'] option:selected").text();
    var listItemsPersonaJuridica = ["CDV", "CDV EXTRANJERIA", "NIT", "NIT EXTRANJERIA"];
    var listItemsPersonaNatural = ["CC", "CEDULA EXTRANJERIA", "H2", "H2 EXTRANJERIA", "PASAPORTE"];
    if (tipoIdent == "-1") {
        numIdent.IsValid = false;
    }
    else if ($.inArray(tipoIdent, listItemsPersonaJuridica) > -1) {
        numIdent.IsValid = patronIdentJuridica.test(numIdent.Value);
        if (!numIdent.IsValid) { $(source).text("La identificación no pertenece a persona jurídica (NIT, CDV)"); }
    }
    else if ($.inArray(tipoIdent, listItemsPersonaNatural) > -1) {
        numIdent.IsValid = patronIdentNatural.test(numIdent.Value);
        if (!numIdent.IsValid) { $(source).text("La identificación no pertenece a persona natural (CC, H2, PASAPORTE)"); }
    }
}

function Trim(elemento) {
    var str = $(elemento).val().trim();
    $(elemento).val(str.replace(/ /g, ""));
}

function habilitaUser(estado) {

    $("input[id$='txnombrePersonaCede']").prop("disabled", estado);
    $("select[id$='ddltipodoctra']").prop("disabled", estado);
    $("input[id$='trDNI']").prop("disabled", estado);
    $("input[id$='txcelularPersonaCedida']").prop("disabled", estado);
    $("input[id*='ckbTras1']").prop("disabled", estado);
    $("input[id*='ckbTras2']").prop("disabled", estado);
    $("input[id$='txdoc1']").prop("disabled", estado);
    $("input[id$='txdoc2']").prop("disabled", estado);
    $("input[id$='txdoc3']").prop("disabled", estado);
    $("input[id$='txdoc4']").prop("disabled", estado);
}

$(document).ready(function () {

    if (($('#canalVenta').val() != 'AGENTES') && (($("input[id$='txtIdPricing']").val() != '') || ($("input[id$='txtIdKoral']").val() != ''))) {
        $('#TipoNegocio_Pnl').show()
        $('#TipoNegocio_ddl').attr('required', 'required')
    }
    else {
        $('#TipoNegocio_ddl').val('')
        $('#TipoNegocio_ddl').removeAttr('required', 'required')
        $('#TipoNegocio_Pnl').hide()
    }

    $('#TipoNegocio_ddl').tooltip();

    $("input[id$='lineasProducto']").change(function (event) {
        event.preventDefault();
        var rows = $("input[id$='lineasProducto']").val();
        $('.form-textArea').attr("rows", rows);
    });
    $("input[id$='trDNI']").change(function (event) {
        event.preventDefault();
        var rows = $("input[id$='lineasProducto']").val();
        $('.form-textArea').attr("rows", rows);
    });
});