﻿function IsCharValid(e, trama) {
    var tramas = { numeric: /[0-9]/, text: /[A-Za-zñÑ0-9,.\s-@]/, nit: /[0-9-]/, float: /[0-9.]/ }
    var keyNumerics = { 96: 0, 97: 1, 98: 2, 99: 3, 100: 4, 101: 5, 102: 6, 103: 7, 104: 8, 105: 9 }
    var patron = tramas[trama];
    var eventKeyCode = (event.keyCode ? e.keyCode : e.which);
    var charCode = String.fromCharCode(eventKeyCode);

    //alert(patron + " | " + eventKeyCode + " | " + charCode + " | " + patron.test(charCode));
    switch (eventKeyCode) {
        case 0:
        case 9:
        case 32:
            return true;
            break;
        default:
            return patron.test(charCode);
            break;
    }
}

function IsDate(fecha, e) {
    var patron = /[0-9]/;
    var eventKeyCode = (event.keyCode ? e.keyCode : e.which);
    var charCode = String.fromCharCode(eventKeyCode);
    var yearMin = 1800;
    var yearMax = 2025;

    switch (eventKeyCode) {
        case 0:
        case 9:
        case 32:
            fecha = 'continue';
            return fecha;
            break;
        default:
            var IsNumeric = patron.test(charCode);

            if (IsNumeric) {
                var año, mes, dia, numDias;
                var longFecha = fecha.length;
                if (longFecha < 3) {
                    fecha = fecha + charCode;
                }
                else if (longFecha == 3) {
                    año = fecha + charCode;
                    año = parseInt(año);
                    if (año >= yearMin && año <= yearMax) {
                        fecha = fecha + charCode + "-";
                    }
                    else {
                        fecha = 'reset';
                    }
                }
                else if (longFecha < 6) {
                    fecha = fecha + charCode;
                }
                else if (longFecha == 6) {
                    año = fecha.substr(0, 4);
                    mes = fecha.substr(5, fecha.length) + charCode;
                    if (mes > 0 && (mes <= 12)) {
                        fecha = año + "-" + mes + "-";
                    }
                    else if ((año >= yearMin) && (año <= yearMax)) {
                        fecha = fecha.substr(0, 5);
                    }
                }
                else if (longFecha > 6 && longFecha <= 9) {
                    fecha = fecha + charCode;
                    longFecha = fecha.length;
                    año = parseInt(fecha.substr(0, 4));
                    mes = parseInt(fecha.substr(5, 2));
                    dia = parseInt(fecha.substr(8, 2));
                    numDias = 31;
                    if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
                        numDias = 30;
                    }// Año no viciesto y es febrero, el dia es mayor a 28
                    else if ((año % 4 == 0) && (mes == 2)) {
                        numDias = 29;
                    }
                    else if ((año % 4 != 0) && (mes == 2)) {
                        numDias = 28;
                    }
                    if ((longFecha >= 10 && dia <= 0) || dia > numDias || longFecha > 10) {
                        fecha = fecha.substr(0, 8);
                    }
                }
            }
            return fecha;
            break;
    }
}

function iif(condicion, truePart, falsePart) {
    if (condicion) {
        return truePart;
    }
    else {
        return falsePart;
    }
}

function AjaxConsulta(pagDestino, parametros, htmlObjetivo) {
    var $htmlObjetivo = $("#" + htmlObjetivo);
    $htmlObjetivo.html("<p align='center'><img src='Imagenes/loading.gif'/><br/><b>Cargando...</b></p>");
    $htmlObjetivo.load(pagDestino, parametros, function (response, status, xhr) {
        if (status == "error") {
            var msg = "Sorry but there was an error: ";
            $htmlObjetivo.append(msg + xhr.status + " " + xhr.statusText);
        }
    });
}

function AjaxConsultaMin(pagDestino, parametros, htmlObjetivo) {
    var $htmlObjetivo = $("#" + htmlObjetivo);
    $htmlObjetivo.html('<img src="Imagenes/min_loading.gif" alt="Cargando..." style="width: 20px; height: 20px;"/>');
    $htmlObjetivo.load(pagDestino, parametros, function (response, status, xhr) {
        if (status == "error") {
            var msg = "Sorry but there was an error: ";
            $htmlObjetivo.append(msg + xhr.status + " " + xhr.statusText);
        }
    });
}

function AjaxUploadExcel(Url, parametros, IdContenedor, IdFileControl) {
    var $htmlObjetivo = $("#" + htmlObjetivo);
    var data = new FormData();
    $.each(parametros, function (key, value) {
        data.append(key, value);
    });
    var file = $("#" + IdFileControl)[0].files[0];
    if (file != undefined) {
        //obtenemos el nombre del archivo
        var fileName = file.name;
        //obtenemos la extensión del archivo
        var fileExtension = fileName.substring(fileName.lastIndexOf('.') + 1);
        //obtenemos el tamaño del archivo
        var fileSize = file.size;
        //obtenemos el tipo de archivo
        var fileType = file.type;
        if (fileExtension == "xls" || fileExtension == "xlsx") {
            data.append("file", file);
            data.append("extension", fileExtension);
            $.ajax({
                url: Url
                , type: "POST"
                , data: data
                , dataType: false
                , contentType: false
                , processData: false
                , cache: false
                , beforeSend: function (xhr) {
                    $htmlObjetivo.html('<img src="Imagenes/min_loading.gif" alt="Cargando..." style="width: 20px; height: 20px;"/>');
                }
                , success: function (data) { //Procesar el valor del método invocado
                    showAlert("El tipo de archivo no es válido!", "success", IdContenedor, true);
                }
                , error: function (response, status, xhr) {
                    var msg = "Sorry but there was an error: ";
                    $htmlObjetivo.html(msg + xhr.status + " " + xhr.statusText);
                }
            });
        }
        else {
            showAlert("El tipo de archivo no es válido!", "warning", IdContenedor, true);
        }
    }
    else {
        showAlert("Seleccione un archivo para continuar!", "warning", IdContenedor, true);
    }
}

function Eval_selectedValues(tagContent, typeValue) {
    var IsValid = true;
    switch (typeValue) {
        case "checked":
            var inputsChecked = $("#" + tagContent + " :checkbox:checked");
            IsValid = (inputsChecked.length > 0);
            if (!IsValid) { showAlert("Debe seleccionar una opción de la lista", "warning", tagContent, true); }
            break;
        case "selected":
            var inputsChecked = $("#" + tagContent + " select");
            var idTag = "#" + tagContent;
            $(idTag + " [data-required]").each(function () {
                var required = $(this).data("required");
                var initialValue = $(this).data("initialvalue");
                var value = $.trim(this.value);
                if (required) {
                    IsValid = (initialValue != undefined) ? (value != "" && value != initialValue) : (value != "" && value != "-1");
                }
            });
            if (!IsValid) { showAlert("Debe seleccionar una opción de los combos de selección", "warning", tagContent, true); }
            break;
    }
    return IsValid;
}

function Eval_Form(tagContent) {
    var IsError = false;
    var idTag = "#" + tagContent;
    var msg = "<span class='page-header'>Se encontraron errores en el formulario:</span><ul>";
    $(idTag + " [data-required], " + idTag + " [data-type], " + idTag + " [data-minlength], " + idTag + " [maxlength]").each(function () {
        var $tag = $(this);
        var $label = $(idTag + " label [for='" + $tag.attr("id") + "'");
        var value = $.trim(this.value);
        var required = $tag.data("required");
        var maxLength = $tag.attr("maxlength");
        var minLength = $tag.data("minlength");
        var longCurrent = this.value.length;
        var IsValid = true;
        var prefijoMsg = "Campo <strong>" + $label.text() + ":</strong> ";

        if (minLength != undefined && longCurrent < longMin) {
            IsValid = false;
            IsError = true;
            msg = "Debe ingresar mínimo " + longMin + " caracteres en este campo.";
            $tag.attr("title", msg).tooltip({
                close: function () {
                    $(this).tooltip("destroy").removeAttr("title");
                }
                , position: { my: "left center", at: "right center" }
            }).tooltip("open");
            $tag.addClass("eNull");
        }

        if (maxLength != undefined && longCurrent > maxLength) {
            IsValid = false;
            IsError = true;
            msg = "Debe ingresar máximo " + maxLength + " caracteres en este campo.";
            $tag.attr("title", msgWarning).tooltip({
                close: function () { $(this).tooltip("destroy").removeAttr("title"); }
                , position: { my: "left center", at: "right center" }
            }).tooltip("open");
            $tag.addClass("has-error");
        }

        if (required != undefined && (required && (value == "" || value == "-1"))) {
            IsValid = false;
            IsError = true;
            msg = "<li>" + prefijoMsg + "es obligatorio</li>";
            $tag.addClass("has-error");
        }

        if (IsValid) { $tag.removeClass("has-error"); }
    });
    msg = msg + "</ul>";
    if (IsError) { showAlert(msg, "warning", tagContent, false); }
    return !IsError;
}

function focusTopPage(selector) {
    var $target = $(selector);
    $('body').animate({ scrollTop: $target.offset().proP }, 1000);
    $target.focus();
}

function Paginar(idTab) {
    //var cant_tablas = $('.tabdetalle[name]').size() + 1;
    $('#' + idTab).each(function (n) {
        //this.title = 'tab' + (n + cant_tablas);
        //this.name = 'tab' + (n + cant_tablas);
        var currentPage = 0;
        var maxRows = 28;
        var $table = $(this);
        $table.find('tbody > tr:odd').css('background-color', '#EEE').hover(
            function () { $(this).css('background-color', '#F5F5C4'); }
            , function () { $(this).css('background-color', '#EEE'); }
        );
        $table.find('tbody > tr:even').css('background-color', '#DDD').hover(
            function () { $(this).css('background-color', '#F5F5C4'); }
            , function () { $(this).css('background-color', '#DDD'); }
        );
        var repaginate = function () {
            $table.find('tbody > tr').hide().slice(currentPage * maxRows, (currentPage + 1) * maxRows).show();
        };
        var numRows = $table.find('tbody > tr').length;
        var numPages = Math.ceil(numRows / maxRows);
        var $pager = $('<div></div>').attr({ id: 'pager' + idTab, /*title:'pager'+ (n + cant_tablas),*/ align: 'center' }).addClass('pager');
        if (numPages > 1) {
            for (var page = 0; page < numPages; page++) {
                $('<a href="#"></a>').text(page + 1).addClass('defaultOption').bind('click', { newPage: page }, function (event) {
                    event.preventDefault();
                    currentPage = event.data['newPage'];
                    $("#pagina").attr('value', currentPage);
                    $pager.children('a.selectedOption').removeClass().addClass('defaultOption');
                    $(this).addClass('selectedOption');
                    repaginate();
                }).appendTo($pager);
            }
            $('<a href="#" title="Anterior"></a>').text('<').addClass('defaultOption').bind('click', {}, function (event) {
                event.preventDefault();
                currentPage = ($pager.children('a.selectedOption').index() - 1);
                if (currentPage <= 0) currentPage = 1;
                $pager.children('a').eq(currentPage + 1).removeClass().addClass('defaultOption');
                $pager.children('a').eq(currentPage).addClass('selectedOption');
                currentPage = currentPage - 1;
                repaginate();
            }).prependTo($pager);
            $('<a href="#" title="Siguiente"></a>').text('>').addClass('defaultOption').bind('click', {}, function (event) {
                event.preventDefault();
                currentPage = ($pager.children('a.selectedOption').index() + 1);
                if (currentPage == 0) currentPage = 2;
                if (currentPage > numPages) currentPage = numPages;
                $pager.children('a').eq(currentPage - 1).removeClass().addClass('defaultOption');
                $pager.children('a').eq(currentPage).addClass('selectedOption');
                currentPage = currentPage - 1;
                repaginate();
            }).appendTo($pager);
            repaginate();
            $pager.insertAfter($table);
        }
    });
}

function showAlert(msg, alertType, tagContent, autoClose) {
    var strongsList = { success: "Transacción Exitosa:", info: "Información:", warning: "Alerta:", danger: "Error:" }
    var strong = strongsList[alertType];
    //<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
    var $alert = $('<div class="alert alert-' + alertType + ' alert-dismissible" role="alert" style="display:none;">' +
                    '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                    '<strong>' + strong + '</strong> ' + msg + '</div>');
    if (autoClose) {
        $alert.prependTo("#" + tagContent).show('highlight').delay(5000).hide('fade', {}, 'normal', function () { $(this).remove() });
    }
    else {
        $alert.prependTo("#" + tagContent).show('highlight');
    }
}

function BeginRequestHandler(sender, args) {
    $("#alertRequest").dialog({
        title: '',
        width: 'auto',
        height:'auto',
        closeOnEscape: false,
        open: function (event, ui) {
            $(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
        }
    });
    $("#alertRequest").dialog("open");
}

function EndRequestHandler(sender, args) {
    $("#alertRequest").dialog("close");
}

function ActivateAlertDiv(visstring, elem, msg) {
    showAlert(visstring, 'info', 'body', true);
}

function showWindowModal(url, windowName, defaultOptions, options) {
    if (defaultOptions) {
        options = "resizable=1, scrollbars=1, status=1, toolbar=0, menubar=1";
    }
    window.open(url, windowName, options);
}

function DateJsonToFormatNative(date) {
    //Formato Nativo yyy-mm-dd HH:MM:SS
    return date.toISOString().replace("T", " ").split(".")[0];
}

var TimeTracer = {
    currentTime: 0
    , IdTracer: 0
    , CountRedirect_Minute: 0
    , CountRedirect_Second: 0
    , IdCounter: 0
        , Counter_Init: function () {
            TimeTracer.CountRedirect_Minute = 5;
            TimeTracer.CountRedirect_Second = 0;
            var RefreshCrono = function () {
                var numSecond = (TimeTracer.CountRedirect_Second < 10) ? ("0" + TimeTracer.CountRedirect_Second) : (TimeTracer.CountRedirect_Second);
                var numMinute = (TimeTracer.CountRedirect_Minute < 10) ? ("0" + TimeTracer.CountRedirect_Minute) : (TimeTracer.CountRedirect_Minute);
                $("#alertTimeTracer_crono").html(numMinute + ":" + numSecond);
                if (TimeTracer.CountRedirect_Minute > 0 || TimeTracer.CountRedirect_Second > 0) {
                    if (TimeTracer.CountRedirect_Second == 0 && TimeTracer.CountRedirect_Minute > 0) {
                        TimeTracer.CountRedirect_Second = 60;
                    }

                    TimeTracer.CountRedirect_Second--;

                    if (TimeTracer.CountRedirect_Second == 59 && TimeTracer.CountRedirect_Minute > 0) {
                        TimeTracer.CountRedirect_Minute--;
                    }
                }
                else if (TimeTracer.CountRedirect_Second == 0 && TimeTracer.CountRedirect_Minute == 0) {
                    TimeTracer.End();
                    var indexUrlPathRoot = window.location.href.indexOf("NabisDigital/");
                    indexUrlPathRoot = indexUrlPathRoot == -1 ? window.location.href.indexOf("Nabis/") : indexUrlPathRoot + (("NabisDigital/").length - 1);
                    indexUrlPathRoot = indexUrlPathRoot == -1 ? window.location.href.lastIndexOf("/") : indexUrlPathRoot + (("Nabis/").length -1);
                    var url = window.location.href.substring(0, indexUrlPathRoot) + "/Account/Logout.aspx";
                    //window.location.href = url;
                    $("a[id$=Nab_LoginStatus]")[0].click();
                    TimeTracer.Counter_End();
                    return;
                }
            }
            TimeTracer.IdCounter = setInterval(RefreshCrono, 1200);
        }
        , Counter_End: function () {
            clearInterval(TimeTracer.IdCounter);
            TimeTracer.CountRedirect_Minute = 5;
            TimeTracer.CountRedirect_Second = 0;
            TimeTracer.currentTime = 0;
        }
         , Init: function () {
             $("body").off('keypress mouseenter').on('keypress mouseenter', function (e) { TimeTracer.currentTime = 0; });

             $("#alertTimeTracer").dialog({
                 autoOpen: false
                 , closeOnEscape: false
                 , draggable: true
                 , modal: true
                 , resizable: true
                 , hide: 'clip'
                 , width: '300px'
                 , title: 'Alerta de Inactividad'
                 , buttons: { Cancelar: function () { $("#alertTimeTracer").dialog('close'); } }
                 , open: function () { TimeTracer.Counter_Init(); }
                 , close: function () { TimeTracer.Counter_End(); }
             }).removeClass("hidden");

             var Refresh = function () {
                 TimeTracer.currentTime++;
                 if (TimeTracer.currentTime == 5) {
                     $("#alertTimeTracer").dialog("open");
                 }
             }

             TimeTracer.IdTracer = setInterval(Refresh, 60000);
         }
         , End: function () { clearInterval(TimeTracer.IdTracer); }
}

function pageLoad() {
    $("input[data-lock=true]").on("cut paste", function (e) {
        e.preventDefault();
    });

    $("body").off('keypress', "input[data-type]").off('focus', "input[data-type]").on('keypress', "input[data-type]", function (e) {
        var type = $(this).data("type");
        if (type == "date") {
            var fecha = IsDate($(this).val(), e);
            if (fecha != "reset" && fecha != "continue") {
                e.preventDefault();
                $(this).val(fecha);
            }
            else if (fecha == "reset") {
                e.preventDefault();
                $(this).val("");
            }
        }
        else {
            if (!IsCharValid(e, type)) {
                e.preventDefault();
            }
        }
    }).on('focus', "input[data-type]", function (e) {
        var val = $(this).val(this.value.trim());
    });
}

$(function() {
    $("[data-toggle='tooltip']").tooltip();
    $("#alertRequest").dialog({ autoOpen: false, modal: true });
    Sys.WebForms.PageRequestManager.getInstance().add_beginRequest(BeginRequestHandler);
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(EndRequestHandler);
    TimeTracer.Init();
    $("#Nab_Menu a.static:not(.parentMenu)").addClass('parentMenu');
    $("#Nab_Menu a.dynamic:not(.childMenu)").addClass('childMenu');
});