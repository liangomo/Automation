package homePage.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class HomePage {

	ObjetosConfigAux objConfAux;
	float px = 0;

	/** LISTA ELEMENTOS */
	By linkCertificado = By.id("overridelink");
	By lnkProducto = By.xpath("//*[@class='mCSB_container']/div/ul/a");
	By contenedor = By.xpath("//*[@id='mCSB_1_container']");
	By btnHomePage = By.xpath("//*[@id='li-home']");
	By lblMiMovistar = By.xpath("//*[@id='content']/div/section/div[1]/div/div[1]");

	By body = By.tagName("body");
	By iframe = By.xpath("//*[@id='LegacyContainer']");
	By lblNombreCliente = By.xpath("//*[@id=\"content\"]/section/div[1]/div/div[1]/p[1]/span[1]");
	By lblApellidoCliente = By.xpath("//*[@id=\"content\"]/section/div[1]/div/div[1]/p[1]/span[2]");

	By lblNumCelular = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_NumeroCelular\"]");
	By lblNombreClienteProd = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_divInfoContacto']/h3");
	By lblDireccion = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_divInfoContacto\"]/p[2]");
	By lblCiudad = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_divInfoContacto']/p[3]");

	By linkOtraLinea = By.linkText("click aqu�");
	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");
	By txtTitulo = By.xpath("//*[@id='ConetidoMargen']/section/h1");

	By linkSiguiente = By.xpath("//*[@id=\"slides\"]/a[2]");

	By imgBannerFactura_IntPrepago = By.cssSelector("#slides > div > div > a:nth-child(1) > img");
	By imgBannerDetalle_RecargasPrepago = By.cssSelector("#slides > div > div > a:nth-child(2) > img");
	By lblPaquetesInternetPrep = By.id("LblTituloGrande");
	By lblRecargaOnlinePrep = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_divRecargaPSE\"]/p[1]");
	By btnVolver = By.id("BtnVolver");

	By imgBannerFacturaDigitalPospago = By.cssSelector("#slides > div > div > a:nth-child(1) > img");
	By imgBannerPagosOnlinePospago = By.xpath("//*[@id='slides']/div/div/a[1]/img");
	By imgBannerRenoRepoPospago = By.xpath("//*[@id='slides']/div/div/a[2]/img");
	By lblFacturaDigitalPospago = By.xpath("//*[@id='contenedor_principal']/header/div/h1");
	By lblPagosOnlinePospago = By.xpath("//*[@id='area_1']/header/h2");
	By lblRenoRepoPospago = By.xpath("//*[@id='contenedorRR']/table[1]/tbody/tr/td/div/div");

	By imgBannerPagosOnlineCtaControl = By.cssSelector("#slides > div > div > a:nth-child(1) > img");
	By imgBannerRenoRepoCtaControl = By.cssSelector("#slides > div > div > a:nth-child(2) > img");
	By lblPagosOnlineCtaControl = By.xpath("//*[@id='area_1']/header/h2");
	By lblRenoRepoCtaControl = By.xpath("//*[@id='contenedorRR']/table[1]/tbody/tr/td/div/div");
	By imgChatServicio = By.id("ctl00_lnChat");
	By lblChat = By.xpath("//*[@id=\"contenedor\"]/div[1]/section/header/h1");

	By imgImprimir = By.cssSelector("span.ladop");
	By btnImprimir = By.xpath("//*[@id=\"print-header\"]/div/button[1]");
	By btnCancelar = By.xpath("//*[@id=\"print-header\"]/div/button[2]");

	By imgFacebook = By.cssSelector("a.contiene_facebook > img");
	By lblHomeLinkFacebook = By.xpath("//*[@id=\"homelink\"]");

	By imgTwittear = By.id("l");
	By btnRegistrateTwitter = By.xpath("//*[@id=\"not-logged-in\"]/a");

	By linkConsultas = By.id("idLiMenu1");
	By linkTransacciones = By.linkText("Transacciones");
	By linkServicios = By.linkText("Servicios");

	/* Constructor */
	public HomePage(ObjetosConfigAux objConfAux) {
		this.objConfAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public By getLinkCertificado() {
		return (linkCertificado);
	}

	public void clickLinkCertificado() {
		this.objConfAux.getDriver().findElement(linkCertificado).click();
	}

	public void clickBtnHomePage() throws InterruptedException {
		String handle = objConfAux.getDriver().getWindowHandle();
		objConfAux.getDriver().switchTo().window(handle);
		if (objConfAux.EsperaElemento(objConfAux.getDriver(), btnHomePage, 2)) {
			objConfAux.getDriver().findElement(btnHomePage).click();
		} else {
			objConfAux.refreshDriver();
		}
	}

	public String getLblMiMovistar() {
		return this.objConfAux.getDriver().findElement(lblMiMovistar).getText();
	}

	public String getBody() {
		return this.objConfAux.getDriver().findElement(body).getText();
	}

	public String getLblNumCelular() {
		return this.objConfAux.getDriver().findElement(lblNumCelular).getText();
	}

	public String getLblNombreCliente() {
		return this.objConfAux.getDriver().findElement(lblNombreCliente).getText();
	}

	public String getLblApellidoCliente() {
		return this.objConfAux.getDriver().findElement(lblApellidoCliente).getText();
	}

	public String getLblNombreClienteProd() {
		return this.objConfAux.getDriver().findElement(lblNombreClienteProd).getText();
	}

	public String getLblDireccion() {
		return this.objConfAux.getDriver().findElement(lblDireccion).getText();
	}

	public String getLblCiudad() {
		return this.objConfAux.getDriver().findElement(lblCiudad).getText();
	}

	public void clickLinkOtraLinea() {
		this.objConfAux.getDriver().findElement(linkOtraLinea).click();
	}

	public By getImgPhotoUser() {
		return (imgPhotoUser);
	}

	public By getTxtTitulo() {
		objConfAux.EsperaElemento(objConfAux.getDriver(), iframe);
		this.objConfAux.getDriver().switchTo().frame("LegacyContainer");
		objConfAux.getDriver().findElement(txtTitulo).getText();
		return (txtTitulo);
	}

	public void clicklinkSiguiente() {
		this.objConfAux.getDriver().findElement(linkSiguiente).click();
	}

	public void clickImgBannerFactura_IntPrepago() {
		objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerFactura_IntPrepago);
		this.objConfAux.getDriver().findElement(imgBannerFactura_IntPrepago).click();
	}

	public String getLblPaquetesInternetPrep() {
		return this.objConfAux.getDriver().findElement(lblPaquetesInternetPrep).getText();
	}

	public void clickImgBannerDetalle_RecargasPrep() {
		objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerDetalle_RecargasPrepago);
		this.objConfAux.getDriver().findElement(imgBannerDetalle_RecargasPrepago).click();
	}

	public String getLblRecargaOnlinePrep() {
		return this.objConfAux.getDriver().findElement(lblRecargaOnlinePrep).getText();
	}

	public void clickImgBannerFacturaDigitalPospago() {
		objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerFacturaDigitalPospago);
		this.objConfAux.getDriver().findElement(imgBannerFacturaDigitalPospago).click();
	}

	public String getLblFacturaDigitalPospago() {
		return this.objConfAux.getDriver().findElement(lblFacturaDigitalPospago).getText();
	}

	public void clickImgBannerPagosOnlinePospago() {
		objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerPagosOnlinePospago);
		this.objConfAux.getDriver().findElement(imgBannerPagosOnlinePospago).click();
	}

	public String getLblPagosOnlinePospago() {
		return this.objConfAux.getDriver().findElement(lblPagosOnlinePospago).getText();
	}

	public void clickImgBannerRenoRepoPospago() {
		objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerRenoRepoPospago);
		this.objConfAux.getDriver().findElement(imgBannerRenoRepoPospago).click();
	}

	public String getLblRenoRepoPospago() {
		return this.objConfAux.getDriver().findElement(lblRenoRepoPospago).getText();
	}

	public void clickImgBannerPagosOnlineCtaControl() {
		this.objConfAux.getDriver().findElement(imgBannerPagosOnlineCtaControl).click();
	}

	public String getLblPagosOnlineCtaControl() {
		return this.objConfAux.getDriver().findElement(lblPagosOnlineCtaControl).getText();
	}

	public void clickImgBannerRenoRepoCtaControl() {
		this.objConfAux.getDriver().findElement(imgBannerRenoRepoCtaControl).click();
	}

	public String getLblRenoRepoCtaControl() {
		return this.objConfAux.getDriver().findElement(lblRenoRepoCtaControl).getText();
	}

	public By getBtnVolver() {
		return (btnVolver);
	}

	public void clickBtnVolver() {
		this.objConfAux.getDriver().findElement(btnVolver).click();
	}

	public void clickImgChatServicio() {
		this.objConfAux.getDriver().findElement(imgChatServicio).click();
	}

	public String getLblChat() {
		return this.objConfAux.getDriver().findElement(lblChat).getText();
	}

	public void clickImgImprimir() {
		this.objConfAux.getDriver().findElement(imgImprimir).click();
	}

	public String getBtnImprimir() {
		return this.objConfAux.getDriver().findElement(btnImprimir).getText();
	}

	public void clickBtnCancelar() {
		this.objConfAux.getDriver().findElement(btnCancelar).click();
	}

	public void clickImgFacebook() {
		this.objConfAux.getDriver().findElement(imgFacebook).click();
	}

	public String getLblHomeLinkFacebook() {
		return this.objConfAux.getDriver().findElement(lblHomeLinkFacebook).getText();
	}

	public void clickImgTwittear() {
		this.objConfAux.getDriver().findElement(imgTwittear).click();
	}

	public String getBtnSesionTwitter() {
		return this.objConfAux.getDriver().findElement(btnRegistrateTwitter).getText();
	}

	public void clickLinkConsultas() throws InterruptedException {
		objConfAux.EsperaElemento(objConfAux.getDriver(), iframe);
		this.objConfAux.getDriver().switchTo().frame("LegacyContainer");
		this.objConfAux.getDriver().findElement(linkConsultas).click();
	}

	public void clickLinkTransacciones() {
		getBodyFrameLegacyContainer();
		this.objConfAux.getDriver().findElement(linkTransacciones).click();
	}

	public void clicklinkServicios() {
		getBodyFrameLegacyContainer();
		this.objConfAux.getDriver().findElement(linkServicios).click();
	}

	public void clicLnkProducto(String pLnkProducto) {
		List<WebElement> listaProducto = objConfAux.getDriver().findElements(lnkProducto);
		try {
			boolean reintentar = true;
			for (int i = 0; i <= listaProducto.size(); i++) {
				reintentar = true;
				while (reintentar) {
					if (listaProducto.get(i).isDisplayed()) {
						reintentar = false;

						if (listaProducto.get(i).getText().toString().equals(pLnkProducto)) {
							JavascriptExecutor js = (JavascriptExecutor) objConfAux.getDriver();
							js.executeScript("arguments[0].click()", listaProducto.get(i));
							i = listaProducto.size() + 1;
							break;
						}
					} else {
						downLstLineas();
					}
				}
			}
		} catch (Exception e) {
		}
	}

	private void downLstLineas() throws InterruptedException {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) objConfAux.getDriver();
		WebElement element = objConfAux.getDriver().findElement(contenedor);
		px = px - 92;
		js.executeScript("arguments[0].setAttribute('style', 'position: relative; top: " + px + "px; left: 0px;')",
				element);
	}

	public void getBodyFrameDefaultContent() {
		this.objConfAux.getDriver().switchTo().defaultContent();
	}

	public void getBodyFrameLegacyContainer() {
		this.objConfAux.getDriver().switchTo().frame("LegacyContainer");
	}

	public void getBodyFrameContentPlaceHolder() {
		this.objConfAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
	}

	public void getBodyFrameChat() {
		this.objConfAux.getDriver().switchTo().frame("main");
	}

	public void getBodyFrameTwitter() {
		this.objConfAux.getDriver().switchTo().frame("twitter-widget-0");
	}

	public void getBodyFramePaqInternet() {
		this.objConfAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_SSO");
	}

	public void keyPressCerrarVentana() throws AWTException, InterruptedException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_F4);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_ALT);
		robot.keyRelease(KeyEvent.VK_F4);
	}

	/** METODOS */

	public void homeMain() throws InterruptedException, AWTException, IOException {

		Integer caracter = Integer.valueOf(getLblNombreCliente().length());
		assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("Texto1").toString()), "Texto1");
		assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("Texto2").toString()), "Texto2");
		assertTrue(caracter > 1, "Caracter");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion home",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}

	public void homeBannerPospago() throws InterruptedException, AWTException, IOException {

		getBodyFrameLegacyContainer();

		/* Banner en movimiento */
		assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerPagosOnlinePospago),
				"BannerPagosOnlinePospago");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
		assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerRenoRepoPospago),
				"BannerRenoRepoPospago");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}

	public void homeBannerCtaControl() throws InterruptedException, AWTException, IOException {

		getBodyFrameLegacyContainer();

		/* Banner en movimiento */
		assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerPagosOnlineCtaControl),
				"BannerPagosOnlineCtaControl");
		assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerRenoRepoCtaControl),
				"BannerRenoRepoCtaControl");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}

	public void homeBannerPrepago() throws InterruptedException, AWTException, IOException {

		getBodyFrameLegacyContainer();
		assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerFactura_IntPrepago),
				"BannerFactura_IntPrepago");
		assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), imgBannerDetalle_RecargasPrepago),
				"BannerDetalle_RecargasPrepago");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion Banners en movimiento",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}

	public void homeLinkChat() throws InterruptedException, AWTException, IOException {

		clickImgChatServicio();
		objConfAux.cambiarVentanaAnterior();
		getBodyFrameChat();
		assertTrue(getLblChat().equals(objConfAux.AdminParam.resultado.get("Chat").toString()), "Bot�n Chat");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion opcion Chat de Servicio",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
		objConfAux.keyPressCerrarPestana();
	}

	public void homeLinks() throws InterruptedException, AWTException, IOException {

		/* Validaci�n opci�n Imprimir */
		objConfAux.cambiarVentanaAnterior();
		getBodyFrameLegacyContainer();
		clickImgImprimir();
		objConfAux.cambiarVentana();
		getBodyFrameDefaultContent();
		assertTrue(getBtnImprimir().equals(objConfAux.AdminParam.resultado.get("Imprimir").toString()),
				"Bot�n Imprimir");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion opcion Imprimir",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
		clickBtnCancelar();

		/* Validacion opcion Facebook */
		objConfAux.cambiarVentanaAnterior();
		getBodyFrameLegacyContainer();
		clickImgFacebook();
		objConfAux.cambiarVentanaAnterior();
		assertTrue(getLblHomeLinkFacebook().equals(objConfAux.AdminParam.resultado.get("Facebook").toString()),
				"Opci�n Facebook");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion opcion de Facebook",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
		keyPressCerrarVentana();

		/* Validacion opcion Twitter */
		objConfAux.cambiarVentanaAnterior();
		getBodyFrameLegacyContainer();
		getBodyFrameTwitter();
		clickImgTwittear();
		objConfAux.cambiarVentana();
		assertTrue(getBtnSesionTwitter().equals(objConfAux.AdminParam.resultado.get("Twitter").toString()),
				"Opci�n Twitter");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion opcion de Twitter",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
		objConfAux.keyPressCerrarPestana();
		objConfAux.cambiarVentanaAnterior();
	}
}