package consultas.paginas;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ConsultaServicios {

	ObjetosConfigAux objConfAux;

	/** LISTA ELEMENTOS */
	By linkConsultaServicios = By.linkText("Consulta de servicios");
	By btnActivacionServicio = By.id("ctl00_ContentPlaceHolder1_btnActivarServicios_Click");
	By lblConsServ = By.xpath("//*[@id='contenido']/div[2]/div[2]/table/tbody/tr[2]/td/table/tbody/tr[1]/td/div/div");
	By linkVolverCuenta = By.id("ctl00_ContentPlaceHolder1_volverMC");
	By lblTelefoniaMovil = By.xpath("//*[@id=\"top_contenido\"]/h1");
	By cmbTipoServicio = By.id("ctl00_ContentPlaceHolder1_cmbTipoServicio");
	By radioDetalleServicio = By.id("ctl00_ContentPlaceHolder1_lstDetalleServicio_0");
	By txtDescripcionServicio = By.name("ctl00$ContentPlaceHolder1$txtDescripcion");
	By btnSiguiente = By.id("ctl00_ContentPlaceHolder1_lnkSiguiente");
	By lblPregutaActivacion = By.xpath("//*[@id=\"Table7\"]/tbody/tr[3]/td/div[2]/strong");

	/* Constructor */
	public ConsultaServicios(ObjetosConfigAux objConfAux) {
		this.objConfAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkConsultaServicios() {
		this.objConfAux.getDriver().findElement(linkConsultaServicios).click();
	}

	public void clickBtnActivacionServicio() {
		this.objConfAux.getDriver().findElement(btnActivacionServicio).click();
	}

	public String getLblConsultaServicios() {
		return this.objConfAux.getDriver().findElement(lblConsServ).getText();
	}

	public void clickLinkVolverCuenta() {
		this.objConfAux.getDriver().findElement(linkVolverCuenta).click();
	}

	public String getLblTelefoniaMovil() {
		return this.objConfAux.getDriver().findElement(lblTelefoniaMovil).getText();
	}

	public void setCmbTipoServicio(String tipoServicio) {
		Select dropdown = new Select(this.objConfAux.getDriver().findElement(cmbTipoServicio));
		dropdown.selectByVisibleText(tipoServicio);
	}

	public void clickRadioDetalleServicio() {
		this.objConfAux.getDriver().findElement(radioDetalleServicio).click();
	}

	public String getTxtDescripcionServicio() {
		objConfAux.EsperaElemento(objConfAux.getDriver(), txtDescripcionServicio);
		return this.objConfAux.getDriver().findElement(txtDescripcionServicio).getText();
	}

	public void clickBtnSiguiente() {
		this.objConfAux.getDriver().findElement(btnSiguiente).click();
	}

	public String getLblPregutaActivacion() {
		return this.objConfAux.getDriver().findElement(lblPregutaActivacion).getText();
	}

	/** METODOS */

	public void execValidarActivacionServicio() throws IOException, InterruptedException {

		clickLinkConsultaServicios();

		clickBtnActivacionServicio();
		assertEquals(getLblConsultaServicios(), objConfAux.AdminParam.resultado.get("ActivacionServ").toString());
		objConfAux.AdminDocPdf.generaEvidencia("Opcion Activacion de Servicio",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickLinkVolverCuenta();
		assertEquals(getLblTelefoniaMovil(), objConfAux.AdminParam.resultado.get("VolverCuenta").toString());
		objConfAux.AdminDocPdf.generaEvidencia("Opcion volver a la cuenta",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}

	public void execSeleccionarDetalleServicio() throws InterruptedException, IOException {

		clickLinkConsultaServicios();
		objConfAux.AdminDocPdf.generaEvidencia("Seleccionar Detalle Servicio",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		setCmbTipoServicio(objConfAux.AdminParam.resultado.get("DetalleServ").toString());

		clickRadioDetalleServicio();
		assertNotNull(getTxtDescripcionServicio());
		objConfAux.AdminDocPdf.generaEvidencia("Opcion para ver el detalle del servicio",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickBtnSiguiente();
		assertEquals(getLblPregutaActivacion(), objConfAux.AdminParam.resultado.get("PregActivacion").toString());
		objConfAux.AdminDocPdf.generaEvidencia("Clic en boton siguiente",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}
}