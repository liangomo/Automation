package consultas.paginas;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ConsultarContrato {

	ObjetosConfigAux objConfAux;

	/** LISTA ELEMENTOS */
	By linkConsultarContrato = By.linkText("Consultar Contrato");
	By lblContratoUnico = By.xpath("/html/body/div/div[1]/div/h1");

	By btnSolicitarContrato = By.linkText("Solicitar contrato");
	By txtIntroduceEmail = By.id("actualiza_mail");
	By btnEnviar = By.linkText("Enviar");
	By lblSolicitudEnviada = By.xpath("/html/body/div/div[2]/p");
	By btnVolver = By.linkText("Volver");

	By btnHistoricoCambios = By.linkText("Consultar hist�rico de cambios");
	By lblHistoricoCambios = By.xpath("//*[@id=\"contenedor_tabla_pospago\"]/p");

	By lblCondicionesServicio = By.xpath("/html/body/div/div[1]/div/h1");
	By linkDescarga = By.linkText("Descarga condiciones de servicio");

	/* Constructor */
	public ConsultarContrato(ObjetosConfigAux objConfAux) {
		this.objConfAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkConsultarContrato() {
		this.objConfAux.getDriver().findElement(linkConsultarContrato).click();
	}

	public By getLblContratoUnico() {
		return (lblContratoUnico);
	}

	public void clickBtnSolicitarContrato() {
		this.objConfAux.getDriver().findElement(btnSolicitarContrato).click();
	}

	public void sendTxtIntroduceEmail(String email) {
		this.objConfAux.getDriver().findElement(txtIntroduceEmail).clear();
		this.objConfAux.getDriver().findElement(txtIntroduceEmail).sendKeys(email);
	}

	public void clickBtnEnviar() {
		this.objConfAux.getDriver().findElement(btnEnviar).click();
	}

	public String getLblSolicitudEnviada() {
		return this.objConfAux.getDriver().findElement(lblSolicitudEnviada).getText();
	}

	public void clickBtnVolver() {
		this.objConfAux.getDriver().findElement(btnVolver).click();
	}

	public void clickBtnHistoricoCambios() {
		this.objConfAux.getDriver().findElement(btnHistoricoCambios).click();
	}

	public String getLblHistoricoCambios() {
		return this.objConfAux.getDriver().findElement(lblHistoricoCambios).getText();
	}

	public String getLblCondicionesServicio() {
		return this.objConfAux.getDriver().findElement(lblCondicionesServicio).getText();
	}

	public void clickLinkDescarga() {
		this.objConfAux.getDriver().findElement(linkDescarga).click();
	}

	/** METODOS */

	public void execIngresarSolicitudContrato() throws InterruptedException, AWTException, IOException {

		clickLinkConsultarContrato();

		this.objConfAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		clickBtnSolicitarContrato();
		sendTxtIntroduceEmail(objConfAux.AdminParam.resultado.get("Email").toString());
		objConfAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo e introducir email",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickBtnEnviar();
		assertEquals(getLblSolicitudEnviada(), objConfAux.AdminParam.resultado.get("Contenido").toString());
		objConfAux.AdminDocPdf.generaEvidencia("Envio Contrato",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickBtnVolver();
		objConfAux.AdminDocPdf.generaEvidencia("Volver Contrato",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}

	public void execConsultarHistoricoCambios() throws InterruptedException, IOException {

		clickLinkConsultarContrato();

		this.objConfAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		clickBtnHistoricoCambios();
		assertEquals(getLblHistoricoCambios(), objConfAux.AdminParam.resultado.get("Contenido").toString());
		objConfAux.AdminDocPdf.generaEvidencia("Consulta Historico",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickBtnVolver();
		objConfAux.AdminDocPdf.generaEvidencia("Volver Historico",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}

	public void execDescargarCondicionesServicio() throws IOException, InterruptedException {

		clickLinkConsultarContrato();
		this.objConfAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertEquals(getLblCondicionesServicio(), objConfAux.AdminParam.resultado.get("Contenido").toString());
		objConfAux.AdminDocPdf.generaEvidencia("Ingreso Modulo",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickLinkDescarga();
		objConfAux.AdminDocPdf.generaEvidencia("Archivo Descargado",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}
}