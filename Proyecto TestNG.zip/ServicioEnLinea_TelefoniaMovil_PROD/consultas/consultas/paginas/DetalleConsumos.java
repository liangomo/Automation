package consultas.paginas;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class DetalleConsumos {

	ObjetosConfigAux objConfAux;

	/** LISTA ELEMENTOS */
	By linkDetalle = By.linkText("Detalle de consumos");
	By selectTipoConsumos = By.id("cmbtipcons");
	By body = By.tagName("body");
	By linkBorrarFiltros = By.linkText("Borrar filtros");
	By linkDescargar = By.linkText("Descargar");
	By linkArchivoConsumosCSV = By.linkText("Consumos.csv");
	By linkVolver = By.linkText("Volver");
	By linkLlamadas = By.linkText("Llamadas ca�das");
	By alertLlamadas = By.xpath("//*[@id=\"contiene_paginas\"]/div/article");

	By linkPrueba1 = By.xpath("//*[@id=\"url\"]");
	By linkPrueba2 = By.xpath("//*[@id=\"file-link\"]");
	By link = By.xpath("//*[@id=\"centeredContent\"]");

	/* Constructor */
	public DetalleConsumos(ObjetosConfigAux objConfAux) {
		this.objConfAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkDetalle() {
		this.objConfAux.getDriver().findElement(linkDetalle).click();
	}

	public void selectTipoConsumo(String tipoConsumo) {
		Select dropdown = new Select(this.objConfAux.getDriver().findElement(selectTipoConsumos));
		dropdown.selectByVisibleText(tipoConsumo);
	}

	public String getTipoConsumo() {
		String selectedOption = new Select(this.objConfAux.getDriver().findElement(selectTipoConsumos))
				.getFirstSelectedOption().getText();
		return selectedOption;
	}

	public String getBody() {
		return this.objConfAux.getDriver().findElement(body).getText();
	}

	public void clickLinkBorrarFiltros() {
		this.objConfAux.getDriver().findElement(linkBorrarFiltros).click();
	}

	public void clickLinkDescargar() {
		this.objConfAux.getDriver().findElement(linkDescargar).click();
	}

	public By getLinkArchivoConsumosCSV() {
		return (linkArchivoConsumosCSV);
	}

	public void clickLinkVolver() {
		this.objConfAux.getDriver().findElement(linkVolver).click();
	}

	public void clickLinkLlamadasCaidas() {
		this.objConfAux.getDriver().findElement(linkLlamadas).click();
	}

	public String getAlertLlamadas() {
		return this.objConfAux.getDriver().findElement(alertLlamadas).getText();
	}

	public String getHrefArchivoDescargado() {
		return this.objConfAux.getDriver().findElement(linkPrueba1).getAttribute("href");
	}

	public String getHrefArchivoDescargado2() {
		return this.objConfAux.getDriver().findElement(linkPrueba2).getAttribute("href");
	}

	public void getHrefArchivoDescargado3() {
		this.objConfAux.getDriver().findElement(link).sendKeys("AAAA");
	}

	/** METODOS */

	public void execRevisarDetalleConsumos() throws InterruptedException, AWTException, IOException {

		clickLinkDetalle();

		this.objConfAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("MensajeDetalle").toString()),
				"Contiene Detalles de Consumo");
		objConfAux.AdminDocPdf.generaEvidencia("Ingreso al modulo",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		selectTipoConsumo(objConfAux.AdminParam.resultado.get("TipoConsumo").toString());
		objConfAux.AdminDocPdf.generaEvidencia("Resultado busqueda",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickLinkBorrarFiltros();
		assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("MensajeBorrarFiltro").toString()),
				"Contiene Tipo de Consumos");
		objConfAux.AdminDocPdf.generaEvidencia("Borrar filtros",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickLinkVolver();
		this.objConfAux.getDriver().switchTo().frame("LegacyContainer");
		assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("MensajeBotonVolver").toString()),
				"Contiene Telefon�a M�vil");
		objConfAux.AdminDocPdf.generaEvidencia("Opcion link volver",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}

	public void execValidarLlamadasCaidas() throws InterruptedException, AWTException, IOException {

		clickLinkDetalle();
		objConfAux.AdminDocPdf.generaEvidencia("Opcion para validar llamadas caidas",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
		objConfAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		clickLinkLlamadasCaidas();
		assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("MensajeLlamadas").toString()),
				"Contiene Consulta de llamadas ca�das");
		objConfAux.AdminDocPdf.generaEvidencia("Ingreso llamadas caidas: " + getAlertLlamadas(),
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}
}