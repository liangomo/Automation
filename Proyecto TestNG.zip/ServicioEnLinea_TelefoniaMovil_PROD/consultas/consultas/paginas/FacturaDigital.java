package consultas.paginas;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class FacturaDigital {

	ObjetosConfigAux objConfAux;

	/** LISTA ELEMENTOS */
	By linkFacturaPROD = By.linkText("Factura Digital");
	By linkFacturaPruebas = By.linkText("Factura y Contrato Digital");
	By body = By.tagName("body");
	By barTitulo = By.id("barTitulo");
	By imgCerrar = By.id("btnXCerrar");
	By imgFacturaDigital = By.xpath("/html/body/center/table[2]/tbody/tr[2]/td/img");

	By imgNovedades = By.xpath("//*[@id=\"imgMenu1\"]");
	By imgImprimir = By.xpath("//*[@id=\"imgMenu2\"]");
	By imgExportarFactura = By.xpath("//*[@id=\"imgMenu3\"]");
	By imgInfoGrafica = By.xpath("//*[@id=\"imgMenu4\"]");
	By spanDetalleInfoGrafica = By.xpath("//*[@id=\"nomBr\"]");
	By imgAdminCorreos = By.xpath("//*[@id=\"imgMenu5\"]");

	By spanNombreCliente = By.xpath("/html/body/div[2]/span");

	By imgPrimeraPag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[2]/img");
	By imgAnteriorPag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[4]/img");
	By imgSiguientePag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[6]/img");
	By imgUltimaPag = By.xpath("//*[@id=\"botGra\"]/tbody/tr[1]/td[8]/img");

	By spanNitCedula = By.xpath("/html/body/div[17]/span");
	By spanTelefono = By.xpath("/html/body/div[19]/span");
	By spanClienteNo = By.xpath("/html/body/div[21]/span");
	By spanFacturaVenta = By.xpath("/html/body/div[23]/span");
	By spanFechaExpedicion = By.xpath("/html/body/div[25]/span");
	By spanFacturaMes = By.xpath("/html/body/div[27]/span");
	By spanFechaProximaFactura = By.xpath("/html/body/div[35]/span");
	By spanNumeroParaPagos = By.xpath("/html/body/div[37]/span");
	By spanFechaLimitePago = By.xpath("/html/body/div[39]/span");
	By spanTotalPagar = By.xpath("/html/body/div[41]/span");

	By spanCargosFacturados = By.xpath("/html/body/div[3]/span");
	By spanValorImpuestos = By.xpath("/html/body/div[4]/span");

	/* Constructor */
	public FacturaDigital(ObjetosConfigAux objConfAux) {
		this.objConfAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkFacturaPROD() {
		this.objConfAux.getDriver().findElement(linkFacturaPROD).click();
	}

	public void clickLinkFacturaPruebas() {
		this.objConfAux.getDriver().findElement(linkFacturaPruebas).click();
	}

	public String getBody() {
		return this.objConfAux.getDriver().findElement(body).getText();
	}

	public void getBodyFramePresenta() {
		this.objConfAux.getDriver().switchTo().frame("presenta");
	}

	public void getBodyAlertAccept() {
		this.objConfAux.getDriver().switchTo().alert().accept();
	}

	public void getBodyFrameFactura() {
		this.objConfAux.getDriver().switchTo().frame("factura");
	}

	public void clickImgCerrar() {
		this.objConfAux.getDriver().findElement(imgCerrar).click();
	}

	public void clickImgNovedades() {
		this.objConfAux.getDriver().findElement(imgNovedades).click();
	}

	public void clickImgImprimir() {
		this.objConfAux.getDriver().findElement(imgImprimir).click();
	}

	public void clickImgExportarFact() {
		objConfAux.EsperaElemento(objConfAux.getDriver(), imgExportarFactura, 2);
		this.objConfAux.getDriver().findElement(imgExportarFactura).click();
	}

	public void clickImgInfoGrafica() {
		objConfAux.EsperaElemento(objConfAux.getDriver(), imgInfoGrafica, 2);
		this.objConfAux.getDriver().findElement(imgInfoGrafica).click();
	}

	public void clickImgAdminCorreos() {
		this.objConfAux.getDriver().findElement(imgAdminCorreos).click();
	}

	public By getSpanNombreCliente() {
		return (spanNombreCliente);
	}

	public void clickImgPrimeraPag() {
		this.objConfAux.getDriver().findElement(imgPrimeraPag).click();
	}

	public void clickImgAnteriorPag() {
		this.objConfAux.getDriver().findElement(imgAnteriorPag).click();
	}

	public void clickImgSiguientePag() {
		this.objConfAux.getDriver().findElement(imgSiguientePag).click();
	}

	public void clickImgUltimaPag() {
		this.objConfAux.getDriver().findElement(imgUltimaPag).click();
	}

	public String getSpanNitCedula() {
		return this.objConfAux.getDriver().findElement(spanNitCedula).getText();
	}

	public String getSpanTelefono() {
		return this.objConfAux.getDriver().findElement(spanTelefono).getText();
	}

	public String getSpanClienteNo() {
		return this.objConfAux.getDriver().findElement(spanClienteNo).getText();
	}

	public String getSpanFacturaVenta() {
		return this.objConfAux.getDriver().findElement(spanFacturaVenta).getText();
	}

	public String getSpanFechaExpedicion() {
		return this.objConfAux.getDriver().findElement(spanFechaExpedicion).getText();
	}

	public String getSpanFacturaMes() {
		return this.objConfAux.getDriver().findElement(spanFacturaMes).getText();
	}

	public String getSpanFechaProximaFactura() {
		return this.objConfAux.getDriver().findElement(spanFechaProximaFactura).getText();
	}

	public String getSpanNumeroParaPagos() {
		return this.objConfAux.getDriver().findElement(spanNumeroParaPagos).getText();
	}

	public String getSpanFechaLimitePago() {
		return this.objConfAux.getDriver().findElement(spanFechaLimitePago).getText();
	}

	public String getSpanTotalPagar() {
		return this.objConfAux.getDriver().findElement(spanTotalPagar).getText();
	}

	public String getSpanCargosFacturados() {
		return this.objConfAux.getDriver().findElement(spanCargosFacturados).getText();
	}

	public String getSpanValorImpuestos() {
		return this.objConfAux.getDriver().findElement(spanValorImpuestos).getText();
	}

	/** METODOS */

	public void execIngresoFactura() throws InterruptedException, IOException {

		clickLinkFacturaPROD();

		objConfAux.cambiarVentana();
		getBodyFramePresenta();
		assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), barTitulo, 2), "Barra Novedades");
		objConfAux.AdminDocPdf.generaEvidencia("Barra Novedades",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickImgCerrar();
		assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), imgFacturaDigital, 2), "Bot�n Cerrar Novedades");
	}

	public void execVerificarSubmoduloPospago() throws InterruptedException, IOException {

		if (objConfAux.EsperaElemento(objConfAux.getDriver(), imgFacturaDigital, 2)) {

			clickImgNovedades();
			assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), barTitulo, 2), "Opci�n Novedades");
			objConfAux.AdminDocPdf.generaEvidencia("Verifica Novedades",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgImprimir();
			assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), barTitulo, 2), "Opci�n Imprimir");
			objConfAux.AdminDocPdf.generaEvidencia("Verifica Imprimir",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgExportarFact();
			assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), barTitulo, 2), "Opci�n Exportar Factura");
			objConfAux.AdminDocPdf.generaEvidencia("Exportar Factura",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgInfoGrafica();
			assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), spanDetalleInfoGrafica, 2),
					"Opci�n Informaci�n Gr�fica");
			objConfAux.AdminDocPdf.generaEvidencia("Informaci�n gr�fica",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());

			clickImgAdminCorreos();
			assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), barTitulo, 2),
					"Opci�n Administraci�n de Correos");
			objConfAux.AdminDocPdf.generaEvidencia("Administrar Correos",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			clickImgCerrar();
		}
	}

	public void execVerificarSubmoduloCtaControl() throws InterruptedException, IOException {

		if (objConfAux.EsperaElemento(objConfAux.getDriver(), imgFacturaDigital, 2)) {

			clickImgNovedades();
			assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), barTitulo, 2), "Opci�n Novedades");
			objConfAux.AdminDocPdf.generaEvidencia("Verifica Novedades",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			clickImgCerrar();

			clickImgImprimir();
			assertTrue(objConfAux.EsperaElemento(objConfAux.getDriver(), barTitulo, 2), "Opci�n Imprimir");
			objConfAux.AdminDocPdf.generaEvidencia("Verifica Imprimir",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			clickImgCerrar();
		}
	}

	public void execVerificarPaginacion() throws InterruptedException, IOException {

		if (objConfAux.EsperaElemento(objConfAux.getDriver(), imgFacturaDigital, 2)) {

			getBodyFrameFactura();
			assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("ContenidoFactura").toString()),
					"Contiene palabra Se�or(a) - PagInicial");
			objConfAux.AdminDocPdf.generaEvidencia("Verifica Ingreso Factura",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());

			objConfAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgSiguientePag();
			getBodyFrameFactura();
			assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("ContenidoPagSig").toString()),
					"Contiene Nit o C�dula - PagSig");
			objConfAux.AdminDocPdf.generaEvidencia("Verificar Siguiente Pagina",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());

			objConfAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgAnteriorPag();
			getBodyFrameFactura();
			assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("ContenidoFactura").toString()),
					"Contiene palabra Se�or(a) - AnteriorPag");
			objConfAux.AdminDocPdf.generaEvidencia("Verificar Anterior Pagina",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());

			objConfAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgUltimaPag();
			// clickImgUltimaPag(); Thread.sleep(2000);
			objConfAux.AdminDocPdf.generaEvidencia("Verificar Ultima Pagina",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			// getBodyAlertAccept();
			// objConfAux.getDriver().switchTo().alert().accept();

			objConfAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgPrimeraPag();
			getBodyFrameFactura();
			assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("ContenidoFactura").toString()),
					"Contiene palabra Se�or(a) - PrimerPag");
			objConfAux.AdminDocPdf.generaEvidencia("Verificar Primera Pagina",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());

			objConfAux.cambiarVentana();
			getBodyFramePresenta();
		}
	}

	public void execVerificarPaginacionCta() throws InterruptedException, IOException {

		if (objConfAux.EsperaElemento(objConfAux.getDriver(), imgFacturaDigital, 2)) {

			getBodyFrameFactura();
			assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("ContenidoFactura").toString()),
					"Contiene palabra Se�or(a) - PagInicial");
			objConfAux.AdminDocPdf.generaEvidencia("Verificar Ingreso Factura",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());

			objConfAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgSiguientePag();
			getBodyFrameFactura();
			assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("ContenidoPagSig").toString()),
					"Contiene Nit o C�dula - PagSig");
			objConfAux.AdminDocPdf.generaEvidencia("Verificar Siguiente Pagina",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());

			objConfAux.cambiarVentana();
			getBodyFramePresenta();
			clickImgAnteriorPag();
			getBodyFrameFactura();
			assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("ContenidoFactura").toString()),
					"Contiene palabra Se�or(a) - AnteriorPag");
			objConfAux.AdminDocPdf.generaEvidencia("Verificar Pagina Anterior",
					Shutterbug.shootPage(objConfAux.getDriver()).getImage());

			objConfAux.cambiarVentana();
			getBodyFramePresenta();
		}
	}

	public void execValidarInformacion() throws InterruptedException, IOException {

		if (objConfAux.EsperaElemento(objConfAux.getDriver(), imgFacturaDigital, 2)) {
			clickImgSiguientePag();
			getBodyFrameFactura();
		}
		objConfAux.AdminDocPdf.generaEvidencia("Validar Informacion",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}
}