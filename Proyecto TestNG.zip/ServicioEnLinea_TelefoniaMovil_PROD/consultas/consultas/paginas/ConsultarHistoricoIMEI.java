package consultas.paginas;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ConsultarHistoricoIMEI {

	ObjetosConfigAux objConfAux;

	/** LISTA ELEMENTOS */
	By linkConsultarHistorico = By.linkText("Consulta Historico IMEI");
	By imgImprimir = By.id("Imprimir");
	By btnImprimir = By.xpath("//*[@id=\"print-header\"]/div/button[1]");
	By btnCancelar = By.xpath("//*[@id=\"print-header\"]/div/button[2]");
	By imgDescargar = By.id("Descargar");
	By linkVolverCuenta = By.id("VolverCuenta");

	By linkSaberIMEI = By.xpath("//*[@id=\"boton_interogacion\"]");
	By cboxClose = By.id("cboxClose");

	By linkMovistarCo = By.id("Movistar");
	By imgMovistarCo = By.xpath("//*[@id=\"footer_2016\"]/div[1]/div/div[2]/div[1]/a/img");
	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");

	/* Constructor */
	public ConsultarHistoricoIMEI(ObjetosConfigAux objConfAux) {
		this.objConfAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkConsultarHistorico() {
		this.objConfAux.getDriver().findElement(linkConsultarHistorico).click();
	}

	public void clickImgImprimir() {
		this.objConfAux.getDriver().findElement(imgImprimir).click();
	}

	public String getBtnImprimir() {
		return this.objConfAux.getDriver().findElement(btnImprimir).getText();
	}

	public void clickBtnCancelar() {
		this.objConfAux.getDriver().findElement(btnCancelar).click();
	}

	public void clickImgDescargar() {
		this.objConfAux.getDriver().findElement(imgDescargar).click();
	}

	public void clickLinkVolverCuenta() {
		this.objConfAux.getDriver().findElement(linkVolverCuenta).click();
	}

	public void clickLinkSaberIMEI() {
		this.objConfAux.getDriver().findElement(linkSaberIMEI).click();
	}

	public By getCboxClose() {
		return (cboxClose);
	}

	public void clickCboxClose() {
		this.objConfAux.getDriver().findElement(cboxClose).click();
	}

	public void clickLinkMovistarCo() {
		this.objConfAux.getDriver().findElement(linkMovistarCo).click();
	}

	public By getImgMovistarCo() {
		return (imgMovistarCo);
	}

	public By getImgPhotoUser() {
		return (imgPhotoUser);
	}


	/** METODOS */

	public void execConsultarHistoricoIMEI() throws InterruptedException, AWTException, IOException {

		clickLinkConsultarHistorico();
		clickImgImprimir();
		objConfAux.cambiarVentana();
		this.objConfAux.getDriver().switchTo().defaultContent();
		assertEquals(getBtnImprimir(), "Imprimir");
		objConfAux.AdminDocPdf.generaEvidencia("Opcion Imprimir",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickBtnCancelar();
		objConfAux.cambiarVentanaAnterior();
		objConfAux.AdminDocPdf.generaEvidencia("Opcion Cancelar",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickLinkVolverCuenta();
		objConfAux.AdminDocPdf.generaEvidencia("Opcion Volver Cuenta",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}

	public void execValidarLinks() throws InterruptedException, AWTException, IOException {

		clickLinkConsultarHistorico();
		Thread.sleep(2000);
		objConfAux.AdminDocPdf.generaEvidencia("Validar links Historico IMEI",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickLinkSaberIMEI();
		Thread.sleep(2000);
		objConfAux.cambiarVentanaAnterior();
		objConfAux.AdminDocPdf.generaEvidencia("Link Saber IMEI",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
		clickCboxClose();
		Thread.sleep(2000);

		clickLinkMovistarCo();
		Thread.sleep(2000);
		objConfAux.AdminDocPdf.generaEvidencia("Opcion movistarCO",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}
}