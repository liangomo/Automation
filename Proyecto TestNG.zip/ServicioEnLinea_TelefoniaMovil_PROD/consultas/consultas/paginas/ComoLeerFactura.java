package consultas.paginas;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ComoLeerFactura {

	ObjetosConfigAux objConfAux;

	/** LISTA ELEMENTOS */
	By linkComoLeerFactura = By.linkText("C�mo leer mi factura");
	By lblConoceTuFactura = By.xpath("//*[@id=\"conoceFactura\"]/div/div[1]/h2");

	/* Constructor */
	public ComoLeerFactura(ObjetosConfigAux objConfAux) {
		this.objConfAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkComoLeerFactura() {
		this.objConfAux.getDriver().findElement(linkComoLeerFactura).click();
	}

	public String getLblConoceTuFactura() {
		return this.objConfAux.getDriver().findElement(lblConoceTuFactura).getText();
	}

	/** METODOS */

	public void execIngresarLeerFactura() throws InterruptedException, AWTException, IOException {

		clickLinkComoLeerFactura();

		objConfAux.cambiarVentana();
		assertEquals(getLblConoceTuFactura(), objConfAux.AdminParam.resultado.get("Contenido").toString());
		objConfAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
		objConfAux.keyPressCerrarPestana();

		objConfAux.cambiarVentanaAnterior();
		Thread.sleep(2000);
	}
}