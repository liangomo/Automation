package consultas.paginas;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ConsultaPagosRecargas {

	ObjetosConfigAux objConfAux;

	/** LISTA ELEMENTOS */
	By linkPagosRecargas = By.linkText("Consulta tus pagos y recargas");
	By tblPrimerNoPago = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_contenidoTabla\"]/div[2]/div[1]/h4");
	By txtNumPagoDetalle = By.id("ctl00_ContentPlaceHolder1_TxtPedido");
	By btnEnviar = By.id("ctl00_ContentPlaceHolder1_BtnEnvio");
	By lblPedido = By.id("ctl00_ContentPlaceHolder1_LblPedido");
	By lblResultadoTrx = By.id("ctl00_ContentPlaceHolder1_LblResultado");

	/* Constructor */
	public ConsultaPagosRecargas(ObjetosConfigAux objConfAux) {
		this.objConfAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkPagosRecargas() throws InterruptedException {
		Thread.sleep(5000);
		this.objConfAux.getDriver().findElement(linkPagosRecargas).click();
	}

	public String getTblPrimerNoPago() {
		return this.objConfAux.getDriver().findElement(tblPrimerNoPago).getText();
	}

	public void setTxtNumPagoDetalle(String numPagoDetalle) {
		this.objConfAux.getDriver().findElement(txtNumPagoDetalle).sendKeys(numPagoDetalle);
	}

	public void clickBtnEnviar() {
		this.objConfAux.getDriver().findElement(btnEnviar).click();
	}

	public String getLblPedido() {
		return this.objConfAux.getDriver().findElement(lblPedido).getText();
	}

	public By byLblResultadoTrx() {
		return (lblResultadoTrx);
	}

	public String getLblResultadoTrx() {
		return this.objConfAux.getDriver().findElement(lblResultadoTrx).getText();
	}

	/** METODOS */

	public void execConsultarPagosYRecargas() throws InterruptedException, IOException {

		clickLinkPagosRecargas();

		String primerNoPago = getTblPrimerNoPago();
		setTxtNumPagoDetalle(primerNoPago);
		objConfAux.AdminDocPdf.generaEvidencia("Ingreso al m�dulo",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickBtnEnviar();
		assertEquals(primerNoPago, getLblPedido());
		objConfAux.AdminDocPdf.generaEvidencia("Envio pago o recarga",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}
}