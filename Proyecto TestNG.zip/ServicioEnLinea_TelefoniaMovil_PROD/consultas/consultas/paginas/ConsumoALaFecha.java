package consultas.paginas;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import com.assertthat.selenium_shutterbug.core.Shutterbug;

import control.elementos.ObjetosConfigAux;

public class ConsumoALaFecha {

	ObjetosConfigAux objConfAux;

	/** LISTA ELEMENTOS */
	By linkConsumosPROD = By.linkText("Consumos a la fecha");
	By linkConsumosPruebas = By.linkText("Resumen de Consumos");
	By body = By.tagName("body");
	By lblSaldoDisponible = By.xpath("//*[@id=\"contenedorTbl\"]/div[1]");
	By linkDetalleConsumo = By.linkText("aqu�");
	By lblDetalleConsumo = By.xpath("//*[@id=\"top_contenido\"]/h1");
	By linkVolverDetalle = By.linkText("Volver");

	/* Constructor */
	public ConsumoALaFecha(ObjetosConfigAux objConfAux) {
		this.objConfAux = objConfAux;
	}

	/** EVENTOS (ACCIONES) EN LOS OBJETOS */

	public void clickLinkConsumosPROD() {
		this.objConfAux.getDriver().findElement(linkConsumosPROD).click();
	}

	public void clickLinkConsumosPruebas() {
		this.objConfAux.getDriver().findElement(linkConsumosPruebas).click();
	}

	public String getBody() {
		return this.objConfAux.getDriver().findElement(body).getText();
	}

	public String getLblSaldoDisponible() {
		return this.objConfAux.getDriver().findElement(lblSaldoDisponible).getText();
	}

	public void clickLinkDetalleConsumo() {
		this.objConfAux.getDriver().findElement(linkDetalleConsumo).click();
	}	

	public String getLblDetalleConsumo() {
		return this.objConfAux.getDriver().findElement(lblDetalleConsumo).getText();
	}

	public void clickLinkVolverDetalle() throws InterruptedException {
		this.objConfAux.getDriver().findElement(linkVolverDetalle).click();
	}

	/** METODOS */

	public void execValidarLinksConsumoALaFecha() throws InterruptedException, IOException {

		clickLinkDetalleConsumo();

		if (!objConfAux.AdminParam.resultado.get("TipoProd").toString().equals("Pospago"))
			this.objConfAux.getDriver().switchTo().frame("LegacyContainer");

		this.objConfAux.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
		assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("Principal").toString()),
				"Contiene Detalles de Consumo");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion detalle de consumo",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		clickLinkVolverDetalle();
		this.objConfAux.getDriver().switchTo().frame("LegacyContainer");
		assertTrue(getBody().contains(objConfAux.AdminParam.resultado.get("VolverDetalle").toString()),
				"Contiene Telefonia M�vil");
		objConfAux.AdminDocPdf.generaEvidencia("Validacion link volver detalle",
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());
	}
}