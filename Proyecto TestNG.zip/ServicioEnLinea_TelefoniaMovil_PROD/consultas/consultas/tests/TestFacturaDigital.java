package consultas.tests;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import consultas.paginas.FacturaDigital;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import homePage.paginas.HomePage;
import login.paginas.Login;
import manager.param.AdminParam;
import model.Ambientes;
import model.DispositivoPrueba;
import model.Estados;
import model.Navegadores;
import model.TipoCone;

public class TestFacturaDigital {
	ObjetosConfigAux objConfAux;
	Login objLogin;
	HomePage objHome;
	FacturaDigital objFact;
	Navegadores navegador;
	Ambientes ambiente = Ambientes.PRODUCCION;

	@BeforeClass
	@Parameters({ "Navegador" })
	public void setup(String navegadores) throws IOException, InterruptedException {

		objConfAux = new ObjetosConfigAux(navegadores);
		this.navegador = objConfAux.getNavegador();
		objLogin = new Login(objConfAux);
		objHome = new HomePage(objConfAux);
		objFact = new FacturaDigital(objConfAux);
		objLogin.execLogin();
	}

	/**
	 * CASOS DE PRUEBA
	 */

	@Test(priority = 1)
	public void cp001_IngresarFacturaPospago() throws InterruptedException, IOException, DocumentException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "FacturaDigital",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clicLnkProducto(objConfAux.AdminParam.resultado.get("Producto").toString());
		objConfAux.AdminDocPdf.generaEvidencia(
				"Ingreso Principal " + objConfAux.AdminParam.resultado.get("Producto").toString(),
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		objHome.clickLinkConsultas();
		objFact.execIngresoFactura();
	}

	@Test(priority = 5)
	public void cp002_IngresarFacturaCtaControl()
			throws InterruptedException, MalformedURLException, DocumentException, IOException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "FacturaDigital",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clicLnkProducto(objConfAux.AdminParam.resultado.get("Producto").toString());
		objConfAux.AdminDocPdf.generaEvidencia(
				"Ingreso Principal " + objConfAux.AdminParam.resultado.get("Producto").toString(),
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		objHome.clickLinkConsultas();
		objFact.execIngresoFactura();
	}

	@Test(priority = 2)
	public void cp003_VerificarSubmoduloPospago()
			throws InterruptedException, MalformedURLException, DocumentException, IOException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objFact.execVerificarSubmoduloPospago();
	}

	@Test(priority = 6)
	public void cp004_VerificarSubmoduloCtaControl()
			throws InterruptedException, MalformedURLException, DocumentException, IOException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objFact.execVerificarSubmoduloCtaControl();
	}

	@Test(priority = 3)
	public void cp005_VerificarPaginacionPospago()
			throws InterruptedException, MalformedURLException, DocumentException, IOException, AWTException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "FacturaDigital",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objFact.execVerificarPaginacion();
	}

	@Test(priority = 7)
	public void cp006_VerificarPaginacionCtaControl()
			throws InterruptedException, MalformedURLException, DocumentException, IOException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "FacturaDigital",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objFact.execVerificarPaginacionCta();
	}

	@Test(priority = 4)
	public void cp007_ValidarInformacionPospago()
			throws InterruptedException, MalformedURLException, DocumentException, IOException, AWTException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "FacturaDigital",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objFact.execValidarInformacion();

		String nitCedula = objFact.getSpanNitCedula();
		String telefono = objFact.getSpanTelefono();
		String clienteNo = objFact.getSpanClienteNo();
		String facturaVenta = objFact.getSpanFacturaVenta();
		String fechaExpedicion = objFact.getSpanFechaExpedicion();
		String facturaMes = objFact.getSpanFacturaMes();
		String fechaProximaFactura = objFact.getSpanFechaProximaFactura();
		String numeroParaPagos = objFact.getSpanNumeroParaPagos();
		String fechaLimitePago = objFact.getSpanFechaLimitePago();
		String totalPagar = objFact.getSpanTotalPagar();

		assertTrue(nitCedula.contains(objConfAux.AdminParam.resultado.get("Cedula").toString()), "nitCedula");
		assertTrue(telefono.contains(objConfAux.AdminParam.resultado.get("Telefono").toString()), "telefono");
		assertTrue(clienteNo.contains(objConfAux.AdminParam.resultado.get("NumeroCliente").toString()), "clienteNo");
		assertNotNull(facturaVenta, "facturaVenta vacio");
		assertNotNull(fechaExpedicion, "fechaExpedicion vacio");
		assertNotNull(facturaMes, "facturaMes vacio");
		assertNotNull(fechaProximaFactura, "fechaProximaFactura vacio");
		assertTrue(numeroParaPagos.contains(objConfAux.AdminParam.resultado.get("NumeroPagos").toString()),
				"numeroParaPagos");
		assertNotNull(fechaLimitePago, "fechaLimitePago vacio");
		assertNotNull(totalPagar, "totalPagar vacio");

		objConfAux.keyPressCerrarPestana();
		objConfAux.cambiarVentanaAnterior();
		Thread.sleep(2000);
	}

	@Test(priority = 8)
	public void cp008_ValidarInformacionCtaControl()
			throws InterruptedException, MalformedURLException, DocumentException, IOException, AWTException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "FacturaDigital",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objFact.execValidarInformacion();

		String nitCedula = objFact.getSpanNitCedula();
		String telefono = objFact.getSpanTelefono();
		String clienteNo = objFact.getSpanClienteNo();
		String facturaVenta = objFact.getSpanFacturaVenta();
		String fechaExpedicion = objFact.getSpanFechaExpedicion();
		String facturaMes = objFact.getSpanFacturaMes();
		String fechaProximaFactura = objFact.getSpanFechaProximaFactura();
		String numeroParaPagos = objFact.getSpanNumeroParaPagos();
		String fechaLimitePago = objFact.getSpanFechaLimitePago();
		String totalPagar = objFact.getSpanTotalPagar();

		assertTrue(nitCedula.contains(objConfAux.AdminParam.resultado.get("Cedula").toString()), "nitCedula");
		assertTrue(telefono.contains(objConfAux.AdminParam.resultado.get("Telefono").toString()), "telefono");
		assertTrue(clienteNo.contains(objConfAux.AdminParam.resultado.get("NumeroCliente").toString()), "clienteNo");
		assertNotNull(facturaVenta, "facturaVenta vacio");
		assertNotNull(fechaExpedicion, "fechaExpedicion vacio");
		assertNotNull(facturaMes, "facturaMes vacio");
		assertNotNull(fechaProximaFactura, "fechaProximaFactura vacio");
		assertTrue(numeroParaPagos.contains(objConfAux.AdminParam.resultado.get("NumeroPagos").toString()),
				"numeroParaPagos");
		assertNotNull(fechaLimitePago, "fechaLimitePago vacio");
		assertNotNull(totalPagar, "totalPagar vacio");

		objConfAux.keyPressCerrarPestana();
		objConfAux.cambiarVentanaAnterior();
		Thread.sleep(2000);
	}

	@AfterMethod
	public void finalizeTest(ITestResult t) throws MalformedURLException, DocumentException, IOException {
		if (t.getStatus() == ITestResult.SUCCESS)
			objConfAux.AdminDocPdf.crearDocumento(Estados.SUCCESS);
		else {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			Throwable cause = t.getThrowable();
			if (null != cause) {
				cause.printStackTrace(pw);
				objConfAux.AdminDocPdf.generaEvidencia(
						"Resultado NO Esperado: "
								+ sw.getBuffer().toString().substring(0, sw.getBuffer().toString().indexOf("at ")),
						Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			} else {
				objConfAux.AdminDocPdf.generaEvidencia("Resultado NO Esperado: ",
						Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			}

			objConfAux.AdminDocPdf.crearDocumento(Estados.FAILED);
		}
	}

	@AfterClass
	public void tearDowns() {
		objConfAux.getDriver().quit();
	}
}