package consultas.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.lowagie.text.DocumentException;

import consultas.paginas.ConsultarHistoricoIMEI;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import homePage.paginas.HomePage;
import login.paginas.Login;
import manager.param.AdminParam;
import model.Ambientes;
import model.DispositivoPrueba;
import model.Estados;
import model.Navegadores;
import model.TipoCone;

public class TestConsultarHistoricoIMEI {

	ObjetosConfigAux objConfAux;
	Login objLogin;
	HomePage objHome;
	ConsultarHistoricoIMEI objImei;
	Navegadores navegador;
	Ambientes ambiente = Ambientes.PRODUCCION;

	@BeforeClass
	@Parameters({ "Navegador" })
	public void setup(String navegadores) throws IOException, InterruptedException {

		objConfAux = new ObjetosConfigAux(navegadores);
		this.navegador = objConfAux.getNavegador();
		objLogin = new Login(objConfAux);
		objHome = new HomePage(objConfAux);
		objImei = new ConsultarHistoricoIMEI(objConfAux);
		objLogin.execLogin();
	}

	/**
	 * CASOS DE PRUEBA
	 */

	@Test(priority = 1)
	public void cp001_ConsultarHistoricoIMEIPospago()
			throws InterruptedException, AWTException, DocumentException, MalformedURLException, IOException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "ConsultarHistoricoIMEI",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clicLnkProducto(objConfAux.AdminParam.resultado.get("Producto").toString());
		objConfAux.AdminDocPdf.generaEvidencia(
				"Ingreso Principal " + objConfAux.AdminParam.resultado.get("Producto").toString(),
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		objHome.clickLinkConsultas();
		objImei.execConsultarHistoricoIMEI();
	}

	@Test(priority = 2)
	public void cp002_ConsultarHistoricoIMEICtaControl()
			throws InterruptedException, AWTException, DocumentException, MalformedURLException, IOException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "ConsultarHistoricoIMEI",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clicLnkProducto(objConfAux.AdminParam.resultado.get("Producto").toString());
		objConfAux.AdminDocPdf.generaEvidencia(
				"Ingreso Principal " + objConfAux.AdminParam.resultado.get("Producto").toString(),
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		objHome.clickLinkConsultas();
		objImei.execConsultarHistoricoIMEI();
	}

	@Test(priority = 3)
	public void cp003_ConsultarHistoricoIMEIPrepago()
			throws InterruptedException, AWTException, DocumentException, MalformedURLException, IOException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "ConsultarHistoricoIMEI",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");

		objConfAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clicLnkProducto(objConfAux.AdminParam.resultado.get("Producto").toString());
		objConfAux.AdminDocPdf.generaEvidencia(
				"Ingreso Principal " + objConfAux.AdminParam.resultado.get("Producto").toString(),
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		objHome.clickLinkConsultas();
		objImei.execConsultarHistoricoIMEI();
	}

	@Test(priority = 4)
	public void cp004_ValidarLinksPospago()
			throws InterruptedException, AWTException, DocumentException, MalformedURLException, IOException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "ConsultarHistoricoIMEI",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clicLnkProducto(objConfAux.AdminParam.resultado.get("Producto").toString());
		objConfAux.AdminDocPdf.generaEvidencia(
				"Ingreso Principal " + objConfAux.AdminParam.resultado.get("Producto").toString(),
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		objHome.clickLinkConsultas();
		objImei.execValidarLinks();
	}

	@Test(priority = 5)
	public void cp005_ValidarLinksCtaControl()
			throws InterruptedException, AWTException, DocumentException, MalformedURLException, IOException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "ConsultarHistoricoIMEI",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clicLnkProducto(objConfAux.AdminParam.resultado.get("Producto").toString());
		objConfAux.AdminDocPdf.generaEvidencia(
				"Ingreso Principal " + objConfAux.AdminParam.resultado.get("Producto").toString(),
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		objHome.clickLinkConsultas();
		objImei.execValidarLinks();

	}

	@Test(priority = 6)
	public void cp006_ValidarLinksPrepago()
			throws InterruptedException, AWTException, DocumentException, MalformedURLException, IOException {

		objConfAux.AdminDocPdf = new AdminDocPdf(ambiente, navegador, DispositivoPrueba.WEB);

		objConfAux.AdminParam = new AdminParam(TipoCone.EXCEL, "ConsultarHistoricoIMEI",
				Thread.currentThread().getStackTrace()[1].getMethodName(), "Consultas.xlsx");
		objConfAux.AdminParam.ObtenerParametros();

		objHome.clickBtnHomePage();
		objHome.clicLnkProducto(objConfAux.AdminParam.resultado.get("Producto").toString());
		objConfAux.AdminDocPdf.generaEvidencia(
				"Ingreso Principal " + objConfAux.AdminParam.resultado.get("Producto").toString(),
				Shutterbug.shootPage(objConfAux.getDriver()).getImage());

		objHome.clickLinkConsultas();
		objImei.execValidarLinks();
	}

	@AfterMethod
	public void finalizeTest(ITestResult t) throws MalformedURLException, DocumentException, IOException {
		if (t.getStatus() == ITestResult.SUCCESS)
			objConfAux.AdminDocPdf.crearDocumento(Estados.SUCCESS);
		else {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			Throwable cause = t.getThrowable();
			if (null != cause) {
				cause.printStackTrace(pw);
				objConfAux.AdminDocPdf.generaEvidencia(
						"Resultado NO Esperado: "
								+ sw.getBuffer().toString().substring(0, sw.getBuffer().toString().indexOf("at ")),
						Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			} else {
				objConfAux.AdminDocPdf.generaEvidencia("Resultado NO Esperado: ",
						Shutterbug.shootPage(objConfAux.getDriver()).getImage());
			}

			objConfAux.AdminDocPdf.crearDocumento(Estados.FAILED);
		}
	}

	@AfterClass
	public void tearDowns() {
		objConfAux.getDriver().quit();
	}
}