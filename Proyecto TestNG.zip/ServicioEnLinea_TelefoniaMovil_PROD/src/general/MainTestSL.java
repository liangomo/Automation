package general;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.CommandLineArgs;
import org.testng.*;
import org.testng.annotations.*;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlInclude;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.beust.jcommander.JCommander;

public class MainTestSL {

	@SuppressWarnings("rawtypes")
	static List<Class> result = new ArrayList<Class>();

	// @args[0] = Nombre del caso de prueba a ejecutar. Si es "all" se
	// ejecutaran todos los casos del proyecto.
	// @args[1] = Especifica el navegador: 1.Internet Explorer, 2.Chrome,
	// 3.Mozila Firefox, 4.Edge, 5.Safari, 6.Opera
	// @args[2] = Ambientes: Produccion, Precol, Proyecto.

	@SuppressWarnings("rawtypes")
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		if (args.length == 0 && args.length > 3) {
			System.out.println("Cantidad de parametros no corresponde con el esperado");
		}
		if (Integer.parseInt(args[1]) > 6) {
			System.out.println("Valor navegador no valido");
		}

		List<XmlClass> xmlClases = new ArrayList<XmlClass>();
		obtenerClases(new File(".").getCanonicalFile());

		outerloop: for (Class c : result) {
			if (args[0].contains("ALL")) {
				Method[] m = c.getMethods();
				for (int i = 0; i < m.length; i++) {
					if (m[i].isAnnotationPresent(Test.class)) {
						xmlClases.add(new XmlClass(c));
						break;
					}
				}
			} else{
				Method[] m = c.getMethods();
				for (int i = 0; i < m.length; i++) {
					if (m[i].isAnnotationPresent(Test.class)) {
						if (args[0].contains("CLASS:")
								&& c.getName().equals(args[0].substring(args[0].indexOf(":") + 1))) {
							xmlClases.add(new XmlClass(c));
							break outerloop;
						} else if (args[0].contains("CP:")
								&& m[i].getName().equals(args[0].substring(args[0].indexOf(":") + 1))) {
							xmlClases.add(new XmlClass(c));
							break outerloop;
						}
					}
				}
			}
		}
		if (xmlClases.size() > 0) {
			ejecutarTests(xmlClases, args);
		} else {
			System.out.println("No se ha identificado el objeto solicitado.");
		}
	}

	public static void obtenerClases(File dir) throws ClassNotFoundException, IOException {
		File listFile[] = dir.listFiles();
		if (listFile != null) {
			for (int i = 0; i < listFile.length; i++) {
				if (listFile[i].isDirectory()) {
					obtenerClases(listFile[i]);
				} else {
					if (listFile[i].getName().endsWith(".class")) {
						int posInicial = listFile[i].getAbsolutePath().indexOf("bin\\") + 4;
						String nombrePackage = listFile[i].getAbsolutePath().substring(posInicial).replace("\\", ".");
						result.add(Class.forName(nombrePackage.substring(0, nombrePackage.length() - 6)));
					}
				}
			}
		}
	}

	@SuppressWarnings({ "unused", "rawtypes", "unchecked" })
	public static void ejecutarTests(List<XmlClass> pXmlClases, String[] args) {
		CommandLineArgs options = new CommandLineArgs();
		JCommander jCommander = new JCommander(options);
		XmlSuite suite = new XmlSuite();
		List<XmlInclude> include = new ArrayList<XmlInclude>();
		Map opciones = new HashMap<String, Object>();
		XmlTest test = new XmlTest(suite);
		List<XmlSuite> suites = new ArrayList<XmlSuite>();
		TestNG testNG = new TestNG();

		suite.setName("EjecucionAutomatica");

		opciones.put("Navegador", args[1]);
		opciones.put("Ambiente", "pruebas");
		suite.setParameters(opciones);

		if (args[0].contains("CP:")) {
			include.add(new XmlInclude(args[0].substring(args[0].indexOf(":") + 1)));
			pXmlClases.get(0).setIncludedMethods(include);
		}

		test.setName(args[0].substring(args[0].indexOf(":") + 1));
		test.setXmlClasses(pXmlClases);

		suites.add(suite);

		testNG.setXmlSuites(suites);
		testNG.run();
	}

}
