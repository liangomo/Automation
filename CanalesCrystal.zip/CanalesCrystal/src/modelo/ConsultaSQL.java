package modelo;

import java.sql.ResultSet;
import java.sql.Statement;

public class ConsultaSQL {

	public ResultSet Consulta(String Sentencia) {
		
		ConexionSQL conexion = new ConexionSQL();

		try {
			conexion.conectar();

			Statement st = conexion.getConexion().createStatement();
			ResultSet rs = st.executeQuery(Sentencia);

			conexion.desconectar();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}