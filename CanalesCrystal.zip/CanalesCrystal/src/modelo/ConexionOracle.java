package modelo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;



public class ConexionOracle {

	Connection conn;

	public void conectar(String Cadena, String Usuario, String Password){
		try {
			DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());

			conn = DriverManager.getConnection(Cadena, Usuario, Password);
			Statement stmt = conn.createStatement();
			@SuppressWarnings("unused")
			ResultSet rset = stmt.executeQuery("select BANNER from SYS.V_$VERSION");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null , e.getMessage(), "Mensaje", JOptionPane.ERROR_MESSAGE);
//			e.printStackTrace();
		}
	}

	public ResultSet consultar(String sql) {

		ResultSet resultado = null;

		try 
		{
			Statement sentencia;
			sentencia = getConn().createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			resultado = sentencia.executeQuery(sql);
		} 
		catch (SQLException e) 
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
			return null;
		}
		return resultado;
	}

	/** desconecta de la base de datos */

	public void desconectar()throws Exception{

		if(!this.getConn().isClosed())
			this.setConn(null);
	}

	public Connection getConn() {
		return conn;
	}

	public void setConn(Connection conn) {
		this.conn = conn;
	}

}