package ejecutable;

import vista.AppSingleton;

public class Ejecutable {
	public static void main(String[] args) {	
		new AppSingleton();
	}
}