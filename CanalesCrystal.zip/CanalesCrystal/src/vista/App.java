package vista;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;

import com.leyer.JKTable;

import modelo.ConexionOracle;
import modelo.ConsultaSQL;

public class App extends JFrame {
	private static final long serialVersionUID = 1L;
	private JTextField txtUsuario;
	private JPasswordField txtPassword;
	@SuppressWarnings("rawtypes")
	private JComboBox comboBoxServidor;
	JLabel lblFormasCrystal;	
	JLabel labelFormasForms;
	ConsultaSQL consulta = new ConsultaSQL();
	JKTable table;
	DefaultTableModel modelo = new DefaultTableModel();

	String query = "SELECT DISTINCT '1', s.description as CODIGO, s.name as NOMBRE, T.NAME AS NOMBRETIMBRE, attrs_pruebas.pk_blob.leer_char(t.detail,21,251) as JOB "
			+ "FROM attrs_pruebas.faamxref x, attrs_pruebas.faamxref x2,attrs_pruebas.fformtim t, attrs_pruebas.fsrv s, attrs_pruebas.fxmlaux AU "
			+ "WHERE x.sock_def_type = 54 and x.plug_def_type = 61 AND "
			+ "x2.sock_def_type = 97 and x2.plug_def_type = x.sock_def_type AND "
			+ "x2.plug_def_id = x.sock_def_id AND "
			+ "t.identitycol = x.plug_def_id AND "
			+ "s.identitycol = x2.sock_def_id AND "
			+ "AU.TABLE_DID = 60 AND "
			+ "AU.REG_ID = T.IDENTITYCOL AND "
			+ "AU.AUX_TYPE = 14 AND "
			+ "AU.AUX_VAL = 1 "
			+ "UNION "
			+ "SELECT distinct '2','Consultas', '', T.NAME AS NOMBRETIMBRE, attrs_pruebas.pk_blob.leer_char(t.detail,21,251) as JOB "
			+ "FROM attrs_pruebas.faamxref x, attrs_pruebas.fformtim t, attrs_pruebas.fxmlaux AU "
			+ "WHERE x.sock_def_type != 54 and x.plug_def_type = 61 AND "
			+ "t.identitycol = x.plug_def_id AND "
			+ "AU.TABLE_DID = 60 AND "
			+ "AU.REG_ID = T.IDENTITYCOL AND "
			+ "AU.AUX_TYPE = 14 AND " + "AU.AUX_VAL = 1";

	@SuppressWarnings("rawtypes")
	public App() {
		setResizable(false);
		try{
			setTitle("Verificaci\u00F3n Formas");
			setVisible(true);
			setBounds(100, 100, 502, 636);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			JPanel panelUsuario = new JPanel();

			JLabel lblServidor = new JLabel("SERVIDOR : ");
			lblServidor.setFont(new Font("Segoe UI Emoji", Font.BOLD, 11));

			JLabel lblUsuario = new JLabel("USUARIO : ");
			lblUsuario.setFont(new Font("Segoe UI Emoji", Font.BOLD, 11));

			JLabel lblPassword = new JLabel("PASSWORD : ");
			lblPassword.setFont(new Font("Segoe UI Emoji", Font.BOLD, 11));

			comboBoxServidor = new JComboBox();
			cargarCombo();
			comboBoxServidor.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent arg0) {
					txtUsuario.setText("");
					txtPassword.setText("");
					table.clearTable();
					lblFormasCrystal.setVisible(false);
					labelFormasForms.setVisible(false);
				}
			});

			txtUsuario = new JTextField();
			txtUsuario.setColumns(10);

			txtPassword = new JPasswordField();
			txtPassword.setColumns(10);

			JButton btnEjecutar = new JButton("EJECUTAR");
			btnEjecutar.setFont(new Font("Trebuchet MS", Font.BOLD, 11));
			btnEjecutar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					new Thread(new Runnable() {

						@SuppressWarnings("deprecation")
						@Override
						public void run() {

							ResultSet rs;

							try {

								rs = consulta.Consulta("SELECT * FROM ServidoresCAN WHERE Servidor = '" + comboBoxServidor.getSelectedItem() + "'");

								rs.next();

								String cadena = "jdbc:oracle:thin:@" + rs.getString("DireccionIP") + ":" + rs.getString("Puerto") + ":canales";
								String usuario = txtUsuario.getText();
								String password = txtPassword.getText();

								ConexionOracle conexionOracle = new ConexionOracle();
								conexionOracle.conectar(cadena, usuario, password);
								Statement stOracle = conexionOracle.getConn().createStatement();

								ResultSet rsOracle = stOracle.executeQuery(query);

								int c = 0;
								int f = 0;

								while (rsOracle.next()) 
								{
									String JOB = rsOracle.getString("JOB").trim();

									Object[] fila = new Object[5];

									fila[0] = rsOracle.getString("CODIGO");
									fila[1] = rsOracle.getString("NOMBRE");
									fila[2] = rsOracle.getString("NOMBRETIMBRE");
									fila[3] = JOB;

									if (JOB.length() > 0) 
									{
										fila[4] = "FORMS PARTNER";
										f++;
									}
									else
									{
										fila[4] = "CRYSTAL REPORTS";
										c++;
									}

									table.addRow(fila);
								}

								lblFormasCrystal.setText("Total Formas Crystal Reports : " + c);
								labelFormasForms.setText("Total Formas Forms Partner: " + f);

								lblFormasCrystal.setVisible(true);
								labelFormasForms.setVisible(true);

								conexionOracle.desconectar();
							} catch (Exception e) { }
						}
					}).start();
				}
			});

			GroupLayout gl_panelUsuario = new GroupLayout(panelUsuario);
			gl_panelUsuario.setHorizontalGroup(
					gl_panelUsuario.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_panelUsuario.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_panelUsuario.createParallelGroup(Alignment.TRAILING)
									.addComponent(btnEjecutar)
									.addGroup(gl_panelUsuario.createSequentialGroup()
											.addGroup(gl_panelUsuario.createParallelGroup(Alignment.LEADING, false)
													.addComponent(lblPassword, GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
													.addComponent(lblUsuario, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
													.addComponent(lblServidor))
											.addPreferredGap(ComponentPlacement.UNRELATED)
											.addGroup(gl_panelUsuario.createParallelGroup(Alignment.LEADING, false)
													.addComponent(txtPassword)
													.addComponent(txtUsuario)
													.addComponent(comboBoxServidor, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE))))
							.addContainerGap(59, Short.MAX_VALUE))
					);

			gl_panelUsuario.setVerticalGroup(
					gl_panelUsuario.createParallelGroup(Alignment.LEADING)
					.addGroup(Alignment.TRAILING, gl_panelUsuario.createSequentialGroup()
							.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addGroup(gl_panelUsuario.createParallelGroup(Alignment.BASELINE)
									.addComponent(lblServidor)
									.addComponent(comboBoxServidor, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_panelUsuario.createParallelGroup(Alignment.BASELINE)
									.addComponent(lblUsuario)
									.addComponent(txtUsuario, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_panelUsuario.createParallelGroup(Alignment.BASELINE)
									.addComponent(lblPassword)
									.addComponent(txtPassword, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnEjecutar)
							.addContainerGap())
					);

			panelUsuario.setLayout(gl_panelUsuario);

			JPanel panelResultado = new JPanel();

			table = new JKTable();
			table.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
			table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
			table.setCellSelectionEnabled(true);
			table.setSurrendersFocusOnKeystroke(true);
			table.addColumn("CODIGO");
			table.addColumn("NOMBRE");
			table.addColumn("NOMBRE TIMBRE");
			table.addColumn("JOB");
			table.addColumn("FORMA");
			panelResultado.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));

			JScrollPane jScrollPane = new JScrollPane(table);
			panelResultado.add(jScrollPane);

			lblFormasCrystal = new JLabel();
			lblFormasCrystal.setFont(new Font("Century Gothic", Font.BOLD, 11));
			lblFormasCrystal.setText("PRU");
			labelFormasForms = new JLabel();
			labelFormasForms.setFont(new Font("Century Gothic", Font.BOLD, 11));
			labelFormasForms.setText("PRU");

			lblFormasCrystal.setVisible(false);
			labelFormasForms.setVisible(false);

			GroupLayout groupLayout = new GroupLayout(getContentPane());
			groupLayout.setHorizontalGroup(
					groupLayout.createParallelGroup(Alignment.LEADING)
					.addGroup(groupLayout.createSequentialGroup()
							.addGap(10)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
									.addComponent(panelResultado, GroupLayout.PREFERRED_SIZE, 474, GroupLayout.PREFERRED_SIZE)
									.addGroup(groupLayout.createSequentialGroup()
											.addComponent(panelUsuario, GroupLayout.PREFERRED_SIZE, 263, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.UNRELATED)
											.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
													.addComponent(lblFormasCrystal, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
													.addComponent(labelFormasForms, GroupLayout.PREFERRED_SIZE, 188, GroupLayout.PREFERRED_SIZE))))
							.addGap(119))
					);

			groupLayout.setVerticalGroup(
					groupLayout.createParallelGroup(Alignment.LEADING)
					.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
									.addGroup(groupLayout.createSequentialGroup()
											.addGap(4)
											.addComponent(panelUsuario, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
									.addGroup(groupLayout.createSequentialGroup()
											.addGap(33)
											.addComponent(lblFormasCrystal, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
											.addGap(18)
											.addComponent(labelFormasForms, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)))
							.addGap(11)
							.addComponent(panelResultado, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())
					);

			getContentPane().setLayout(groupLayout);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void cargarCombo()
	{
		ResultSet rs;
		try {

			rs = consulta.Consulta("SELECT Servidor FROM ServidoresCAN");

			while(rs.next())
			{
				comboBoxServidor.addItem(rs.getString("Servidor"));
			}

			rs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}