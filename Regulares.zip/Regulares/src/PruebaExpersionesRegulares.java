import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PruebaExpersionesRegulares{

	static DBconnection conex;

//	public PruebaExpersionesRegulares() {
//
//		conex = new DBconnection();
//		String retorno = "";
//		String Mensaje = "Advertencia: Descripcion : |MESSAGES FOR CR CTA-RD 000095 IM80 IM1448 I: ACTIVIDAD MONETARIA HOY MESSAGES FOR COMISI GEN 0149059115 IM80 SI8425 I: CUENTA CON ORDEN DE NO PAGO IM80 IM1448 I: ACTIVIDAD MONETARIA HOY MESSAGES FOR RD DEBITO TSLG09 TSRB TS0264 : CUENTA:00149059115 TIPO:CTE OTL1 TS0000 I: NORMAL";
//
//		boolean msnExiste = false;
//
//		ResultSet mensajesDB = conex.Consulta("SELECT Mensaje, Resultado FROM MensajesCAN where Resultado <> 'MENSAJE_SIN_VALIDACION'");
//
//		try {
//			while(mensajesDB.next())
//			{
//				retorno = mensajesDB.getString(1);
//				if(EvaluarExpresion(retorno, Mensaje))
//				{	
//					System.out.println("Encontrado");
//					msnExiste = true;
//					break;
//				}
//			}
//			if(msnExiste==false){
//				System.out.println("MENSAJE_SIN_VALIDACION");
//				conex.ejecutar("INSERT INTO MensajesCAN VALUES('" + Mensaje + "', 'MENSAJE_SIN_VALIDACION')");
//			}	
//		} catch (SQLException e) {
//			// TODO Bloque catch generado autom�ticamente
//			e.printStackTrace();
//		}
//	}

	public static boolean EvaluarExpresion(String Patron, String Mensaje)
	{
		Pattern p = Pattern.compile(Patron);
		Matcher matcher = p.matcher(Mensaje);

		return matcher.matches();
	}

	public static void main(String[] args) {
		conex = new DBconnection();
		String retorno = "";
		String Mensaje = "Advertencia: Descripcion : |MESSAGES FOR COMISI GEN 0149059115 IM80 SI8425 I: CUENTA CON ORDEN DE NO PAGO IM80 IM1448 I: ACTIVIDAD MONETARIA HOY MESSAGES FOR RD DEBITO TSLG09 TSRB TS0264 : CUENTA:00149059115 TIPO:CTE OTL1 TS0000 I: NORMAL";

		boolean msnExiste = false;

		ResultSet mensajesDB = conex.Consulta("SELECT Mensaje, Resultado FROM MensajesCAN where Resultado <> 'MENSAJE_SIN_VALIDACION'");

		try {
			while(mensajesDB.next())
			{
				retorno = mensajesDB.getString(1);
				if(EvaluarExpresion(retorno, Mensaje))
				{	
					System.out.println("Encontrado");
					msnExiste = true;
					break;
				}
			}
			if(msnExiste==false){
				System.out.println("MENSAJE_SIN_VALIDACION");
				conex.ejecutar("INSERT INTO MensajesCAN VALUES('" + Mensaje + "', 'MENSAJE_SIN_VALIDACION')");
			}	
		} catch (SQLException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
	}
}

