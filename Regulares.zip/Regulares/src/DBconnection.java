import java.sql.*;
import javax.swing.*;

public class DBconnection {
	
	private java.sql.Connection Conec = null;
	private final String url = "jdbc:sqlserver://";
	private final String serverName = "AQUILESSQL25\\REPOSITORY";
	private final String databaseName = "BD_AUT_ReservaRobot";
	private final String userName = "usr_AUTResRobot";
	private final String password = "ReservaRobot_5015";
//	private final String selectMethod = "cursor";

    Statement St;
    /*Creando la instania de conexion */
    
    
    
    public DBconnection() {

    	try{
    		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    		Conec =DriverManager.getConnection(url + serverName + ";databaseName=" + databaseName + ";", userName ,  password);

    		if (Conec != null){
    			
    			System.out.println("Successfully connected");
    			
    		}
    	}
    	catch ( SQLException excepcionSql)
    	{
    		JOptionPane.showMessageDialog( null, excepcionSql.getMessage(),"Error en base de datos", JOptionPane.ERROR_MESSAGE );
    	}

    	catch ( ClassNotFoundException claseNoEncontrada ){
    		JOptionPane.showMessageDialog( null, claseNoEncontrada.getMessage(),"No se encontr� el controlador", JOptionPane.ERROR_MESSAGE );
    	}
    }
    
    //Metodo de ejecucion de insert,update,delete a la base de datos
    public String ejecutar(String sql) {

    	String error="";
    	try {
    		St=Conec.createStatement();
    		St.executeQuery(sql);
    		
    	}
    	catch(Exception ex){
    		error = ex.getMessage();
    		
    	}
    	return(error);
    }

    //Metodo para las consultas a la base de datos
    public ResultSet Consulta(String sql) {
      ResultSet res = null;
      try
      {
          Statement s = Conec.createStatement();
          res = s.executeQuery(sql);
      } catch (Exception e)
      {
          e.printStackTrace();
          System.out.println("error en consulta");
      }
      return res;
    }
}
