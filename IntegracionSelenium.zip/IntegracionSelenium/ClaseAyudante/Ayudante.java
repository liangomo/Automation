package ClaseAyudante;

import inicio.Inicio;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.*;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import sqlConexion.ConsultaSQL;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import com.rational.test.ft.object.interfaces.TestObject;
import com.rational.test.ft.script.RationalTestScript;

/**
 * Description : Super class for script helper
 * 
 * @author dzaraza
 * @since agosto 10, 2016
 */
public abstract class Ayudante extends RationalTestScript {
	private java.sql.Connection Conec = null;
	Statement St;
	int numeroKill = 0;
	Connection conexionBD;
	Statement stamt;
	String[] Datos;
	String Conn = "//AQUILESSQL25\\REPOSITORY";
	protected int i;
	String cont;
	Paragraph parrafo;
	Document documento;

	/**
	 * METODOS PARA MANEJO DE LOGS (ARCHIVOS .TXT, .PDF y ARCHIVOS .JPG)
	 * */

	// M�todo para la generacion o apertura del archivo
	public FileWriter generacionArchivo(String rutaArchivo, String nombreArchivo) {
		FileWriter fichero = null;
		try {
			fichero = new FileWriter(rutaArchivo + nombreArchivo, true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fichero;
	}

	// M�todo para ingresar cadenas de texto al archivo
	public void InsertarArchivo(FileWriter fichero, String sentencia) {

		PrintWriter pw = null;
		pw = new PrintWriter(fichero);
		pw.println(sentencia);
	}

	// M�todo para ingresar cadenas de texto al archivo sin salto de l�nea
	public void ContinuarRegistro(FileWriter fichero, String sentencia) {

		PrintWriter pw = null;
		pw = new PrintWriter(fichero);
		pw.print(sentencia);
	}

	// M�todo para cerrar y cuardar el archivo
	public void cerrarArchivo(FileWriter fichero) {
		try {
			fichero.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * METODOS PARA ADMINISTRACION
	 * */

	// M�todo para cerrar navegadores
	public void cerrarNavegadores() {
		TestObject[] browsers = find(atChild(".class", "Html.HtmlBrowser"));
		if (browsers.length == 0) {
			System.out.println("Found no Html.HtmlBrowser");
			return;
		}
		for (TestObject browser : browsers) {
			((com.rational.test.ft.object.interfaces.BrowserTestObject) browser)
			.close();
		}
		// Anular el registro de los objetos de prueba.
		unregister(browsers);
	}

	// M�todo para finalizar proceso IE
	public void MatarProceso() {
		System.out
		.println("------------------------------Kill------------------------");
		try {
			String line;
			Process p = Runtime.getRuntime().exec(
					System.getenv("windir") + "\\system32\\" + "tasklist.exe");
			BufferedReader input = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			while ((line = input.readLine()) != null) {
				if (line.contains("iexplor")) {
					Runtime.getRuntime().exec(
							"taskkill /im " + line.substring(0, 12));
					numeroKill++;
					if (numeroKill < 3) {
						MatarProceso();
						sleep(2);
					} else
						Runtime.getRuntime().exec(
								"taskkill /im " + line.substring(0, 12) + "/F");
				}
			}
			input.close();
		} catch (Exception err) {
			err.printStackTrace();
		}
	}

	/**
	 * 
	 * METODOS PARA EL MANEJO DE HORA, MINUTOS Y SEGUNDOS (FECHAS)
	 * 
	 * */

	// M�todo para obtener FECHA en formato, A�o/Mes/Dia
	public String ObtenerFecha() {
		String fecha;	
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("yyyyMMdd");
		fecha = formato.format(calendar.getTime());
		return fecha;
	}

	// M�todo para obtener mes de certificaci�n
	public String ObtenerMes() {
		Calendar miCalendario = Calendar.getInstance();
		int mes; 
		String m;

		if (ObtenerDia() > 20)
			if(miCalendario.get(Calendar.MONTH) == 11)
				mes = 1;
			else
				mes = miCalendario.get(Calendar.MONTH)+2;
		else
			mes = miCalendario.get(Calendar.MONTH) + 1;

		if(mes < 10)
			m = "0" + mes;
		else
			m = "" + mes;

		return m;
	}

	// M�todo para obteber el d�a actual
	public Integer ObtenerDia() {
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		return diaHoy;
	}

	// M�todo para obtener HORA en formato Hora:Minutos:Segundos
	public String ObtenerHora() {
		String hora;	
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("HHmmss");
		calendar.get(Calendar.MONTH);
		hora = formato.format(calendar.getTime());
		return hora;
	}

	/* Consumo OTP */
	public String Cliente(String TipoId, String NroID) {
		String otp = null;

		try {
			Inicio in = new Inicio();
			ConsultaSQL con = new ConsultaSQL();

			String[] TipoDoc = { "C�dula de Ciudadan�a",
					"C�dula de Extranjer�a", "Tarjeta de identidad",
					"Pasaporte", "Registro civil", "Nit persona natural",
					"Nit de extranjer�a", "Nit persona jur�dica" };

			int tipo = 0;

			for (int i = 0; i < TipoDoc.length; i++) {
				if (TipoDoc[i].equals(TipoId)) {
					tipo = i + 1;
					i = TipoDoc.length;
				}
			}

			ResultSet rs = con
					.Consulta("SELECT * FROM SemillasDigipass WHERE TipoID = '"
							+ tipo + "' AND NroId = '" + NroID + "'");

			while (rs.next()) {
				System.out.println(rs.getString("TipoID") + " - "
						+ rs.getString("NroID") + " - "
						+ rs.getString("EstadoSemilla"));
				otp = in.generacion("" + tipo, rs.getString("NroID"),
						rs.getString("EstadoSemilla"));
				System.out.println("OTP: " + otp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return otp;
	}

	/**
	 * METODOS PARA MANEJO DE BASE DE DATOS
	 * */

	public void ConnectionDB() {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Conec = DriverManager
					.getConnection(
							"jdbc:sqlserver://AQUILESSQL25\\REPOSITORY;databaseName=BD_AUT_PSE;",
							"usr_AUTPSE", "usr_AUTPSE#2016");

			if (Conec != null) {

//				System.out.println("Successfully connected");

			}
		} catch (SQLException excepcionSql) {
			JOptionPane.showMessageDialog(null, excepcionSql.getMessage(),
					"Error en base de datos", JOptionPane.ERROR_MESSAGE);
		}

		catch (ClassNotFoundException claseNoEncontrada) {
			JOptionPane.showMessageDialog(null, claseNoEncontrada.getMessage(),
					"No se encontr� el controlador", JOptionPane.ERROR_MESSAGE);
		}
	}

	// Metodo de ejecucion de insert,update,delete a la base de datos
	public String[] querySQL(String query) {
		// CONTROLA QUE LA CONSULTA NO ESTE NULA O VACIA
		try {
			ConnectionDB();

			stamt = Conec.createStatement();
			// SE ENVIA CODIGO DE INSERCION SQL
			stamt.executeUpdate(query);
			// SE CIERRA CONEXION
			Conec.close();
		}
		// IMPRIME CON CONSOLA EL SI EXISTIO ALGUN ERROR EN LA CONEXION
		catch (Exception e) {
			e.printStackTrace();
		}
		// NO RETORNA NADA
		return Datos;
	}



	// Metodo para las consultas a la base de datos
	public ResultSet Consulta(String sql) {
		ConnectionDB();
		ResultSet res = null;
		try {
			Statement s = Conec.createStatement();
			res = s.executeQuery(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	// FUNCION PARA GUARDAR LAS IMAGENES CAPTURADAS
	public void guardarImagen(RenderedImage image, String Nombre, Document doc) {
		String ruta = "C:\\tmp\\PSE\\Imagenes\\" + Nombre + ".jpg";

		// DECLARA Y CREA EL ARCHIVO CON LA IMAGEN RECIBIDA
		File file = new File(ruta);
		try {
			ImageIO.write(image, "jpg", file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// cutImage(ruta);
		addImage(ruta, doc);
	}

	// METODO QUE CREA UN PDF PARA PRESENTAR LOS RESULTADOS DE LOS SCRIPT
	public Document createPdf(String nombre) throws DocumentException,
	MalformedURLException, IOException {
		// SE CREA UN DOCUMENTO CON TAMA�O CARTA Y SE ESCOJE LA RUTA Y NOMBRE
		// DEL ARCHIVO
		Document documento = new Document(PageSize.LETTER, 80, 80, 75, 75);
		String archivo = "C:\\tmp\\PSE\\" + nombre + ".pdf";
		@SuppressWarnings("unused")
		PdfWriter writer = PdfWriter.getInstance(documento,
				new FileOutputStream(archivo, true));

		// SE LE AGREGA EL TITULO Y AUTOR AL DOCUMENTO
		documento.addTitle("Registro Pruebas de Regresi�n PSE - "
				+ nombre);
		documento
		.addAuthor("Equipo de Automatizaci�n - Direcci�n de Desarrollo Tecnologico");
		documento.open();

		// SE CREA UN PARAGRAFO QUE LLEBA EL ENCABEZADO DEL DOCUMENTO TITULO
		// LETRA GRANDE
		Paragraph titulo = new Paragraph();
		titulo.setAlignment(Paragraph.ALIGN_CENTER);
		titulo.setFont(FontFactory.getFont("Sans", 15, Font.BOLD));
		titulo.add("REGISTRO PRUEBAS DE REGRESION TRANSACCION - " + nombre
				+ "\n\n");

		// SE AGREGA EL PARAGRAFO AL DOCUMENTO
		documento.add(titulo);

		return documento;
	}

	/* M�todo para a�adir texto al PDF */
	public void addTexto(String Cadena, Document doc) {
		try {
			Paragraph parrafo = new Paragraph();
			parrafo.setFont(FontFactory.getFont("Sans", 12, Font.NORMAL));
			parrafo.setAlignment(Paragraph.ALIGN_LEFT);
			parrafo.add(Cadena);
			doc.add(parrafo);
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	/* M�todo para agregar una im�gen a un PDF */
	public void addImage(String ruta, Document doc) {
		Image imagen;
		try {
			imagen = Image.getInstance(ruta);
			imagen.setAlignment(Image.ALIGN_CENTER);
			imagen.setUseVariableBorders(true);
			imagen.scalePercent(40);
			doc.add(imagen);
		} catch (BadElementException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	/* M�todo para cerrar PDF */
	public void closePDF(Document doc) {
		doc.close();
	}

	// METODO QUE RECORTA LA IMAGEN A UNAS MEDIDAS PREESTABLESIDAS
	public void cutImage(String ruta) throws IOException {
		File file = new File(ruta);
		BufferedImage bi = ImageIO.read(file);

		if (bi.getWidth() > 937) {
			bi = bi.getSubimage(0, 0, 937, bi.getHeight());
			ImageIO.write(bi, "jpg", file);
		}
	}
}