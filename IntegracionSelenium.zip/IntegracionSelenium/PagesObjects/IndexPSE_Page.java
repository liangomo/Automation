package PagesObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class IndexPSE_Page {
	WebDriver driver;
	By selectTipoIdentificacion = By.id("IdentificationType");
	By txtIdentificacion = By.id("Identification");
	By btnNatural = By.id("button_btnNatural");
	By btnEmpresas = By.id("button_btnEmpresas");
	
	public IndexPSE_Page(WebDriver driver)
	{
		this.driver = driver;
	}

	public void setSelectTipoIdentificacion(String tipoIdentificacion)
	{
		this.driver.findElement(selectTipoIdentificacion).sendKeys(tipoIdentificacion);
	}

	public void setTxtIdentificacion(String identificacion)
	{
		this.driver.findElement(txtIdentificacion).sendKeys(identificacion);
	}

	public void setBtnNatural()
	{
		this.driver.findElement(btnNatural).click();
	}

	public void setBtnEmpresas()
	{
		this.driver.findElement(btnEmpresas).click();
	}
}