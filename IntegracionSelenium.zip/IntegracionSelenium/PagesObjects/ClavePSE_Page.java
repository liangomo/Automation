package PagesObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ClavePSE_Page {
	WebDriver driver;
	static By txtClave = By.id("Password");
	static By btnSalir = By.id("button2");
	static By btnAceptar = By.id("button_validate");
	
	public ClavePSE_Page(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void setTxtClave(String clave) {
		driver.findElement(txtClave).sendKeys(clave);
	}
	
	public void clickSalir() {
		driver.findElement(btnSalir).click();
	}
	
	public void clickAceptar() {
		driver.findElement(btnAceptar).click();
	}
}