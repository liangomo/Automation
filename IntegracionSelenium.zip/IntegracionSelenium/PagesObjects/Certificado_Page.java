package PagesObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Certificado_Page {
	WebDriver driver;
	By linkIrASitio = By.id("overridelink");
	
	public Certificado_Page(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void setLinkIrASitio()
    {
		this.driver.findElement(linkIrASitio).click();
    }
}