package PagesObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Comercio_Page {
	WebDriver driver;
	By txtCus =  By.id("TrazabilityCode");
	By txtCodigoEntidad = By.id("FinancialInstitutionCode");
	By txtCodigoComercio = By.id("EntityCode");
	By txtNombreComercio = By.id("EntityName");
	By txtValorCompra = By.id("TransactionValue");
	By txtValorIVA = By.id("VatValue");
	By txtNumeroFactura = By.id("TicketId");
	By txtCodigoServicio = By.id("ServiceCode");
	By txtTipoUsuario = By.id("UserType");
	By txtCicloTransaccion = By.id("TransactionCycle");
	By txtDescripcionCompra = By.id("PaymentDescription");
	By txtReferencia1 = By.id("ReferenceNumber1");
	By txtReferencia2 = By.id("ReferenceNumber2");
	By txtReferencia3 = By.id("ReferenceNumber3");
	By btnPagar = By.id("bPagar");
	
	public Comercio_Page(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void setTxtCus(String cus)
	{
		driver.findElement(txtCus).sendKeys(cus);
	}

	public void setTxtCodigoEntidad(String codigoEnt)
	{
		driver.findElement(txtCodigoEntidad).sendKeys(codigoEnt);
	}

	public void setTxtCodigoComercio(String codigoComercio)
	{
		driver.findElement(txtCodigoComercio).sendKeys(codigoComercio);
	}

	public void setTxtNombreComercio(String nombreComercio)
	{
		driver.findElement(txtNombreComercio).sendKeys(nombreComercio);
	}

	public void setTxtValorCompra(String valorCompra)
	{
		driver.findElement(txtValorCompra).sendKeys(valorCompra);
	}

	public void setTxtValorIVA(String valorIva)
	{
		driver.findElement(txtValorIVA).sendKeys(valorIva);
	}

	public void setTxtNumeroFactura(String numeroFactura)
	{
		driver.findElement(txtNumeroFactura).sendKeys(numeroFactura);
	}

	public void setTxtCodigoServicio(String codigoServicio)
	{
		driver.findElement(txtCodigoServicio).sendKeys(codigoServicio);
	}

	public void setTxtTipoUsuario(String tipoUsuario)
	{
		driver.findElement(txtTipoUsuario).sendKeys(tipoUsuario);
	}

	public void setTxtCicloTransaccion(String cicloTransaccion)
	{
		driver.findElement(txtCicloTransaccion).sendKeys(cicloTransaccion);
	}

	public void setTxtDescripcionCompra(String descripcionCompra)
	{
		driver.findElement(txtDescripcionCompra).sendKeys(descripcionCompra);
	}

	public void setTxtReferencia1(String referencia1)
	{
		driver.findElement(txtReferencia1).sendKeys(referencia1);
	}

	public void setTxtReferencia2(String referencia2)
	{
		driver.findElement(txtReferencia2).sendKeys(referencia2);
	}

	public void setTxtReferencia3(String referencia3)
	{
		driver.findElement(txtReferencia3).sendKeys(referencia3);
	}

	public void clickBtnPagar()
	{
		driver.findElement(btnPagar).click();
	}
}