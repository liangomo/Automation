import java.awt.AWTException;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import resources.LanzadorHelper;
import PagesObjects.Certificado_Page;
import PagesObjects.ClavePSE_Page;
import PagesObjects.Comercio_Page;
import PagesObjects.IndexPSE_Page;

public class Lanzador extends LanzadorHelper
{
	private static WebDriver driver = null;
	private static String baseUrl;
	private static String[] drivers = { "webdriver.gecko.driver", "webdriver.chrome.driver", "webdriver.ie.driver" };
	private static String[] rutas = { "D:\\driverSelenium\\geckodriver.exe", "D:\\driverSelenium\\chromedriver.exe", "D:\\driverSelenium\\IEDriverServer.exe" };

	public void testMain(Object[] args) throws SQLException, IOException, AWTException
	{
		try
		{
			for (int i = 1; i < 2; i++)
			{
				if (i > 1)
					driver.close();

				if (i == 0)
				{
					ProfilesIni profile = new ProfilesIni();
					FirefoxProfile myprofile = profile.getProfile("Selenium");
					System.setProperty(drivers[i], rutas[i]);
					driver = new FirefoxDriver(myprofile);
				}
				else if (i == 1)
				{
					DesiredCapabilities capabilities = DesiredCapabilities.chrome();
					capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
					System.setProperty(drivers[i], rutas[i]);
					driver = new ChromeDriver(capabilities);
				}
				else if (i == 2)
				{
					DesiredCapabilities capabilities = new DesiredCapabilities();
					capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
					capabilities.setCapability("requireWindowFocus", true);
					System.setProperty(drivers[i], rutas[i]);
					driver = new InternetExplorerDriver(capabilities);
				}

				baseUrl = "https://test2.bancodebogota.com.co/";
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.get(baseUrl);
				driver.manage().window().maximize();

				By txtUsuario 	 = By.name("RqrdAN000Usuario");
				By txtContrasena = By.name("RqrdAN000Clave");
				By btnIngresar   = By.xpath("/html/body/form/table[1]/tbody/tr[5]/td/input[1]");
				By imgLeido      = By.cssSelector("area[alt=\"LEIDO\"]");
				By msgError      = By.xpath("/html/body/form/div/font/b");
				By close = By.xpath("//*[@id=\"splash-97385-close-button\"]");
				By productos = By.xpath("/html/body/form/table[4]/tbody");
//				/html/body/form/table[4]/tbody

				driver.findElement(imgLeido).click();
				driver.findElement(txtUsuario).sendKeys("11098638337");
				driver.findElement(txtContrasena).sendKeys("zxcasdqwe123");
				driver.findElement(btnIngresar).click();

				Thread.sleep(10000);
				
				
				

//				driver.findElement(close).click();
				
				System.out.println("Antes del IF");
//				
//				if(driver.findElement(productos).isDisplayed())
//				{
//					System.out.println("Entro IF");
//					
//					WebElement tableElement = driver.findElement(productos);

					List<WebElement> row = driver.findElements(By.cssSelector("body > form > table:nth-child(15) > tbody > tr:nth-child(2) > td:nth-child(1) > font > b > a"));

					System.out.println(row.size());
					
//					int column = 0;
//
//					for(int j = 0; j < row.size(); j++)
//					{
//						
////						List<WebElement> col = tableElement.findElements(By.tagName("td"));
////
////						for(WebElement columna : col )
////						{
//							System.out.println(row.get(j).getText());
////							column++;
////						}
//					}
//				}
//				else
//					System.out.println("NO");
//
//



				//				ResultSet rs = Consulta("SELECT * FROM PSE.FormularioPSE");
				//
				//				rs.next();
				//
				//				if (i == 2)
				//					Certificado_Page.link(driver).click();
				//
				//				Comercio_Page.cus(driver).sendKeys(rs.getString("CUS"));
				//				Comercio_Page.codigoEntidad(driver).sendKeys(rs.getString("CodEntidadFinanciera"));
				//				Comercio_Page.codigoComercio(driver).sendKeys(rs.getString("IDComercio"));
				//				Comercio_Page.nombreComercio(driver).sendKeys(rs.getString("NombreComercio"));
				//				Comercio_Page.valorCompra(driver).sendKeys(rs.getString("ValorCompra"));
				//				Comercio_Page.valorIVA(driver).sendKeys(rs.getString("ValorIva"));
				//				Comercio_Page.numeroFactura(driver).sendKeys(rs.getString("NumFactura"));
				//				Comercio_Page.codigoServicio(driver).sendKeys(rs.getString("CodServicio"));
				//				Comercio_Page.tipoUsuario(driver).sendKeys(rs.getString("TipoUsuario"));
				//				Comercio_Page.cicloTransaccion(driver).sendKeys(rs.getString("CicloTrx"));
				//
				//				Comercio_Page.pagarButton(driver).click();
				//
				//				Thread.sleep(10000);
				//
				//				Set<String> allHandles = driver.getWindowHandles();
				//
				//				allHandles.remove(allHandles.iterator().next());
				//
				//				String lastHandle = allHandles.iterator().next();
				//				lastHandle = allHandles.iterator().next();
				//
				//				driver.switchTo().window(lastHandle);
				//				driver.manage().window().maximize();
				//
				//				if (i == 2)
				//					Certificado_Page.link(driver).click();
				//
				//				IndexPSE_Page.tipoIdendificacion(driver).sendKeys("C�dula Ciudadan�a");
				//				IndexPSE_Page.identificacion(driver).sendKeys("19905234");
				//				IndexPSE_Page.btnNatural(driver).click();
				//
				//				Thread.sleep(5000);
				//
				//				ClavePSE_Page.clave(driver).sendKeys("7890");
				//				ClavePSE_Page.btnContinuar(driver).click();

				//				Thread.sleep(20000);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			driver.close();
		}
	}
}