﻿
using Microsoft.Exchange.WebServices.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mail;
using System.Security.Principal;
using System.Web.Hosting;

namespace Evol.CeroPapel.ServiceTask.EnvioCorreo
{
    /// <summary>
    /// Clase Correo que se utiliza para el envió de correo.
    /// </summary>
    public class Correo
    {
        //[ThreadStatic]
        //private VW_CERO_PAPEL_PARAMETROBll ceroPapelParametroBll;
        ///// <summary>
        ///// Bll de conexion para obtener parametros del sistema.
        ///// </summary>
        //protected VW_CERO_PAPEL_PARAMETROBll CeroPapelParametroBll
        //{
        //    get
        //    {
        //        if (this.ceroPapelParametroBll == null)
        //        {
        //            this.ceroPapelParametroBll = new VW_CERO_PAPEL_PARAMETROBll();
        //        }
        //        return this.ceroPapelParametroBll;
        //    }
        //}

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private List<string> lListaAdjuntos = new List<string>();

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sAsunto = string.Empty;

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sCC = string.Empty;

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sCCOculta = string.Empty;

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sContrasenha = string.Empty;

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sDestinatario = string.Empty;

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sDomain = string.Empty;

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private SmtpClient serverSmtp = new SmtpClient();

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sMensajeCuerpo = string.Empty;

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sPuerto = string.Empty;

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sRemitente = string.Empty;

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sServidor = string.Empty;

        /// <summary>
        /// Atributo de la clase.
        /// </summary>
        private string sUsuario = string.Empty;

        /// <summary>
        /// Initializes a new instance of the BEnviarCorreo class.
        /// </summary>

        public Correo()
        {
            //var Asunto = "AVISO DESPLIEGUE NCA";
            var Asunto = "DESPLIEGUE NCA EXITOSO";


            //var asunto = this.CeroPapelParametroBll.ObtenerParametroPoAlias("Mail_Asunto");
            //if (asunto == null)
            //{
            //    throw new ApplicationException("El valor de asunto no puede ser un valor nulo o vacio");
            //}

            this.sAsunto = Asunto;

            //var remitente = this.CeroPapelParametroBll.ObtenerParametroPoAlias("Mail_Remitente");
            //if (remitente == null)
            //{
            //    throw new ApplicationException("El valor de remitente no puede ser un valor nulo o vacio.");
            //}
            this.sRemitente = "GerPruebasEvolTecno@telefonica.com.co";
            //var servidor = this.CeroPapelParametroBll.ObtenerParametroPoAlias("Mail_ServerExchange");
            //if (servidor == null)
            //{
            //    throw new ApplicationException("El valor de servidor no puede ser un valor nulo o vacio.");
            //}
            this.sServidor = "http://10.80.19.111/ews/Exchange.asmx";
            //var puerto = this.CeroPapelParametroBll.ObtenerParametroPoAlias("Mail_Puerto");
            //if (puerto == null)
            //{
            //    throw new ApplicationException("el valor de puerto no puede ser un valor nulo o vacio.");
            //}
            this.sPuerto = "80";
            //var contrasenha = this.CeroPapelParametroBll.ObtenerParametroPoAlias("Mail_Contrasenia");
            //if (contrasenha == null)
            //{
            //    throw new ApplicationException("El valor de contraseña no puede ser un valor nulo o vacio.");
            //}
            this.sContrasenha = "Movistar*23";
            //var usuario = this.CeroPapelParametroBll.ObtenerParametroPoAlias("Mail_Usuario");
            //if (usuario == null)
            //{
            //    throw new ApplicationException("El valor de usuario no puede ser un valor nulo o vacio.");
            //}
            this.sUsuario = "GerPruebasEvolTecno";
            //var dominio = this.CeroPapelParametroBll.ObtenerParametroPoAlias("Mail_Dominio");
            //if (dominio == null)
            //{
            //    throw new ApplicationException("El valor de dominio no puede ser un valor nulo o vacio.");
            //}
            this.sDomain = "nh";
        }

        /// <summary>
        /// Gets or sets the name of the CC.
        /// </summary>
        public string CC
        {
            get { return this.sCC; }
            set { this.sCC = value; }
        }

        /// <summary>
        /// Gets or sets the name of the CCOculta.
        /// </summary>
        public string CCOculta
        {
            get { return this.sCCOculta; }
            set { this.sCCOculta = value; }
        }

        /// <summary>
        /// Gets or sets the name of the Destinatario.
        /// </summary>
        public string Destinatario
        {
            get { return this.sDestinatario; }
            set { this.sDestinatario = value; }
        }

        /// <summary>
        /// Gets or sets the name of the ListaAdjuntos.
        /// </summary>
        public List<string> ListaAdjuntos
        {
            get { return this.lListaAdjuntos; }
            set { this.lListaAdjuntos = value; }
        }

        /// <summary>
        /// Gets or sets the name of the MensajeCuerpo.
        /// </summary>
        public string MensajeCuerpo
        {
            get { return this.sMensajeCuerpo; }
            set { this.sMensajeCuerpo = value; }
        }

        public string SAsunto
        {
            get { return this.sAsunto; }
            set { this.sAsunto = value; }
        }

        public bool EnviarCorreo(string mensajeCuerpo, string destinatario, string copia, string adjunto, ref string sError)
        {
            if (string.IsNullOrWhiteSpace(mensajeCuerpo))
            {
                throw new ArgumentNullException("mensajeCuerpo", "el contenido del mensaje no puede ser un valor nulo o vacio.");
            }

            if (string.IsNullOrWhiteSpace(destinatario))
            {
                throw new ArgumentNullException("destinatario", "El destinatario del mensaje no puede ser un valor nulo o vacio.");
            }

            //this.sRemitente = destinatario;
            this.sDestinatario = destinatario;
            this.sCC = copia;
            this.sMensajeCuerpo = mensajeCuerpo;

            string paso = "1";
            try
            {
                System.Net.ServicePointManager.ServerCertificateValidationCallback = CertificateValidationCallBack;
                ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
                paso = "2";
                service.Credentials = new Microsoft.Exchange.WebServices.Data.WebCredentials(this.sUsuario, this.sContrasenha, this.sDomain);
                ////Se Obtienen las Credenciales de red del Contexto de seguridad Actual.
                paso = "3";
                WindowsIdentity user = WindowsIdentity.GetCurrent();
                service.Url = new Uri(this.sServidor);
                service.Timeout = 940000;
                EmailMessage objMensaje = new EmailMessage(service);
                paso = "4";
                objMensaje.From = this.sRemitente;
                objMensaje.Subject = this.sAsunto;
                int posicionsigno = 0;
                int lencadena = this.sDestinatario.Length;
                paso = "5";
                if (!string.IsNullOrEmpty(this.sDestinatario))
                {
                    this.sDestinatario = this.sDestinatario + ";";

                    while (this.sDestinatario.IndexOf(";") != -1)
                    {
                        posicionsigno = this.sDestinatario.IndexOf(";");
                        lencadena = this.sDestinatario.Length;

                        if (posicionsigno == -1)
                        {
                            objMensaje.ToRecipients.Add(this.sDestinatario.Trim());
                        }
                        else
                        {
                            objMensaje.ToRecipients.Add(this.sDestinatario.Substring(0, posicionsigno).Trim());
                        }

                        this.sDestinatario = this.sDestinatario.Substring(posicionsigno + 1, lencadena - posicionsigno - 1);
                    }

                    posicionsigno = 0;
                    lencadena = this.sCC.Length;
                }
                paso = "6";
                if (!string.IsNullOrEmpty(this.sCC))
                {
                    this.sCC = this.sCC + ";";

                    while (this.sCC.IndexOf(";") != -1)
                    {
                        posicionsigno = this.sCC.IndexOf(";");
                        lencadena = this.sCC.Length;

                        if (posicionsigno == -1)
                        {
                            objMensaje.CcRecipients.Add(this.sCC.Trim());
                        }
                        else
                        {
                            objMensaje.CcRecipients.Add(this.sCC.Substring(0, posicionsigno).Trim());
                        }

                        this.sCC = this.sCC.Substring(posicionsigno + 1, lencadena - posicionsigno - 1);
                    }

                    posicionsigno = 0;
                    lencadena = this.sCC.Length;
                }
                paso = "7";
                if (!string.IsNullOrEmpty(this.sCCOculta))
                {
                    this.sCCOculta = this.sCCOculta + ";";

                    while (this.sCCOculta.IndexOf(";") != -1)
                    {
                        posicionsigno = this.sCCOculta.IndexOf(";");
                        lencadena = this.sCCOculta.Length;

                        if (posicionsigno == -1)
                        {
                            objMensaje.BccRecipients.Add(this.sCCOculta.Trim());
                        }
                        else
                        {
                            objMensaje.BccRecipients.Add(this.sCCOculta.Substring(0, posicionsigno).Trim());
                        }

                        this.sCCOculta = this.sCCOculta.Substring(posicionsigno + 1, lencadena - posicionsigno - 1);
                    }
                }
                paso = "8";

                //if (PDF.Length > 0)
                if(adjunto.Equals("SI"))
                {
                    string nombreArchivo = "";
                    //objMensaje.Attachments.AddFileAttachment(adjunto);
                    for (int i=0;i<2;i++)
                    {
                        if (i == 0) { nombreArchivo = "sv-doc91.pdf"; }
                        else { nombreArchivo = "70pr- -propuesta fo.pptx"; }

                        var PDF = System.IO.File.ReadAllBytes(@"\\koral01\ReportesET\nca\" + nombreArchivo);
                        Stream stream = new MemoryStream(PDF);
                        objMensaje.Attachments.AddFileAttachment(nombreArchivo, stream);

                    }

                    
                }

                paso = "9";
                //objMensaje.Body = "<html><head><body> <p> Hola mundo     </p>  </body></head></html>";
                string mensaje = File.ReadAllText(HostingEnvironment.MapPath("~/App_Data/dailyMail.html"));
                mensaje = mensaje.Replace("#Saludo", "Buenos días.");
                //mensaje = mensaje.Replace("#Saludo", "Buenas tardes.");






                //NUEVO DESPLIEGUE
                //mensaje = mensaje.Replace("#Mensaje", @"Está previsto el despliegue de una nueva versión de NCA en el siguiente periodo: <br/><br/>  
                //    <strong>22-02-2018 desde las 18:00 horas hasta las 08:00 horas del 23-02-2018</strong>   
                //    <br/><br/> La aplicación no estará disponible durante este periodo de tiempo.<br/>");





                //DESPLIEGUE EXITOSO
                mensaje = mensaje.Replace("#Mensaje", @"Ya se encuentra disponible la aplicación <br/><br/>  
                    Se ha habilitado el ambiente de producción de la herramienta NCA en su versión número 10.<br/>");




                mensaje = mensaje.Replace("#Despedida","Cordialmente;");
                mensaje = mensaje.Replace("#Remitente", "Equipo de Soporte y Evolución Tecnológica.");
                mensaje = mensaje.Replace("#year",DateTime.Now.Year.ToString());
                
                                
                objMensaje.Body = mensaje;
                
                var imagenMovistar = objMensaje.Attachments.AddFileAttachment("LogoMovistar.jpg", File.OpenRead(HostingEnvironment.MapPath("~/Images/LogoMovistar.jpg")));
                imagenMovistar.ContentId = "LogoMovistar";

                var imagenNca = objMensaje.Attachments.AddFileAttachment("LogoNCA.jpg", File.OpenRead(HostingEnvironment.MapPath("~/Images/LogoNCA.jpg")));
                imagenNca.ContentId = "LogoNCA";


                objMensaje.Body.BodyType = BodyType.HTML;
                objMensaje.Send();
            }
            catch (Exception ex)
            {
                sError = "Paso --" + paso + "--" + ex.Message + "---Inner---" + ex.InnerException;
                return false;
            }

            return true;
        }

        /// <summary>
        /// Función para enviar correo.
        /// </summary>
        /// <param name="sError">Parametró en el cual se insertara el mensaje de error si este llega a ocurrir.</param>
        /// <returns>Se retorna un valor boleano indicando si la operacion fue exitosa.</re turns>
        public bool EnviarCorreo(byte[] PDF, ref string sError)
        {
            string paso = "1";
            try
            {
                System.Net.ServicePointManager.ServerCertificateValidationCallback = CertificateValidationCallBack;
                ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
                paso = "2";
                service.Credentials = new Microsoft.Exchange.WebServices.Data.WebCredentials(this.sUsuario, this.sContrasenha, this.sDomain);
                ////Se Obtienen las Credenciales de red del Contexto de seguridad Actual.
                paso = "3";
                WindowsIdentity user = WindowsIdentity.GetCurrent();
                service.Url = new Uri(this.sServidor);
                service.Timeout = 940000;
                EmailMessage objMensaje = new EmailMessage(service);
                paso = "4";
                objMensaje.From = this.sRemitente;
                objMensaje.Subject = this.sAsunto;
                int posicionsigno = 0;
                int lencadena = this.sDestinatario.Length;
                paso = "5";
                if (!string.IsNullOrEmpty(this.sDestinatario))
                {
                    this.sDestinatario = this.sDestinatario + ";";

                    while (this.sDestinatario.IndexOf(";") != -1)
                    {
                        posicionsigno = this.sDestinatario.IndexOf(";");
                        lencadena = this.sDestinatario.Length;

                        if (posicionsigno == -1)
                        {
                            objMensaje.ToRecipients.Add(this.sDestinatario.Trim());
                        }
                        else
                        {
                            objMensaje.ToRecipients.Add(this.sDestinatario.Substring(0, posicionsigno).Trim());
                        }

                        this.sDestinatario = this.sDestinatario.Substring(posicionsigno + 1, lencadena - posicionsigno - 1);
                    }

                    posicionsigno = 0;
                    lencadena = this.sCC.Length;
                }
                paso = "6";
                if (!string.IsNullOrEmpty(this.sCC))
                {
                    this.sCC = this.sCC + ";";

                    while (this.sCC.IndexOf(";") != -1)
                    {
                        posicionsigno = this.sCC.IndexOf(";");
                        lencadena = this.sCC.Length;

                        if (posicionsigno == -1)
                        {
                            objMensaje.CcRecipients.Add(this.sCC.Trim());
                        }
                        else
                        {
                            objMensaje.CcRecipients.Add(this.sCC.Substring(0, posicionsigno).Trim());
                        }

                        this.sCC = this.sCC.Substring(posicionsigno + 1, lencadena - posicionsigno - 1);
                    }

                    posicionsigno = 0;
                    lencadena = this.sCC.Length;
                }
                paso = "7";
                if (!string.IsNullOrEmpty(this.sCCOculta))
                {
                    this.sCCOculta = this.sCCOculta + ";";

                    while (this.sCCOculta.IndexOf(";") != -1)
                    {
                        posicionsigno = this.sCCOculta.IndexOf(";");
                        lencadena = this.sCCOculta.Length;

                        if (posicionsigno == -1)
                        {
                            objMensaje.BccRecipients.Add(this.sCCOculta.Trim());
                        }
                        else
                        {
                            objMensaje.BccRecipients.Add(this.sCCOculta.Substring(0, posicionsigno).Trim());
                        }

                        this.sCCOculta = this.sCCOculta.Substring(posicionsigno + 1, lencadena - posicionsigno - 1);
                    }
                }
                paso = "8";

                if (PDF.Length > 0)
                {
                    //objMensaje.Attachments.AddFileAttachment(adjunto);
                    Stream stream = new MemoryStream(PDF);
                    objMensaje.Attachments.AddFileAttachment("CopiaContrato.pdf", stream);
                }

                //paso = "9";
                
                //objMensaje.Body = this.sMensajeCuerpo;
                //objMensaje.Send();

                paso = "9";
                objMensaje.Body = "<html><head><body style=\"background-color:black\">  </body></head></html>";
                objMensaje.Body.BodyType = BodyType.HTML;
                objMensaje.Send();



            }
            catch (Exception ex)
            {
                sError = "Paso --" + paso + "--" + ex.Message + "---Inner---" + ex.InnerException;
                return false;
            }

            return true;
        }

        private static bool CertificateValidationCallBack(
                                                    object sender,
                                                    System.Security.Cryptography.X509Certificates.X509Certificate certificate,
                                                    System.Security.Cryptography.X509Certificates.X509Chain chain,
                                                    System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            // If the certificate is a valid, signed certificate, return true.
            if (sslPolicyErrors == System.Net.Security.SslPolicyErrors.None)
            {
                return true;
            }

            // If there are errors in the certificate chain, look at each error to determine the cause.
            if ((sslPolicyErrors & System.Net.Security.SslPolicyErrors.RemoteCertificateChainErrors) != 0)
            {
                if (chain != null && chain.ChainStatus != null)
                {
                    foreach (System.Security.Cryptography.X509Certificates.X509ChainStatus status in chain.ChainStatus)
                    {
                        if ((certificate.Subject == certificate.Issuer) &&
                           (status.Status == System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.UntrustedRoot))
                        {
                            // Self-signed certificates with an untrusted root are valid.
                            continue;
                        }
                        else
                        {
                            if (status.Status != System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NoError)
                            {
                                // If there are any other errors in the certificate chain, the certificate is invalid,
                                // so the method returns false.
                                continue;
                                // return false;
                            }
                        }
                    }
                }

                // When processing reaches this line, the only errors in the certificate chain are
                // untrusted root errors for self-signed certificates. These certificates are valid
                // for default Exchange server installations, so return true.
                return true;
            }
            else
            {
                // In all other cases, return false.
                return false;
            }
        }
    }
}
