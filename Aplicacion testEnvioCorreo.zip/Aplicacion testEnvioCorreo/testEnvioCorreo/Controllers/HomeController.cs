﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Evol.CeroPapel.ServiceTask.EnvioCorreo;
using System.IO;

namespace testEnvioCorreo.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            
            
            Correo EnvCorreo = new Correo();


            string sError = "";
            // var documento = System.IO.File.ReadAllBytes(@"C:\Users\amlatorreag\Documents\NCA_Paso.txt");



            // pruebas
            //if (EnvCorreo.EnviarCorreo("<b>Envio de correo</b>", "andrey.rodriguez@telefonica.com",
            //    "andrey.rodriguez@telefonica.com", "NO", ref sError))
            //{
            //    ;
            //}
            //else
            //{
            //    ;
            //}


            if (EnvCorreo.EnviarCorreo("<b>Envio de correo</b>",
                @"laura.gutierrezm@telefonica.com;laura.pieschacon@telefonica.com;diana.lozano@telefonica.com;lina.davila@telefonica.com;
                PAULA.HERNANDEZ@telefonica.com;claudia.lopezm@telefonica.com;diana.rojas@telefonica.com;jeison.murillo@telefonica.com;
                anamaria.tarazona@telefonica.com;norma.lemos@telefonica.com;tatiana.sandoval@telefonica.com;
                sandra.fandino@telefonica.com;CLAUDIA.RODRIGUEZ@TELEFONICA.COM;ANA.SANZ@TELEFONICA.COM;Juliana.Lamus@telefonica.com;
                andres.sanchez@telefonica.com;marcela.rubiano@telefonica.com"
                , @"yuver.hurtado@telefonica.com;agustin.contreras@telefonica.com;carlos.castano@telefonica.com;
                mariac.cordoba@telefonica.com;claudia.zuluaga@telefonica.com;andrey.rodriguez@telefonica.com"
                , "NO", ref sError))
            {
                ;
            }
            else
            {
                ;
            }

            return View();
        }

        

    }
}
