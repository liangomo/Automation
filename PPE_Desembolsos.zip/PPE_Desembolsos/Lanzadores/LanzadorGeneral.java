package Lanzadores;

import java.awt.image.RenderedImage;
import java.sql.ResultSet;
import java.sql.SQLException;
import resources.Lanzadores.LanzadorGeneralHelper;
import com.lowagie.text.Document;

public class LanzadorGeneral extends LanzadorGeneralHelper
{
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	String fecha = ObtenerFecha();
	String hora = ObtenerHora();
	Document doc;
	RenderedImage imagen;
	boolean band = false;


	public void testMain(Object[] args) throws SQLException
	{
		/** Creaci�n Carpetas */
		callScript("SuperClaseAyudante.CreacionCarpetasLogs");


		/** Conexi�n a la Base de Datos */

		/* Consulta en la tabla login para traer el usuario y contrase�a del Login */
		ResultSet cp = Consulta("SELECT * FROM PPE.CasosPrueba, PPE.Login WHERE LineaCredito LIKE '" + args[0] + "%'"
				+ "AND Ejecutado = 'NO EJECUTADO'");

		Object[]lineas = new Object[88];


		/** Definici�n de argumentos que ser�n llamados en los callscript 
		 *  */

		try 
		{
			while (cp.next()) 
			{
				/* Asociaci�n de variables */
				lineas[0] = cp.getString("ID_CasosPrueba");			lineas[1] = cp.getString("Ejecutado"); 
				lineas[2] = cp.getString("CasoPrueba"); 			lineas[3] = cp.getString("LineaCredito"); 
				lineas[4] = cp.getString("TipoIdentificacion");		lineas[5] = cp.getString("NoIdentificacion");
				lineas[6] = cp.getString("ValorCredito");			lineas[7] = cp.getString("CambiarFechaPago");
				lineas[8] = cp.getString("FechaPrimerPago");		lineas[9] = cp.getString("DiaPago");
				lineas[10] = cp.getString("Oficina");				lineas[11] = cp.getString("OficialVenta");
				lineas[12] = cp.getString("Vendedor");				lineas[13] = cp.getString("PlazoCredito");
				lineas[14] = cp.getString("CobroGastos");			lineas[15] = cp.getString("Seguro");
				lineas[16] = cp.getString("CodigoCIIU");			lineas[17] = cp.getString("TipoTasa");
				lineas[18] = cp.getString("SignoTasa");				lineas[19] = cp.getString("ValorTasa");
				lineas[20] = cp.getString("TipoPlan");				lineas[21] = cp.getString("PlanesEspeciales");
				lineas[22] = cp.getString("PeriodoPagoIntereses");	lineas[23] = cp.getString("ValorCuotaCapital");
				lineas[24] = cp.getString("PeriodoPagoCapital");	lineas[25] = cp.getString("PeriodoDeGracia");
				lineas[26] = cp.getString("Garantia");				lineas[27] = cp.getString("FAG");
				lineas[28] = cp.getString("Pagare");				lineas[29] = cp.getString("NoGarantia");
				lineas[30] = cp.getString("FNG");					lineas[31] = cp.getString("ProductoComisionFNG");
				lineas[32] = cp.getString("TipoCobroComisionFNG");	lineas[33] = cp.getString("CoberturaFNG");
				lineas[34] = cp.getString("GarantiaMobiliaria");	lineas[35] = cp.getString("TipoGarantiaMobiliaria");
				lineas[36] = cp.getString("GarantiaAbiertaCerrada");lineas[37] = cp.getString("NumeroGarantia");
				lineas[38] = cp.getString("CantidadFolios");		lineas[39] = cp.getString("TipoDesembolso");
				lineas[40] = cp.getString("TipoProductoDebito");	lineas[41] = cp.getString("NumerosCuentaDebito");
				lineas[42] = cp.getString("DestinoDesembolso");		lineas[43] = cp.getString("NumeroCuentaDesembolso");
				lineas[44] = cp.getString("CobroGMF");				lineas[45] = cp.getString("TipoID_ChequeGerencia");
				lineas[46] = cp.getString("NoIdentificacionCheque");lineas[47] = cp.getString("TipoIDCuentaContable");
				lineas[48] = cp.getString("IDCuentaContable");		lineas[49] = cp.getString("Convenio");
				lineas[50] = cp.getString("NoCreditoAbonar");		lineas[51] = cp.getString("PresentaCertificacion");
				lineas[52] = cp.getString("FormaPagoGMF");			lineas[53] = cp.getString("FuenteGMF");
				lineas[54] = cp.getString("NoCuentaGMF");			lineas[55] = cp.getString("CuentaConGMF");
				lineas[56] = cp.getString("CuentaSEBRA");			lineas[57] = cp.getString("TipoAbonoSEBRA");
				lineas[58] = cp.getString("Portafolio");			lineas[59] = cp.getString("TipoIDDestinatarioSEBRA");
				lineas[60] = cp.getString("NoIDDestinatarioSEBRA");	lineas[61] = cp.getString("TipoProductoDestino");
				lineas[62] = cp.getString("NoProductoDestino");		lineas[63] = cp.getString("TitularDestino");
				lineas[64] = cp.getString("ObservacionesGMF");		lineas[65] = cp.getString("PlanSeguro");
				lineas[66] = cp.getString("SeguroVehiculo");		lineas[67] = cp.getString("CodigoAseguradora");
				lineas[68] = cp.getString("ValorPrimaMensual");		lineas[69] = cp.getString("Placa");
				lineas[70] = cp.getString("TipoVehiculo");			lineas[71] = cp.getString("CanalVenta");
				lineas[72] = cp.getString("SeguroDeVida");			lineas[73] = cp.getString("SegProtegidoPlus");
				lineas[74] = cp.getString("MargenRedescuento");		lineas[75] = cp.getString("NumeroAprobacion");
				lineas[76] = cp.getString("SubdestinoEconomico");	lineas[77] = cp.getString("LineaFomento");
				lineas[78] = cp.getString("ValorTasaFomento");		lineas[79] = cp.getString("SignoTasaFomento");
				lineas[80] = cp.getString("Usuario");				lineas[81] = cp.getString("Contrase�a");
				lineas[82] = cp.getString("Dominio");				lineas[84] = cp.getString("ResultadoEsperado");
				lineas[85] = fecha;									lineas[86] = hora;


				/** CREACI�N INFORME DETALLADO */
				if (!band) {
					lineas[87] = "Detallado_PPEDesembolsos_" + ObtenerMes() +  "_" + fecha + "_" + hora;
					doc = createPdf((String)lineas[87], getSubString((String)lineas[3],0,4));
					lineas[83] = doc;
					addTitulo("LINEA DE CR�DITO: " + lineas[3] + "\n\n", doc);
					band = true;
				}


				/** SECUENCIA PARA LA CAPTURA Y EL DESEMBOLSO */

				/* Secuencia para realizar la captura del desembolso */
				if (getSubString((String) lineas[3],0,4).equals("B300")) { 	

					callScript("Scripts.A_Login",  lineas);						//LOGIN CAPTURADOR
					callScript("Scripts.L_ReservaNumerosCreditos",lineas);		//INGRESO A RESERVAR NUMEROS DE CREDITOS
					callScript("Scripts.C_DatosPrincipalesDelCredito",lineas);	//INGRESO DE DATOS PRINCIPALES DEL CREDITO
					callScript("Scripts.D_InformacionAdicional",lineas);		//INFORMACION ADICIONAL
					callScript("Scripts.E_CondicionesAprobacion",lineas);		//CONDICIONES DE APROBACION
					callScript("Scripts.F_Garantias",lineas);					//GARANTIAS
					callScript("Scripts.G_DatosDesembolso",lineas);				//DATOS DEL DESEMBOLSO
					callScript("Scripts.N_InformacionCarteraFomento",lineas);	//INFORMACION CARTERA FOMENTO

				} else {

					callScript("Scripts.A_Login", lineas); sleep(2);						//LOGIN CAPTURADOR
					callScript("Scripts.B_CapturarCreditoSinReserva"); sleep(7);         	//INGRESO A CAPTURAR CR�DITO SIN RESERVA 
					callScript("Scripts.C_DatosPrincipalesDelCredito",lineas);	sleep(5); 	//INGRESO DATOS PRINCIPALES DEL CREDITO
					callScript("Scripts.D_InformacionAdicional",lineas); sleep(5);			//INFORMACION ADICIONAL
					callScript("Scripts.E_CondicionesAprobacion",lineas); sleep(5);			//CONDICIONES DE APROBACION
					callScript("Scripts.F_Garantias",lineas); sleep(5);						//GARANTIAS
					callScript("Scripts.G_DatosDesembolso",lineas);sleep(2);				//DATOS DEL DESEMBOLSO
				}


				/* Secuencia para realizar el desembolso */
				callScript("Scripts.I_LinkDesembolso");									//LINK DESEMBOOLSO
				callScript("Scripts.J_BuscarCredito", lineas);sleep(2);					//BUSCAR CR�DITO
				callScript("Scripts.K_DesembolsarCredito", lineas);sleep(7);			//DESEMBOLSAR
				callScript("Scripts.O_CamposVerificarDesembolso", lineas);sleep(2);		//VERIFICAR DATOS
				callScript("Scripts.P_ValidacionResultadoEsperado", lineas);sleep(2); 	//VALIDAR RESULTADO ESPERADO


				/* Actualizar el caso de prueba a EJECUTADO al finalizar la transacci�n */
				querySQL("UPDATE PPE.CasosPrueba SET Ejecutado = 'EJECUTADO' WHERE CasoPrueba = '" + lineas[2] + "'");
			}
		} catch(Exception e)
		{
			e.printStackTrace();

			/* Insertar texto al PDF */
			addTexto(lineas[2] + " - PROBLEMA ENCONTRADO" + "\n", doc);

			/* Capturar im�gen y guardar en PDF */
			imagen = document_bancoDeBogot�PortalDe(ANY, LOADED).getScreenSnapshot();
			guardarImagen(imagen, lineas[2] + " - Incompleto", doc);

			/* Insertar resultado en Base de Datos para el informe Resumen */
			querySQL("INSERT INTO PPE.ConsolidadosEjecucion VALUES('" + "PPE Desembolsos" + "','" + ObtenerA�o() + "','" + ObtenerMes() + "','" 
					+ fecha +  "','" + hora +  "','" + lineas[2] +  "','" + lineas[3] +  "','" + lineas[84] +  "','"  
					+ "INCOMPLETO" +  "','" + "INCOMPLETO" + "','" 
					+ "C:\\tmp\\PPE_Desembolsos\\" + getSubString((String)lineas[3],0,4) +  "\\" + lineas[87] + ".pdf" + "')");

		} finally {
			if (doc != null)
				closePDF(doc);
		}
	}
}