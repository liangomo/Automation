package GarantiaMobiliaria;
import resources.GarantiaMobiliaria.button_AceptarHelper;
/**
 * Description   : Functional Test Script
 * @author javedan
 */
public class button_Aceptar extends button_AceptarHelper
{
	/**
	 * Script Name   : <b>button_aceptar</b>
	 * Generated     : <b>18/05/2016 14:46:08</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2016/05/18
	 * @author javedan
	 */
	public void testMain(Object[] args) 
	{
		button_aceptaRbutton().find(atDescendant(".class","Html.IFRAME",".id","iframe iFrame1"));
		//button_aceptaRbutton().waitForExistence();
		button_aceptaRbutton().click();sleep(2);
	}
}