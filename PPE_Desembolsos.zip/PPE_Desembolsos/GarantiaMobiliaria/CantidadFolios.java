package GarantiaMobiliaria;
import resources.GarantiaMobiliaria.CantidadFoliosHelper;
/**
 * Description   : Functional Test Script
 * @author javedan
 */
public class CantidadFolios extends CantidadFoliosHelper
{
	/**
	 * Script Name   : <b>CantidadFolios</b>
	 * Generated     : <b>17/05/2016 16:48:31</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2016/05/17
	 * @author javedan
	 */
	public void testMain(Object[] args) 
	
    {
		if (args[1].equals("B300_NoDebeEntrar"))	
        {
			
		text_digiteLaCantidadDeFoliosM2().waitForExistence();
		text_digiteLaCantidadDeFoliosM2().setText((String) args[0]);
			
	   }
	
	else 
	
	{

		text_digiteLaCantidadDeFoliosM().waitForExistence();
		text_digiteLaCantidadDeFoliosM().setText((String) args[0]);	
	
	}
	
    }
}

