package GarantiaMobiliaria;
import resources.GarantiaMobiliaria.NoGarantiaHelper;
/**
 * Description   : Functional Test Script
 * @author javedan
 */
public class NoGarantia extends NoGarantiaHelper
{

	public void testMain(Object[] args) 
	 
	{
		if (args[1].equals("B300_NoDebeEntrar"))	
	{
		text_digiteElN�meroDeGarant�aM2().waitForExistence();
		text_digiteElN�meroDeGarant�aM2().setText((String) args[0]);
			
	}
	
	else 
	
	{

		text_digiteElN�meroDeGarant�aM().waitForExistence();
		text_digiteElN�meroDeGarant�aM().setText((String) args[0]);
	
	}
	
	
	}
}