package GarantiaMobiliaria;
import resources.GarantiaMobiliaria.Garantia_MobiliariaHelper;
/**
 * Description   : Functional Test Script
 * @author javedan
 */
public class Garantia_Mobiliaria extends Garantia_MobiliariaHelper
{
	/**
	 * Script Name   : <b>Garantia_Mobiliaria</b>
	 * Generated     : <b>17/05/2016 14:25:01</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2016/05/17
	 * @author javedan
	 */
	public void testMain(Object[] args) 
	{
	if (args[1].equals("B300"))	
	{
		list_seleccioneUnAGarant�aMobi().waitForExistence();
		list_seleccioneUnAGarant�aMobi().select((String) args[0]);
			
	}
	
	else 
	
	{

		list_seleccioneUnAGarant�aMobi2().waitForExistence();
		list_seleccioneUnAGarant�aMobi2().select((String) args[0]);
	
	}
   }

}