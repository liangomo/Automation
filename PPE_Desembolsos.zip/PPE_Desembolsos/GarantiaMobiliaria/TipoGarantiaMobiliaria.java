package GarantiaMobiliaria;
import resources.GarantiaMobiliaria.TipoGarantiaMobiliariaHelper;
/**
 * Description   : Functional Test Script
 * @author javedan
 */
public class TipoGarantiaMobiliaria extends TipoGarantiaMobiliariaHelper
{
/**
	 * Script Name   : <b>TipoGarantiaMobiliaria</b>
	 * Generated     : <b>17/05/2016 16:25:42</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2016/05/17
	 * @author javedan
	 */
	public void testMain(Object[] args)
	{	
	if (args[1].equals("B300_NoDebeEntrar"))	
	{
		list_seleccioneUnATipoGarant�a().waitForExistence();
		list_seleccioneUnATipoGarant�a().select((String) args[0]);
			
	}
	
	else 
	
	{

		list_seleccioneUnATipoGarant�a2().waitForExistence();
		list_seleccioneUnATipoGarant�a2().select((String) args[0]);
	
	}
}
}
