package GarantiaMobiliaria;
import resources.GarantiaMobiliaria.GarantiaAbiertaCerradaHelper;
/**
 * Description   : Functional Test Script
 * @author javedan
 */
public class GarantiaAbiertaCerrada extends GarantiaAbiertaCerradaHelper
{
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			list_seleccioneUnAGarant�aAbie2().waitForExistence();
			list_seleccioneUnAGarant�aAbie2().select((String) args[0]);
		} else {
			list_seleccioneUnAGarant�aAbie().waitForExistence();
			list_seleccioneUnAGarant�aAbie().select((String) args[0]);
		}
	}
}