package Desembolso;
import resources.Desembolso.button_okHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class button_ok extends button_okHelper
{
	/**
	 * Script Name   : <b>button_ok</b>
	 * Generated     : <b>09/01/2015 17:05:19</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		button_oKbutton().waitForExistence();
		button_oKbutton().click();
	}
}