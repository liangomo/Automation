package Desembolso;
import resources.Desembolso.button_GuardarHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class button_Guardar extends button_GuardarHelper
{
	/**
	 * Script Name   : <b>button_Guardar</b>
	 * Generated     : <b>05/01/2016 09:19:51</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2016/01/05
	 * @author lgomez11
	 */
	public void testMain(Object[] args) 
	{
		button_guardarbutton().waitForExistence();
		button_guardarbutton().click();
	}
}

