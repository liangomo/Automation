package Desembolso;
import resources.Desembolso.K_button_AceptarHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class K_button_Aceptar extends K_button_AceptarHelper
{
	
	public void testMain(Object[] args) 
	{
		button_aceptarbutton().waitForExistence();
		button_aceptarbutton().click();
	}
}