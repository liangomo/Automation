package Desembolso;
import resources.Desembolso.list_DesembolsoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_Desembolso extends list_DesembolsoHelper
{

	public void testMain(Object[] args) 
	{
		list_selecioneUnaOpcion().waitForExistence();
		list_selecioneUnaOpcion().select("Desembolsar");
	}
}