package DatosDesembolso;
import resources.DatosDesembolso.list_TipoProductoDebitoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_TipoProductoDebito extends list_TipoProductoDebitoHelper
{

	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			list_seleccioneUnATipoProducto2().waitForExistence();
			list_seleccioneUnATipoProducto2().select((String) args[0]);
			
		} else {

			list_seleccioneUnATipoProducto().waitForExistence();
			list_seleccioneUnATipoProducto().select((String) args[0]);
		}
	}
}