package DatosDesembolso;
import resources.DatosDesembolso.list_CuentaDebitoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_CuentaDebito extends list_CuentaDebitoHelper
{
	public void testMain(Object[] args) 
	{

		if (args[1].equals("B300_NoDebeEntrar")) {

			list_seleccioneUnaCuenta2().waitForExistence();
			list_seleccioneUnaCuenta2().select((String) args[0]);

		} else {

			list_seleccioneUnaCuenta().waitForExistence();
			list_seleccioneUnaCuenta().select((String) args[0]);	
		}
	}
}