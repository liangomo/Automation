package DatosDesembolso;
import resources.DatosDesembolso.list_FuenteCargoGMFHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_FuenteCargoGMF extends list_FuenteCargoGMFHelper
{
	/**
	 * Script Name   : <b>list_FuentedeCargoGMF</b>
	 * Generated     : <b>27/01/2015 10:07:03</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/27
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnAFuenteDeCarg().waitForExistence();
		list_seleccioneUnAFuenteDeCarg().select((String) args[0]);
	}
}

