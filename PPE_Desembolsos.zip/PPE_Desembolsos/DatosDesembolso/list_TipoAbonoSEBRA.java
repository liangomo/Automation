package DatosDesembolso;
import resources.DatosDesembolso.list_TipoAbonoSEBRAHelper;
/**
 * Description   : Functional Test Script
 * @author dpena6
 */
public class list_TipoAbonoSEBRA extends list_TipoAbonoSEBRAHelper
{
	/**
	 * Script Name   : <b>list_TipoAbonoSEBRA</b>
	 * Generated     : <b>02/02/2015 13:51:36</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/02
	 * @author dpena6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnATipoAbonoTra2().waitForExistence();
		list_seleccioneUnATipoAbonoTra2().select((String) args[0]);
	}
}

