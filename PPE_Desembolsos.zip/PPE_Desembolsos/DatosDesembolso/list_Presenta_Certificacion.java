package DatosDesembolso;
import resources.DatosDesembolso.list_Presenta_CertificacionHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_Presenta_Certificacion extends list_Presenta_CertificacionHelper
{
	/**
	 * Script Name   : <b>list_Presenta_Certificacion</b>
	 * Generated     : <b>27/01/2015 09:48:11</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/27
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnAPresentaCert().waitForExistence();
		list_seleccioneUnAPresentaCert().select((String) args[0]);
	}
}

