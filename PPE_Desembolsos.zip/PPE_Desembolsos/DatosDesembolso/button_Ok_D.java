package DatosDesembolso;
import resources.DatosDesembolso.button_Ok_DHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class button_Ok_D extends button_Ok_DHelper
{

	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			button_oKbutton2().waitForExistence();
			button_oKbutton2().click();
		} else {
			button_oKbutton().waitForExistence();
			button_oKbutton().click();
		}
	}
}