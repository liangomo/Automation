package DatosDesembolso;
import resources.DatosDesembolso.list_CobroGMFHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_CobroGMF extends list_CobroGMFHelper
{
	/**
	 * Script Name   : <b>list_CobroGMF</b>
	 * Generated     : <b>13/01/2015 10:20:51</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/13
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			list_seleccioneUnACobroGMF2().waitForExistence();
			list_seleccioneUnACobroGMF2().select((String) args[0]);
			
		} else {

			list_seleccioneUnACobroGMF().waitForExistence();
			list_seleccioneUnACobroGMF().select((String) args[0]);
			
		}

	}
}