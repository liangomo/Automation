package DatosDesembolso;
import resources.DatosDesembolso.text_NoProductoDestinoHelper;
/**
 * Description   : Functional Test Script
 * @author dpena6
 */
public class text_NoProductoDestino extends text_NoProductoDestinoHelper
{
	/**
	 * Script Name   : <b>text_NoProductoDestino</b>
	 * Generated     : <b>02/02/2015 14:26:27</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/02
	 * @author dpena6
	 */
	public void testMain(Object[] args) 
	{
		text_ingreseElValorDelRedescue2().waitForExistence();
		text_ingreseElValorDelRedescue2().setText((String) args[0]);
	}
}

