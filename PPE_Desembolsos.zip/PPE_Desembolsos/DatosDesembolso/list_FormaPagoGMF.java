package DatosDesembolso;
import resources.DatosDesembolso.list_FormaPagoGMFHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_FormaPagoGMF extends list_FormaPagoGMFHelper
{
	/**
	 * Script Name   : <b>list_FormaPagoGMF</b>
	 * Generated     : <b>27/01/2015 10:05:20</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/27
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnAFormaPagoGMF().waitForExistence();
		list_seleccioneUnAFormaPagoGMF().select((String) args[0]);
	}
}

