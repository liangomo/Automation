package DatosDesembolso;
import resources.DatosDesembolso.text_TitularDestinoHelper;
/**
 * Description   : Functional Test Script
 * @author dpena6
 */
public class text_TitularDestino extends text_TitularDestinoHelper
{
	/**
	 * Script Name   : <b>text_TitularDestino</b>
	 * Generated     : <b>02/02/2015 14:34:36</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/02
	 * @author dpena6
	 */
	public void testMain(Object[] args) 
	{
		text_ingreseElValorDelRedescue().waitForExistence();
		text_ingreseElValorDelRedescue().setText((String) args[0]);
		
	}
}

