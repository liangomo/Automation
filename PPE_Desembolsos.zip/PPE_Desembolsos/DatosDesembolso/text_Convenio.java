package DatosDesembolso;
import resources.DatosDesembolso.text_ConvenioHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_Convenio extends text_ConvenioHelper
{
	/**
	 * Script Name   : <b>text_Convenio</b>
	 * Generated     : <b>13/01/2015 10:16:46</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/13
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		text_campoNumericoRequerido().waitForExistence();
		text_campoNumericoRequerido().setText((String) args[0]);
	}
}

