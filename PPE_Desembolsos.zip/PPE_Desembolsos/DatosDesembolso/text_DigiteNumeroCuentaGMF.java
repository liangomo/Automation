package DatosDesembolso;
import resources.DatosDesembolso.text_DigiteNumeroCuentaGMFHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_DigiteNumeroCuentaGMF extends text_DigiteNumeroCuentaGMFHelper
{
	/**
	 * Script Name   : <b>text_DigiteNumeroCuentaGMF</b>
	 * Generated     : <b>27/01/2015 10:09:02</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/27
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		text_digiteElN�meroDeCuentaAso().waitForExistence();
		text_digiteElN�meroDeCuentaAso().setText((String) args[0]);
	}
}

