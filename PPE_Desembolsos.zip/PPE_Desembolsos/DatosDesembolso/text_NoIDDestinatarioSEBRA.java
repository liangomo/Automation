package DatosDesembolso;
import resources.DatosDesembolso.text_NoIDDestinatarioSEBRAHelper;
/**
 * Description   : Functional Test Script
 * @author dpena6
 */
public class text_NoIDDestinatarioSEBRA extends text_NoIDDestinatarioSEBRAHelper
{
	/**
	 * Script Name   : <b>text_NoIDDestinatarioSEBRA</b>
	 * Generated     : <b>02/02/2015 14:11:06</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/02
	 * @author dpena6
	 */
	public void testMain(Object[] args) 
	{
		text_ingreseElValorDelRedescue2().waitForExistence();
		text_ingreseElValorDelRedescue2().setText((String) args[0]);
	}
}

