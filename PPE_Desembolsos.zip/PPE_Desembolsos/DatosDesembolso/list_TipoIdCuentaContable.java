package DatosDesembolso;
import resources.DatosDesembolso.list_TipoIdCuentaContableHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_TipoIdCuentaContable extends list_TipoIdCuentaContableHelper
{

	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			list_seleccioneUnATipoIdentifi2().waitForExistence();
			list_seleccioneUnATipoIdentifi2().select((String) args[0]);
			
		} else {

			list_seleccioneUnATipoIdentifi().waitForExistence();
			list_seleccioneUnATipoIdentifi().select((String) args[0]);
			
		}
		
		
		
		
	}
}

