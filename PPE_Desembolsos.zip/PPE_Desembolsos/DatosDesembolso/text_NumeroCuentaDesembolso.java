package DatosDesembolso;
import resources.DatosDesembolso.text_NumeroCuentaDesembolsoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_NumeroCuentaDesembolso extends text_NumeroCuentaDesembolsoHelper
{
	/**
	 * Script Name   : <b>text_NumeroCuentaDesembolso</b>
	 * Generated     : <b>13/01/2015 09:46:15</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/13
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			text_digiteElN�meroDeCuentaAso2().waitForExistence();
			text_digiteElN�meroDeCuentaAso2().setText((String) args[0]);
			
		} else {

			text_digiteElN�meroDeCuentaAso().waitForExistence();
			text_digiteElN�meroDeCuentaAso().setText((String) args[0]);
			
		}
		
		
		
	}
}

