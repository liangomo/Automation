package DatosDesembolso;
import resources.DatosDesembolso.text_IdCuentaContableHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_IdCuentaContable extends text_IdCuentaContableHelper
{
	/**
	 * Script Name   : <b>text_IdCuentaContable</b>
	 * Generated     : <b>13/01/2015 10:09:42</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/13
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			text_ingreseElNumeroDeIdentifi2().waitForExistence();
			text_ingreseElNumeroDeIdentifi2().setText((String) args[0]);
			
		} else {

			text_ingreseElNumeroDeIdentifi().waitForExistence();
			text_ingreseElNumeroDeIdentifi().setText((String) args[0]);
			
		}
	
	}
}

