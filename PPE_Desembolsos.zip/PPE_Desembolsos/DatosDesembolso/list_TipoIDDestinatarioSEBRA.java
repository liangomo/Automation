package DatosDesembolso;
import resources.DatosDesembolso.list_TipoIDDestinatarioSEBRAHelper;
/**
 * Description   : Functional Test Script
 * @author dpena6
 */
public class list_TipoIDDestinatarioSEBRA extends list_TipoIDDestinatarioSEBRAHelper
{
	/**
	 * Script Name   : <b>list_TipoIDDestinatarioSEBRA</b>
	 * Generated     : <b>02/02/2015 14:07:44</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/02
	 * @author dpena6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnATipoIDDestin2().waitForExistence();
		list_seleccioneUnATipoIDDestin2().select((String) args[0]);
	}
}

