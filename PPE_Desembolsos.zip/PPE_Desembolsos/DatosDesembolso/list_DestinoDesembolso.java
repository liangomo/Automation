package DatosDesembolso;
import resources.DatosDesembolso.list_DestinoDesembolsoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_DestinoDesembolso extends list_DestinoDesembolsoHelper
{
	/**
	 * Script Name   : <b>list_DestinoDesembolso</b>
	 * Generated     : <b>13/01/2015 09:43:21</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/13
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			list_seleccioneUnADestinoDesem2().waitForExistence();
			list_seleccioneUnADestinoDesem2().select((String) args[0]);
			
		} else {

			list_seleccioneUnADestinoDesem().waitForExistence();
			list_seleccioneUnADestinoDesem().select((String) args[0]);
			
		}
		
		
		
	}
}

