package DatosDesembolso;
import resources.DatosDesembolso.G_button_GuardarHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class G_button_Guardar extends G_button_GuardarHelper
{

	public void testMain(Object[] args) 
	{		
		if (args[0].equals("B300")) {

			button_siguientebutton().waitForExistence();
			button_siguientebutton().click();

		} else {

			button_guardarbutton().waitForExistence();
			button_guardarbutton().click();

		}


	}
}