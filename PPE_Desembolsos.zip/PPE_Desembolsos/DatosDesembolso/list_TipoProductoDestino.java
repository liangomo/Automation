package DatosDesembolso;
import resources.DatosDesembolso.list_TipoProductoDestinoHelper;
/**
 * Description   : Functional Test Script
 * @author dpena6
 */
public class list_TipoProductoDestino extends list_TipoProductoDestinoHelper
{
	/**
	 * Script Name   : <b>list_TipoProductoDestino</b>
	 * Generated     : <b>02/02/2015 14:14:43</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/02
	 * @author dpena6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnATipoProducto2().waitForExistence();
		list_seleccioneUnATipoProducto2().select((String) args[0]);
	}
}

