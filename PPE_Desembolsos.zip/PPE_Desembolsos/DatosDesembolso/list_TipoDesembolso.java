package DatosDesembolso;
import resources.DatosDesembolso.list_TipoDesembolsoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_TipoDesembolso extends list_TipoDesembolsoHelper
{

	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			list_seleccioneUnATipoDesembol2().waitForExistence();
			list_seleccioneUnATipoDesembol2().select((String) args[0]);
			
		} else {

			list_seleccioneUnATipoDesembol().waitForExistence();
			list_seleccioneUnATipoDesembol().select((String) args[0]);
			
		}
	}
}