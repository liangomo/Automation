package Garantia;
import resources.Garantia.button_Aceptar_FHelper;

public class button_Aceptar_F extends button_Aceptar_FHelper
{

	public void testMain(Object[] args) 
	{
		button_aceptaRbutton().waitForExistence();		
		button_aceptaRbutton().click();
	}
}