package Garantia;
import resources.Garantia.list_FAGHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_FAG extends list_FAGHelper
{
	/**
	 * Script Name   : <b>list_FAG</b>
	 * Generated     : <b>11/02/2015 17:22:43</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/11
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnAFAG().waitForExistence();
		list_seleccioneUnAFAG().select((String) args[0]);
		
	}
}

