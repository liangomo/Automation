package Garantia;
import resources.Garantia.text_PagareHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_Pagare extends text_PagareHelper
{
	/**
	 * Script Name   : <b>text_Pagare</b>
	 * Generated     : <b>22/01/2015 10:28:06</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/22
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		text_digiteElN�meroDeContragar().waitForExistence();
		text_digiteElN�meroDeContragar().setText((String) args[0]);
		
	}
}

