package Garantia;
import resources.Garantia.list_GarantiaHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_Garantia extends list_GarantiaHelper
{
	/**
	 * Script Name   : <b>list_Garantia</b>
	 * Generated     : <b>09/01/2015 16:43:12</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			list_seleccioneUnAGarantia2().waitForExistence();
			list_seleccioneUnAGarantia2().select((String) args[0]);
		
		} else {
			list_seleccioneUnAGarantia().waitForExistence();
			list_seleccioneUnAGarantia().select((String) args[0]);
		}
	
	}
}

