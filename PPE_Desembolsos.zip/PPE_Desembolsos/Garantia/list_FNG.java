package Garantia;
import resources.Garantia.list_FNGHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_FNG extends list_FNGHelper
{
	/**
	 * Script Name   : <b>list_FNG</b>
	 * Generated     : <b>22/01/2015 10:41:23</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/22
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnAFNG().waitForExistence();
		list_seleccioneUnAFNG().select((String) args[0]);
	}
}

