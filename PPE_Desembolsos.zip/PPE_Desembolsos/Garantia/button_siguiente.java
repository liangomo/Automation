package Garantia;
import resources.Garantia.button_siguienteHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class button_siguiente extends button_siguienteHelper
{
	/**
	 * Script Name   : <b>button_siguiente</b>
	 * Generated     : <b>09/01/2015 16:48:16</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		if (args[0].equals("B300_NoDebeEntrar")) {
			
			button_siguientebutton2().waitForExistence();
			button_siguientebutton2().click();
			
		} else {

			button_siguientebutton().waitForExistence();		
			button_siguientebutton().click();
			
		}
		
		
	}
}

