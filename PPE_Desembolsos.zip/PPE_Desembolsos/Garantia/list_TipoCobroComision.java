package Garantia;
import resources.Garantia.list_TipoCobroComisionHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_TipoCobroComision extends list_TipoCobroComisionHelper
{
	/**
	 * Script Name   : <b>list_TipoCobroComision</b>
	 * Generated     : <b>22/01/2015 10:47:20</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/22
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnATipoCobroCom().waitForExistence();
		list_seleccioneUnATipoCobroCom().select((String) args[0]);
	}
}

