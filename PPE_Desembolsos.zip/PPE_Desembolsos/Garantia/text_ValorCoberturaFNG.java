package Garantia;
import resources.Garantia.text_ValorCoberturaFNGHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_ValorCoberturaFNG extends text_ValorCoberturaFNGHelper
{
	/**
	 * Script Name   : <b>text_ValorCoberturaFNG</b>
	 * Generated     : <b>22/01/2015 10:52:34</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/22
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		text_ingreseElValorDeLaCobertu().waitForExistence();
		text_ingreseElValorDeLaCobertu().setText((String) args[0]);
	}
}

