package Garantia;
import resources.Garantia.list_ProductoComisionFNGHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_ProductoComisionFNG extends list_ProductoComisionFNGHelper
{
	/**
	 * Script Name   : <b>list_ProductoComisionFNG</b>
	 * Generated     : <b>22/01/2015 10:44:34</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/22
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnAProductoComi().waitForExistence();
		list_seleccioneUnAProductoComi().select((String) args[0]);
	}
}

