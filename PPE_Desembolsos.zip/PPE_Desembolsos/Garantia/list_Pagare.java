package Garantia;
import resources.Garantia.list_PagareHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_Pagare extends list_PagareHelper
{
	/**
	 * Script Name   : <b>list_Pagare</b>
	 * Generated     : <b>22/01/2015 10:25:55</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/22
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnATienePagar�C().waitForExistence();
		list_seleccioneUnATienePagar�C().select((String) args[0]);
	}
}

