package BuscarReserva;
import resources.BuscarReserva.text_NoIdentificacionHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_NoIdentificacion extends text_NoIdentificacionHelper
{

	public void testMain(Object[] args) 
	{
		text_htmlINPUTText().waitForExistence();
		text_htmlINPUTText().setText((String) args[0]);
		System.out.println("args[0]"+args[0]);
	}
}