package BuscarReserva;
import resources.BuscarReserva.text_UsuarioHelper;

public class text_Usuario extends text_UsuarioHelper
{

	public void testMain(Object[] args) 
	{
		text_htmlINPUTText().waitForExistence();
		text_htmlINPUTText().setText((String)args[80]);
		
	}
}