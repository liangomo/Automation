package BuscarReserva;
import resources.BuscarReserva.text_NumeroReservaHelper;

public class text_NumeroReserva extends text_NumeroReservaHelper { 
	
	public void testMain(Object[] args) {
		
		text_htmlINPUTText2().waitForExistence();
		text_htmlINPUTText2().click();
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		
		text_htmlINPUTText().setText((String) args[0]);
	}
}