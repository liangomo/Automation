package Scripts;
import java.awt.image.RenderedImage;
import java.io.IOException;
import com.lowagie.text.Document;
import resources.Scripts.G_DatosDesembolsoHelper;

public class G_DatosDesembolso extends G_DatosDesembolsoHelper
{
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;
		
	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	String[] tmp = new String[2];
	
	/* Variables para los datos de la BD */
	String 	NoIdentificacion = new String(),			//Variable Numero de identificacion 
			TipoDesembolso= new String(),				//Variable Tipo de Desembolso
			TipoProductoDebito= new String(),			//Variable Tipo Producto D�bito
			NumerosCuentaDebito= new String(),			//Variable Numero de cuenta Debito
			DestinoDesembolso= new String(),			//Variable Destino Desembolso
			NumeroCuentaDesembolso= new String(),		//Variable Numero de cuenta Desembolso
			CobroGMF = new String(),					//Variable Cobro GMF
			TipoID_ChequeGerencia= new String(),		//Variable Tipo Identificacion para Cheque de Gerencia
			NoIdentificacionCheque= new String(),		//Variable Numero de identificacion para Cheque 
			TipoIDCuentaContable = new String(),		//Variable Tipo de Identifiacacion para Cuenta Contable
			IDCuentaContable = new String(),			//Variable Numero de Identificacion de Cuenta Contable
			NoCreditoAbonar = new String(),				//Variable Numero de credito Abonar
			Convenio = new String(),					//Variable Convenio de Libranzas
			PresentaCertificacion= new String(),		//Variable Presenta Certificacion 
			FormaPagoGMF= new String(),					//Variable Forma de Pago de GMF
			FuenteGMF= new String(),					//Variable Fuente de GMF
			NoCuentaGMF = new String(),					//Variable Numero de Cuenta GMF
			CuentaConGMF= new String(),					//Variable Cuenta Contable GMF
			CuentaSEBRA = new String(),					//Variable Cuenta SEBRA	 
			TipoAbonoSEBRA= new String(),				//Variable Tipo de Abono SEBRA
			Portafolio = new String(),					//Variable Portafolio
			TipoIDDestinatarioSEBRA = new String(),		//Variable Tipo Identifiacacion Destinatario SEBRA
			NoIDDestinatarioSEBRA = new   String(),		//Variable Numero de Identificacion Destinatario SEBRA 
			TipoProductoDestino = new String(),			//Variable Tipo producto Destino
			NoProductoDestino = new String(),			//Variable Numero Prodcuto Destino
			TitularDestino = new String();				//Variable Titular Destino

	/* Variables para definir campos habilitados de acuerdo a la l�nea */
	Boolean BooleanTipoDesembolso= false,
			BooleanTipoProductoDebito= false,
			BooleanNumerosCuentaDebito= false,
			BooleanDestinoDesembolso= false,
			BooleanNumeroCuentaDesembolso= false,
			BooleanCobroGMF = false,
			BooleanTipoID_ChequeGerencia= false,
			BooleanNoIdentificacionCheque= false,
			BooleanTipoIDCuentaContable = false,
			BooleanIDCuentaContable = false,
			BooleanNoCreditoAbonar = false,
			BooleanConvenio = false,
			BooleanPresentaCertificacion= false,
			BooleanFormaPagoGMF= false,
			BooleanFuenteGMF= false,
			BooleanNoCuentaGMF = false,
			BooleanCuentaConGMF= false,
			BooleanCuentaSEBRA = false,
			BooleanTipoAbonoSEBRA= false,
			BooleanPortafolio = false,
			BooleanTipoIDDestinatarioSEBRA = false,
			BooleanNoIDDestinatarioSEBRA = false,
			BooleanTipoProductoDestino = false,
			BooleanNoProductoDestino = false,
			BooleanTitularDestino = false;	

	/* Variables Comparativas */
	String CuentaCorrientes="Cuentas corrientes";		// Variable comparativa Cuentas corrientes
	String CuentaAhorros="Cuentas ahorros";				// Variable comparativa Cuentas ahorros
	String SinCuenta="Sin cuenta";						// Variable comparativa Sin cuenta
	String ChequeGerencia="Cheque gerencia";			// Variable comparativa Cheque gerencia
	String OtrosCuentaContable="Otros(Cuenta Contable)";// Variable comparativa Otros(Cuenta Contable)
	String AbonoACredito="Abono a Credito";				// Variable comparativa Abono a Credito
	String TrasladoSebra="Traslado SEBRA";				// Variable comparativa Traslado SEBRA
	String AbonoCuentaSEBRA ="Abono a la cuenta SEBRA";	// Variable comparativa Abono a la cuenta SEBRA
	String AbonoOtroProducto= "Abono a otro producto";	// Variable comparativa	Abono a otro producto
	String DescontarCreditoCargandoCuenta = "Descontar del credito completando cargando a Cuenta"; 	// Variable comparativa Descontar del credito completando cargando a Cuenta
	String CargoCuentaAhorros="Cargo en Cuenta de Ahorros";		// Variable comparativa Cargo en Cuenta de Ahorros
	String CargoCuentaCorriente= "Cargo en Cuenta Corriente";	// Variable comparativa Cargo en Cuenta Corriente

	
	public void testMain(Object[] args) throws IOException 
	{	
		/** ASIGNACI�N DE VARIABLES */
		
		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		NoIdentificacion = (String) args[5];
		TipoDesembolso = (String) args[39];		
		TipoProductoDebito = (String) args[40];	
		NumerosCuentaDebito = (String) args[41];	
		DestinoDesembolso = (String) args[42];	
		NumeroCuentaDesembolso = (String) args[43];
		CobroGMF = (String) args[44];			
		TipoID_ChequeGerencia = (String) args[45];
		NoIdentificacionCheque = (String) args[46];
		TipoIDCuentaContable = (String) args[47];
		IDCuentaContable = (String) args[48];	
		NoCreditoAbonar = (String) args[50];		
		Convenio = (String) args[49];			
		PresentaCertificacion = (String) args[51];
		FormaPagoGMF = (String) args[52];	
		FuenteGMF = (String) args[53];			
		NoCuentaGMF = (String) args[54];			
		CuentaConGMF = (String) args[55];			
		CuentaSEBRA = (String) args[56];			
		TipoAbonoSEBRA = (String) args[57];		
		Portafolio = (String) args[58];			
		TipoIDDestinatarioSEBRA = (String) args[59];
		NoIDDestinatarioSEBRA = (String) args[60];
		TipoProductoDestino = (String) args[61];	
		NoProductoDestino = (String) args[62];	
		TitularDestino = (String) args[63];
		
		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];


		/** VALIDACI�N DE CAMPOS HABILITADOS DEPENDIENDO DE LA L�NEA */
		
		/* Validaci�n de campos habilitados dependiendo de la l�nea */
		if (getSubString((String) args[3],0,4).equals("BB01")) {
			BooleanTipoDesembolso= true;
			BooleanTipoProductoDebito= true;
			BooleanNumerosCuentaDebito= true;
			BooleanDestinoDesembolso= true;
			BooleanNumeroCuentaDesembolso= true;
			BooleanCobroGMF = true;
			BooleanTipoID_ChequeGerencia= true;
			BooleanNoIdentificacionCheque= true;
			BooleanTipoIDCuentaContable = true;
			BooleanIDCuentaContable = true;
		}

		if (getSubString((String) args[3],0,4).equals("BB27")) {
			BooleanDestinoDesembolso= true;
			BooleanNumeroCuentaDesembolso= true;
			BooleanCobroGMF = true;
			BooleanTipoID_ChequeGerencia= true;
			BooleanNoIdentificacionCheque= true;
			BooleanTipoIDCuentaContable = true;
			BooleanIDCuentaContable = true;
			/* 12/07/2016 LGOMEZ11 - CVAPD00236607 Convenio de Anticipos juntas m�dicas Libranzas producto BB27 */
			//BooleanConvenio = true;				
		}

		if (getSubString((String) args[3],0,4).equals("B002")) {
			BooleanTipoDesembolso= true;
			BooleanTipoProductoDebito= true;
			BooleanNumerosCuentaDebito= true;
			BooleanCobroGMF = true;
		}	

		if (getSubString((String) args[3],0,4).equals("B131")) {			
			// BooleanTipoDesembolso= true;
			BooleanDestinoDesembolso= true;
			BooleanNumeroCuentaDesembolso= true;
			BooleanCobroGMF = true;
			BooleanTipoID_ChequeGerencia= true;
			BooleanNoIdentificacionCheque= true;
			BooleanTipoIDCuentaContable = true;
			BooleanIDCuentaContable = true;
			BooleanConvenio = true;				
		}

		if (getSubString((String) args[3],0,4).equals("M002")) {			
			BooleanTipoDesembolso= true;
			BooleanTipoProductoDebito= true;
			BooleanNumerosCuentaDebito= true;
			BooleanDestinoDesembolso= true;
			BooleanNumeroCuentaDesembolso= true;
			BooleanTipoID_ChequeGerencia= true;
			BooleanNoIdentificacionCheque= true;
			BooleanTipoIDCuentaContable = true;
			BooleanIDCuentaContable = true;
			BooleanNoCreditoAbonar = true;
			BooleanPresentaCertificacion= true;
			BooleanFormaPagoGMF= true;
			BooleanFuenteGMF= true;
			BooleanNoCuentaGMF= true;
			BooleanCuentaConGMF= true;
			BooleanCuentaSEBRA = true;
			BooleanTipoAbonoSEBRA= true;
			BooleanPortafolio = true;
			BooleanTipoIDDestinatarioSEBRA = true;
			BooleanNoIDDestinatarioSEBRA = true;
			BooleanTipoProductoDestino = true;
			BooleanNoProductoDestino = true;
			BooleanTitularDestino = true;	
		}

		if (getSubString((String) args[3],0,4).equals("B300")) {			
			BooleanTipoDesembolso= true;
			BooleanTipoProductoDebito= true;
			BooleanNumerosCuentaDebito= true;
			BooleanDestinoDesembolso= true;
			BooleanNumeroCuentaDesembolso= true;
			BooleanTipoID_ChequeGerencia= true;
			BooleanNoIdentificacionCheque= true;
			BooleanTipoIDCuentaContable = true;
			BooleanIDCuentaContable = true;
			BooleanCobroGMF=true;	
		}

		if (getSubString((String) args[3],0,4).equals("M007")) {			
			BooleanTipoDesembolso= true;
			BooleanTipoProductoDebito= true;
			BooleanNumerosCuentaDebito= true;
			BooleanDestinoDesembolso= true;
			BooleanNumeroCuentaDesembolso= true;
			BooleanTipoID_ChequeGerencia= true;
			BooleanNoIdentificacionCheque= true;
			BooleanTipoIDCuentaContable = true;
			BooleanIDCuentaContable = true;
			BooleanPresentaCertificacion= true;
			BooleanFormaPagoGMF= true;
			BooleanFuenteGMF= true;
			BooleanNoCuentaGMF= true;
			BooleanCuentaConGMF= true;
			BooleanCuentaSEBRA = true;
			BooleanTipoAbonoSEBRA= true;
			BooleanPortafolio = true;
			BooleanTipoIDDestinatarioSEBRA = true;
			BooleanNoIDDestinatarioSEBRA = true;
			BooleanTipoProductoDestino = true;
			BooleanNoProductoDestino = true;
			BooleanTitularDestino = true;	
		}

		if (getSubString((String) args[3],0,4).equals("BB15")) {
			BooleanTipoDesembolso= true;
			BooleanTipoProductoDebito= true;
			BooleanNumerosCuentaDebito= true;
			BooleanDestinoDesembolso= true;
			BooleanNumeroCuentaDesembolso= true;
			BooleanCobroGMF = true;
			BooleanTipoID_ChequeGerencia= true;
			BooleanNoIdentificacionCheque= true;
			BooleanTipoIDCuentaContable = true;
			BooleanIDCuentaContable = true;
		}

		if (getSubString((String) args[3],0,4).equals("M039")) {			
			BooleanTipoDesembolso= true;
			BooleanTipoProductoDebito= true;
			BooleanNumerosCuentaDebito= true;
			BooleanDestinoDesembolso= true;
			BooleanNumeroCuentaDesembolso= true;
			BooleanTipoID_ChequeGerencia= true;
			BooleanNoIdentificacionCheque= true;
			BooleanTipoIDCuentaContable = true;
			BooleanIDCuentaContable = true;
			BooleanPresentaCertificacion= true;
			BooleanFormaPagoGMF= true;
			BooleanFuenteGMF= true;
			BooleanNoCuentaGMF= true;
			BooleanCuentaConGMF= true;
			BooleanCuentaSEBRA = true;
			BooleanTipoAbonoSEBRA= true;
			BooleanPortafolio = true;
			BooleanTipoIDDestinatarioSEBRA = true;
			BooleanNoIDDestinatarioSEBRA = true;
			BooleanTipoProductoDestino = true;
			BooleanNoProductoDestino = true;
			BooleanTitularDestino = true;	
		}

		if (getSubString((String) args[3],0,4).equals("BP14")) {
			BooleanTipoDesembolso= true;
			BooleanTipoProductoDebito= true;
			BooleanNumerosCuentaDebito= true;
			BooleanCobroGMF = true;
		}		

		if (getSubString((String) args[3],0,4).equals("BB04")) {
			BooleanTipoDesembolso= true;
			BooleanTipoProductoDebito= true;
			BooleanNumerosCuentaDebito= true;
			BooleanCobroGMF = true;
		}

		/** INGRESO DE LOS DATOS DEL DESEMBOLSO (Quinta Pantalla) */
		
		if (BooleanTipoDesembolso) {
			tmp [0]= TipoDesembolso; // Ingreso de tipo de Desembolso "Simple" o "Mixto"
			tmp [1]= getSubString((String) args[3],0,4);
			callScript("DatosDesembolso.list_TipoDesembolso",tmp);
		}

		if (BooleanTipoProductoDebito) {
			tmp [0]=TipoProductoDebito; // Ingreso tipo producto donde se va a debitar "Cuentas ahorros" o "Cuentas corrientes"	o "Sin cuenta"
			tmp [1]= getSubString((String) args[3],0,4);
			callScript("DatosDesembolso.list_TipoProductoDebito",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");	
		}

		if (BooleanNumerosCuentaDebito) {

			if (TipoProductoDebito.equals(CuentaAhorros)|| TipoProductoDebito.equals(CuentaCorrientes)) // Validacion Cuenta Debito 
			{
				tmp[0] = NumerosCuentaDebito; // Ingreso de Numero de la Cuenta D�bito
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("DatosDesembolso.list_CuentaDebito", tmp);
			}
		}

		if (BooleanDestinoDesembolso) {
			tmp [0]=DestinoDesembolso;		// Ingreso Destino del desembolso alternativas
			tmp [1]= getSubString((String) args[3],0,4);
			callScript("DatosDesembolso.list_DestinoDesembolso",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			Espera(2);

			if (DestinoDesembolso.equals(CuentaAhorros)||DestinoDesembolso.equals(CuentaCorrientes)) { //Validacion si es Cuenta de Ahorros o Cuentas Corrientes
				tmp [0]= NumeroCuentaDesembolso;  //Ingreso cuenta destino
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("DatosDesembolso.text_NumeroCuentaDesembolso",tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");					
			}

			if (DestinoDesembolso.equals(ChequeGerencia)) { //Validacion si es Cheque de gerencia
				tmp [0]= TipoID_ChequeGerencia;		//Ingreso Tipo de identificacion de la persona a la cual va salir el cheque
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("DatosDesembolso.list_TipoIDChequeGerencia",tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

				tmp [0]= NoIdentificacionCheque;	//Ingreso de numero de identificacion del beneficiario del cheque
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("DatosDesembolso.text_NoIdentificacionCheque",tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");


				if (!NoIdentificacion.equals(NoIdentificacionCheque)) { // Validacion si no es el mismo numero de identificacion del cliente
					//html_mesajeRespuestaDialog().waitForExistence();
					tmp [1]= getSubString((String) args[3],0,4);
					callScript("DatosDesembolso.button_Ok_D",tmp);
				} else {
					BooleanPresentaCertificacion= false;
				}
			}

			if (DestinoDesembolso.equals(OtrosCuentaContable)) {	//Validacion de Otros Cuenta contable	
				tmp [0]=TipoIDCuentaContable;	// Ingreso Tipo Identificacion
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("DatosDesembolso.list_TipoIdCuentaContable",tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

				tmp [0]= IDCuentaContable;	// Ingreso Numero de Identificacion
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("DatosDesembolso.text_IdCuentaContable",tmp);

				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

				if (!IDCuentaContable.equals(NoIdentificacion)) { //Validacion si no es el mismo numero de identificacion del cliente
					tmp [1]= getSubString((String) args[3],0,4);
					callScript("DatosDesembolso.button_Ok_D",tmp);
				} else {
					BooleanPresentaCertificacion= false;
				}
			}
		
			if (DestinoDesembolso.equals(AbonoACredito)) { // Validacion Abono credito 
				tmp [0]= NoCreditoAbonar;	// Ingresar No de cr�dito que no se haya cancelado ni pagado en totalidad	
				callScript("DatosDesembolso.text_NumeroCredito",tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

			}
		
			if (DestinoDesembolso.equals(TrasladoSebra)) { // Validacion si es trasaldo SEBRA
				tmp[0]=CuentaSEBRA; // Ingresar Cuenta SEBRA
				callScript("DatosDesembolso.text_CuentaSEBRA",tmp); sleep(2);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

				tmp[0]=TipoAbonoSEBRA; // Ingresar Tipo Abono SEBRA
				callScript("DatosDesembolso.list_TipoAbonoSEBRA",tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

				if (TipoAbonoSEBRA.equals(AbonoCuentaSEBRA)) { // Validacion si el tipo de abono SEBRA es "Abono a la cuenta SEBRA"
					tmp[0]=Portafolio; // Ingresar Portafolio
					callScript("DatosDesembolso.text_Portafolio",tmp);
				}

				if (TipoAbonoSEBRA.equals(AbonoOtroProducto)) { // Validacion si el tipo de abono SEBRA es "Abono a otro producto"
					tmp[0]=Portafolio; // Ingreso de Portafolio
					callScript("DatosDesembolso.text_Portafolio",tmp);

					tmp[0]=TipoIDDestinatarioSEBRA; // Ingreso de Tipo Identificacion Destinatario SEBRA
					callScript("DatosDesembolso.list_TipoIDDestinatarioSEBRA",tmp);
					browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

					tmp[0]=NoIDDestinatarioSEBRA; // Ingreso de Numero de identificacion Destinatario SEBRA
					callScript("DatosDesembolso.text_NoIDDestinatarioSEBRA",tmp);

					tmp[0]=TipoProductoDestino; // Ingreso de Tipo de producto Destino 
					callScript("DatosDesembolso.list_TipoProductoDestino",tmp);
					browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

					tmp[0]=NoProductoDestino; // Ingreso de Numero de producto Destino
					callScript("DatosDesembolso.text_NoProductoDestino",tmp);

					tmp[0]=TitularDestino; // Ingreso de Titular de Destino
					callScript("DatosDesembolso.text_TitularDestino",tmp);
				}
			}
		}

		if (BooleanConvenio) {
			tmp [0]= Convenio; //Seleccion de Convenio si es producto BB27
			callScript("DatosDesembolso.text_Convenio",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanCobroGMF) {
			tmp [0]= CobroGMF;	// Seleccionar Si se cobra o no el GMF
			tmp [1]= getSubString((String) args[3],0,4);
			callScript("DatosDesembolso.list_CobroGMF",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanPresentaCertificacion) {
			tmp[0]=PresentaCertificacion; // Ingresar si Presenta Certificacion o no
			callScript("DatosDesembolso.list_Presenta_Certificacion",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

			if (PresentaCertificacion.equals("No")) { // Validacion si Presenta de Certificacion  
				tmp[0]=FormaPagoGMF; // Ingresar forma de Pago de GMF
				callScript("DatosDesembolso.list_FormaPagoGMF",tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

				if (FormaPagoGMF.equals(DescontarCreditoCargandoCuenta)) { // Validacion si la Forma de Pago GMF  es "Descontar del credito completando cargando a Cuenta"
					tmp[0]=FuenteGMF; // Ingreso de Fuente GMF
					callScript("DatosDesembolso.list_FuenteCargoGMF", tmp);
					browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

					if (FuenteGMF.equals(CargoCuentaAhorros)||FuenteGMF.equals(CargoCuentaCorriente)) { //Validacion si el cargo de GMF se hace a Cuenta de Ahorros o Corriente 
						tmp[0] = NoCuentaGMF; // Ingreso de Numero de Cuenta a la cual se le realizara el cargo de GMF
						callScript("DatosDesembolso.text_DigiteNumeroCuentaGMF",tmp);
					}

					if (FuenteGMF.equals("Cargo otros")) { // Validacion si el cargo de GMF se hace con Cargo Otros
						tmp[0]=CuentaConGMF; // Ingreso de Cuenta contable GMF
						callScript("DatosDesembolso.text_NumeroCuentaContableGMF",tmp);
					}

					browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
				}
			}
		}
		
		
		/** INFORME DETALLADO PDF */
		
		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - G_DatosDesembolso", doc);

		
		/** CONTINUAR A SIGUIENTE PANTALLA */
		
		/* Clic en boton Guardar */
		tmp [0]= getSubString((String) args[3],0,4);
		callScript("DatosDesembolso.G_button_Guardar",tmp);
		Espera(1);

		/* Clic en boton Ok si es la l�nea B300 */
		if (!getSubString((String) args[3],0,4).equals("B300"))
			callScript("DatosDesembolso.button_Ok_D",tmp);
	}
}