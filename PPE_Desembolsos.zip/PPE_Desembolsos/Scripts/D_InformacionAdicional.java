package Scripts;
import java.awt.image.RenderedImage;
import java.io.IOException;
import com.lowagie.text.Document;
import resources.Scripts.D_InformacionAdicionalHelper;

public class D_InformacionAdicional extends D_InformacionAdicionalHelper
{	
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;

	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	String[] tmp = new String[4];	

	/* Variables para los datos de la BD */
	String 	ValorCredito= new String(),			// Variable Valor del Cr�dito
			ValorOriginalCredito = new String(),
			CambiarFechaPago= new String(),		// Variable de cambiar Fecha de Pago
			PrimeraFechaPago= new String(),		// Variable de Primera Fecha de Pago
			diaPago = new String(), 			// Variable de Lista dia pago (Seleccion) 
			Oficina= new String(),				// Variable de Oficina 
			oficinaRadicacion = new String(),	// Variable de Oficina de Radicaci�n
			OficialVenta= new String(),			// Variable de Oficial Venta
			Vendedor= new String(),				// Variable de Vendedor
			PlazoCredito= new String(),			// Variable de Plazo Cr�dito
			SeguroVehiculo= new String(),		// Variable de Seguro del Vehiculo
			CodigoAseguradora= new String(),	// Variable de Codigo de la Aseguradora
			ValorPrimaMensual= new String(),	// Variable del Valor de la prima mensual
			TipoVehiculo= new String(),			// Variable de tipo de Vehiculo
			Placa= new String(), 				// Variable de Placa Veh�culo
			CobroGastos= new String(),			// Variable de Cobro de Gastos
			Seguro= new String(),				// Variable de Seguro 
			PlanSeguro = new String(),			// Variable de Plan de Seguro
			CanalDeVenta= new String(),			// Variable de Canal de Venta
			CodigoCIIU= new String(),			// Variable de Codigo CIIU
			SeguroDeVida= new String(),			// Variable de Seguro de Vida
			Convenio = new String(),			//Variable Convenio de Libranzas
			seguroAutoProtegPlus = new String(), // Variable Seguro Auto Protegido Plus

			// Aplica unicamente para validaci�n de fechas B300
			PeriodoPagoIntereses= new String();	//Variable de Periodo Pago de Intereses

	/* Variables para definir campos habilitados de acuerdo a la l�nea */
	Boolean BooleanIngrValorCredito= false,
			BooleanValorOriginalCredito = false,
			BooleanCambiarFechaPago= false,
			BooleanPrimeraFechaPagoLibre= false,
			BooleanPrimeraFechaPagoLista= false,
			BooleanOficina= false,
			BooleanOficinaRadicacion = false,
			BooleanOficialVenta= false,
			BooleanVendedor= false,
			BooleanPlazoCreditoLibre= false,
			BooleanPlazoCreditoLista= false,
			BooleanSeguroVehiculo= false,		
			BooleanCodigoAseguradora= false,	
			BooleanValorPrimaMensual= false,	
			BooleanTipoVehiculo= false,	
			BooleanTipoVehiculo1= false,	
			BooleanPlaca= false,
			BooleanCobroGastos= false,
			BooleanSeguro= false,
			BooleanTipoPlanSeguro=false,
			BooleanCanalVenta= false,
			BooleanCodigoCIIU= false,
			BooleanSeguroDeVida= false,
			BooleanPeriodoPagoIntereses= false,
			BooleanConvenio = false,
			BooleanSeguroAutoProtegPlus = false;

	/* Variables Comparativas */
	String 	accidentesPersonales ="Accidentes Personales", 	// Variable comparativa para Accidentes Personales 
			SegmentoDocente = "Segmento Docente",			// Variable comparativa para Segmento Docente
			SegmentoExperiencia = "Segmento Experiencia",	// Variable comparativa para Accidentes Experiencia
			proteccionBienestarVida = "Protecci�n Bienestar y Vida",
			proteccionIntegralFamilia = "Protecci�n Integral Familia";


	public void testMain(Object[] args) throws IOException 
	{

		/** ASIGNACI�N DE VARIABLES */

		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		ValorCredito= (String) args[6];
		ValorOriginalCredito = (String) args[6];
		CambiarFechaPago= (String) args[7];
		PrimeraFechaPago= (String) args[8];
		diaPago = (String) args[9];
		Oficina = (String) args[10];
		oficinaRadicacion =  (String) args[10];
		OficialVenta= (String) args[11];
		Vendedor= (String) args[12];
		PlazoCredito= (String) args[13];
		SeguroVehiculo= (String) args[66];
		CodigoAseguradora= (String) args[67];
		ValorPrimaMensual= (String) args[68];
		TipoVehiculo= (String) args[70];
		Placa= (String) args[69]; 
		CobroGastos= (String) args[14];
		Seguro= (String) args[15];
		PlanSeguro = (String) args[65];
		CanalDeVenta= (String) args[71];
		CodigoCIIU= (String) args[16];
		SeguroDeVida= (String) args[72];
		Convenio = (String) args[49];
		seguroAutoProtegPlus = (String) args[73]; 
		PeriodoPagoIntereses = (String) args[22];

		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];


		/** VALIDACI�N DE CAMPOS HABILITADOS DEPENDIENDO DE LA L�NEA */

		if (getSubString((String) args[3],0,4).equals("BB01")) {
			BooleanIngrValorCredito= true;
			BooleanValorOriginalCredito= true;
			BooleanPrimeraFechaPagoLibre= true;
			BooleanPrimeraFechaPagoLista= false;
			BooleanOficina= true;
			BooleanOficialVenta= true;
			BooleanVendedor= true;
			BooleanPlazoCreditoLibre= true;
			BooleanPlazoCreditoLista= false;
			BooleanSeguro= true;
			BooleanCanalVenta= true;
			BooleanCodigoCIIU= true;
			BooleanSeguroDeVida= true;
		}

		if (getSubString((String) args[3],0,4).equals("BB27")) {
			BooleanIngrValorCredito= true;
			BooleanValorOriginalCredito= true;
			BooleanCambiarFechaPago= true;
			BooleanPrimeraFechaPagoLibre= true;
			BooleanPrimeraFechaPagoLista= false;
			BooleanOficina= true;
			BooleanOficinaRadicacion= true;
			BooleanOficialVenta= true;
			BooleanVendedor= true;
			BooleanPlazoCreditoLibre= true;
			BooleanPlazoCreditoLista= false;
			BooleanCobroGastos= true;
			BooleanSeguro= true;
			BooleanTipoPlanSeguro=true;
			BooleanCanalVenta= true;
			BooleanCodigoCIIU= true;
			/* 12/07/2016 LGOMEZ11 - CVAPD00236607 Convenio de Anticipos juntas m�dicas Libranzas producto BB27 */
			BooleanConvenio = true;
			if (Convenio.equals("33100003370")) {
				BooleanCambiarFechaPago= false;
				BooleanPlazoCreditoLibre= false;
				BooleanCobroGastos= false;
				BooleanSeguro= false;
				BooleanTipoPlanSeguro=false;
			}
		}

		if (getSubString((String) args[3],0,4).equals("B002")) {
			BooleanIngrValorCredito= true;
			BooleanPrimeraFechaPagoLibre= false;
			BooleanPrimeraFechaPagoLista= true;
			BooleanOficina= true;
			BooleanOficialVenta= true;
			BooleanVendedor= true;

			/* 2015.07.24 - LGOMEZ11 - CVAPD00077997 Req Plazo crediservice 48 meses */
			/*	BooleanPlazoCreditoLibre= false;
				BooleanPlazoCreditoLista= true; */
			BooleanSeguro= true;
			BooleanCodigoCIIU= true;
			BooleanSeguroDeVida= true;
		}


		if (getSubString((String) args[3],0,4).equals("B131")) {
			BooleanIngrValorCredito= true;
			BooleanValorOriginalCredito= true;
			BooleanCambiarFechaPago= true;
			BooleanPrimeraFechaPagoLibre= true;
			BooleanPrimeraFechaPagoLista= false;
			BooleanOficina= true;
			BooleanOficialVenta= true;
			BooleanVendedor= true;
			BooleanPlazoCreditoLibre= true;
			BooleanPlazoCreditoLista= false;
			BooleanCobroGastos= true;
			BooleanSeguro= true;
			BooleanTipoPlanSeguro=true;
			BooleanCanalVenta= true;
			BooleanCodigoCIIU= true;
		}

		if (getSubString((String) args[3],0,4).equals("M002")) {
			BooleanIngrValorCredito= true;
			BooleanCambiarFechaPago= true;
			BooleanPrimeraFechaPagoLibre= true;
			BooleanPrimeraFechaPagoLista= false;
			BooleanOficina= true;
			BooleanOficialVenta= true;
			BooleanVendedor= true;
			BooleanPlazoCreditoLibre= true;
			BooleanPlazoCreditoLista= false;
			BooleanCobroGastos= true;
			BooleanCodigoCIIU= true;
		}

		if (getSubString((String) args[3],0,4).equals("B300")) {
			BooleanIngrValorCredito= true;
			BooleanPrimeraFechaPagoLibre= true;
			BooleanPrimeraFechaPagoLista= false;
			BooleanOficialVenta= true;
			BooleanVendedor= true;
			BooleanPlazoCreditoLibre= true;
			BooleanPlazoCreditoLista= false;
			BooleanCodigoCIIU= true;
			BooleanPeriodoPagoIntereses= true;
		}

		if (getSubString((String) args[3],0,4).equals("M007")) {
			BooleanIngrValorCredito= true; 
			BooleanCambiarFechaPago= true;
			BooleanPrimeraFechaPagoLibre= true;
			BooleanPrimeraFechaPagoLista= false;
			BooleanOficina= true;
			BooleanOficialVenta= true;
			BooleanVendedor= true;
			BooleanPlazoCreditoLibre= true;
			BooleanPlazoCreditoLista= false;
			BooleanCobroGastos= true;
			BooleanCodigoCIIU= true;
		}

		if (getSubString((String) args[3],0,4).equals("BB15")) {
			BooleanIngrValorCredito= true; 
			BooleanPrimeraFechaPagoLibre= true;
			BooleanPrimeraFechaPagoLista= false;
			BooleanOficina= true;
			BooleanOficialVenta= true;
			BooleanVendedor= true;
			BooleanPlazoCreditoLibre= true;
			BooleanPlazoCreditoLista= false;
			BooleanSeguroVehiculo= true;
			BooleanCodigoAseguradora= true;
			BooleanValorPrimaMensual=true;

			/* 2015.07.21 - LGOMEZ11 - CVAPD00077997 Seguro de Desempleo para l�neas de Veh�culos de red de oficinas */
			/*	BooleanSeguro=true;
				BooleanTipoVehiculo=true; */

			/* 2016.01.28 - LGOMEZ11 - CVAPD00195035 Inclusi�n Placa y TipoVeh�culo - Facturaci�n de TRDM veh�culos */
			BooleanPlaca=true;
			BooleanTipoVehiculo1=true;

			/* 2016.09.30 LGOMEZ11 - CVAPD00248114 Crear la Opci�n Seguro Cuota Protegida Mensual L�nea 15 Veh�culos */
			BooleanSeguro=true;

			BooleanCodigoCIIU= true;
			BooleanCanalVenta= true;

			/* 2016.10.28 LGOMEZ11 - Inclusi�n campo SeguroAutoProtegidoPlus */
			BooleanSeguroAutoProtegPlus = true;

		}

		if (getSubString((String) args[3],0,4).equals("M039")) {
			BooleanIngrValorCredito= true; 
			BooleanCambiarFechaPago= true;
			BooleanPrimeraFechaPagoLibre= true;
			BooleanPrimeraFechaPagoLista= false;
			BooleanOficina= true;
			BooleanOficialVenta= true;
			BooleanVendedor= true;
			BooleanPlazoCreditoLibre= true;
			BooleanPlazoCreditoLista= false;
			BooleanCobroGastos= true;
			BooleanCodigoCIIU= true;
		}

		if (getSubString((String) args[3],0,4).equals("BP14")) {
			BooleanIngrValorCredito= true;
			BooleanPrimeraFechaPagoLibre= false;
			BooleanPrimeraFechaPagoLista= true;
			BooleanOficina= true;
			BooleanOficialVenta= true;
			BooleanVendedor= true;
			BooleanSeguro= true;
			BooleanCodigoCIIU= true;
			BooleanSeguroDeVida= true;
		}

		/**
		 * JHON DOTOR 
		 * */

		if (getSubString((String) args[3],0,4).equals("BB04")) {
			BooleanIngrValorCredito= true;
			BooleanPrimeraFechaPagoLista= true;
			BooleanOficina= true;
			BooleanOficialVenta= true;
			BooleanVendedor= true;
			BooleanCodigoCIIU= true;
		}


		/** INGRESO DE DATOS EN INFORMACI�N ADICIONAL (Segunda Pantalla)*/

		if (BooleanIngrValorCredito) {
			// Ingreso del valor del credito
			tmp[0] = ValorCredito;		
			tmp[1] = getSubString((String) args[1], 0, 4); 
			callScript("InformacionAdicional.D_text_ValorCredito", tmp);
		}

		if (BooleanValorOriginalCredito) {
			// Ingreso del valor del credito
			tmp[0] = ValorOriginalCredito;		
			tmp[1] = getSubString((String) args[1], 0, 4); 
			callScript("InformacionAdicional.D_text_ValorOriginalCredito", tmp);
		}

		if (BooleanConvenio) {
			tmp [0]= Convenio; //Seleccion de Convenio si es producto BB27
			callScript("DatosPrincipalesDelCredito.C_text_Convenio_2",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanCambiarFechaPago) {
			//Ingreso  SI/NO cambio fecha de pago
			tmp[0]=CambiarFechaPago;	
			callScript("InformacionAdicional.D_list_SeleccionarCambioFechaSiNo",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanPrimeraFechaPagoLibre) {

			if (PrimeraFechaPago!= null) {
				//Ingreso de Primera fecha de pago sin resticcion al momento de digitar
				tmp[0] = PrimeraFechaPago;
				tmp[1] = getSubString((String) args[3],0,4);
				tmp[2] = PeriodoPagoIntereses;
				tmp[3] = PlazoCredito;
				callScript("InformacionAdicional.D_text_PrimeraFechaPago", tmp); sleep(1);
				browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT_FLAGS).inputKeys("{TAB}");
			}

		}

		if (BooleanPrimeraFechaPagoLista) {
			if (diaPago!=null) {
				tmp[0] = diaPago;	//Ingreso de Primera fecha de pago con resticcion al momento de digitar
				callScript("InformacionAdicional.D_list_SeleccionDiaPago", tmp);
			}
		}

		if (BooleanOficina) {
			tmp[0] = Oficina; // Ingreso de la Oficina Ojo con los espacios despues del nombre de la oficina 
			callScript("InformacionAdicional.D_text_campoOficina", tmp);
			browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanOficinaRadicacion) {
			tmp[0] = oficinaRadicacion; // Ingreso de la Oficina Ojo con los espacios despues del nombre de la oficina 
			callScript("InformacionAdicional.D_text_campoOficinaRadicacion", tmp);
			browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanOficialVenta) {
			tmp[0] = OficialVenta;//Ingreso Oficial de venta
			tmp[1] = getSubString((String) args[3],0,4);
			callScript("InformacionAdicional.D_text_campoOficialVenta", tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanVendedor) {
			tmp[0] = Vendedor;// Ingreso de Vendedor
			tmp[1] = getSubString((String) args[3],0,4);
			callScript("InformacionAdicional.D_text_campoVendedor", tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanPlazoCreditoLibre) {
			tmp[0]=PlazoCredito;// Ingreso de Palzo credito
			tmp[1] = getSubString((String) args[3],0,4);
			callScript("InformacionAdicional.D_text_Plazo",tmp);
		}

		if (BooleanPlazoCreditoLista) {
			tmp[0]=PlazoCredito;	// Ingreso de Palzo credito
			callScript("InformacionAdicional.D_list_Plazo",tmp);
		}


		if (BooleanCobroGastos) {
			tmp[0]=CobroGastos;		// Ingresar Cobro Gastos
			callScript("InformacionAdicional.D_list_CobroGastos",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanSeguroVehiculo) {
			tmp[0]=SeguroVehiculo; // Ingresar seguro de Vehiculo
			callScript("InformacionAdicional.D_list_SeguroVehiculo",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

			if (SeguroVehiculo.equals("Si")) {

				tmp[0]=CodigoAseguradora; // Ingresar Codigo de la Aseguradora
				callScript("InformacionAdicional.D_text_CodigoAseguradora",tmp);

				tmp[0]=ValorPrimaMensual; // Ingresar Valor de la prima Mensual
				callScript("InformacionAdicional.D_text_ValorPrimaMensual",tmp);

				tmp[0]=Placa; // Ingresar Valor de la prima Mensual
				callScript("InformacionAdicional.D_text_Placa", tmp);

				tmp[0] = TipoVehiculo;	// Ingreso de tipo de Vehiculo
				callScript("InformacionAdicional.D_list_TipoVehiculo1", tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			}

		}

		if (BooleanSeguro) {
			tmp[0] = Seguro;	// Ingreso de tipo de Seguro
			callScript("InformacionAdicional.D_list_Seguro", tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanTipoVehiculo) {
			tmp[0] = TipoVehiculo;	// Ingreso de tipo de Vehiculo
			callScript("InformacionAdicional.D_list_TipoVehiculo",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanTipoPlanSeguro 
				&& (Seguro.equals(accidentesPersonales)
						|| Seguro.equals(proteccionBienestarVida)
						|| Seguro.equals(proteccionIntegralFamilia))) {
			tmp[0] = PlanSeguro; // Ingreso de Plan de Seguro Dependiendo del tipo de Seguro y la l�nea
			callScript("InformacionAdicional.D_list_TipoPlan", tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanSeguroAutoProtegPlus) {
			tmp[0] = seguroAutoProtegPlus;
			callScript("InformacionAdicional.D_list_SeguroAutoProtegPlus", tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanCanalVenta) {
			tmp[0]=CanalDeVenta;	//Ingreso Canal Venta	
			callScript("InformacionAdicional.D_list_CanalDeVenta",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanCodigoCIIU) {
			tmp[0] = CodigoCIIU;	//Ingreso Codigo CIIU	
			tmp[1] = getSubString((String) args[3],0,4);
			callScript("InformacionAdicional.D_text_CodigoCIIU", tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (BooleanSeguroDeVida) {
			tmp[0]=SeguroDeVida;	// Ingreso Seguro de vida
			callScript("InformacionAdicional.D_list_SeguroDeVida",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}


		/** INFORME DETALLADO PDF */

		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - D_InformacionAdicional", doc);


		/** CONTINUAR A SIGUIENTE PANTALLA */

		/* Clic en bot�n siguiente y luego aceptar confirmando el valor del cr�dito */
		tmp[0]=getSubString((String) args[3],0,4);
		callScript("InformacionAdicional.D_button_Siguiente",tmp);
		callScript("InformacionAdicional.D_button_Aceptar_I",tmp); 
	}
}