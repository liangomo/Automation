package Scripts;
import java.awt.image.RenderedImage;
import java.io.IOException;
import com.lowagie.text.Document;
import resources.Scripts.N_InformacionCarteraFomentoHelper;

public class N_InformacionCarteraFomento extends N_InformacionCarteraFomentoHelper
{
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;
		
	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	String[] tmp = new String[2];
	
	/* Variables para los datos de la BD */
	String 	MargenRedescuento = new String(),			//Variable Margen de redescuento 
			NumeroAprobacion= new String(),				//Variable Numero de Aprobacion
			SubDestinoEconomico= new String(),			//Variable SubDestinoEconomico
			LineaFomento= new String(),					//Variable Linea de Fomento
			ValorTasaFomento= new String(),				//Variable Valor de la tasa de Fomento
			SignoTasaFomento= new String();				//Variable Signo de la tasa de Fomento

	/* Variables para definir campos habilitados de acuerdo a la l�nea */
	Boolean BooleanMargenRedescuento = false,	
			BooleanNumeroAprobacion= false,
			BooleanSubDestinoEconomico= false,
			BooleanLineaFomento= false,
			BooleanValorTasaFomento= false,
			BooleanSignoTasaFomento= false;


	public void testMain(Object[] args) throws IOException 
	{
		/** ASIGNACI�N DE VARIABLES */
		
		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		MargenRedescuento = (String) args[74];
		NumeroAprobacion = (String) args[75];
		SubDestinoEconomico = (String) args[76];
		LineaFomento = (String) args[77];
		ValorTasaFomento = (String) args[78];
		SignoTasaFomento = (String) args[79];
		
		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];


		/** VALIDACI�N DE CAMPOS HABILITADOS DEPENDIENDO DE LA L�NEA */
		
		/* Validaci�n de campos habilitados dependiendo de la l�nea */
		if (getSubString((String) args[3],0,4).equals("B300")) {
			BooleanMargenRedescuento = true; 
			BooleanNumeroAprobacion= true;
			BooleanSubDestinoEconomico= true;	
			BooleanLineaFomento= true;			
			BooleanValorTasaFomento= true;		
			BooleanSignoTasaFomento= true;	
		}


		/** INGRESO DE LOS DATOS B�SICOS DEL CR�DITO (Primera Pantalla) */
		
		if (BooleanMargenRedescuento) {
			tmp[0]=MargenRedescuento; // Ingresar margen de Redescuento
			callScript("InformacionCarteraFomento.text_MargenDeRedescuento",tmp);
		}

		if (BooleanNumeroAprobacion) {
			tmp[0]=NumeroAprobacion;
			callScript("InformacionCarteraFomento.text_NumeroAprobacion",tmp);
		}

		if (BooleanSubDestinoEconomico) {
			tmp[0]= SubDestinoEconomico;
			callScript("InformacionCarteraFomento.text_SubDestinoEconomico",tmp);
		}

		if (BooleanLineaFomento) {
			tmp[0]=LineaFomento;
			callScript("InformacionCarteraFomento.list_LineaFomento",tmp);
		}

		if (BooleanValorTasaFomento) {
			tmp[0]=ValorTasaFomento;
			callScript("InformacionCarteraFomento.text_ValorTasaFomento",tmp);
		}

		if (BooleanSignoTasaFomento) {
			tmp[0]=SignoTasaFomento;
			callScript("InformacionCarteraFomento.list_SignoTasaFomento",tmp);
		}

		
		/** INFORME DETALLADO PDF */
		
		/* Insertar texto al PDF */
		addTexto(args[2] + ": INFORMACI�N CARTERA FOMENTO" + "\n", doc);
		addTexto(args[2] + ": " + "L�nea Fomento: " + args[77] + "\n", doc);
		
		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�PortalDe(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - N_InfoCarteraFomento", doc);
		
		
		/** CONTINUAR A SIGUIENTE PANTALLA */
		
		/* Clic en bot�n Guardar */	
		callScript("InformacionCarteraFomento.button_Guardar");
	}
}