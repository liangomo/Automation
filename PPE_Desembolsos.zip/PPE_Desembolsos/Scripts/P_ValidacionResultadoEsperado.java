package Scripts;
import java.awt.image.RenderedImage;
import com.lowagie.text.Document;
import resources.Scripts.P_ValidacionResultadoEsperadoHelper;

public class P_ValidacionResultadoEsperado extends P_ValidacionResultadoEsperadoHelper
{
	/* 2015.12.30 - LGOMEZ11 - CVAPD00185243 Ajuste en captura en el m�dulo de desembolsos en PPE */

	/** INICIALIZACION DE VARIABLES: */
	
	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;
	
	/* Variables para los Logs */
	String resultadoObtenido = null;
	String veredicto = new String();
	boolean esCoincidente = false;

	public void testMain(Object[] args)  throws Exception 
	{
		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];
		
		Espera(2);
		
		/* Obtener el resultado de la transacci�n */
		resultadoObtenido = (String) (html_mesajeRespuestaDialog(ANY, LOADED).getProperty(".text"));

		/* Espera para identificar el resultado de la transacci�n */
		Espera(1);

		/* Comparar Resultado Obtenido vs. Resultado Esperado - Validaci�n de Veredicto */
		if(EvaluarExpresion((String)args[84], resultadoObtenido))
			veredicto = "EXITOSO";
		else
			veredicto = "FALLIDO";
		
		
		/** INFORME DETALLADO PDF */
		
		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�PortalDe(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - P_ValidacionResultadoEsperado", doc);
		
		/* Insertar texto al PDF */
		addTexto("\n" + args[2] + ": VALIDACI�N RESULTADO" + "\n", doc);
		addTexto("Resultado Obtenido: " + "\n" + resultadoObtenido + "\n\n", doc);
		addTexto("Veredicto: " + veredicto + "\n", doc);
		addTexto("-------------------------------------------------------------------" + "\n\n", doc);
		
		
		/** INFORME RESUMEN BASE DE DATOS */

		/* Insertar resultado en Base de Datos para el informe Resumen */
		querySQL("INSERT INTO PPE.ConsolidadosEjecucion VALUES('" + "PPE Desembolsos" + "','" + ObtenerA�o() + "','" + ObtenerMes() + "','" 
				+ args[85] +  "','" + args[86] +  "','" + args[2] +  "','" + args[3] +  "','" + args[84] +  "','"  
				+ resultadoObtenido +  "','" + veredicto + "','" 
				+ "C:\\tmp\\PPE_Desembolsos\\" + getSubString((String)args[3],0,4) +  "\\" + args[87] + ".pdf" + "')");
		
		
		/** CERRAR VENTANA DE RESULTADO FINAL DESEMBOLSO */
		if (button_oKbutton().isEnabled())
			button_oKbutton().click();
		else
			addTexto(args[2] + "Bot�n no Encontrado" + "\n", doc);
	}
}