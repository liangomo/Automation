package Scripts;
import java.awt.image.RenderedImage;
import java.io.IOException;
import com.lowagie.text.Document;
import resources.Scripts.L_ReservaNumerosCreditosHelper;

public class L_ReservaNumerosCreditos extends L_ReservaNumerosCreditosHelper
{
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;

	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	Object[] tmp = new Object[4];

	/* Variables para los datos de la BD */
	String lineaCredito= new String(); 	//Variable de L�nea de Cr�dito
	String tipoID= new String();		//Variable Tipo de Identificacion
	String numeroID= new String();  	//Variable Numero de Identificaci�n
	String oficina= new String();		//Variable Numero de la Oficina 
	String casoPrueba = new String();


	public void testMain(Object[] args) throws IOException 
	{
		/** ASIGNACI�N DE VARIABLES */

		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		if (getSubString((String) args[3],0,4).equals("B300")) { // Asignar variables si el producto es B300
			lineaCredito = (String) args[3];
			tipoID = (String) args[4];
			numeroID = (String) args[5];
			oficina = (String) args[10];
			casoPrueba = (String) args[2];
		}

		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];


		/** INGRESO AL LINK DE RESERVAR CR�DITO */

		/* DESEMBOLSOS >> LINEAS DE CREDITO >> RESERVAR CR�DITO */

		link_desembolsos().waitForExistence(); 
		link_desembolsos().click();

		link_l�neasDeCr�dito().waitForExistence();
		link_l�neasDeCr�dito().click();

		link_reservarCr�dito().waitForExistence();
		link_reservarCr�dito().click();


		/** INGRESO DE LOS DATOS B�SICOS DEL CR�DITO (Primera Pantalla Cr�ditos con Reserva) */

		tmp[0]=lineaCredito;
		callScript("ReservaNumerosCreditos.text_LineaCredito",tmp);

		tmp[0]=tipoID;
		callScript("ReservaNumerosCreditos.list_TipoID",tmp);

		tmp[0]=numeroID;
		callScript("ReservaNumerosCreditos.text_NumeroID",tmp);

		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

		tmp[0]=oficina;
		callScript("ReservaNumerosCreditos.text_Oficina",tmp);

		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

		/* Clic en Reservar N�mero */
		callScript("ReservaNumerosCreditos.button_ReservarNumero");

		/* Capturar N�mero de Reserva */
		String tpm = getSubString((String)html_mesajeRespuestaDialog().getProperty(".contentText"), 44, 58);
		String tpm1 = getSubString((String)html_mesajeRespuestaDialog().getProperty(".contentText"), 75, 89);
		System.out.println("Numero Activo: "+tpm); 
		System.out.println("Numero Pasivo: "+tpm1); 


		/** INFORME DETALLADO PDF */

		/* Insertar texto al PDF */
		addTexto(args[2] + ": RESERVA N�MEROS CR�DITO" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - L_ReservaNumCreditos", doc);


		/** CONTINUAR CON LA CAPTURA DEL CR�DITO */		

		/* Clic en bot�n OK */
		button_oKbutton().click();	

		/* Ir al link de Capturar Cr�dito con Reserva */
		link_capturarCr�ditoConReserva().waitForExistence();
		link_capturarCr�ditoConReserva().click();

		/* Buscar el n�mero de reserva para la captura de los datos */
		tmp[0] = numeroID;
		tmp[1] = tpm;
		tmp[2] = doc;
		tmp[3] = casoPrueba;
		callScript("Scripts.M_BuscarReserva",tmp);
	}
}