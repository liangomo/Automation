package Scripts;
import java.awt.image.RenderedImage;
import java.io.IOException;
import resources.Scripts.F_GarantiasHelper;
import com.lowagie.text.Document;

public class F_Garantias extends F_GarantiasHelper
{ 
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;

	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	String[] tmp = new String[11];

	/* Variables para los datos de la BD */
	String Garantia= new String(),		      //Variable de la Garantia
			PagareSiNo= new String(),	      //Variable de Pagare Si No
			NoGarantia= new String(),	      //Variable Numero de la garantia
			FNGSiNo= new String(),		      //Variable Fondo Nacional de Garnatias Si/No
			ProductoFNG= new String(),	      //Variable No Producto Fondo Nacional de Garantias 
			ComisionFNG= new String(),	      //Variable Comision Fondo Nacional de Garantias
			CoberturaFNG=new String(),	      //Variable Cobertura del Fondo Nacional de Garantias
			FAG = new String(), 			      //Variable FAG
			GarantiaMobiliaria= new String(),  //Variable Garantia Moviliaraia 
			TipoGarantiaMobiliaria= new String(),
			GarantiaAbiertaCerrada= new String(),
			NumeroGarantia= new String(),
			CantidadFolios= new String(),
			NumAle = "";

	/* Variables para definir campos habilitados de acuerdo a la l�nea */
	boolean BooleanGarantia=false,
			BooleanPagareSiNo= false,
			BooleanNoGarantia= false,
			BooleanFNGSiNo= false,
			BooleanProductoFNG= false,
			BooleanComisionFNG= false,
			BooleanCoberturaFNG=false,
			BooleanFAG=false,
			BooleanGarantiaMobiliaria=false,
			BooleanTipoGarantiaMobiliaria= true,
			BooleanGarantiaAbiertaCerrada= true,
			BooleanNumeroGarantia= true,
			BooleanCantidadFolios= true,
			BooleanNumeroFolios= true,
			BooleanNumeroFolios1= true,
			BooleanNumeroFolios2= true,
			BooleanNumeroFolios3= true,
			BooleanNumeroFolios4= true,
			BooleanNumeroFolios5= true,
			BooleanNumeroFolios6= true,
			BooleanNumeroFolios7= true,
			BooleanNumeroFolios8= true,
			booleanGarantiaMobNO = false;

	/* Variables Comparativas */
	String CompGarantiaIdonea="Idonea",		// Variable comparativa para Garantia Idonea
			CompGarantiaOtras="Otras",       // Variable comparativa para Garantia Otras
			CompGarantiaMobiliariaSi="Si",   // Variable comparativa para Garantia mobiliaria Si
			CompGarantiaMobiliariaNo="No",   // Variable comparativa para Garantia mobiliaria No
			CompFNGEMP001="EMP001 - Garantia empresarial multiproposito",	// Variable comparativa para FNG Garantia empresarial multiproposito
			CompFNGEMP050="EMP050 - Multiproposito corto plazo",				// Variable comparativa para FNG Multiproposito corto plazo
			CompFNGEMP061="EMP061 - Colombia Exporta � Modalidad Cr�dito";	// Variable comparativa para FNG Colombia Exporta - Modalidad Cr�dito


	public void testMain(Object[] args) throws IOException 
	{	
		/** ASIGNACI�N DE VARIABLES */

		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		Garantia = (String) args[26];		  
		PagareSiNo = (String) args[28];	      
		NoGarantia = (String) args[29];	      
		FNGSiNo = (String) args[30];		      
		ProductoFNG = (String) args[31];	       
		ComisionFNG = (String) args[32];	      
		CoberturaFNG = (String) args[33]; 
		FAG = (String) args[27]; 			  
		GarantiaMobiliaria = (String) args[34];
		TipoGarantiaMobiliaria = (String) args[35];
		GarantiaAbiertaCerrada = (String) args[36];
		NumeroGarantia = (String) args[37];
		CantidadFolios = (String) args[38];

		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];


		/** VALIDACI�N DE CAMPOS HABILITADOS DEPENDIENDO DE LA L�NEA */

		if (getSubString((String) args[3],0,4).equals("BB01")) {
			BooleanGarantia=true;
			BooleanGarantiaMobiliaria=true;		
		}

		if (getSubString((String) args[3],0,4).equals("BB27")) {
			BooleanGarantia=true;
			BooleanGarantiaMobiliaria=true;
		}

		if (getSubString((String) args[3],0,4).equals("B002")) {
			BooleanGarantia=true;
			//BooleanGarantiaMobiliaria=true;
		}

		if (getSubString((String) args[3],0,4).equals("B131")) {
			BooleanGarantia=true;
			BooleanGarantiaMobiliaria=true;
		}

		if (getSubString((String) args[3],0,4).equals("M002")) {
			BooleanGarantia=true;
			BooleanPagareSiNo=true;
			BooleanNoGarantia= true;
			BooleanFNGSiNo= true;
			BooleanProductoFNG= true;
			BooleanComisionFNG= true;
			BooleanCoberturaFNG=true;
			BooleanGarantiaMobiliaria=true;
		}

		if (getSubString((String) args[3],0,4).equals("B300")) {
			BooleanGarantia=true;
			BooleanFAG=true;
			BooleanGarantiaMobiliaria=true;
		}

		if (getSubString((String) args[3],0,4).equals("M007")) {
			BooleanGarantia=true;
			BooleanPagareSiNo=true;
			BooleanNoGarantia= true;
			BooleanFNGSiNo= true;
			BooleanProductoFNG= true;
			BooleanComisionFNG= true;
			BooleanCoberturaFNG=true;
			BooleanGarantiaMobiliaria=true;
		}

		if (getSubString((String) args[3],0,4).equals("BB15")) {
			BooleanGarantia=true;
			BooleanGarantiaMobiliaria=true;
		}

		if (getSubString((String) args[3],0,4).equals("M039")) {
			BooleanGarantia=true;
			BooleanPagareSiNo=true;
			BooleanNoGarantia= true;
			BooleanFNGSiNo= true;
			BooleanProductoFNG= true;
			BooleanComisionFNG= true;
			BooleanCoberturaFNG=true;
			BooleanGarantiaMobiliaria=true;
		}

		if (getSubString((String) args[3],0,4).equals("BP14")) {
			BooleanGarantia=true;
			BooleanGarantiaMobiliaria=true;
		}
		
		if (getSubString((String) args[3],0,4).equals("BB04")) {
			BooleanGarantia=true;
			BooleanFNGSiNo= true;
			BooleanProductoFNG= true;
			BooleanCoberturaFNG=true;
			BooleanGarantiaMobiliaria=true;
		}


		/** INGRESO DE LOS DATOS DE GARANT�AS (Cuarta Pantalla) */

		// Ingreso de garantia
		if (BooleanGarantia) {
			tmp[0]=Garantia;	// Ingreso de tipo de Garantia
			tmp[1]=getSubString((String) args[3],0,4);
			callScript("Garantia.list_Garantia",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		/* Validaci�n si la garant�a es = Otras */
		if (Garantia.equals(CompGarantiaOtras)) { // Validacion si la garantia es igual a "Otras"
			if (BooleanPagareSiNo) {
				tmp[0] = PagareSiNo; // Ingresar Pagare Si/No
				callScript("Garantia.list_Pagare", tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

				if (PagareSiNo.equals("Si")) {
					tmp[0] = NoGarantia; // Ingreso del numero de Garantia si la variable del pagare es "Si"
					callScript("Garantia.text_Pagare",tmp);
				}
			}
		}

		/* Validaci�n si la garant�a es = Idonea */
		if (Garantia.equals(CompGarantiaIdonea)) { // Validaci�n si la garantia es igual a "Idoneas"

			if (BooleanFNGSiNo) {
				tmp[0]=FNGSiNo; // Ingresar Si/No Fondo Nacional de Garantias
				callScript("Garantia.list_FNG",tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");


				if (FNGSiNo.equals("Si")) { // Validacion si es Fondo Nacional de Garantias 
					if (BooleanProductoFNG) {
						tmp[0]=ProductoFNG; // Ingresar Producto FNG
						callScript("Garantia.list_ProductoComisionFNG",tmp);
						browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");

						/* 2016.01.27 - LGOMEZ11 - CVAPD00195785 Deshabilitar servicio PPE */
						/*if (!ProductoFNG.equals(CompFNGEMP061)) // Validacion si el Producto de FNG es EMP061 - Colombia Exporta � Modalidad Cr�dito
						{
							tmp[0]=CoberturaFNG; // Ingreso de Cobertura de Fondo Nacional de Garantias 
							callScript("Garantia.text_ValorCoberturaFNG",tmp);
						}*/
						/*****/
						tmp[0]=CoberturaFNG; // Ingreso de Cobertura de Fondo Nacional de Garantias 
						callScript("Garantia.text_ValorCoberturaFNG",tmp);
						/*****/
					}	
				}
			}



			if (BooleanFAG) {

				tmp[0]=FAG; // Ingresar Si/No FAG
				callScript("Garantia.list_FAG",tmp);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			}

		}

		/* Ingreso a Garantia mobiliaria Si/No */
		if (BooleanGarantiaMobiliaria) {
			tmp[0]= GarantiaMobiliaria;
			tmp[1] = getSubString((String) args[3],0,4);

			callScript("GarantiaMobiliaria.Garantia_Mobiliaria",tmp);

			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}
		//Valida que garantia mobiliaria es Si
		if (GarantiaMobiliaria.equals(CompGarantiaMobiliariaSi)) {
			
			tmp[0]= TipoGarantiaMobiliaria;
			callScript("GarantiaMobiliaria.TipoGarantiaMobiliaria",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			
			tmp[0]=GarantiaAbiertaCerrada;
			callScript("GarantiaMobiliaria.GarantiaAbiertaCerrada",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			
			tmp[0]=NumeroGarantia;
			callScript("GarantiaMobiliaria.NoGarantia",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			
			tmp[0]=CantidadFolios;
			callScript("GarantiaMobiliaria.CantidadFolios",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			
			/* Controla el numero de folios que se van a ejecutar */
			text_digiteElN�meroDeFolio().click();

			for (int i = 0; i < Integer.parseInt(CantidadFolios); i++) {
				tmp[0] = GeneracionNumAle();
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tmp[0] + "{TAB}");
			}

		} else {

			booleanGarantiaMobNO = true;
		}	


		/** INFORME DETALLADO PDF */

		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - F_Garant�as", doc);


		/** CONTINUAR A SIGUIENTE PANTALLA */

		/* Clic en el bot�n Siguiente */
		tmp[0]=getSubString((String) args[3],0,4);
		callScript("Garantia.button_siguiente",tmp);

		/* Si Garant�a Mobiliaria = No aparece mensaje de aceptaci�n */
		if (booleanGarantiaMobNO) {

			tmp[0]=getSubString((String) args[3],0,4);
			callScript("Garantia.button_Aceptar_F",tmp);
		}

	}
}