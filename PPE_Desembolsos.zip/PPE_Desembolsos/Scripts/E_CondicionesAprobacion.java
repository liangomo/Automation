package Scripts;
import java.awt.image.RenderedImage;
import java.io.IOException;
import resources.Scripts.E_CondicionesAprobacionHelper;
import com.lowagie.text.Document;

public class E_CondicionesAprobacion extends E_CondicionesAprobacionHelper
{	
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;
		
	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	String[] tmp = new String[2];
	
	/* Variables para los datos de la BD */
	String 	TipoTasa= new String(),					//Variable de Tipo de Tasa
			SignoTasa= new String(),				//Variable de Signo de Tasa
			ValorTasa= new String(),				//Variable de Valor Tasa
			PeriodoPagoIntereses= new String(),		//Variable de Periodo Pago de Intereses
			ValorCuotaCapital= new String(),		//Variable de Valor Cuota Capital
			PeriodoPagoCapital= new String(),		//Variable de Periodo Pago de Capital 
			PeriodoGracia= new String(),			//Variable de Periodo de Gracia
			TipoPlan= new String(),					//Variable de Tipo del Plan 
			PlanesEspeciales= new String();			//Variable de Modalidad de Pago de Intereses

	/* Variables para definir campos habilitados de acuerdo a la l�nea */
	boolean booleanTipoTasa=false,
			booleanSignoTasa=false,
			booleanValorTasa=false,
			booleanPeriodoPagoIntereses=false,
			booleanValorCuotaCapital=false,
			booleanPeriodoPagoCapital=false,
			booleanPeriodoGracia=false,
			booleanTipoPlan=false,
			booleanPlanesEspeciales=false;

	
	public void testMain(Object[] args) throws IOException 
	{
		/** ASIGNACI�N DE VARIABLES */

		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		TipoTasa = (String) args[17];
		SignoTasa = (String) args[18];
		ValorTasa = (String) args[19];
		PeriodoPagoIntereses = (String) args[22];
		ValorCuotaCapital = (String) args[23];
		PeriodoPagoCapital = (String) args[24];
		PeriodoGracia = (String) args[25];
		TipoPlan = (String) args[20];
		PlanesEspeciales = (String) args[21];
		
		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];


		/** VALIDACI�N DE CAMPOS HABILITADOS DEPENDIENDO DE LA L�NEA */

		if (getSubString((String) args[3],0,4).equals("BB01")) {						
			booleanSignoTasa=true;
			booleanValorTasa=true;
		}

		if (getSubString((String) args[3],0,4).equals("BB27")) {
			booleanValorTasa=true;	
		}

		if (getSubString((String) args[3],0,4).equals("B002")) {
			// No se realiza ninga modificacion para este producto
		}

		if (getSubString((String) args[3],0,4).equals("B131")) {
			booleanValorTasa=true;
		}

		if (getSubString((String) args[3],0,4).equals("M002")) {
			booleanTipoTasa=true;
			booleanSignoTasa=true;
			booleanValorTasa=true;
			booleanPeriodoPagoIntereses=true;
			booleanPeriodoPagoCapital=true;
			booleanPeriodoGracia=false;
		}

		if (getSubString((String) args[3],0,4).equals("B300")) {
			booleanSignoTasa=true;
			booleanValorTasa=true;
			booleanPeriodoPagoIntereses=true;
			booleanValorCuotaCapital=true;
			booleanPeriodoPagoCapital=true;
			booleanPeriodoGracia=true;
		}

		if (getSubString((String) args[3],0,4).equals("M007")) {
			booleanTipoTasa=true;
			booleanSignoTasa=true;
			booleanValorTasa=true;
			booleanPeriodoPagoIntereses=true;
			booleanPeriodoPagoCapital=true;
			booleanPeriodoGracia=false;
		}

		if (getSubString((String) args[3],0,4).equals("BB15")) {
			booleanSignoTasa=true;
			booleanValorTasa=true;
			//booleanTipoPlan=true;
			//booleanPlanesEspeciales=true;
		}

		if (getSubString((String) args[3],0,4).equals("M039")) {
			booleanTipoTasa=true;
			booleanSignoTasa=true;
			booleanValorTasa=true;
			booleanPeriodoPagoIntereses=true;
			booleanPeriodoPagoCapital=true;
			booleanPeriodoGracia=false;
		}

		if (getSubString((String) args[3],0,4).equals("BP14")) {
			booleanSignoTasa=true;
		}
		
		if (getSubString((String) args[3],0,4).equals("BB04")) {
			
			booleanSignoTasa=true;
			booleanValorTasa=true;
			booleanPeriodoGracia=false;
		}

		/** INGRESO DE DATOS EN CONDICIONES DE APROBACI�N (Tercera Pantalla)*/
		
		if (booleanTipoTasa) {
			tmp[0]=TipoTasa; // Cambio de tipo de tasa
			callScript("CondicionesAprobacion.list_TipoTasa",tmp);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			//Ventana emergente que aparece para los tipos de tasa IPC, IBR-1M, IBR-3M y TBR
			if (TipoTasa.equals("IPC")||TipoTasa.equals("IBR-1M")||TipoTasa.equals("IBR-3M")||TipoTasa.equals("TBR")) {
				callScript("CondicionesAprobacion.button_Ok_C");
			}
		}

		if (booleanSignoTasa) {
			tmp[0]=SignoTasa;	// Cambio de signo de tasa
			tmp[1]=getSubString((String) args[3],0,4);
			callScript("CondicionesAprobacion.list_SignoTasa",tmp);
		}

		if (booleanValorTasa) {
			tmp[0]=ValorTasa; // Ingreso de Valor de la Tasa
			tmp[1]=getSubString((String) args[3],0,4);
			callScript("CondicionesAprobacion.text_ValorTasa",tmp);
		}
	
		if (booleanTipoPlan) {
			tmp[0]= TipoPlan;
			callScript("CondicionesAprobacion.list_TipoPlan",tmp);

			if (TipoPlan.equals("Plan Especial")||TipoPlan.equals("Plan Normal Periodo de Gracia")) {
				tmp[0]=PlanesEspeciales;
				callScript("CondicionesAprobacion.list_PlanesEspeciales",tmp);
			}
		}

		if (booleanPeriodoPagoIntereses) {
			tmp[0]=PeriodoPagoIntereses; // Ingreso de Periodo Pago de Intereses
			tmp[1]=getSubString((String) args[3],0,4);
			callScript("CondicionesAprobacion.list_PeriodoPagoIntereses",tmp);

		}

		if (booleanValorCuotaCapital) {
			tmp[0]=ValorCuotaCapital; // Ingreso de Valor Cuota Capital
			callScript("CondicionesAprobacion.text_ValorCuotaCapital",tmp);
		}

		if (booleanPeriodoPagoCapital) {
			tmp[0]=PeriodoPagoCapital; // ingreso de Periodo de Pago a Capital
			tmp[1]=getSubString((String) args[3],0,4);
			callScript("CondicionesAprobacion.list_PeriodoPagoCapital",tmp);
		}
		
		
		/** INFORME DETALLADO PDF */
		
		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - E_CodicionesAprobacion", doc);
		
		
		/** CONTINUAR A SIGUIENTE PANTALLA */
		
		 /* Clic en boton Siguiente */
		tmp[0]=getSubString((String) args[3],0,4);
		callScript("CondicionesAprobacion.button_Siguiente",tmp);
	}
}