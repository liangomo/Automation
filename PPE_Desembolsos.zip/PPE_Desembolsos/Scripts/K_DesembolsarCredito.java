package Scripts;
import java.awt.image.RenderedImage;

import resources.Scripts.K_DesembolsarCreditoHelper;

import com.lowagie.text.Document;

public class K_DesembolsarCredito extends K_DesembolsarCreditoHelper
{
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;
		
	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	String[] tmp = new String[1];
	
	/* Variables para los datos de la BD */
	String ObservacionesGMF= new String();		// Variable de Observaciones GMF
	String DestinoDesembolso= new String();		// Variable de Credito a Abonar

	/* Variables para definir campos habilitados de acuerdo a la l�nea */
	boolean booleanvalidaci�nGMF= false; 		
	boolean booleanvalidaci�nCreditoAbonar= false; 	
	
	/* Variables Comparativas */
	String trasladoSEBRA = "Traslado SEBRA";


	public void testMain(Object[] args) throws Exception 
	{
		/** ASIGNACI�N DE VARIABLES */
		
		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		ObservacionesGMF=(String) args[64];
		DestinoDesembolso = (String) args[42];
		
		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];
		
		
		/** VALIDACI�N DE CAMPOS HABILITADOS DEPENDIENDO DE LA L�NEA */

		/* Asignar variables si el producto es M002 */
		if (getSubString((String) args[3],0,4).equals("M002") 
				&& DestinoDesembolso.equals(trasladoSEBRA)) { 
			booleanvalidaci�nGMF= true; 
			booleanvalidaci�nCreditoAbonar = true;
			
			/* Asignar variables si el producto es M007 o M039 */
		} else if (getSubString((String) args[3],0,4).equals("M007")
				|| getSubString((String) args[3],0,4).equals("M039")) {
			
			booleanvalidaci�nGMF= true; 
		}

		
		/** CLIC EN SIGUIENTE A LAS 5 PANTALLAS */

		/* Pantalla Datos Principales del cr�dito */
		callScript("DesembolsarCredito.button_Siguiente_C");

		/* Pantalla Informacion adicional */
		callScript("DesembolsarCredito.button_Siguiente_D");

		/* Pantalla Condiciones de Aprobacion */
		callScript("DesembolsarCredito.button_Siguiente_E");

		/* Pantalla Garantias */
		callScript("DesembolsarCredito.button_Siguiente_F");

		/* Pantalla Datos Desembolso */
		tmp[0] = getSubString((String) args[3],0,4);
		callScript("DesembolsarCredito.button_Siguiente_G", tmp);

		/* Pantalla Informacion Cartera de Fomento para B300 */
		if (getSubString((String) args[3],0,4).equals("B300")) {
			callScript("DesembolsarCredito.button_Siguiente_N");
		}

		/* Pantalla Opcion Desembolso - Selecciona la opcion "Desembolsar" */
		callScript("Desembolso.list_Desembolso");

		
		/** INGRESO DE OBSERVACIONES SI APLICA (Pantalla del Desembolso) */

		if (booleanvalidaci�nGMF) {

			if (ObservacionesGMF != null) {
				text_observacionesGMFTextArea().click();
				browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT_FLAGS).inputChars(ObservacionesGMF);

				text_conceptoInput().click();
				browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT_FLAGS).inputChars(ObservacionesGMF);
			}
		}
		
		
		/** INFORME DETALLADO PDF */
		
		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - K_DesembolsarCredito", doc);
		
		
		/** CONTINUAR A PANTALLA DE VALIDACI�N DE CAMPOS */

		/* Clic en Bot�n Aceptar */
		callScript("Desembolso.K_button_Aceptar");
	}
}