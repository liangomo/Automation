package Scripts;
import resources.Scripts.H_CerrarSesionHelper;

public class H_CerrarSesion extends H_CerrarSesionHelper
{

	public void testMain(Object[] args) 
	{
		/*
		 * Dar click en Cerrar sesion
		 * */
	
		link_cerrarSesi�n().waitForExistence();	
		link_cerrarSesi�n().click();
	
		/*
		 * Confirmar cierre de sesion
		 * */
		
		button_siSalirYCerrarbutton().waitForExistence();
		button_siSalirYCerrarbutton().click();
	}
}