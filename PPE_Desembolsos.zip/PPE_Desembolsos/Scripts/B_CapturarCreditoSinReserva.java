package Scripts;
import resources.Scripts.B_CapturarCreditoSinReservaHelper;

public class B_CapturarCreditoSinReserva extends B_CapturarCreditoSinReservaHelper
{
	
	public void testMain(Object[] args) 
	{
		/*
		 * Abre el menu de Desembolso sin Reserva
		 * Validar que el usuario tenga los permisos de Capturar cr�dito
		 * */		
		
		link_desembolsos(ANY,LOADED).waitForExistence();	
		link_desembolsos(ANY,LOADED).click();
		
		link_l�neasDeCr�dito(ANY,LOADED).waitForExistence();
		link_l�neasDeCr�dito(ANY,LOADED).click();
		
		link_capturarCr�ditosSinReserv(ANY,LOADED).waitForExistence();
		link_capturarCr�ditosSinReserv(ANY,LOADED).click();

	}
}