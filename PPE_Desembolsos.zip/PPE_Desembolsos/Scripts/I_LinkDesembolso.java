package Scripts;
import resources.Scripts.I_LinkDesembolsoHelper;

public class I_LinkDesembolso extends I_LinkDesembolsoHelper
{
	
	public void testMain(Object[] args) 
	{
		/*
		 * Ingresa al Menu de Desembolsos > Desembolsos
		 * Se da Click para reiniciar el menu inicial
		 * */
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{F5}");
		
		link_desembolsos().waitForExistence();
		link_desembolsos().click();
		
		link_l�neasDeCr�dito().waitForExistence();
		link_l�neasDeCr�dito().click();
		
		link_desembolsar().waitForExistence();
		link_desembolsar().click();
		
	}
}