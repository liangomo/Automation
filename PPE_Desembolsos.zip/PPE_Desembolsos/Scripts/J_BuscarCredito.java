package Scripts;
import java.awt.image.RenderedImage;
import java.io.IOException;
import com.lowagie.text.Document;
import resources.Scripts.J_BuscarCreditoHelper;

public class J_BuscarCredito extends J_BuscarCreditoHelper
{
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;

	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	String[] tmp = new String[2];

	/* Variables para los datos de la BD */
	String NoIdentificacion = new String(),
			usuario = new String();


	public void testMain(Object[] args) throws IOException 
	{		
		/** ASIGNACI�N DE VARIABLES */

		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		NoIdentificacion=(String) args[5];
		usuario = (String) args[80];
		
		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];


		/** INGRESO DE LOS DATOS PARA LA B�SQUEDA DEL CREDITO CAPTURADO (Rol Desembolsador) */
		
		//Se ingresa el usuario con el que se esten haciendo los desembolsos
		tmp[0]=usuario;
		callScript("BuscarCredito.text_Usuario", tmp);

		// Ingresa el numero de identificacion del cliente 
		tmp[0]=NoIdentificacion;
		callScript("BuscarCredito.text_Identificacion", tmp);

		// Organiza las capturas de la mas reciente a la mas antigua
		callScript("BuscarCredito.table_OrganizarFecha");
		
		
		/** INFORME DETALLADO PDF */
		
		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�PortalDe(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - J_BuscarCredito", doc);
		
		
		/** SELECCIONAR CREDITO CAPTURADO */

		/* Selecciona el primer registro */
		Espera(1);
		table_capturadosTable().click(atCell(atRow(atIndex(2)), atColumn(atIndex(0))));
	}
}