package Scripts;
import java.awt.image.RenderedImage;
import com.lowagie.text.Document;
import resources.Scripts.M_BuscarReservaHelper;

public class M_BuscarReserva extends M_BuscarReservaHelper
{
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;

	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	String[] tmp = new String[1];	

	/* Variables para los datos de la BD */
	String NoIdentificacion = new String();


	public void testMain(Object[] args) 
	{
		/** ASIGNACI�N DE VARIABLES */
		
		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		NoIdentificacion=(String) args[0];
		
		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[2];

		
		/** INGRESO DE LOS DATOS B�SICOS PARA LA B�SQUEDA DEL CR�DITO RESERVADO */
		
		/* NUMERO DEL CREDITO */
		tmp[0]=(String) args[1];
		callScript("BuscarReserva.text_NumeroReserva",tmp);


		/** INFORME DETALLADO PDF */

		/* Insertar texto al PDF */
		addTexto(args[3] + ": B�SQUEDA DE CR�DITO RESERVADO" + "\n", doc);

		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�PortalDe(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[3] + " - M_BuscarReserva", doc);


		/** SELECCIONAR CREDITO RESERVADO */

		/* Seleccionar RadioButton */
		radioButton__8capturadoCheck().click();
	}
}