package Scripts;
import java.awt.image.RenderedImage;
import java.io.IOException;
import resources.Scripts.C_DatosPrincipalesDelCreditoHelper;
import com.lowagie.text.Document;


public class C_DatosPrincipalesDelCredito extends C_DatosPrincipalesDelCreditoHelper
{
	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;
		
	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	String[] tmp = new String[1];
	
	/* Variables para los datos de la BD */
	String lineaCredito= new String(); 				//Variable de L�nea de Cr�dito
	String tipoID= new String();					//Variable Tipo de Identificacion
	String numeroID= new String();					//Variable Numero de Identificaci�n
	
	/* Variables para definir campos habilitados de acuerdo a la l�nea */
	Boolean booleanValidacionPN = false,			// Variable de tipo Booleano que indica realizar validacion de Persona Natural
			booleanlineaCredito = false,			// Variable de tipo Booleano que indica ingresar lineaCredito
			booleantipoID = false,					// Variable de tipo Booleano que indica ingresar TipoID
			booleannumeroID = false,				// Variable de tipo Booleano que indica ingresar numeroID
			booleanButtonCreditoSinReserva = false; // Variable de tipo Booleano que indica que el boton siguiente es de un credito sin reserva
			
	/* Vector que agrupa todos los tipos de identificacion de Persona Natural */
	String[] tiposPN = new String[5];
	
	
	public void testMain(Object[] args) throws IOException 
	{
		
		/** ASIGNACI�N DE VARIABLES */
		tiposPN = llenarconPN(tiposPN); 			// Llenar array tipos de Persona Natural
		
		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];
		
		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		lineaCredito = (String) args[3];
		tipoID = (String) args[4];
		numeroID = (String) args[5];
		
		
		/** VALIDACI�N DE CAMPOS HABILITADOS DEPENDIENDO DE LA L�NEA */
			
		if (getSubString((String) args[3],0,4).equals("BB01")) { 	
			booleanlineaCredito= true;
			booleantipoID=true;
			booleannumeroID=true;
			booleanValidacionPN= true;
		}
				
		if (getSubString((String) args[3],0,4).equals("BB27")) {				
			booleanlineaCredito= true;
			booleantipoID=true;
			booleannumeroID=true;
			booleanValidacionPN= false;
		}
				
		if (getSubString((String) args[3],0,4).equals("B002")) {
			booleanlineaCredito= true;
			booleantipoID=true;
			booleannumeroID=true;
			booleanValidacionPN= true;	
		}
		
		if (getSubString((String) args[3],0,4).equals("B131")) {
			booleanlineaCredito= true;
			booleantipoID=true;
			booleannumeroID=true;
			booleanValidacionPN= false;
		}
	
		if (getSubString((String) args[3],0,4).equals("M002")) {
			booleanlineaCredito= true;
			booleantipoID=true;
			booleannumeroID=true;
			booleanValidacionPN= false;
		}
				
		if (getSubString((String) args[3],0,4).equals("B300")) {
			booleanValidacionPN= false;
			booleanButtonCreditoSinReserva=true;
		}
		
		if (getSubString((String) args[3],0,4).equals("M007")) {
			booleanlineaCredito= true;
			booleantipoID=true;
			booleannumeroID=true;
			booleanValidacionPN= false;		
		}
		
		if (getSubString((String) args[3],0,4).equals("BB15")) {
			booleanlineaCredito= true;
			booleantipoID=true;
			booleannumeroID=true;
			booleanValidacionPN= false;		
		}
		
		if (getSubString((String) args[3],0,4).equals("M039")) {
			booleanlineaCredito= true;
			booleantipoID=true;
			booleannumeroID=true;
			booleanValidacionPN= false;		
		}
		
		if (getSubString((String) args[3],0,4).equals("BP14")) {
			booleanlineaCredito= true;
			booleantipoID=true;
			booleannumeroID=true;
			booleanValidacionPN= true;
		}
		
		if (getSubString((String) args[3],0,4).equals("BB04")) {
			booleanlineaCredito= true;
			booleantipoID=true;
			booleannumeroID=true;
			booleanValidacionPN= true;
		}
		
		/**  URGENTEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
		 *RECOEMDNACION REVISAR LA LOGICA INVERSA O IMPLEMENTACION DE O (||) 
		 */
		
		
		/** INGRESO DE LOS DATOS B�SICOS DEL CR�DITO (Primera Pantalla) */
		
		/* Ingreso L�nea de Cr�dito */
		if (booleanlineaCredito) {
			tmp[0] = lineaCredito;	// Ingreso L�nea de Cr�dito
			callScript("DatosPrincipalesDelCredito.C_text_LineaCredito", tmp);

		}
		
		/* Ingreso Tipo Identificacion */		
		if (booleantipoID) {
			tmp[0] = tipoID;
			callScript("DatosPrincipalesDelCredito.list_tipoId", tmp);
		}
		
		/* Validacion de que sea Persona Natural, siempre y cuando ValidacionPN sea verdadera */
		if (booleanValidacionPN) {
			
			if (Comparacion(tiposPN, tipoID)) {
				
				// Ingreso de Numero de identificacion 
				tmp[0]=numeroID;
				callScript("DatosPrincipalesDelCredito.text_numeroId",tmp);
							
				//Digitar TAB
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");	
				
				
				/** INFORME DETALLADO PDF */
				
				/* Capturar im�gen y guardar en PDF */
				imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
				guardarImagen(imagen, args[2] + " - C_DatosPrincipales", doc);
			
				/* Clic en bot�n siguiente */	
				tmp[0]=getSubString((String) args[3],0,4);
				callScript("DatosPrincipalesDelCredito.C_button_Siguiente",tmp);
			
			}
			// Cuando no es persona Natural y ValidacionPN es verdadera
			else {
				
				//Insertar en Log de RFT
				logInfo("Mensaje: "+ html_mesajeRespuestaDialog().getProperty(".contentText"), browser_htmlBrowser(ANY, LOADED).getScreenSnapshot()); 
				
				
				/** INFORME DETALLADO PDF */
				
				/* Capturar im�gen y guardar en PDF */
				imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
				guardarImagen(imagen, args[2] + " - C_DatosPrincipales", doc);
				
				button_oKbutton().click(); // Click en boton OK
			}
			
		} else {
			
			// Cuando ValidacionPN es falsa
			if (booleannumeroID) {
				// Ingreso de Numero de identificacion 
				tmp[0] = numeroID;
				callScript("DatosPrincipalesDelCredito.text_numeroId", tmp);
				browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT_FLAGS).inputKeys("{TAB}"); 
			}
			
			
			/** INFORME DETALLADO PDF */
			
			/* Capturar im�gen y guardar en PDF */
			imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
			guardarImagen(imagen, args[2] + " - C_DatosPrincipales", doc);
			
			
			/** CONTINUAR A SIGUIENTE PANTALLA */
			
			/* Clic en bot�n siguiente */					
			tmp[0]=getSubString((String) args[3],0,4);
			callScript("DatosPrincipalesDelCredito.C_button_Siguiente",tmp); 
		}
	}
}