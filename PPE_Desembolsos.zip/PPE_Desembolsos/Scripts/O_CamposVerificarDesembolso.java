package Scripts;
import java.awt.image.RenderedImage;
import java.io.IOException;
import com.lowagie.text.Document;
import resources.Scripts.O_CamposVerificarDesembolsoHelper;
/**
 * Description   : Functional Test Script
 * @author LGOMEZ11
 */
public class O_CamposVerificarDesembolso extends O_CamposVerificarDesembolsoHelper
{

	/* 2015.12.30 - LGOMEZ11 - CVAPD00185243 Ajuste en captura en el m�dulo de desembolsos en PPE */

	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;

	/* Variable temporal para pasar informacion a los Scripts en los callscript */
	String[] tmp = new String[4];

	/* Variables para los datos de la BD */
	String 	lineaCredito = new String(),			//Variable LineaCredito
			valorCredito = new String(), 			//Variable ValorCredito
			valorOriginalCredito = new String(),
			cambiarFechaPago = new String(),		//Variable CambiarFechaPago
			primerFechaPago = new String(), 		//Variable PrimerFechaPago
			oficina = new String(), 			    //Variable Oficina
			plazoCredito =new String(),             //Variable Plazo Credito
			seguro = new String(),                  //Variable Seguro
			planSeguro = new String(),
			tipoTasa = new String(),  				//Variable TipoTasa
			valorTasa = new String(),				//Variable ValorTasa
			destinoDesembolso = new String(), 		//Variable DestinoDesembolso
			numCuentaDesembolso = new String(),  //Variable N�meroCuentaDesembolso
			numCreditoAbonar = new String(),     //Variable N�meroCreditoAbonar
			noIdentificacion = new String(), 		//Variable 
			tipoID_ChequeGerencia = new String(), 	//Variable 
			idChequeGerencia = new String(),		//Variable NumeroChequeGerencia
			tipoIDCuentaContable = new String(), 	//Variable TipoIdentificacion
			idCuentaContable = new String(),		//Variable NumeroIdentificacion
			tipoAbonoSEBRA = new String(), 			//Variable 
			portafolio = new String(), 				//Variable 
			tipoIDDestinatarioSEBRA = new String(), //Variable 
			noIDDestinatarioSEBRA = new String(), 	//Variable 
			tipoProductoDestino = new String(), 	//Variable 
			noProductoDestino = new String(), 		//Variable 
			titularDestino = new String(), 			//Variable 
			presentaCertificacion = new String(),	//Variable PresentaCertificacion
			cobroGMF = new String(),				//Variable CobroGMF
			numCtaDesembolsoSebra = new String(),	//Variable CobroGMF
			convenio = new String(), 				//Variable Convenio
			seguroAutoProtegPlus = new String(), 	// Variable Seguro Auto Protegido Plus

			// Aplica unicamente para validaci�n de fechas B300
			periodoPagoIntereses= new String();	//Variable de Periodo Pago de Intereses


	/* Variables para definir campos habilitados de acuerdo a la l�nea */
	boolean booleanLineaCredito = false,	
			booleanValorCredito = false,
			booleanValorOriginalCredito = false,
			booleanCambiarFechaPago = false,
			booleanPrimerFechaPagoLibre = false,
			booleanPrimerFechaPagoLista = false,
			booleanOficina = false,
			booleanPlazoCreditoLibre = false,
			booleanPlazoCreditoLista = false,
			booleanSeguro = false,
			booleanTipoTasa = false,
			booleanValorTasa = false,
			booleanNumeroCreditoAbonar = false,
			booleanDestinoDesembolso = false,
			booleanNumCuentaDesembolso = false,
			booleantipoID_ChequeGerencia=false,
			booleanIdChequeGerencia=false,
			booleantipoIDCuentaContable = false,
			booleanIdCuentaContable = false,
			booleanPresentaCertificacion = false,
			booleanNumeroConvenio = false,
			booleanCobroGMF = false,
			booleanPeriodoPagoIntereses= false,
			booleanNumCtaDesembolsoSebra=false,
			booleanTipoPlanSeguro=false,
			booleanConvenio= false,
			booleanSeguroAutoProtegPlus = false;

	/* Variables Comparativas */
	String cuentaCorriente="Cuentas corrientes";		// Variable comparativa Cuentas corrientes
	String cuentaAhorros="Cuentas ahorros";				// Variable comparativa Cuentas ahorros
	String chequeGerencia="Cheque gerencia";			// Variable comparativa Cheque gerencia
	String otrosCuentaContable="Otros(Cuenta Contable)";// Variable comparativa Otros(Cuenta Contable)
	String abonoACredito="Abono a Credito";				// Variable comparativa Abono a Credito
	String trasladoSebra="Traslado SEBRA";				// Variable comparativa Traslado SEBRA
	String si = "si"; //Variable cambio de fecha primer pago l�neas Liquidez
	String no = "no"; //Variable cambio de fecha primer pago l�neas Liquidez
	String 	AccidentesPersonales ="Accidentes Personales";


	public void testMain(Object[] args) throws IOException 
	{
		/** ASIGNACI�N DE VARIABLES */
		
		/* Asignacion de variables de la tabla de la Base de datos a variables locales */
		lineaCredito = (String) args[3];
		valorCredito = (String) args[6];		
		valorOriginalCredito = (String) args[6];
		cambiarFechaPago = (String) args[7];	
		primerFechaPago = (String) args[8];	
		oficina = (String) args[10];			
		plazoCredito = (String) args[13];
		seguro = (String) args[15];
		planSeguro = (String) args[65];
		tipoTasa = (String) args[17];			
		valorTasa = (String) args[19];			
		destinoDesembolso = (String) args[42];	
		numCuentaDesembolso = (String) args[43];
		numCreditoAbonar = (String) args[50];
		noIdentificacion = (String) args[5];	
		tipoID_ChequeGerencia = (String) args[45];
		idChequeGerencia = (String) args[46];	
		tipoIDCuentaContable = (String) args[47];
		idCuentaContable = (String) args[48];	
		tipoAbonoSEBRA = (String) args[57];		
		portafolio = (String) args[58];			
		tipoIDDestinatarioSEBRA = (String) args[59];
		noIDDestinatarioSEBRA = (String) args[60];
		tipoProductoDestino = (String) args[61];
		noProductoDestino = (String) args[62];	
		titularDestino = (String) args[63];		
		presentaCertificacion = (String) args[51];
		cobroGMF = (String) args[44];			
		numCtaDesembolsoSebra = (String) args[56];
		convenio = (String) args[49];			
		seguroAutoProtegPlus = (String) args[73];
		periodoPagoIntereses = (String) args[22];
		
		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];

		
		/** VALIDACI�N DE CAMPOS HABILITADOS DEPENDIENDO DE LA L�NEA */

		/* Asignar variables si el producto es BB01 */
		if (getSubString((String) args[3],0,4).equals("BB01")) {	
			booleanLineaCredito=true;
			booleanValorCredito=true;
			booleanValorOriginalCredito=true;
			booleanPrimerFechaPagoLibre=true;
			booleanPrimerFechaPagoLista=false;
			booleanOficina=true;
			booleanPlazoCreditoLibre=true;
			booleanSeguro=true;	
			booleanTipoTasa=true;
			booleanValorTasa=true;
			booleanDestinoDesembolso=true;
			booleanNumCuentaDesembolso=true;
			booleantipoID_ChequeGerencia=true;
			booleanIdChequeGerencia=true;
			booleantipoIDCuentaContable=true;
			booleanIdCuentaContable=true;
			booleanCobroGMF=true;
		}

		/* Asignar variables si el producto es BB27 */
		if (getSubString((String) args[3],0,4).equals("BB27")) {
			booleanLineaCredito=true;
			booleanValorCredito=true;
			booleanValorOriginalCredito=true;
			booleanCambiarFechaPago=true;
			booleanPrimerFechaPagoLibre=true;
			booleanPrimerFechaPagoLista=false;
			booleanOficina=true;
			booleanPlazoCreditoLibre=true;
			booleanSeguro=true;	
			booleanTipoPlanSeguro=true;
			booleanValorTasa=true;
			booleanDestinoDesembolso=true;
			booleanNumCuentaDesembolso=true;
			booleantipoID_ChequeGerencia=true;
			booleanIdChequeGerencia=true;
			booleantipoIDCuentaContable=true;
			booleanIdCuentaContable=true;
			booleanConvenio=true;
			booleanCobroGMF=true;
		}

		/* Asignar variables si el producto es B131 */
		if (getSubString((String) args[3],0,4).equals("B131")) {
			booleanLineaCredito=true;
			booleanValorCredito=true;
			booleanValorOriginalCredito=true;
			booleanCambiarFechaPago=true;
			booleanPrimerFechaPagoLibre=true;
			booleanPrimerFechaPagoLista=false;
			booleanOficina=true;
			booleanPlazoCreditoLibre=true;
			booleanSeguro=true;	
			booleanTipoPlanSeguro=true;
			booleanValorTasa=true;
			booleanDestinoDesembolso=true;
			booleanNumCuentaDesembolso=true;
			booleantipoID_ChequeGerencia=true;
			booleanIdChequeGerencia=true;
			booleantipoIDCuentaContable=true;
			booleanIdCuentaContable=true;
			booleanConvenio=true;
			booleanCobroGMF=true;
		}

		/* Asignar variables si el producto es BB15 */
		if (getSubString((String) args[3],0,4).equals("BB15")) {
			booleanLineaCredito=true;
			booleanValorCredito=true;
			booleanPrimerFechaPagoLibre=true;
			booleanPrimerFechaPagoLista=false;
			booleanOficina=true;
			booleanPlazoCreditoLibre=true;
			booleanTipoTasa=true;
			booleanValorTasa=true;
			booleanDestinoDesembolso=true;
			booleanNumCuentaDesembolso=true;
			booleantipoID_ChequeGerencia=true;
			booleanIdChequeGerencia=true;
			booleantipoIDCuentaContable=true;
			booleanIdCuentaContable=true;
			booleanCobroGMF=true;
			/* 2016.09.30 LGOMEZ11 - CVAPD00248114 Crear la Opci�n Seguro Cuota Protegida Mensual L�nea 15 Veh�culos */
			booleanSeguro=true;
			/* 2016.10.28 LGOMEZ11 - Inclusi�n campo SeguroAutoProtegidoPlus */
			booleanSeguroAutoProtegPlus = true;
		}

		/* Asignar variables si el producto es B002 */
		if (getSubString((String) args[3],0,4).equals("B002")) {
			booleanLineaCredito=true;
			booleanValorCredito=true;
			booleanPrimerFechaPagoLibre=false;
			booleanPrimerFechaPagoLista=true;
			booleanOficina=true;
			booleanSeguro=true;	
			booleanTipoTasa=true;
			booleanCobroGMF=true;
		}

		/* Asignar variables si el producto es BP14 */
		if (getSubString((String) args[3],0,4).equals("BP14")) {
			booleanLineaCredito=true;
			booleanValorCredito=true;
			booleanPrimerFechaPagoLibre=false;
			booleanPrimerFechaPagoLista=true;
			booleanOficina=true;
			booleanSeguro=true;	
			booleanTipoTasa=true;
			booleanCobroGMF=true;
		}

		/* Asignar variables si el producto es M002 */
		if (getSubString((String) args[3],0,4).equals("M002")) {
			booleanLineaCredito=true;
			booleanValorCredito=true;
			booleanCambiarFechaPago=true;
			booleanPrimerFechaPagoLibre=true;
			booleanPrimerFechaPagoLista=false;
			booleanOficina=true;
			booleanPlazoCreditoLibre=true;
			booleanTipoTasa=true;
			booleanValorTasa=true;
			booleanDestinoDesembolso=true;
			booleanNumCuentaDesembolso=true;
			booleantipoID_ChequeGerencia=true;
			booleanIdChequeGerencia=true;
			booleantipoIDCuentaContable=true;
			booleanIdCuentaContable=true;
			booleanNumeroCreditoAbonar=true;
			booleanPresentaCertificacion=true;
			booleanNumCtaDesembolsoSebra=true;
		}

		/* Asignar variables si el producto es M007 */
		if (getSubString((String) args[3],0,4).equals("M007")) {
			booleanLineaCredito=true;
			booleanValorCredito=true;
			booleanCambiarFechaPago=true;
			booleanPrimerFechaPagoLibre=true;
			booleanPrimerFechaPagoLista=false;
			booleanOficina=true;
			booleanPlazoCreditoLibre=true;
			booleanTipoTasa=true;
			booleanValorTasa=true;
			booleanDestinoDesembolso=true;
			booleanNumCuentaDesembolso=true;
			booleantipoID_ChequeGerencia=true;
			booleanIdChequeGerencia=true;
			booleantipoIDCuentaContable=true;
			booleanIdCuentaContable=true;
			booleanPresentaCertificacion=true;
			booleanNumCtaDesembolsoSebra=true;
		}

		/* Asignar variables si el producto es M039 */
		if (getSubString((String) args[3],0,4).equals("M039")) {
			booleanLineaCredito=true;
			booleanValorCredito=true;
			booleanCambiarFechaPago=true;
			booleanPrimerFechaPagoLibre=true;
			booleanPrimerFechaPagoLista=false;
			booleanOficina=true;
			booleanPlazoCreditoLibre=true;
			booleanTipoTasa=true;
			booleanValorTasa=true;
			booleanDestinoDesembolso=true;
			booleanNumCuentaDesembolso=true;
			booleantipoID_ChequeGerencia=true;
			booleanIdChequeGerencia=true;
			booleantipoIDCuentaContable=true;
			booleanIdCuentaContable=true;
			booleanPresentaCertificacion=true;
			booleanNumCtaDesembolsoSebra=true;
		}

		/* Asignar variables si el producto es B300 */
		if (getSubString((String) args[3],0,4).equals("B300")) {
			booleanLineaCredito=true;
			booleanValorCredito=true;
			booleanPrimerFechaPagoLibre=true;
			booleanPrimerFechaPagoLista=false;
			booleanOficina=true;
			booleanPlazoCreditoLibre=true;
			booleanTipoTasa=true;
			booleanValorTasa=true;
			booleanDestinoDesembolso=true;
			booleanNumCuentaDesembolso=true;
			booleantipoID_ChequeGerencia=true;
			booleanIdChequeGerencia=true;
			booleantipoIDCuentaContable=true;
			booleanIdCuentaContable=true;
			booleanCobroGMF=true;
		}		


		/** INGRESO DE LOS DATOS EN LA PANTALLA - Deben ser los mismos de la captura */

		if (booleanLineaCredito) {
			tmp[0] = lineaCredito;	// Ingreso L�nea de Cr�dito
			callScript("CamposVerificarDesembolso.text_LineaCredito_O", tmp);
		}

		if (booleanValorCredito) {
			// Ingreso del valor del credito
			tmp[0] = valorCredito;		
			tmp[1] = getSubString((String) args[1], 0, 4); 
			callScript("CamposVerificarDesembolso.text_ValorCredito_O", tmp);
		}

		if (booleanValorOriginalCredito) {
			// Ingreso del valor del credito
			tmp[0] = valorOriginalCredito;		
			tmp[1] = getSubString((String) args[1], 0, 4);
			callScript("CamposVerificarDesembolso.text_ValorOriginalCredito_O", tmp);

		}

		if (booleanCambiarFechaPago & cambiarFechaPago.equals(si)) {
			booleanPrimerFechaPagoLibre = true;
		} else if (booleanCambiarFechaPago & cambiarFechaPago.equals(no)) {
			booleanPrimerFechaPagoLibre = false;
		}

		if (booleanPrimerFechaPagoLibre) {

			if (primerFechaPago!= null)
			{
				//Ingreso de Primera fecha de pago sin resticcion al momento de digitar
				tmp[0] = primerFechaPago;
				tmp[1] = getSubString((String) args[3],0,4);
				tmp[2] = periodoPagoIntereses;
				tmp[3] = plazoCredito;
				callScript("CamposVerificarDesembolso.text_PrimerFechaPago_O", tmp);
				System.out.println(tmp[0]);
			}

			html_cuerpoVerificacion().click();
		}


		if (booleanPrimerFechaPagoLista) {

			if (primerFechaPago!=null) {
				tmp[0] = primerFechaPago;	//Ingreso de Primera fecha de pago con resticcion al momento de digitar
				callScript("CamposVerificarDesembolso.list_SeleccionDiaPago_O", tmp);
			}
		}

		if (booleanOficina) {
			tmp[0] = oficina; // Ingreso de la Oficina sin espacios despues del nombre de la oficina 
			callScript("CamposVerificarDesembolso.text_Oficina_O", tmp);
			browser_htmlBrowser(document_bancoDeBogot�PortalDe(), DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (booleanPlazoCreditoLibre) {
			tmp[0]=plazoCredito;// Ingreso de Plazo credito
			tmp[1] = getSubString((String) args[3],0,4);
			callScript("CamposVerificarDesembolso.text_Plazo_O", tmp);
			browser_htmlBrowser(document_bancoDeBogot�PortalDe(), DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (booleanSeguro) {
			tmp[0] = seguro;	// Ingreso de tipo de Seguro
			callScript("CamposVerificarDesembolso.list_Seguro_O", tmp);
			browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (booleanTipoPlanSeguro && seguro.equals(AccidentesPersonales)) {
			tmp[0] = planSeguro; // Ingreso de Plan de Seguro Dependiendo del tipo de Seguro y la l�nea
			callScript("CamposVerificarDesembolso.list_TipoPlan_O",tmp);
			browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}


		if (booleanSeguroAutoProtegPlus) {
			tmp[0] = seguroAutoProtegPlus;
			callScript("CamposVerificarDesembolso.list_SeguroAutoProtegPlus_O",tmp);
			browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (booleanTipoTasa) {
			tmp[0]="Fija";
			tmp[1]= getSubString((String) args[3],0,4);
			tmp[2]= tipoTasa;
			tmp[3]= "DTF";
			callScript("CamposVerificarDesembolso.list_TipoTasa_O", tmp); sleep(2);
		}

		if (booleanValorTasa) {
			tmp[0]=valorTasa; // Ingreso de Valor de la Tasa
			tmp[1]=getSubString((String) args[3],0,4);
			callScript("CamposVerificarDesembolso.text_ValorTasa_O", tmp);
		}

		if (booleanDestinoDesembolso) {
			tmp [0]=destinoDesembolso;		// Ingreso Destino del desembolso alternativas
			tmp [1]= getSubString((String) args[3],0,4);
			callScript("CamposVerificarDesembolso.list_DestinoDesembolso_O", tmp);
			browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");
			Espera(2);

			if (destinoDesembolso.equals(cuentaAhorros)||destinoDesembolso.equals(cuentaCorriente)) { //Validacion si es Cuenta de Ahorros o Cuenta Corriente
				tmp [0]= numCuentaDesembolso;  //Ingreso cuenta destino
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("CamposVerificarDesembolso.text_NumCuentaDesembolso_O",tmp);
				browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");					
			}

			if (destinoDesembolso.equals(chequeGerencia)) { //Validacion si es Cheque de gerencia
				tmp [0]= tipoID_ChequeGerencia;		//Ingreso Tipo de identificacion de la persona a la cual va salir el cheque
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("CamposVerificarDesembolso.txt_TipoIdChequeGcia_O",tmp);

				tmp [0]= idChequeGerencia;	//Ingreso de numero de identificacion del beneficiario del cheque
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("CamposVerificarDesembolso.txt_NumIdChequeGcia_O",tmp);
				browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");
				System.out.println("noIdentificacion: " + noIdentificacion);
				System.out.println("idChequeGerencia" + idChequeGerencia);

				if (noIdentificacion.equals(idChequeGerencia)) // Validacion si no es el mismo numero de identificacion del cliente
					booleanPresentaCertificacion= false;
			}

			if (destinoDesembolso.equals(otrosCuentaContable)) { //Validacion de Otros Cuenta contable	
				tmp [0]=tipoIDCuentaContable;	// Ingreso Tipo Identificacion
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("CamposVerificarDesembolso.list_TipoIdCtaContable_O", tmp);

				tmp [0]= idCuentaContable;	// Ingreso Numero de Identificacion
				tmp [1]= getSubString((String) args[3],0,4);
				callScript("CamposVerificarDesembolso.text_NumIdCtaContable_O", tmp);

				browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");

				if (noIdentificacion.equals(idCuentaContable)) // Validacion si no es el mismo numero de identificacion del cliente
					booleanPresentaCertificacion= false;
			}

			if (destinoDesembolso.equals(abonoACredito)) { // Validacion Abono credito 
				tmp [0]= numCreditoAbonar;	// Ingresar No de cr�dito que no se haya cancelado ni pagado en totalidad	
				callScript("CamposVerificarDesembolso.txt_NumCreditoAbonar_O",tmp);
				browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");
			}

			if (destinoDesembolso.equals(trasladoSebra)) { // Validacion si es traslado SEBRA
				tmp[0]=numCtaDesembolsoSebra; // Ingresar Cuenta SEBRA
				callScript("CamposVerificarDesembolso.text_NumCuentaDesembolsoSebra_O",tmp);
				browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");
			}

		}

		if (booleanConvenio) {
			tmp [0]= convenio; //Seleccion de Convenio si es producto BB27 � B131
			callScript("CamposVerificarDesembolso.text_Convenio_O",tmp);
			browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (booleanCobroGMF) {
			tmp [0]= cobroGMF;	// Seleccionar Si se cobra o no el GMF
			tmp [1]= getSubString((String) args[3],0,4);
			callScript("CamposVerificarDesembolso.list_CobroGMF_O", tmp);
			browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}

		if (booleanPresentaCertificacion) {
			tmp[0]=presentaCertificacion; // Ingresar si Presenta Certificacion o no
			callScript("CamposVerificarDesembolso.list_PresentaCertificacion_O",tmp);
			browser_htmlBrowser(document_bancoDeBogot�PortalDe(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}
		
		
		/** INFORME DETALLADO PDF */
		
		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�PortalDe(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - O_CamposVerificarDesembolso", doc);
		
		
		/** REALIZAR DESEMBOLSO */

		/* Ventana con los campos para verificar los datos del desembolso */
		callScript("CamposVerificarDesembolso.button_Guardar_O");
		callScript("CamposVerificarDesembolso.button_OK_O");
	}
}