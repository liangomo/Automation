package Scripts;
import java.awt.image.RenderedImage;
import java.io.IOException;
import java.sql.SQLException;
import com.lowagie.text.Document;
import resources.Scripts.A_LoginHelper;

public class A_Login extends A_LoginHelper 
{  

	/** INICIALIZACI�N DE VARIABLES */

	/* Creaci�n PDF */
	Document doc;
	RenderedImage imagen;


	public void testMain(Object[] args) throws IOException, SQLException 
	{
		
		/** ASIGNACI�N DE VARIABLES */

		/* Traer PDF creado para incluir informaci�n en �l */
		doc = (Document) args[83];
		
		
		/** INFORME DETALLADO PDF */
		
		/* Insertar texto al PDF */
		addTexto(args[2] + ": DATOS PRINCIPALES DEL CR�DITO" + "\n", doc);
		addTexto("Tipo Identificaci�n: " + args[4] + "\n", doc);
		addTexto("N�mero Identificaci�n: " + args[5] + "\n", doc);
		
		addTexto("\n" + args[2] + ": INFORMACI�N ADICIONAL" + "\n", doc);
		addTexto("Valor del Cr�dito: " + args[6] + "\n", doc);
		
		addTexto("\n" + args[2] + ": CONDICIONES DE APROBACI�N" + "\n", doc);
		addTexto("Valor Tasa: " + args[19] + "\n", doc);


		/** LOGIN */
		
		/*System.out.println(text_password(ANY, LOADED).getProperty(".hasFocus"));
		if (text_password(ANY, LOADED).getProperty(".hasFocus").equals(true)) {
			text_password(ANY,LOADED).setText((String) args[81]);
			button_button().click(); 
			link_inicio().click(); sleep(2);
			browser_htmlBrowser().maximize();

		} else */if (link_inicio(ANY,LOADED).exists()) {
			link_inicio().click();
			browser_htmlBrowser().maximize();

		} else {

			
			/** TERMINAR PROCESOS DEL NAVEGADOR, ABRIR NAVEGADOR Y MAXIMIZAR */
			
			MatarProceso();	sleep(3);		
			
			/* Inicio Aplicacion PPE */
			startApp("PPE"); sleep(3);
			browser_htmlBrowser().maximize();

			
			/** INGRESO DE USUARIO Y CONTRASE�A */

			/* 2015.10.07 - LGOMEZ11 - CVAPD00189106 Ajuste Portal Sesion */
			browser_htmlBrowser(document_portalDeProductividad(ANY,LOADED),DEFAULT_FLAGS).click(atPoint(1218,180));

			text_usuario(ANY,LOADED).setText((String) args[80]); 	// Ingresa Usuario Capturador
			text_fake_pass(ANY,LOADED).setText((String) args[81]);	sleep(2); // Ingresa Contrase�a Capturador

			document_bancoDeBogot�().click(); sleep(1);
			list_dominio(ANY,LOADED).select((String) args[82]); 	//Selecciona Dominio de usuarios 

			
			/** INFORME DETALLADO PDF */

			/* Capturar im�gen y guardar en PDF */
			imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
			guardarImagen(imagen, args[2] + " - A_Login", doc); sleep(2);
			
			
			/** INGRESAR A LA APLICACI�N */
			
			/* Clic en Ingresar para realizar el login en la aplicacion */
			button_ingresarsubmit(ANY,LOADED).doubleClick();
			Espera(2);

		}


		/** INFORME DETALLADO PDF */

		/* Capturar im�gen y guardar en PDF */
		imagen = document_bancoDeBogot�(ANY, LOADED).getScreenSnapshot();
		guardarImagen(imagen, args[2] + " - A_Login", doc);
	}
}