package InformacionCarteraFomento;
import resources.InformacionCarteraFomento.list_LineaFomentoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_LineaFomento extends list_LineaFomentoHelper
{
	/**
	 * Script Name   : <b>list_LineaFomento</b>
	 * Generated     : <b>12/02/2015 15:01:58</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/12
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnaOpcion().waitForExistence();
		list_seleccioneUnaOpcion().select((String) args[0]);
	}
}


