package InformacionCarteraFomento;
import resources.InformacionCarteraFomento.text_SubDestinoEconomicoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_SubDestinoEconomico extends text_SubDestinoEconomicoHelper
{
	/**
	 * Script Name   : <b>text_SubDestinoEconomico</b>
	 * Generated     : <b>12/02/2015 14:58:29</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/12
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		text_campoNumericoRequerido().waitForExistence();
		text_campoNumericoRequerido().setText((String) args[0]);
	}
}

