package InformacionCarteraFomento;
import resources.InformacionCarteraFomento.text_MargenDeRedescuentoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_MargenDeRedescuento extends text_MargenDeRedescuentoHelper
{
	/**
	 * Script Name   : <b>text_MargenDeRedescuento</b>
	 * Generated     : <b>12/02/2015 14:44:32</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/12
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		text_campoNumericoRequerido().waitForExistence();
		text_campoNumericoRequerido().setText((String) args[0]);
		
	}
}

