package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.list_CobroGMF_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class list_CobroGMF_O extends list_CobroGMF_OHelper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneElTipoDeCobroDe().waitForExistence();
		list_seleccioneElTipoDeCobroDe().select((String) args[0]);
	}
}