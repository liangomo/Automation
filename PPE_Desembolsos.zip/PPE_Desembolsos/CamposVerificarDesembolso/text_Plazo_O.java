package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.text_Plazo_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class text_Plazo_O extends text_Plazo_OHelper
{

	public void testMain(Object[] args) 
	{
		text_elPlazoMinimoDebeEstarEnt().waitForExistence();
		text_elPlazoMinimoDebeEstarEnt().setText((String) args[0]);
	}
}