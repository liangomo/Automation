package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.list_TipoPlan_OHelper;
/**
 * Description   : Functional Test Script
 * @author javedan
 */
public class list_TipoPlan_O extends list_TipoPlan_OHelper
{
	public void testMain(Object[] args) 
	{
		list_selecioneUnTipoDePlan().waitForExistence();
		list_selecioneUnTipoDePlan().select((String) args[0]);
	}
}