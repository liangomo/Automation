package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.text_PrimerFechaPago_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class text_PrimerFechaPago_O extends text_PrimerFechaPago_OHelper
{

	public void testMain(Object[] args) 
	{
		
		if (args[0].equals("si")) {
			
			if (args[1].equals("M002")) {
				
				text_laPrimeraFechaDePagoEsObl().waitForExistence();
				text_laPrimeraFechaDePagoEsObl().setText(ObtenerFechaLiquidez());
				
			} else {
				
				if (args[1].equals("B300")) {
			
					text_laPrimeraFechaDePagoEsObl().waitForExistence();
					text_laPrimeraFechaDePagoEsObl().setText(ObtenerFechaConProrrata_Val(args[2],args[3]));
				
				} else {

					text_laPrimeraFechaDePagoEsObl().waitForExistence();
					text_laPrimeraFechaDePagoEsObl().setText(ObtenerFechaConProrrata());
					
				}
			}
		}
		
		
		if (args[0].equals("no")) {
			
			if (args[1].equals("M002")) {
				
				text_laPrimeraFechaDePagoEsObl().waitForExistence();
				text_laPrimeraFechaDePagoEsObl().setText(ObtenerFechaLiquidez());
				
			} else {
				
				if (args[1].equals("B300")) {
							
				text_laPrimeraFechaDePagoEsObl().waitForExistence();			
					text_laPrimeraFechaDePagoEsObl().setText(ObtenerFechaSinProrrata_Val(args[2],args[3]));

						
				} else {

					text_laPrimeraFechaDePagoEsObl().waitForExistence();
					text_laPrimeraFechaDePagoEsObl().setText(ObtenerFechaSinProrrata());
				}
				
			}

		}
	}
}