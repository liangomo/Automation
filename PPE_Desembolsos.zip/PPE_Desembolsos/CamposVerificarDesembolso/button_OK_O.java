package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.button_OK_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class button_OK_O extends button_OK_OHelper
{

	public void testMain(Object[] args)
	{
		button_oKbutton().waitForExistence();
		button_oKbutton().click();
	}
}