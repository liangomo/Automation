package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.text_NumIdCtaContable_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class text_NumIdCtaContable_O extends text_NumIdCtaContable_OHelper
{

	public void testMain(Object[] args) 
	{
		text_ingreseElNumeroDeIdentifi().waitForExistence();
		text_ingreseElNumeroDeIdentifi().setText((String) args[0]);
	}
}