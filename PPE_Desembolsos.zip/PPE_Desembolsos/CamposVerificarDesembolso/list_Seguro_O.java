package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.list_Seguro_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class list_Seguro_O extends list_Seguro_OHelper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneElSeguro().waitForExistence();
		list_seleccioneElSeguro().select((String) args[0]);
	}
}