package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.txt_TipoIdChequeGcia_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class txt_TipoIdChequeGcia_O extends txt_TipoIdChequeGcia_OHelper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneElTipoDeGrantia().waitForExistence();
		list_seleccioneElTipoDeGrantia().select((String) args[0]);
	}
}