package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.txt_NumCreditoAbonar_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class txt_NumCreditoAbonar_O extends txt_NumCreditoAbonar_OHelper
{

	public void testMain(Object[] args) 
	{
		text_digiteNumeroDeCredito().waitForExistence();
		text_digiteNumeroDeCredito().setText((String) args[0]);
	}
}