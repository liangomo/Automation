package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.list_TipoIdCtaContable_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class list_TipoIdCtaContable_O extends list_TipoIdCtaContable_OHelper
{

	public void testMain(Object[] args) 
	{
		list_tipoIdOtrosSelectVerifica().waitForExistence();
		list_tipoIdOtrosSelectVerifica().select((String) args[0]);
	}
}