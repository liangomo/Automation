package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.list_DestinoDesembolso_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class list_DestinoDesembolso_O extends list_DestinoDesembolso_OHelper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneDestinoDesembol().waitForExistence();
		list_seleccioneDestinoDesembol().select((String) args[0]);
	}
}