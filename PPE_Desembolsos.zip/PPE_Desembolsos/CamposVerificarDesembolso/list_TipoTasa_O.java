package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.list_TipoTasa_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class list_TipoTasa_O extends list_TipoTasa_OHelper
{

	public void testMain(Object[] args) 
	{
		
		if (args[1].equals("BB01") || args[1].equals("BB15")
				|| args[1].equals("B002") || args[1].equals("BP14")) {
			
			list_seleccioneElTipoDeCobroDe().waitForExistence();
			list_seleccioneElTipoDeCobroDe().select((String) args[0]);
			
		} else if (args[1].equals("B300")) {
			
			list_seleccioneElTipoDeCobroDe().waitForExistence();
			list_seleccioneElTipoDeCobroDe().select((String) args[3]);
			
		}	else {
			
			list_seleccioneElTipoDeCobroDe().click();
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(args[2] + "{TAB}");

		}
	}
}