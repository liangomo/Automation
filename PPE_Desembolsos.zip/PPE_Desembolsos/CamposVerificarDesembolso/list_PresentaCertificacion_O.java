package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.list_PresentaCertificacion_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class list_PresentaCertificacion_O extends list_PresentaCertificacion_OHelper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneUnaOpcion().waitForExistence();
		list_seleccioneUnaOpcion().select((String) args[0]);
	}
}