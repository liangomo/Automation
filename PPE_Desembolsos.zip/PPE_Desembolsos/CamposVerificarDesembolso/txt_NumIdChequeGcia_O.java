package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.txt_NumIdChequeGcia_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class txt_NumIdChequeGcia_O extends txt_NumIdChequeGcia_OHelper
{

	public void testMain(Object[] args) 
	{
		text_ingreseElNumeroDeIdentifi().waitForExistence();
		text_ingreseElNumeroDeIdentifi().setText((String) args[0]);
	}
}