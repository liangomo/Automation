package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.text_Oficina_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class text_Oficina_O extends text_Oficina_OHelper
{

	public void testMain(Object[] args) 
	{
		text_campoNumericoRequerido().waitForExistence();
		text_campoNumericoRequerido().setText((String) args[0]);
	}
}