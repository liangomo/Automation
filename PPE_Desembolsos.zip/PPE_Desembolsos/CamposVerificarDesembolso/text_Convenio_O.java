package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.text_Convenio_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class text_Convenio_O extends text_Convenio_OHelper
{

	public void testMain(Object[] args) 
	{
		text_campoNumericoRequerido().waitForExistence();
		text_campoNumericoRequerido().setText((String) args[0]);
	}
}