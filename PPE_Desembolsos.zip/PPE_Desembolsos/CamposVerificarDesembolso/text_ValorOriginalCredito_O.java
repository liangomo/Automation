package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.text_ValorOriginalCredito_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class text_ValorOriginalCredito_O extends text_ValorOriginalCredito_OHelper
{

	public void testMain(Object[] args) 
	{
		text_ingreseUnMonto().waitForExistence();
		text_ingreseUnMonto().setText((String) args[0]);
	}
}