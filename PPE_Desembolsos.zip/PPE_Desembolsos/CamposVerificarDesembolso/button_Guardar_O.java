package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.button_Guardar_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class button_Guardar_O extends button_Guardar_OHelper
{

	public void testMain(Object[] args) 
	{
		button_guardarbutton().waitForExistence();
		button_guardarbutton().click();
	}
}