package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.text_LineaCredito_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class text_LineaCredito_O extends text_LineaCredito_OHelper
{
	
	public void testMain(Object[] args) 
	{
		text_seleccioneUnaOpcion().waitForExistence();
		text_seleccioneUnaOpcion().setText((String) args[0]);
	}
}