package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.list_SeleccionDiaPago_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class list_SeleccionDiaPago_O extends list_SeleccionDiaPago_OHelper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneUnaOpcion().waitForExistence();
		list_seleccioneUnaOpcion().select((String) args[0]);
	}
}