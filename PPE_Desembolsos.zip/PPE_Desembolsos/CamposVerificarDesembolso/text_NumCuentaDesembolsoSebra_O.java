package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.text_NumCuentaDesembolsoSebra_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class text_NumCuentaDesembolsoSebra_O extends text_NumCuentaDesembolsoSebra_OHelper
{

	public void testMain(Object[] args) 
	{
		text_digiteElN�meroCuentaDesem().waitForExistence();
		text_digiteElN�meroCuentaDesem().setText((String) args[0]);
	}
}