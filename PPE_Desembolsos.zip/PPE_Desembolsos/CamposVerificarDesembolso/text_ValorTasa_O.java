package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.text_ValorTasa_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class text_ValorTasa_O extends text_ValorTasa_OHelper
{

	public void testMain(Object[] args) 
	{
		text_ingreseElValorDeLaTasaAnu().waitForExistence();
		text_ingreseElValorDeLaTasaAnu().setText((String) args[0]);
	}
}