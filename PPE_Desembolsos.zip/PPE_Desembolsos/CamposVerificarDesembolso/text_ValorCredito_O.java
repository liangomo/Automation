package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.text_ValorCredito_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class text_ValorCredito_O extends text_ValorCredito_OHelper
{

	public void testMain(Object[] args) 
	{
		text_elValorMinimoEsDe500MilPe().waitForExistence();
		text_elValorMinimoEsDe500MilPe().setText((String) args[0]);
	}
}