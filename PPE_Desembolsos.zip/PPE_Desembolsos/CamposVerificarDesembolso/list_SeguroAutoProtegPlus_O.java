package CamposVerificarDesembolso;
import resources.CamposVerificarDesembolso.list_SeguroAutoProtegPlus_OHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class list_SeguroAutoProtegPlus_O extends list_SeguroAutoProtegPlus_OHelper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneSiDeseaONoAgreg().waitForExistence();
		list_seleccioneSiDeseaONoAgreg().select((String) args[0]);
	}
}