package DesembolsarCredito;
import resources.DesembolsarCredito.button_Siguiente_FHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class button_Siguiente_F extends button_Siguiente_FHelper
{

	public void testMain(Object[] args) 
	{
		/* Clic en el bot�n de la pantalla Garant�as */
		button_siguientebutton().waitForExistence();
		button_siguientebutton().click();
	}
}