package DesembolsarCredito;
import resources.DesembolsarCredito.button_Siguiente_EHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class button_Siguiente_E extends button_Siguiente_EHelper
{

	public void testMain(Object[] args) 
	{
		/* Clic en el bot�n de la pantalla Condiciones de Aprobaci�n */
		button_siguientebutton().waitForExistence();
		button_siguientebutton().click();
	}
}