package DesembolsarCredito;
import resources.DesembolsarCredito.button_Siguiente_DHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class button_Siguiente_D extends button_Siguiente_DHelper
{
	/**
	 * Script Name   : <b>button_Siguiente_D</b>
	 * Generated     : <b>06/01/2016 12:31:34</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2016/01/06
	 * @author lgomez11
	 */
	public void testMain(Object[] args) 
	{
		/* Clic en el bot�n de la pantalla Informaci�n Adicional */
		button_siguientebutton().waitForExistence();
		button_siguientebutton().click();

		/* Confirmaci�n del valor del cr�dito */
		button_aceptaRbutton().waitForExistence();
		button_aceptaRbutton().click();
	}
}