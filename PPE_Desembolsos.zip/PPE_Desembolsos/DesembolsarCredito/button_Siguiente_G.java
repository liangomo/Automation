package DesembolsarCredito;
import resources.DesembolsarCredito.button_Siguiente_GHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class button_Siguiente_G extends button_Siguiente_GHelper
{

	public void testMain(Object[] args) 
	{
		/* Clic en el bot�n de la pantalla Datos desembolso */
		if (args[0].equals("B300")) {
			
			button_siguientebutton2().waitForExistence();
			button_siguientebutton2().click();
			
		} else {
			
			button_siguientebutton().waitForExistence();
			button_siguientebutton().click();
		}
	}
}