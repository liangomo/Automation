package DesembolsarCredito;
import resources.DesembolsarCredito.button_Siguiente_NHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class button_Siguiente_N extends button_Siguiente_NHelper
{

	public void testMain(Object[] args) 
	{
		/* Clic en el bot�n de la pantalla Informaci�n Cartera de Fomento B300 */
		button_siguientebutton().waitForExistence();
		button_siguientebutton().click();
	}
}