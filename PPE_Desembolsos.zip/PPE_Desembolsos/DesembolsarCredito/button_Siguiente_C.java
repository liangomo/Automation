package DesembolsarCredito;
import resources.DesembolsarCredito.button_Siguiente_CHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class button_Siguiente_C extends button_Siguiente_CHelper
{
	/**
	 * Script Name   : <b>button_Siguiente_C</b>
	 * Generated     : <b>06/01/2016 12:19:39</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2016/01/06
	 * @author lgomez11
	 */
	public void testMain(Object[] args) 
	{
		/* Clic en el bot�n de la pantalla Datos principales del cr�dito */
		button_siguientebutton().waitForExistence();
		button_siguientebutton().click();
	}
}