package InformacionAdicional;
import resources.InformacionAdicional.D_list_TipoPlanHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class D_list_TipoPlan extends D_list_TipoPlanHelper
{

	public void testMain(Object[] args) 
	{
		list_selecioneUnTipoDePlan().waitForExistence();
		list_selecioneUnTipoDePlan().select((String) args[0]);
	}
}		