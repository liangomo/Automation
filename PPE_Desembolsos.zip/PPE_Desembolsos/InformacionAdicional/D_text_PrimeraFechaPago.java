package InformacionAdicional;
import resources.InformacionAdicional.D_text_PrimeraFechaPagoHelper;

public class D_text_PrimeraFechaPago extends D_text_PrimeraFechaPagoHelper
{
	
	public void testMain(Object[] args) 
	{
		
		if (args[0].equals("si")) {
			
			if (args[1].equals("M002")) {
				
				text_laPrimeraFechaDePagoEsObl().waitForExistence();
				text_laPrimeraFechaDePagoEsObl().setText(ObtenerFechaLiquidezConProrrata());
				
			} else {
				
				if (args[1].equals("B300")) {
			
					text_laPrimeraFechaDePagoEsObl2().waitForExistence();
					text_laPrimeraFechaDePagoEsObl2().setText(ObtenerFechaConProrrata_Val(args[2],args[3]));
				
				} else {

					text_laPrimeraFechaDePagoEsObl().waitForExistence();
					text_laPrimeraFechaDePagoEsObl().setText(ObtenerFechaConProrrata());
					
				}
			}
		}
		
		
		if (args[0].equals("no")) {
			
			if (args[1].equals("M002")) {
				
				text_laPrimeraFechaDePagoEsObl().waitForExistence();
				text_laPrimeraFechaDePagoEsObl().setText(ObtenerFechaLiquidez());
				
			} else if (args[1].equals("B300")) {
				
					text_laPrimeraFechaDePagoEsObl2().waitForExistence();			
					text_laPrimeraFechaDePagoEsObl2().setText(ObtenerFechaSinProrrata_Val(args[2],args[3]));

						
				} else {

					text_laPrimeraFechaDePagoEsObl().waitForExistence();
					text_laPrimeraFechaDePagoEsObl().setText(ObtenerFechaSinProrrata());
				}
				
			}
	}
}