package InformacionAdicional;
import resources.InformacionAdicional.D_text_ValorPrimaMensualHelper;
/**
 * Description   : Functional Test Script
 * @author Dpena6
 */
public class D_text_ValorPrimaMensual extends D_text_ValorPrimaMensualHelper
{
	/**
	 * Script Name   : <b>text_ValorPrimaMensual</b>
	 * Generated     : <b>23/02/2015 08:37:01</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/23
	 * @author Dpena6
	 */
	public void testMain(Object[] args) 
	{
		text_valorPrimaMensualInput().waitForExistence();
		text_valorPrimaMensualInput().setText((String) args[0]);
	}
}

