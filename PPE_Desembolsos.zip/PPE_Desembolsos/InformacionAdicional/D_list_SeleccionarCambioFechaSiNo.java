package InformacionAdicional;
import resources.InformacionAdicional.D_list_SeleccionarCambioFechaSiNoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class D_list_SeleccionarCambioFechaSiNo extends D_list_SeleccionarCambioFechaSiNoHelper
{
	/**
	 * Script Name   : <b>list_SeleccionarCambioFechaSiNo</b>
	 * Generated     : <b>09/01/2015 08:55:34</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnACambiarFecha().waitForExistence();
		list_seleccioneUnACambiarFecha().select((String) args[0]);
	}
}