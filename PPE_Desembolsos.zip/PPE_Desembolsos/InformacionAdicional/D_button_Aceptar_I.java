package InformacionAdicional;
import resources.InformacionAdicional.D_button_Aceptar_IHelper;

public class D_button_Aceptar_I extends D_button_Aceptar_IHelper
{

	public void testMain(Object[] args) 
	{

		if (args[0].equals("B300_NoDebeEntrar")) {

			button_aceptaRbutton2().waitForExistence();
			button_aceptaRbutton2().click();

		} else {
			button_aceptaRbutton().waitForExistence();
			button_aceptaRbutton().click();
		}

	}
}