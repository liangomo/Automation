package InformacionAdicional;
import resources.InformacionAdicional.D_text_ValorCreditoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class D_text_ValorCredito extends D_text_ValorCreditoHelper
{
	/**
	 * Script Name   : <b>text_ValorCredito</b>
	 * Generated     : <b>09/01/2015 08:50:07</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{

		if (args[1].equals("M002")||args[1].equals("M007")||args[1].equals("M039")) {

			text_ingreseUnMonto().waitForExistence();
			text_ingreseUnMonto().setText((String) args[0]);


		}

		else {


			if (args[1].equals("B300")) {

				text_ingreseUnMonto2().waitForExistence();
				text_ingreseUnMonto2().setText((String) args[0]);



			} else {
				text_elValorMinimoEsDe500MilPe().waitForExistence();
				text_elValorMinimoEsDe500MilPe().setText((String) args[0]);

			}



		}

	}
}

