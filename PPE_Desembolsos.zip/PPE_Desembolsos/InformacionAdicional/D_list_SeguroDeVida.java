package InformacionAdicional;
import resources.InformacionAdicional.D_list_SeguroDeVidaHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class D_list_SeguroDeVida extends D_list_SeguroDeVidaHelper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneUnASeguroDeVida().waitForExistence();
		list_seleccioneUnASeguroDeVida().select((String) args[0]);
	}
}