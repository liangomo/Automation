package InformacionAdicional;
import resources.InformacionAdicional.D_text_PlacaHelper;
/**
 * Description   : Functional Test Script
 * @author LPICON
 */
public class D_text_Placa extends D_text_PlacaHelper
{
	
	public void testMain(Object[] args) 
	{
		text_ingreseLaPlacaDelVeh�culo().waitForExistence();
		text_ingreseLaPlacaDelVeh�culo().setText((String) args[0]);
	}
}