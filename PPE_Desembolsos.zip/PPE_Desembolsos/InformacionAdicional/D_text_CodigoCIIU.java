package InformacionAdicional;
import resources.InformacionAdicional.D_text_CodigoCIIUHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class D_text_CodigoCIIU extends D_text_CodigoCIIUHelper
{
	/**
	 * Script Name   : <b>text_CodigoCIIU</b>
	 * Generated     : <b>09/01/2015 15:27:48</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			
			text_codigoCIIUEsObligatorio2().waitForExistence();
			text_codigoCIIUEsObligatorio2().setText((String) args[0]);
			
			
		} else {

			text_codigoCIIUEsObligatorio().waitForExistence();		
			text_codigoCIIUEsObligatorio().setText((String) args[0]);
			
		}
		
	
	}
}