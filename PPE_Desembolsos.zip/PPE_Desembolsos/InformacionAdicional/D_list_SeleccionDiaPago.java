package InformacionAdicional;
import resources.InformacionAdicional.D_list_SeleccionDiaPagoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class D_list_SeleccionDiaPago extends D_list_SeleccionDiaPagoHelper
{
	/**
	 * Script Name   : <b>list_SeleccionDiaPago</b>
	 * Generated     : <b>09/01/2015 14:45:42</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	
	public void testMain(Object[] args) 
	{
		list_seleccioneUnADiaDePago().waitForExistence();
		list_seleccioneUnADiaDePago().select((String) args[0]);
	}
}

