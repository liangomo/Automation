package InformacionAdicional;
import resources.InformacionAdicional.D_text_campoOficinaRadicacionHelper;
/**
 * Description   : Functional Test Script
 * @author LGOMEZ11
 */
public class D_text_campoOficinaRadicacion extends D_text_campoOficinaRadicacionHelper
{

	public void testMain(Object[] args) 
	{
		text_campoNumericoRequerido().waitForExistence();
		text_campoNumericoRequerido().setText((String) args[0]);
	}
}