package InformacionAdicional;
import resources.InformacionAdicional.D_text_campoOficialVentaHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class D_text_campoOficialVenta extends D_text_campoOficialVentaHelper
{
	/**
	 * Script Name   : <b>text_campoOficialVenta</b>
	 * Generated     : <b>09/01/2015 14:53:00</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			text_campoNumericoRequerido2().waitForExistence();
			text_campoNumericoRequerido2().setText((String) args[0]);
			
		}
		else{
		text_campoNumericoRequerido().waitForExistence();
		text_campoNumericoRequerido().setText((String) args[0]);
		}
	}
}

