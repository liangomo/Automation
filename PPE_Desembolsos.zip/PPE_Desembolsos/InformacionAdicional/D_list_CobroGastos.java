package InformacionAdicional;
import resources.InformacionAdicional.D_list_CobroGastosHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class D_list_CobroGastos extends D_list_CobroGastosHelper
{
	/**
	 * Script Name   : <b>list_CobroGastos</b>
	 * Generated     : <b>09/01/2015 15:16:45</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnACobroGastos().waitForExistence();
		list_seleccioneUnACobroGastos().select((String) args[0]);
	}
}

