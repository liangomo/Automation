package InformacionAdicional;
import resources.InformacionAdicional.D_list_SeguroAutoProtegPlusHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class D_list_SeguroAutoProtegPlus extends D_list_SeguroAutoProtegPlusHelper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneUnASeguroAutoPr().waitForExistence();		
		list_seleccioneUnASeguroAutoPr().select((String) args[0]);
	}
}