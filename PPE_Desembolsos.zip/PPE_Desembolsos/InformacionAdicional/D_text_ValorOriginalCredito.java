package InformacionAdicional;
import resources.InformacionAdicional.D_text_ValorOriginalCreditoHelper;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class D_text_ValorOriginalCredito extends D_text_ValorOriginalCreditoHelper
{

	public void testMain(Object[] args) 
	{
		text_ingreseUnMonto().waitForExistence();
		text_ingreseUnMonto().setText((String) args[0]);
	}
}