package InformacionAdicional;
import resources.InformacionAdicional.D_list_SeguroHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class D_list_Seguro extends D_list_SeguroHelper
{
	/**
	 * Script Name   : <b>list_Seguro</b>
	 * Generated     : <b>09/01/2015 15:18:52</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnASeguro().waitForExistence();		
		list_seleccioneUnASeguro().select((String) args[0]);
	}
}