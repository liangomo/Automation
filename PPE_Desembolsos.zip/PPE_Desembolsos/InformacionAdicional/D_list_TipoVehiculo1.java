package InformacionAdicional;
import resources.InformacionAdicional.D_list_TipoVehiculo1Helper;
/**
 * Description   : Functional Test Script
 * @author LPICON
 */
public class D_list_TipoVehiculo1 extends D_list_TipoVehiculo1Helper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneElTipoDeVeh�cul().waitForExistence();
		list_seleccioneElTipoDeVeh�cul().select((String) args[0]);
	}
}