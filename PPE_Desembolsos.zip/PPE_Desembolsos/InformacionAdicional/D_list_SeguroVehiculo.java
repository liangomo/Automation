package InformacionAdicional;
import resources.InformacionAdicional.D_list_SeguroVehiculoHelper;
/**
 * Description   : Functional Test Script
 * @author Dpena6
 */
public class D_list_SeguroVehiculo extends D_list_SeguroVehiculoHelper
{
	/**
	 * Script Name   : <b>list_SeguroVehiculo</b>
	 * Generated     : <b>23/02/2015 08:30:05</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/23
	 * @author Dpena6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnASeguroDeVehi().waitForExistence();
		list_seleccioneUnASeguroDeVehi().select((String) args[0]);
	}
}

