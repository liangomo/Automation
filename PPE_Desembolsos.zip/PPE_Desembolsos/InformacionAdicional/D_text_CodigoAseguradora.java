package InformacionAdicional;
import resources.InformacionAdicional.D_text_CodigoAseguradoraHelper;
/**
 * Description   : Functional Test Script
 * @author Dpena6
 */
public class D_text_CodigoAseguradora extends D_text_CodigoAseguradoraHelper
{
	/**
	 * Script Name   : <b>text_CodigoAseguradora</b>
	 * Generated     : <b>23/02/2015 08:34:31</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/23
	 * @author Dpena6
	 */
	public void testMain(Object[] args) 
	{
		text_seleccioneElCodigoDeLaAse().waitForExistence();
		text_seleccioneElCodigoDeLaAse().setText((String) args[0]);
	}
}

