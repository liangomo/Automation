package InformacionAdicional;
import resources.InformacionAdicional.D_list_TipoVehiculoHelper;
/**
 * Description   : Functional Test Script
 * @author Dpena6
 */
public class D_list_TipoVehiculo extends D_list_TipoVehiculoHelper
{
	/**
	 * Script Name   : <b>list_TipoVehiculo</b>
	 * Generated     : <b>23/02/2015 08:39:38</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/23
	 * @author Dpena6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnATipoDeVehicu().waitForExistence();
		list_seleccioneUnATipoDeVehicu().select((String) args[0]);
	}
}

