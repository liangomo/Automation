package InformacionAdicional;
import resources.InformacionAdicional.D_text_PlazoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class D_text_Plazo extends D_text_PlazoHelper
{
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			text_campoNumericoRequerido().waitForExistence();
			text_campoNumericoRequerido().setText((String) args[0]);
			
		} else {

			text_elPlazoMinimoDebeEstarEnt().waitForExistence();
			text_elPlazoMinimoDebeEstarEnt().setText((String) args[0]);
		}
		
	}
}