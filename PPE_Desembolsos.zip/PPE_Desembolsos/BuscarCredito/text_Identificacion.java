package BuscarCredito;
import resources.BuscarCredito.text_IdentificacionHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_Identificacion extends text_IdentificacionHelper
{
	public void testMain(Object[] args) 
	{
		
		text_htmlINPUTText().waitForExistence();
		text_htmlINPUTText().setText((String) args[0]);
	}
}