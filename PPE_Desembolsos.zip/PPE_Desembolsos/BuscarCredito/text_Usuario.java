package BuscarCredito;
import resources.BuscarCredito.text_UsuarioHelper;

public class text_Usuario extends text_UsuarioHelper
{

	public void testMain(Object[] args) 
	{
		text_htmlINPUTText(ANY, LOADED).waitForExistence();sleep(3);
		text_htmlINPUTText(ANY, LOADED).setText((String) args[0]);
	}
}