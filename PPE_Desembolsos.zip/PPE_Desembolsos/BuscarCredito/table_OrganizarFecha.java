package BuscarCredito;
import resources.BuscarCredito.table_OrganizarFechaHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class table_OrganizarFecha extends table_OrganizarFechaHelper
{

	public void testMain(Object[] args) 
	{
		table_capturadosTable().waitForExistence();
		table_capturadosTable().click(atCell(atRow(""), atColumn(atIndex(1))));
		table_capturadosTable().click(atCell(atRow(""), atColumn(atIndex(1))));
	}
}