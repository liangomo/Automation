package ReservaNumerosCreditos;
import resources.ReservaNumerosCreditos.text_OficinaHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_Oficina extends text_OficinaHelper
{

	public void testMain(Object[] args) 
	{
		text_seleccioneLaOficina().waitForExistence();
		text_seleccioneLaOficina().setText((String) args[0]);
	}
}