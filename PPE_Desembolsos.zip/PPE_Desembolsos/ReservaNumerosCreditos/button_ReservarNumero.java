package ReservaNumerosCreditos;
import resources.ReservaNumerosCreditos.button_ReservarNumeroHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class button_ReservarNumero extends button_ReservarNumeroHelper
{

	public void testMain(Object[] args) 
	{
		button_reservarNumerobutton().waitForExistence();
		button_reservarNumerobutton().click();
	}
}