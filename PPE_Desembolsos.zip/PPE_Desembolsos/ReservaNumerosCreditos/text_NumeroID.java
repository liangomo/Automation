package ReservaNumerosCreditos;
import resources.ReservaNumerosCreditos.text_NumeroIDHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_NumeroID extends text_NumeroIDHelper
{

	public void testMain(Object[] args) 
	{
		text_campoRequerido().waitForExistence();
		text_campoRequerido().setText((String) args[0]);
	}
}