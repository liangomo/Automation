package ReservaNumerosCreditos;
import resources.ReservaNumerosCreditos.list_TipoIDHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_TipoID extends list_TipoIDHelper
{

	public void testMain(Object[] args) 
	{
		list_seleccioneUnaOpcion().click();
		list_seleccioneUnaOpcion().click(atText((String) args[0]));
	}
}
