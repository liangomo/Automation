package SuperClaseAyudante;
import java.io.File;
import java.sql.SQLException;

import resources.SuperClaseAyudante.CreacionCarpetasLogsHelper;

public class CreacionCarpetasLogs extends CreacionCarpetasLogsHelper
{

	public void testMain(Object[] args) throws SQLException 
	{
		/** Creaci�n Carpetas */
		File folder0 = new File("C:\\tmp\\PPE_Desembolsos");
		folder0.mkdir();
		
		File folder1 = new File("C:\\tmp\\PPE_Desembolsos\\Imagenes");
		folder1.mkdir();

		File folder2 = new File("C:\\tmp\\PPE_Desembolsos\\B002");
		folder2.mkdir();

		File folder3 = new File("C:\\tmp\\PPE_Desembolsos\\B131");
		folder3.mkdir();

		File folder4 = new File("C:\\tmp\\PPE_Desembolsos\\B300");
		folder4.mkdir();
		
		File folder5 = new File("C:\\tmp\\PPE_Desembolsos\\BB01");
		folder5.mkdir();
		
		File folder6 = new File("C:\\tmp\\PPE_Desembolsos\\BB15");
		folder6.mkdir();
		
		File folder7 = new File("C:\\tmp\\PPE_Desembolsos\\BB27");
		folder7.mkdir();
		
		File folder8 = new File("C:\\tmp\\PPE_Desembolsos\\BP14");
		folder8.mkdir();
		
		File folder9 = new File("C:\\tmp\\PPE_Desembolsos\\M002");
		folder9.mkdir();
		
		File folder10 = new File("C:\\tmp\\PPE_Desembolsos\\M007");
		folder10.mkdir();
		
		File folder11 = new File("C:\\tmp\\PPE_Desembolsos\\M039");
		folder11.mkdir();
		
		File folder12 = new File("C:\\tmp\\PPE_Desembolsos\\BB04");
		folder12.mkdir();
		
	}
}