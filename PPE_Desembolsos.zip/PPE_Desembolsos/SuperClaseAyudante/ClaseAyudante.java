package SuperClaseAyudante;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import com.rational.test.ft.object.interfaces.TestObject;
import com.rational.test.ft.script.RationalTestScript;

public abstract class ClaseAyudante extends RationalTestScript
{
	/** VARIABLES GLOBALES */
	Document documento;
	Paragraph parrafo;

	private Connection Conec = null;
	Statement St;
	int numeroKill = 0;
	Connection conexionBD;
	Statement stamt;
	String[] Datos;
	String Conn = "//AQUILESSQL25\\REPOSITORY";
	protected int i;
	String cont;


	/**
	 * 
	 * METODOS PARA MANEJO DE LOGS (ARCHIVOS .TXT y ARCHIVOS .JPG)
	 * */

	// M�todo para la generacion o apertura del archivo 
	public FileWriter generacionArchivo(String rutaArchivo, String nombreArchivo ) throws IOException{

		FileWriter fichero = null;
		fichero = new FileWriter(rutaArchivo+nombreArchivo, true);
		return fichero;
	}

	//M�todo para ingresar cadenas de texto al archivo
	public void InsertarArchivo(FileWriter fichero, String sentencia) {

		PrintWriter pw = null;
		pw = new PrintWriter(fichero);
		pw.println(sentencia);
	}

	// M�todo para cerrar y cuardar el archivo	
	public void cerrarArchivo(FileWriter fichero) throws IOException{

		fichero.close();
	}

	// M�todo para guardar imagenes de soporte de las pruebas.
	public void GuardarImagen(RenderedImage image, String Nombre) throws IOException
	{
		File file = new File("C:\\tmpImagenes\\" + Nombre + ".jpg");
		ImageIO.write(image, "jpg", file);
	}

	/**
	 * 
	 * METODOS PARA EL MANEJO DE HORA, MINUTOS Y SEGUNDOS (FECHAS)
	 * 
	 * */

	// M�todo para obtener FECHA en formato, A�oMesDia
	public String ObtenerFecha() {
		String fecha;	
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("yyyyMMdd");
		fecha = formato.format(calendar.getTime());
		return fecha;
	}

	// M�todo para obtener FECHA en formato, MesDiaA�o
	public String FechaInicioDia() {
		String fecha;	
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("MMddyyyy");
		fecha = formato.format(calendar.getTime());
		return fecha;
	}

	// M�todo para obtener mes de certificaci�n
	public String ObtenerMes() {
		Calendar miCalendario = Calendar.getInstance();
		int mes; 
		String m;

		if (ObtenerDia() > 20)
			if (miCalendario.get(Calendar.MONTH) == 11)
				mes = 1;
			else
				mes = miCalendario.get(Calendar.MONTH)+2;
		else
			mes = miCalendario.get(Calendar.MONTH) + 1;

		if (mes < 10)
			m = "0" + mes;
		else
			m = "" + mes;

		String mesCertif = "";

		switch (m) {

			case "01": {
				mesCertif = "Enero";
				break;
			} case "02": {
				mesCertif = "Febrero";
				break;
			} case "03": {
				mesCertif = "Marzo";
				break;
			} case "04": {
				mesCertif = "Abril";
				break;
			} case "05": {
				mesCertif = "Mayo";
				break;
			} case "06": {
				mesCertif = "Junio";
				break;
			} case "07": {
				mesCertif = "Julio";
				break;
			} case "08": {
				mesCertif = "Agosto";
				break;
			} case "09": {
				mesCertif = "Septiembre";
				break;
			} case "10": {
				mesCertif = "Octubre";
				break;
			} case "11": {
				mesCertif = "Noviembre";
				break;
			} case "12": {
				mesCertif = "Diciembre";
				break;
			} 
		}
		return mesCertif;
	}

	// M�todo para obteber el d�a actual
	public Integer ObtenerDia() {
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		return diaHoy;
	}

	// M�todo para obteber el a�o actual
	public Integer ObtenerA�o() {
		Calendar miCalendario = Calendar.getInstance();
		int a�o = miCalendario.get(Calendar.YEAR);
		return a�o;
	}

	// M�todo para obtener HORA en formato Hora:Minutos:Segundos
	public String ObtenerHora() {
		String hora;	
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("HHmmss");
		calendar.get(Calendar.MONTH);
		hora = formato.format(calendar.getTime());
		return hora;
	}

	/* M�todo para Obtener Fecha Sin Prorrata en formato Mes/Dia/A�o */
	public String FechaReporte() {
		String fecha;	
		Date fechaActual = new Date();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

		fecha = formato.format(calendar.getTime());
		return fecha;

	}

	/* M�todo para Obtener Fecha Sin Prorrata en formato Mes/Dia/A�o */
	public String ObtenerFechaSinProrrata() {
		String fecha;	
		Date fechaActual = new Date();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("MM/dd/yyyy");
		calendar.add(Calendar.MONTH, 1);

		fecha = formato.format(calendar.getTime());
		return fecha;

	}


	/* M�todo para Obtener Fecha Con Prorrata de 10 dias en formato Mes/Dia/A�o	*/
	public String ObtenerFechaConProrrata() {
		String fecha;	
		Date fechaActual = new Date();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("MM/dd/yyyy");
		calendar.add(Calendar.MONTH, 1);
		calendar.add(Calendar.DAY_OF_MONTH, 10 );

		fecha = formato.format(calendar.getTime());
		return fecha;
	}


	/* M�todo para Obtener Fecha Sin Prorrata en formato Mes/Dia/A�o */
	public String ObtenerFechaSinProrrata_Val(Object args, Object argp) {

		int plazo = Integer.parseInt((String) argp);
		String fecha;	
		Date fechaActual = new Date();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("MM/dd/yyyy");

		// Validaci�n Periodo de Pago Intereses
		if (args.equals("Mensual"))
			calendar.add(Calendar.MONTH, 1);
		else if (args.equals("Bimestral")) 
			calendar.add(Calendar.MONTH, 2);
		else if (args.equals("Trimestral")) 
			calendar.add(Calendar.MONTH, 3);
		else if (args.equals("Semestral")) 
			calendar.add(Calendar.MONTH, 6);
		else if (args.equals("Anual")) 
			calendar.add(Calendar.MONTH, 12);
		else 
			calendar.add(Calendar.MONTH, plazo);

		fecha = formato.format(calendar.getTime());
		return fecha;

	}


	/* M�todo para Obtener Fecha Con Prorrata de 10 dias en formato Mes/Dia/A�o	*/
	public String ObtenerFechaConProrrata_Val(Object args, Object argp) {

		int plazo = Integer.parseInt((String) argp);
		String fecha;	
		Date fechaActual = new Date();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("MM/dd/yyyy");

		// Validaci�n Periodo de Pago Intereses
		if (args.equals("Mensual"))
			calendar.add(Calendar.MONTH, 1);
		else if (args.equals("Bimestral")) 
			calendar.add(Calendar.MONTH, 2);
		else if (args.equals("Trimestral")) 
			calendar.add(Calendar.MONTH, 3);
		else if (args.equals("Semestral")) 
			calendar.add(Calendar.MONTH, 6);
		else if (args.equals("Anual")) 
			calendar.add(Calendar.MONTH, 12);
		else 
			calendar.add(Calendar.MONTH, plazo);

		calendar.add(Calendar.DAY_OF_MONTH, 10 );
		fecha = formato.format(calendar.getTime());
		return fecha;
	}


	/* M�todo para Obtener Fecha M002 en formato Mes/Dia/A�o */
	@SuppressWarnings("static-access")
	public String ObtenerFechaLiquidez() {

		String fecha;	
		Date fechaActual = new Date();

		Calendar calendar = Calendar.getInstance();
		System.out.println("D�a de la semana "+ calendar.get(calendar.DAY_OF_WEEK));

		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("MM/dd/yyyy");

		calendar.add(Calendar.MONTH, 1);
		System.out.println("MAS UN MES "+calendar.get(calendar.DAY_OF_WEEK));

		if (calendar.get(calendar.DAY_OF_WEEK)==1)
			calendar.add(calendar.DAY_OF_MONTH, 2);
		if (calendar.get(calendar.DAY_OF_WEEK)==7)
			calendar.add(calendar.DAY_OF_MONTH, 3);

		System.out.println("ARREGLADO"+calendar.get(calendar.DAY_OF_WEEK));

		fecha = formato.format(calendar.getTime());
		return fecha;
	}
	
	/* M�todo para Obtener Fecha M002 en formato Mes/Dia/A�o con Prorrata */
	@SuppressWarnings("static-access")
	public String ObtenerFechaLiquidezConProrrata() {

		String fecha;	
		Date fechaActual = new Date();

		Calendar calendar = Calendar.getInstance();
		System.out.println("D�a de la semana "+ calendar.get(calendar.DAY_OF_WEEK));

		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("MM/dd/yyyy");

		calendar.add(Calendar.MONTH, 1);
		System.out.println("MAS UN MES "+calendar.get(calendar.DAY_OF_WEEK));

		if (calendar.get(calendar.DAY_OF_WEEK)==1)
			calendar.add(calendar.DAY_OF_MONTH, 2);
		if (calendar.get(calendar.DAY_OF_WEEK)==7)
			calendar.add(calendar.DAY_OF_MONTH, 3);

		System.out.println("ARREGLADO"+calendar.get(calendar.DAY_OF_WEEK));

		calendar.add(Calendar.DAY_OF_MONTH, 10 );
		fecha = formato.format(calendar.getTime());
		return fecha;
	}

	/** 
	 * METODOS PARA MANEJO DE LECTURA DE ARCHIVOS
	 *  */

	/* M�todo para Obtener los valores de cuota del desembolso */
	@SuppressWarnings({ "resource", "unused" })
	public String archivo(String[] args, String destinoDesembolso) throws Exception 
	{
		BufferedReader sarchivo = null;
		sarchivo = new BufferedReader(new FileReader("C:\\tmp\\PPE_Desembolsos\\logPPE.txt"));
		int k = 0;
		String linea = "";

		while ((linea = sarchivo.readLine()) != null) {
			k++;
		}

		String line = null;
		int cantLine = 0;

		BufferedReader sarchivoA = null;
		sarchivoA = new BufferedReader(new FileReader("C:\\tmp\\PPE_Desembolsos\\logPPE.txt"));

		if (destinoDesembolso.equals("Abono a Credito")) {
			while (cantLine < k - 3) {
				if (sarchivoA.readLine() == null)
					throw new IOException ("");
				cantLine ++;
			} while (cantLine <= k - 3) {
				line = sarchivoA.readLine();
				if (line == null)
					return line;

				String cadena = null;
				String valorCuota;
				valorCuota = line.substring(14);
				cadena = valorCuota;
				System.out.println(cadena); 
				return valorCuota;
			}
		} else {
			while (cantLine < k - 2) {
				if (sarchivoA.readLine() == null)
					throw new IOException ("");
				cantLine ++;
			} while (cantLine <= k - 2) {
				line = sarchivoA.readLine();
				if (line == null)
					return line;

				String cadena = null;
				String valorCuota;
				valorCuota = line.substring(14);
				cadena = valorCuota;
				System.out.println(cadena); 
				return valorCuota;
			}
		}

		return line;
	}

	/* M�todo para Obtener los montos desembolsados */
	@SuppressWarnings({ "resource", "unused" })
	public String montoNeto(String[] args, String destinoDesembolso) throws Exception 
	{
		BufferedReader sarchivo = null;
		sarchivo = new BufferedReader(new FileReader("C:\\tmp\\PPE_Desembolsos\\logPPE.txt"));
		int k = 0;
		String linea = "";

		while ((linea = sarchivo.readLine()) != null) {
			k++;
		}

		String line = null;
		int cantLine = 0;

		BufferedReader sarchivoA = null;
		sarchivoA = new BufferedReader(new FileReader("C:\\tmp\\PPE_Desembolsos\\logPPE.txt"));

		if (destinoDesembolso.equals("Abono a Credito")) {
			while (cantLine < k - 2) {
				if (sarchivoA.readLine() == null)
					throw new IOException ("");
				cantLine ++;
			} while (cantLine <= k - 2) {
				line = sarchivoA.readLine();
				if (line == null)
					return line;

				String cadena = null;
				String valorCuota;
				valorCuota = line.substring(26);
				cadena = valorCuota;
				System.out.println(cadena); 
				return valorCuota;
			}
		} else {
			while (cantLine < k - 1) {
				if (sarchivoA.readLine() == null)
					throw new IOException ("");
				cantLine ++;
			} while (cantLine <= k - 1) {
				line = sarchivoA.readLine();
				if (line == null)
					return line;

				String cadena = null;
				String valorCuota;
				valorCuota = line.substring(26);
				cadena = valorCuota;
				System.out.println(cadena); 
				return valorCuota;
			}
		}


		return line;
	}

	/**
	 * METODOS PARA ADMINISTRACION 
	 * */

	//M�todo para cerrar navegadores
	public void cerrarNavegadores() 
	{
		// Buscar objetos de navegador con la funci�n find de // Rational
		// Functional Tester y almacenarlos en el objeto de prueba
		TestObject[] browsers = find(atChild(".class", "Html.HtmlBrowser"));
		if (browsers.length == 0) {
			System.out.println("Found no Html.HtmlBrowser");
			return;
		}
		for (TestObject browser : browsers) {
			((com.rational.test.ft.object.interfaces.BrowserTestObject) browser)
			.close();
		}
		// Anular el registro de los objetos de prueba.
		unregister(browsers);
	}

	//M�todo para finalizar proceso IE
	public void MatarProceso() { 
		System.out.println("------------------------------Kill------------------------");
		try {
			String line;
			Process p = Runtime.getRuntime().exec(System.getenv("windir") +"\\system32\\"+"tasklist.exe");
			BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
			while ((line = input.readLine()) != null) 
			{
				if (line.contains("iexplor"))
				{	
					Runtime.getRuntime().exec("taskkill /im "+ line.substring(0,12));
					numeroKill++;
					if (numeroKill<3) {
						MatarProceso();
						sleep(2);
					}	
					else
						Runtime.getRuntime().exec("taskkill /im "+ line.substring(0,12) + "/F");
				}
			}
			input.close();
		} 
		catch (Exception err) 
		{
			err.printStackTrace();
		}
	}

	// M�todo para generalizar Espera en el proyecto seg�n tiempos de respuesta del aplicativo
	public void Espera (int Segundos) {
		sleep(Segundos*8);
	}

	/* Evaluar expresiones regulares traidas de BD */
	public boolean EvaluarExpresion(String Patron, String Mensaje) {
		Pattern p = Pattern.compile(Patron);
		Matcher matcher = p.matcher(Mensaje);

		return matcher.matches();
	}

	// M�todo para obtener el nombre del Datapool 
	public String getDatapool (String ProductoDesembolso) {

		String strDatapool= null;
		if (ProductoDesembolso.equals("BB01")) {
			strDatapool = "BB01_LibreDestino";
		}
		if (ProductoDesembolso.equals("BB27")) {
			strDatapool = "BB27_LibranzasMantiz";
		}
		if (ProductoDesembolso.equals("B002")) {
			strDatapool = "B002_Crediservice";
		}
		if (ProductoDesembolso.equals("B131")) {
			strDatapool = "B131_CredifacilLibranzasConvenioMensual";
		}
		if (ProductoDesembolso.equals("M002")) {
			strDatapool = "M002_Liquidez_30_dias_hasta_180_dias";
		}
		if (ProductoDesembolso.equals("B300")) {
			strDatapool = "B300_Finagro";
		}
		if (ProductoDesembolso.equals("M007")) {
			strDatapool = "M007_Liquidez_12_Meses";
		}
		if (ProductoDesembolso.equals("BB15")) {
			strDatapool = "BB15_Vehiculo_Red_BancoBogota";
		}
		if (ProductoDesembolso.equals("M039")) {
			strDatapool = "M039_Liquidez_18_Meses";
		}
		if (ProductoDesembolso.equals("BP14")) {
			strDatapool = "BP14_Rotativo_Premium_PN";
		}
		return strDatapool;
	}

	// M�todo para comparar si un string esta un vector o no
	public boolean Comparacion (String[] vector, String valor ) {

		String tmp=null;
		for (int i = 0; i < vector.length; i++) {
			if (vector[i].equals(valor)) {
				tmp=vector[i];
			} 
		}

		if (tmp== null) {
			return false;
		} else {
			return true;
		}

	}

	//M�todo para obtener un substring, especificando inicio y fin
	public String getSubString(String string, int inicio, int fin) {

		String stringFinal= "";
		stringFinal= string.substring(inicio, fin);
		return stringFinal;
	}

	public String[] llenarconPN(String[] Vector) {

		// Llenar array tipos de Persona Natural		
		Vector[0]="C - Cedula De Ciudadania";
		Vector[1]="T - Tarjeta de Identidad";
		Vector[2]="P - Pasaporte";
		Vector[3]="E - C�dula de Extranjeria";
		Vector[4]="R - Registro Civil";

		return Vector;
	}


	/* Creacion de metodo genera un numero aleatorio de 17 digitos para el numero de los folios */
	public String GeneracionNumAle() {
		String NumAle = "";
		Random NroCert = new Random();
		long valor = Math.abs(NroCert.nextLong()); 

		NumAle = Long.toString(valor);

		if (NumAle.length() > 17)
			NumAle = NumAle.substring(0, 17);
		else
			while(NumAle.length() < 17)
				NumAle = "0" + NumAle;
		return NumAle;
	}

	/**
	 * METODOS PARA MANEJO DE BASE DE DATOS
	 * */

	public void ConnectionDB() {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Conec = DriverManager
					.getConnection(
							"jdbc:sqlserver://AQUILESSQL25\\REPOSITORY;databaseName=BD_AUT_Desembolsos;",
							"usr_AUTDesembolsos", "usr_AUTDesembolsos#2016");

			if (Conec != null) {

				System.out.println("Successfully connected");

			}
		} catch (SQLException excepcionSql) {
			JOptionPane.showMessageDialog(null, excepcionSql.getMessage(),
					"Error en base de datos", JOptionPane.ERROR_MESSAGE);
		}

		catch (ClassNotFoundException claseNoEncontrada) {
			JOptionPane.showMessageDialog(null, claseNoEncontrada.getMessage(),
					"No se encontr� el controlador", JOptionPane.ERROR_MESSAGE);
		}
	}

	// Metodo de ejecucion de insert,update,delete a la base de datos
	public String[] querySQL(String query) {
		// CONTROLA QUE LA CONSULTA NO ESTE NULA O VACIA
		try {
			ConnectionDB();

			stamt = Conec.createStatement();
			// SE ENVIA CODIGO DE INSERCION SQL
			stamt.executeUpdate(query);
			// SE CIERRA CONEXION
			Conec.close();
		}
		// IMPRIME CON CONSOLA EL SI EXISTIO ALGUN ERROR EN LA CONEXION
		catch (Exception e) {
			e.printStackTrace();
		}
		// NO RETORNA NADA
		return Datos;
	}



	// Metodo para las consultas a la base de datos
	public ResultSet Consulta(String sql) {
		ConnectionDB();
		ResultSet res = null;
		try {
			Statement s = Conec.createStatement();
			res = s.executeQuery(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	// FUNCION PARA GUARDAR LAS IMAGENES CAPTURADAS
	public void guardarImagen(RenderedImage image, String Nombre, Document doc) {
		String ruta = "C:\\tmp\\PPE_Desembolsos\\Imagenes\\" + Nombre + ".jpg";

		// DECLARA Y CREA EL ARCHIVO CON LA IMAGEN RECIBIDA
		File file = new File(ruta);
		try {
			ImageIO.write(image, "jpg", file);
		} catch (IOException e) {
			e.printStackTrace();
		}
		addImage(ruta, doc);
	}

	// METODO QUE CREA UN PDF PARA PRESENTAR LOS RESULTADOS DE LOS SCRIPT
	public Document createPdf(String nombre, String trx) throws DocumentException,
	MalformedURLException, IOException {
		// SE CREA UN DOCUMENTO CON TAMA�O CARTA Y SE ESCOJE LA RUTA Y NOMBRE
		// DEL ARCHIVO
		Document documento = new Document(PageSize.LETTER, 80, 80, 75, 75);
		String archivo = "C:\\tmp\\PPE_Desembolsos\\" + trx + "\\" + nombre + ".pdf";
		@SuppressWarnings("unused")
		PdfWriter writer = PdfWriter.getInstance(documento,
				new FileOutputStream(archivo, true));

		// SE LE AGREGA EL TITULO Y AUTOR AL DOCUMENTO
		documento.addTitle("Registro Pruebas de Regresi�n PPE_Desembolsos - "
				+ nombre);
		documento
		.addAuthor("Equipo de Automatizaci�n - Direcci�n de Desarrollo Tecnologico");
		documento.open();

		// SE CREA UN PARAGRAFO QUE LLEBA EL ENCABEZADO DEL DOCUMENTO TITULO
		// LETRA GRANDE
		Paragraph titulo = new Paragraph();
		titulo.setAlignment(Paragraph.ALIGN_CENTER);
		titulo.setFont(FontFactory.getFont("Sans", 15, Font.BOLD));
		titulo.add("REGISTRO PRUEBAS DE REGRESION LINEA DE CREDITO - " + trx
				+ "\n\n");

		// SE AGREGA EL PARAGRAFO AL DOCUMENTO
		documento.add(titulo);

		return documento;
	}

	/* M�todo para a�adir texto al PDF */
	public void addTexto(String Cadena, Document doc) {
		try {
			Paragraph parrafo = new Paragraph();
			parrafo.setFont(FontFactory.getFont("Sans", 12, Font.NORMAL));
			parrafo.setAlignment(Paragraph.ALIGN_LEFT);
			parrafo.add(Cadena);
			doc.add(parrafo);
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}


	/* M�todo para a�adir texto al PDF CENTRADO (TITULOS) */
	public void addTitulo(String Cadena, Document doc) {
		try {
			Paragraph parrafo = new Paragraph();
			parrafo.setFont(FontFactory.getFont("Sans", 14, Font.NORMAL));
			parrafo.setAlignment(Paragraph.ALIGN_CENTER);
			parrafo.add(Cadena);
			doc.add(parrafo);
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}


	/* M�todo para agregar una im�gen a un PDF */
	public void addImage(String ruta, Document doc) {
		Image imagen;
		try {
			imagen = Image.getInstance(ruta);
			imagen.setAlignment(Image.ALIGN_CENTER);
			imagen.setUseVariableBorders(true);
			imagen.scalePercent(40);
			doc.add(imagen);
		} catch (BadElementException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	/* M�todo para cerrar PDF */
	public void closePDF(Document doc) {
		doc.close();
	}

	// METODO QUE RECORTA LA IMAGEN A UNAS MEDIDAS PREESTABLESIDAS
	public void cutImage(String ruta) throws IOException {
		File file = new File(ruta);
		BufferedImage bi = ImageIO.read(file);

		if (bi.getWidth() > 937) {
			bi = bi.getSubimage(0, 0, 937, bi.getHeight());
			ImageIO.write(bi, "jpg", file);
		}
	}

}