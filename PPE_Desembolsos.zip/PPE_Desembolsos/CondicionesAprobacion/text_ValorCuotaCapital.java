package CondicionesAprobacion;
import resources.CondicionesAprobacion.text_ValorCuotaCapitalHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_ValorCuotaCapital extends text_ValorCuotaCapitalHelper
{
	/**
	 * Script Name   : <b>text_ValorCuotaCapital</b>
	 * Generated     : <b>11/02/2015 17:01:37</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/11
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		text_campoRequerido().waitForExistence();
		text_campoRequerido().setText((String) args[0]);
	}
}

