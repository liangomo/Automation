package CondicionesAprobacion;
import resources.CondicionesAprobacion.list_PeriodoPagoInteresesHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_PeriodoPagoIntereses extends list_PeriodoPagoInteresesHelper
{
	/**
	 * Script Name   : <b>list_PeriodoPago</b>
	 * Generated     : <b>21/01/2015 13:54:50</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/21
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300")) {
			
			list_seleccioneUnAPeriodoPagoI2().waitForExistence();
			list_seleccioneUnAPeriodoPagoI2().select((String) args[0]);
			
		} else {

			list_seleccioneUnAPeriodoPagoI().waitForExistence();
			list_seleccioneUnAPeriodoPagoI().select((String) args[0]);
			
		}
		
		
	}
}

