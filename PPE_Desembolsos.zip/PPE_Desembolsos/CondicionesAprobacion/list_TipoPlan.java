package CondicionesAprobacion;
import resources.CondicionesAprobacion.list_TipoPlanHelper;
/**
 * Description   : Functional Test Script
 * @author Dpena6
 */
public class list_TipoPlan extends list_TipoPlanHelper
{
	/**
	 * Script Name   : <b>list_TipoPlan</b>
	 * Generated     : <b>23/02/2015 09:25:49</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/23
	 * @author Dpena6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnATipoDePlan().waitForExistence();
		list_seleccioneUnATipoDePlan().select((String) args[0]);
	}
}

