package CondicionesAprobacion;
import resources.CondicionesAprobacion.button_Ok_CHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class button_Ok_C extends button_Ok_CHelper
{
	/**
	 * Script Name   : <b>button_Ok</b>
	 * Generated     : <b>21/01/2015 13:52:57</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/21
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
			button_oKbutton().waitForExistence();
			button_oKbutton().click();
	}
}