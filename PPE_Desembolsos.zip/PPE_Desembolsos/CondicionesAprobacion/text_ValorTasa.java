package CondicionesAprobacion;
import resources.CondicionesAprobacion.text_ValorTasaHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_ValorTasa extends text_ValorTasaHelper
{
	/**
	 * Script Name   : <b>text_ValorTasa</b>
	 * Generated     : <b>09/01/2015 16:37:23</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/09
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			text_ingreseElValorDeLaTasaAnu2().waitForExistence();
			text_ingreseElValorDeLaTasaAnu2().setText((String) args[0]);
			
		} else {

			text_ingreseElValorDeLaTasaAnu().waitForExistence();
			text_ingreseElValorDeLaTasaAnu().setText((String) args[0]);
			
		}
		
		
	}
}

