package CondicionesAprobacion;
import resources.CondicionesAprobacion.text_periodoGraciaHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class text_periodoGracia extends text_periodoGraciaHelper
{
	/**
	 * Script Name   : <b>text_periodoGracia</b>
	 * Generated     : <b>21/01/2015 13:58:20</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/21
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		text_campoNumericoRequerido().waitForExistence();
		text_campoNumericoRequerido().setText((String) args[0]);
	}
}

