package CondicionesAprobacion;
import resources.CondicionesAprobacion.list_SignoTasaHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_SignoTasa extends list_SignoTasaHelper
{

	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300_NoDebeEntrar")) {
			
			list_seleccioneUnASignoTasa2().waitForExistence();
			list_seleccioneUnASignoTasa2().select((String) args[0]);
			
		} else {

			list_seleccioneUnASignoTasa().waitForExistence();
			list_seleccioneUnASignoTasa().select((String) args[0]);
			
		}
	}
}