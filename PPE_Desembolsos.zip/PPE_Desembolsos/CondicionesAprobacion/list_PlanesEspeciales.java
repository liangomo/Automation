package CondicionesAprobacion;
import resources.CondicionesAprobacion.list_PlanesEspecialesHelper;
/**
 * Description   : Functional Test Script
 * @author Dpena6
 */
public class list_PlanesEspeciales extends list_PlanesEspecialesHelper
{
	/**
	 * Script Name   : <b>list_PlanesEspeciales</b>
	 * Generated     : <b>23/02/2015 09:28:40</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/02/23
	 * @author Dpena6
	 */
	public void testMain(Object[] args) 
	{
		list_seleccioneUnaOpcion().waitForExistence();
		list_seleccioneUnaOpcion().select((String) args[0]);
	}
}

