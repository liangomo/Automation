package CondicionesAprobacion;
import resources.CondicionesAprobacion.list_TipoTasaHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_TipoTasa extends list_TipoTasaHelper
{
	/**
	 * Script Name   : <b>list_TipoTasa</b>
	 * Generated     : <b>21/01/2015 13:50:23</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/21
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{		
		list_seleccioneUnATipoTasa().waitForExistence();
		list_seleccioneUnATipoTasa().select((String) args[0]);
			
	}
}

