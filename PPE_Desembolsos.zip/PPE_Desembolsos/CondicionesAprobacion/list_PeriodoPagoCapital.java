package CondicionesAprobacion;
import resources.CondicionesAprobacion.list_PeriodoPagoCapitalHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class list_PeriodoPagoCapital extends list_PeriodoPagoCapitalHelper
{
	/**
	 * Script Name   : <b>list_PeriodoPagoCapital</b>
	 * Generated     : <b>21/01/2015 13:56:39</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/01/21
	 * @author DPENA6
	 */
	public void testMain(Object[] args) 
	{
		if (args[1].equals("B300")) {
			
			list_seleccioneUnAPeriodoDePag2().waitForExistence();
			list_seleccioneUnAPeriodoDePag2().select((String) args[0]);
			
		} else {
			System.out.println(args[0]);
			list_seleccioneUnAPeriodoDePag().waitForExistence();
			list_seleccioneUnAPeriodoDePag().select((String) args[0]);
			
		}
		
		
	}
}

