package CondicionesAprobacion;
import resources.CondicionesAprobacion.button_SiguienteHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class button_Siguiente extends button_SiguienteHelper
{

	public void testMain(Object[] args) 
	{
	
		if (args[0].equals("B300_NoDebeEntrar")) {
			
			button_siguientebutton2().waitForExistence();
			button_siguientebutton2().click();
			
		} else {

			button_siguientebutton().waitForExistence();
			button_siguientebutton().click();
			
		}
		
	}
}