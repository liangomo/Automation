package DatosPrincipalesDelCredito;
import resources.DatosPrincipalesDelCredito.C_text_Convenio_2Helper;

public class C_text_Convenio_2 extends C_text_Convenio_2Helper
{

	public void testMain(Object[] args) 
	{
		text_campoNumericoRequerido().waitForExistence();
		text_campoNumericoRequerido().setText((String) args[0]);
	}
}