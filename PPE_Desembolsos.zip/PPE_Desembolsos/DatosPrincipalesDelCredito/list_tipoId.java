package DatosPrincipalesDelCredito;
import resources.DatosPrincipalesDelCredito.list_tipoIdHelper;

public class list_tipoId extends list_tipoIdHelper
{

	public void testMain(Object[] args) 
	{
		list_tipoIdSelect().waitForExistence();
		list_tipoIdSelect().select((String) args[0]);
	}
}