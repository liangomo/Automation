package DatosPrincipalesDelCredito;
import resources.DatosPrincipalesDelCredito.text_numeroIdHelper;

public class text_numeroId extends text_numeroIdHelper
{

	public void testMain(Object[] args) 
	{
		text_numeroIdInput().waitForExistence();
		text_numeroIdInput().setText((String) args[0]);
	}
}