package DatosPrincipalesDelCredito;
import resources.DatosPrincipalesDelCredito.C_text_LineaCreditoHelper;
/**
 * Description   : Functional Test Script
 * @author DPENA6
 */
public class C_text_LineaCredito extends C_text_LineaCreditoHelper
{

	public void testMain(Object[] args) 
	{ 
		text_seleccioneUnaOpcion().waitForExistence();
		text_seleccioneUnaOpcion().setText((String) args[0]);
	}
}