package configInicial.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.lowagie.text.DocumentException;

import configInicial.paginas.CerrarSesion;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import model.Ambientes;
import model.DispositivoPrueba;
import model.Estados;
import model.Navegadores;

public class TestCerrarSesion {
	ObjetosConfigAux objAux;
	CerrarSesion objCerrarSesion;
	
	@BeforeClass
	public void setup() throws IOException, InterruptedException {
		objAux = new ObjetosConfigAux("9d1f456c", true);
		objCerrarSesion = new CerrarSesion(objAux);
	}
	
	@Test
	public void login_CerrarSesion() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.ANDROID, DispositivoPrueba.Movil);
		Thread.sleep(10000);
		objCerrarSesion.cerrarSesion();
	}
	
	@AfterMethod
	public void finalizeTest(ITestResult t) throws MalformedURLException, DocumentException, IOException {
		if (t.getStatus() == ITestResult.SUCCESS)
			objAux.AdminDocPdf.crearDocumento(Estados.SUCCESS);
		else {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			Throwable cause = t.getThrowable();
			if (null != cause) {
				cause.printStackTrace(pw);
				objAux.AdminDocPdf.generaEvidencia(
						"Resultado NO Esperado: "
								+ sw.getBuffer().toString().substring(0, sw.getBuffer().toString().indexOf("at ")),
						objAux.getDriver());
			} else {
				objAux.AdminDocPdf.generaEvidencia("Resultado NO Esperado: ", objAux.getDriver());
			}

			objAux.AdminDocPdf.crearDocumento(Estados.FAILED);
		}
	}

	@AfterClass
	public void tearDowns() {
		objAux.getDriver().quit();
	}

}
