package configInicial.paginas;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

//import org.apache.commons.lang3.ObjectUtils;
import org.openqa.selenium.By;

import control.elementos.ObjetosConfigAux;
import io.appium.java_client.android.AndroidDriver;

public class TerminosCondiciones {
	ObjetosConfigAux objAux;

	// Elementos
	By titTitulo = By.xpath("//*[@id='parentViewContainer']/ion-view/h3");
	By btnFlecha = By.xpath("//*[@class = 'icon icono-abajo-green']");
	By btnAcepto = By.xpath("//*[contains(text(),'Acepto')]");
	
	// Elementos Baner WIFI
	By BannerWifi = By.xpath("//div[contains(@class, 'popup-container info popup-showing active')]");
	By imgWifi = By.xpath("//*[contains(@class,'hide-android4 hide-android5')]");
	By lblNoVolverAMostrar = By.xpath("//button[contains(text(),'No volver a mostrar')]");
	By lblTextoInformacion = By.xpath("//p[contains(text(),'Puedes acceder directamente')]");
	By btnContinuar = By.xpath("//button[contains(text(),'Entendido')]");

	// Constructor
	/**
	 * @param objAux
	 */
	public TerminosCondiciones(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}

	// Eventos
	public String getTitulo() {
		return objAux.getDriver().findElement(titTitulo).getText();
	}

	public void clicBtnFlecha() {
		objAux.getDriver().findElement(btnFlecha).click();
	}

	public void clicBtnAcepto() {
		objAux.getDriver().findElement(btnAcepto).click();
	}
	
	@SuppressWarnings("rawtypes")
	public void validarBannerConexionWifi() throws IOException{
		if(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), BannerWifi) == true){			
			assertTrue(objAux.getDriver().findElement(imgWifi).isDisplayed(),"validando Imagen");
			assertTrue(objAux.getDriver().findElement(lblTextoInformacion).isDisplayed(), "Texto de informacion");
			assertTrue(objAux.getDriver().findElement(lblNoVolverAMostrar).isDisplayed(), "Texto no volver a mostrar");
			objAux.AdminDocPdf.generaEvidencia("Pantalla Wifi", objAux.getDriver());
			objAux.getDriver().findElement(lblNoVolverAMostrar).click();
			objAux.AdminDocPdf.generaEvidencia("Pantalla Terminos y Condiciones", objAux.getDriver());
		}
	}
	
	public void validarTerminosyCondiciones() throws IOException{
		objAux.EsperaElemento(objAux.getDriver(), titTitulo, 10);
		objAux.AdminDocPdf.generaEvidencia("Pantalla inicio", objAux.getDriver());

		clicBtnFlecha();
		objAux.AdminDocPdf.generaEvidencia("Aparece boton aceptar", objAux.getDriver());
		clicBtnAcepto();

		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), titTitulo, 4));
		objAux.AdminDocPdf.generaEvidencia("Walkthrough", objAux.getDriver());
	}

	// Metodo
	public void aceptarTerminos() throws IOException {		
		validarBannerConexionWifi();
		validarTerminosyCondiciones();		
	}
}
