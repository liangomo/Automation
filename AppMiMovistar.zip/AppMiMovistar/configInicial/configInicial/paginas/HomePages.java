package configInicial.paginas;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import control.elementos.ObjetosConfigAux;

public class HomePages {

	ObjetosConfigAux objAux;
	float px = 0;

	/** LISTA ELEMENTOS */
	By btnFlechaAbajo = By.xpath("//i[@class=contains(text(), '')]");
	By divProducto = By.xpath("//span[contains(@class,'alias ng-binding' ) and contains(text(), '')]");
	By btnMas = By.xpath("//*[@class='ng-binding' and contains(text(),'M�s')]");

	/* Constructor */
	public HomePages(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}

	/** EVENTOS (ACCIONES) 
	 * @throws InterruptedException */

	public void clickbtnMas() throws InterruptedException {
		objAux.EsperaElemento(objAux.getDriver(), btnMas);
		objAux.getDriver().findElement(btnMas).click();
	}

	public void clicBtnFlechaAbajo() {
		objAux.getDriver().findElement(btnFlechaAbajo).click();
	}

	/** METODOS */

	public void clicBtnProducto(String pProducto) throws IOException, InterruptedException {
	
		Thread.sleep(5000);
		clickbtnMas();
		clicBtnFlechaAbajo();
		List<WebElement> listaProducto = objAux.getDriver().findElements(divProducto);

		try {
			boolean reintentar = true;
			for (int i = 0; i <= listaProducto.size(); i++) {
				reintentar = true;
				while (reintentar) {
					if (listaProducto.get(i).isDisplayed()) {
						reintentar = false;

						if (listaProducto.get(i).getText().toString().contains(pProducto)) {
							// objAux.desplazarPantalla(objAux.getDriver(),
							// listaProducto.get(i));
							System.out.println(listaProducto.get(i));
							System.out.println(listaProducto.get(i).getText());
							listaProducto.get(i).click();
							i = listaProducto.size() + 1;
							break;
						}
					} else {
						objAux.desplazarPantalla(objAux.getDriver(), listaProducto.get(i));
					}
				}
			}
		} catch (Exception e) {
		}
	}
}