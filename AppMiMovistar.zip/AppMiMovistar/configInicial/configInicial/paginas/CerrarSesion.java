package configInicial.paginas;

import java.io.IOException;
import org.openqa.selenium.By;
import control.elementos.ObjetosConfigAux;

public class CerrarSesion {
	
	ObjetosConfigAux objAux;
	
	/** LISTA ELEMENTOS */
	By btnMas = By.xpath("//span[@class='ng-binding'  and contains(text(),'M�s')]");
	By btnSalir = By.xpath("//span[contains(text(), 'Salir')]");

	
	/* Constructor */
	public CerrarSesion(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}
	
	//Eventos
	
	public void clicBtnMas() throws IOException{
		objAux.EsperaElemento(objAux.getDriver(), btnMas);
		objAux.AdminDocPdf.generaEvidencia("boton mas", objAux.getDriver());
		objAux.getDriver().findElement(btnMas).click();
		objAux.AdminDocPdf.generaEvidencia("boton mas", objAux.getDriver());
	}
	
	public void clicBtnSalir() throws IOException, InterruptedException {
		objAux.getDriver().findElement(btnSalir).click();
		Thread.sleep(15000);
		objAux.AdminDocPdf.generaEvidencia("boton mas", objAux.getDriver());	
	}
	
	public void buscarOpcionSalir() throws IOException, InterruptedException {
		objAux.desplazarPantalla(objAux.getDriver(), btnSalir);		
		objAux.AdminDocPdf.generaEvidencia("boton mas", objAux.getDriver());
	}
	
	//Metodos
	
	public void cerrarSesion() throws IOException, InterruptedException{
		clicBtnMas();
		buscarOpcionSalir();
		clicBtnSalir();
	}
}