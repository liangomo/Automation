package configInicial.paginas;

import static org.testng.Assert.assertFalse;

import java.io.IOException;

import org.openqa.selenium.By;

import control.elementos.ObjetosConfigAux;
import io.appium.java_client.android.AndroidDriver;

public class Walkthrough {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By btnSaltar = By.xpath("//*[contains(text(),'Saltar')]");
	By btnContinuar = By.xpath("//*[contains(text(),'Continuar')]");
	By btnPermitir = By.id("com.android.packageinstaller:id/permission_allow_button");
	By btnAcepto = By.xpath("//*[contains(text(),'Acepto')]");

	/* Constructor */
	public Walkthrough(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}

	/** EVENTOS (ACCIONES) */
	public void clicBtnSaltar() throws IOException {
		objAux.AdminDocPdf.generaEvidencia("boton saltar", objAux.getDriver());
		objAux.getDriver().findElement(btnSaltar).click();
	}

	public void clicBtnContinuar() throws InterruptedException, IOException {
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("boton continuar", objAux.getDriver());
		objAux.getDriver().findElement(btnContinuar).click();
	}

	public void clicBtnAcepto() throws InterruptedException, IOException {
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Bot�n Acepto", objAux.getDriver());
		objAux.getDriver().findElement(btnAcepto).click();
	}

	@SuppressWarnings("rawtypes")
	public void clicBtnPermitir() throws IOException, InterruptedException {
		objAux.AdminDocPdf.generaEvidencia("boton Permitir", objAux.getDriver());
		((AndroidDriver) objAux.getDriver()).context("NATIVE_APP");
		objAux.getDriver().findElement(btnPermitir).click();
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Pantalla inicial", objAux.getDriver());
		((AndroidDriver) objAux.getDriver()).context("WEBVIEW");
	}

	/** METODOS */

	public void execWalkthrough() throws InterruptedException, IOException {		

		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), btnSaltar, 2));
		clicBtnSaltar();
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), btnSaltar, 2));
		clicBtnSaltar();
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), btnContinuar, 2));
		clicBtnContinuar();
		clicBtnAcepto();
		clicBtnPermitir();
	}
}