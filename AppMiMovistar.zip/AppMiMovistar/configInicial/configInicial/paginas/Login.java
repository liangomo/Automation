package configInicial.paginas;

import static org.testng.Assert.assertFalse;

import java.io.IOException;

import org.openqa.selenium.By;

import control.elementos.ObjetosConfigAux;
import io.appium.java_client.android.AndroidDriver;

public class Login {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */
	By btnMas = By.xpath("//span[@class='ng-binding'  and contains(text(),'M�s')]");
	By btnVerTodosMisProductos = By.xpath("//*[contains(text(),'Ver todos mis productos')]");
	By btnIniciarSesion = By.xpath("//*[contains(text(),'Iniciar sesi�n')]");
	By txtUsuario = By.id("UserName");
	By txtPassword = By.id("Password");
	By btnIngresar = By.id("submitbutton");
	By txtIconoMovistar = By.xpath("(//span[@class='icon icono-logo-white'])[1]");

	/* Constructor */
	public Login(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}

	/** EVENTOS (ACCIONES) */
	
	public void clicBtnMas() throws IOException, InterruptedException {
		Thread.sleep(10000);
		objAux.AdminDocPdf.generaEvidencia("Boton Mas", objAux.getDriver());
		objAux.getDriver().findElement(btnMas).click();
	}

	public void clicBtnVerTodosMisProductos() throws IOException, InterruptedException {
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Boton Ver todos mis productos", objAux.getDriver());
		objAux.getDriver().findElement(btnVerTodosMisProductos).click();
	}

	public void clicBtnIniciarSesion() throws IOException {
		objAux.AdminDocPdf.generaEvidencia("Boton Iniciar sesi�n", objAux.getDriver());
		objAux.getDriver().findElement(btnIniciarSesion).click();
	}

	@SuppressWarnings("rawtypes")
	public void setUsuario(String pTxtUsuario) throws IOException, InterruptedException {
		objAux.AdminDocPdf.generaEvidencia("Ingresar usuario", objAux.getDriver());
		((AndroidDriver) objAux.getDriver()).context("NATIVE_APP");
		objAux.getDriver().findElement(txtUsuario).clear();
		objAux.getDriver().findElement(txtUsuario).sendKeys(pTxtUsuario);
	}

	@SuppressWarnings("rawtypes")
	public void setPassword(String pTextPassword) throws IOException {
		objAux.AdminDocPdf.generaEvidencia("Ingresar contrase�a", objAux.getDriver());
		((AndroidDriver) objAux.getDriver()).context("NATIVE_APP");
		objAux.getDriver().findElement(txtPassword).clear();
		objAux.getDriver().findElement(txtPassword).sendKeys(pTextPassword);
	}

	@SuppressWarnings("rawtypes")
	public void clicBtnIngresar() throws IOException, InterruptedException {
		objAux.AdminDocPdf.generaEvidencia("Boton Ingresar", objAux.getDriver());
		objAux.getDriver().findElement(btnIngresar).click();
		((AndroidDriver) objAux.getDriver()).context("WEBVIEW");
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Boton Ingresar", objAux.getDriver());
	}
	
	@SuppressWarnings("rawtypes")
	public void validarIconoMovistar() throws IOException, InterruptedException {
		Thread.sleep(10000);
		if (objAux.getDriver().findElement(txtIconoMovistar).isDisplayed()) {
			objAux.AdminDocPdf.generaEvidencia("Se encuentra el icono movistar", objAux.getDriver());
		} else {
			objAux.AdminDocPdf.generaEvidencia("El icono movistar, no existe", objAux.getDriver());
			((AndroidDriver) objAux.getDriver()).context("WEBVIEW");
		}
	}
	
	/** METODOS */
	
	public void execLogin() throws IOException, InterruptedException {
		
		clicBtnMas();
		clicBtnVerTodosMisProductos();
		clicBtnIniciarSesion();
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), txtUsuario, 2));
		setUsuario(objAux.getUsuario());
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), txtPassword, 2));
		setPassword(objAux.getContrasenia());
		clicBtnIngresar();
	}
	
	public void execLoginNuevo() throws IOException, InterruptedException {
		
		setUsuario(objAux.getUsuario());
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), txtPassword, 2));
		setPassword(objAux.getContrasenia());
		clicBtnIngresar();
	}
}