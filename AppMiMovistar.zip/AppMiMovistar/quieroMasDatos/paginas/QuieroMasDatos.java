package paginas;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import control.elementos.ObjetosConfigAux;
import io.appium.java_client.android.AndroidDriver;

public class QuieroMasDatos {

	ObjetosConfigAux objAux;

	// Elementos
	By btnConsumo = By.xpath("//span[text() = 'Consumos']");
	By menuInternet = By.xpath("//*[@class='ng-binding' and contains(text(),'Internet')]");
	By btnQuieroMasDatos = By.xpath("//a[contains(text(),'Quiero m�s datos')]");
	By txtLoSentimos = By.xpath("//h2[contains(text(),'�Lo sentimos!')]");
	By btnMas = By.xpath("//span[@class='ng-binding'  and contains(text(),'M�s')]");

	By txtComprarDatos = By.xpath("//p[contains(text(),'Comprar datos')]");
	By btnVolver = By.xpath("//span[@class='icon icono-atras-white']");
	By iconoCelular = By.xpath("//span[contains(@class, 'icon icono-recargas-white ')]");

	By tapConRecarga = By.xpath("//span[contains(text(),'Con recarga')]");
	By tapConFactura = By.xpath("//span[contains(text(),'Con factura')]");
	By txtSaldoDeRecargas = By.xpath("//span[contains(text(),'Saldo de Recargas')]");
	By txtValorRecargas = By.xpath("//span[contains(@class,'value ng-binding') and contains(text(),'')]");

	By SeccionChat = By.xpath("//span[contains(@class,'title ng-binding') and text()='Chat']");
	By bonoPrincipalChat = By.xpath("//android.view.View[@content-desc='45MB']");
	By bonoInicialChat = By
			.xpath("((//div[contains(@class,'swiper-wrapper')])[1]/*/*/div[contains(@class,'packageContainer')])[1]");
	By bonoFinalChat = By.xpath(
			"((//div[contains(@class,'swiper-wrapper')])[1]/*/*/div[contains(@class,'packageContainer')])[last()]");
	By btnLoQuieroBonoChat = By.xpath(
			"(//div[contains(@class,'swiper-wrapper')])[1]/div[contains(@class,'itemCompraTablet swiper-slide swiper-slide-active')]/*/div/div[2]/span[contains(text(),'Lo quiero')]");
	By btnOK = By.xpath("//button[contains(text(),'OK')]");
	By btnCerrar = By.xpath("//span[contains(@class,'icono-cerrar-white')]");
	By btnAceptar = By.xpath("//button[contains(text(),'Aceptar')]");
	By btnCancelar = By.xpath("//button[contains(text(),'Cancelar')]");
	By txtTituloPaqueteChat = By.xpath("//h3[contains(text(),'Paquete �?�Chat')]");

	By txtTituloPaqueteInternet = By.xpath("//h3[contains(text(),'Paquete Internet Full')]");
	By bonoPrincipalInternet = By.xpath("//android.view.View[@content-desc='50 MB']");
	By bonoInicialInternet = By
			.xpath("((//div[contains(@class,'swiper-wrapper')])[2]/*/*/div[contains(@class,'packageContainer')])[1]");
	By bonoFinalInternet = By.xpath(
			"((//div[contains(@class,'swiper-wrapper')])[2]/*/*/div[contains(@class,'packageContainer')])[last()]");
	By btnLoQuieroBonoInternet = By.xpath(
			"(//div[contains(@class,'swiper-wrapper')])[2]/div[contains(@class,'itemCompraTablet swiper-slide swiper-slide-active')]/*/div/div[2]/span[contains(text(),'Lo quiero')]");

	By txtTituloPaqueteRedesChat = By.xpath("//h3[contains(text(),'Paquete Redes+Chat')]");
	By bonoPrincipalRedesChat = By.xpath("//android.view.View[@content-desc='800MB']");
	By bonoInicialRedesChat = By
			.xpath("((//div[contains(@class,'swiper-wrapper')])[3]/*/*/div[contains(@class,'packageContainer')])[1]");
	By bonoFinalRedesChat = By.xpath(
			"((//div[contains(@class,'swiper-wrapper')])[3]/*/*/div[contains(@class,'packageContainer')])[last()]");
	By btnLoQuieroBonoRedesChat = By.xpath(
			"(//div[contains(@class,'swiper-wrapper')])[3]/div[contains(@class,'itemCompraTablet swiper-slide swiper-slide-active')]/*/div/div[2]/span[contains(text(),'Lo quiero')]");

	By txtSeccionChat = By.xpath("//span[text()='Chat']");
	By txtSeccionInternet = By.xpath("//span[text()='Internet Full']");
	By txtSeccionRedesChat = By.xpath("//span[text()='Redes+Chat']");

	By btnMiPlan = By.xpath("//*[contains(text(),'Mi Plan')]");
	By txtTituloMiPlan = By.xpath("//p[contains(text(),'Mi Plan')]");

	By btnQuieroMasDatosMenuMas = By.xpath("//a[@class='item-content']/span[contains(text(),'Quiero m�s datos')]");

	// Metodo Constructor
	public QuieroMasDatos(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}

	// Eventos de Elementos
	public void clicBtnConsumo() throws IOException {
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), btnConsumo, 3));
		objAux.getDriver().findElement(btnConsumo).click();
	}

	public void clicBtnQuieroMasDatos() throws IOException {
		objAux.getDriver().findElement(btnQuieroMasDatos).click();
	}

	public void clicBtnMas() throws IOException {
		objAux.AdminDocPdf.generaEvidencia("boton mas", objAux.getDriver());
		objAux.getDriver().findElement(btnMas).click();
	}

	public void clicBtnQuieroMasDatosMenuMas() throws IOException {
		objAux.AdminDocPdf.generaEvidencia("Opcion quiero mas datos", objAux.getDriver());
		objAux.getDriver().findElement(btnQuieroMasDatosMenuMas).click();

	}

	public void clicMenuInternet() throws IOException {
		objAux.getDriver().findElement(menuInternet).click();
		objAux.AdminDocPdf.generaEvidencia("Vista del Menu internet", objAux.getDriver());
	}

	public void clicBotonVolver() {
		objAux.getDriver().findElement(btnVolver).click();
	}

	@SuppressWarnings("rawtypes")
	public void desplazarPantallaHorizontal_IaD(WebDriver driverA, By bonoPrincipal, By bonoInicial)
			throws IOException {

		((AndroidDriver) driverA).context("NATIVE_APP");
		Dimension size = ((AndroidDriver) driverA).manage().window().getSize();
		WebElement elementoPaquete = ((AndroidDriver) driverA).findElement(bonoPrincipal);
		System.out.println("altura con driver nativo -->" + elementoPaquete.getLocation().getY());
		int y_element = (int) elementoPaquete.getLocation().getY();
		((AndroidDriver) driverA).context("WEBVIEW");
		WebElement elementoPaquete2 = ((AndroidDriver) driverA).findElement(By.xpath(
				"(//div[contains(@class,'swiper-wrapper')])[1]/div[contains(@class,'itemCompraTablet swiper-slide swiper-slide-active')]/*/div/div/div[2]"));
		System.out.println("altura con driver webview -->" + elementoPaquete2.getLocation().getY());

		boolean bandera = false;
		while (bandera == false) {
			if (((AndroidDriver) driverA).findElement(bonoInicial).isDisplayed() == true) {
				((AndroidDriver) driverA).context("NATIVE_APP");
				((AndroidDriver) driverA).swipe(5, y_element, (size.getWidth() - 10), y_element, 2000);
				objAux.AdminDocPdf.generaEvidencia("Bono Inicial", objAux.getDriver());
				((AndroidDriver) driverA).context("WEBVIEW");
				bandera = true;
			}
			if (bandera == false) {
				((AndroidDriver) driverA).context("NATIVE_APP");
				((AndroidDriver) driverA).swipe(5, y_element, (size.getWidth() - 10), y_element, 2000);
				((AndroidDriver) driverA).context("WEBVIEW");
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public void desplazarPantallaHorizontal_DaI(WebDriver driverA, By bonoPrincipal, By bonoFinal) throws IOException {

		((AndroidDriver) driverA).context("NATIVE_APP");
		Dimension size = ((AndroidDriver) driverA).manage().window().getSize();
		WebElement elementoPaquete = ((AndroidDriver) driverA).findElement(bonoPrincipal);
		System.out.println("altura con driver nativo -->" + elementoPaquete.getLocation().getY());
		int y_element = (int) elementoPaquete.getLocation().getY();
		((AndroidDriver) driverA).context("WEBVIEW");
		WebElement elementoPaquete2 = ((AndroidDriver) driverA).findElement(By.xpath(
				"(//div[contains(@class,'swiper-wrapper')])[1]/div[contains(@class,'itemCompraTablet swiper-slide swiper-slide-active')]/*/div/div/div[2]"));
		System.out.println("altura con driver webview -->" + elementoPaquete2.getLocation().getY());

		boolean bandera = false;
		while (bandera == false) {
			if (((AndroidDriver) driverA).findElement(bonoFinal).isDisplayed() == true) {
				((AndroidDriver) driverA).context("NATIVE_APP");
				((AndroidDriver) driverA).swipe(((int) size.width / 2), y_element, 5, y_element, 2000);
				objAux.AdminDocPdf.generaEvidencia("Bono Chat", objAux.getDriver());
				((AndroidDriver) driverA).context("WEBVIEW");
				bandera = true;
			}
			if (bandera == false) {
				((AndroidDriver) driverA).context("NATIVE_APP");
				((AndroidDriver) driverA).swipe(((int) size.width / 2), y_element, 5, y_element, 2000);
				objAux.AdminDocPdf.generaEvidencia("Bono Chat", objAux.getDriver());
				((AndroidDriver) driverA).context("WEBVIEW");
			}
		}
	}

	// Metodos

	public void validarTextoLoSentimos() throws IOException {
		objAux.EsperaElemento(objAux.getDriver(), txtLoSentimos, 3);
		assertTrue(objAux.getDriver().findElement(txtLoSentimos).isDisplayed());
		objAux.AdminDocPdf.generaEvidencia("Mensaje de Error", objAux.getDriver());
	}

	public void validarEncabezadoQuieroMasDatos() {
		assertTrue(objAux.getDriver().findElement(txtComprarDatos).isDisplayed(), "Texto titulo Comprar datos");
		assertTrue(objAux.getDriver().findElement(btnVolver).isDisplayed(), "validar boton volver");
		assertTrue(objAux.getDriver().findElement(iconoCelular).isDisplayed(), "validar icono de celular");
	}

	public void validarTapConRecarga() throws IOException {
		objAux.getDriver().findElement(tapConRecarga).click();
		assertTrue(objAux.getDriver().findElement(txtSaldoDeRecargas).isDisplayed(), "validar texto Saldo de Recargas");
		assertTrue(objAux.getDriver().findElement(txtValorRecargas).isDisplayed(), "validar texto Valor de Recargas");
		objAux.AdminDocPdf.generaEvidencia("Validacion tap Con Recarga", objAux.getDriver());
	}

	public void validarTapConFactura() throws IOException {
		objAux.getDriver().findElement(tapConFactura).click();
	}

	public void validarSeccionChat() throws IOException {
		desplazarPantallaHorizontal_IaD(objAux.getDriver(), bonoPrincipalChat, bonoInicialChat);
		validarBonoSeccionChat();
		desplazarPantallaHorizontal_DaI(objAux.getDriver(), bonoPrincipalChat, bonoFinalChat);

	}

	public void validarBonoSeccionChat() throws IOException {
		assertTrue(objAux.getDriver().findElement(txtSeccionChat).isDisplayed(), "Validar titulo Seccion Chat");
		objAux.getDriver().findElement(btnLoQuieroBonoChat).click();
		objAux.AdminDocPdf.generaEvidencia("Pantalla 1 bono", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(btnCerrar).isDisplayed(), "Boton X - Cerrar");
		assertTrue(objAux.getDriver().findElement(txtTituloPaqueteChat).isDisplayed(), "Texto titulo Paquete Chat");
		objAux.getDriver().findElement(btnOK).click();
		objAux.AdminDocPdf.generaEvidencia("Pantalla 2 bono", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(btnAceptar).isDisplayed(), "Boton Aceptar");
		objAux.getDriver().findElement(btnCancelar).click();
	}

	public void validarSeccionInternet() throws IOException {
		desplazarPantallaHorizontal_IaD(objAux.getDriver(), bonoPrincipalInternet, bonoInicialInternet);
		validarBonoSeccionInternet();
		desplazarPantallaHorizontal_DaI(objAux.getDriver(), bonoPrincipalInternet, bonoFinalInternet);
	}

	public void validarBonoSeccionInternet() throws IOException {
		assertTrue(objAux.getDriver().findElement(txtSeccionInternet).isDisplayed(),
				"Validar titulo Seccion Internet Full");
		objAux.getDriver().findElement(btnLoQuieroBonoInternet).click();
		objAux.AdminDocPdf.generaEvidencia("Pantalla 1 bono", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(btnCerrar).isDisplayed(), "Boton X - Cerrar");
		assertTrue(objAux.getDriver().findElement(txtTituloPaqueteInternet).isDisplayed(),
				"Texto titulo Paquete Internet Full");
		objAux.getDriver().findElement(btnOK).click();
		objAux.AdminDocPdf.generaEvidencia("Pantalla 2 bono", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(btnAceptar).isDisplayed(), "Boton Aceptar");
		objAux.getDriver().findElement(btnCancelar).click();
	}

	public void validarSeccionRedesChat() throws IOException {
		desplazarPantallaHorizontal_IaD(objAux.getDriver(), bonoPrincipalRedesChat, bonoInicialRedesChat);
		validarBonoSeccionRedesChat();
		desplazarPantallaHorizontal_DaI(objAux.getDriver(), bonoPrincipalRedesChat, bonoFinalRedesChat);
	}

	public void validarBonoSeccionRedesChat() throws IOException {
		assertTrue(objAux.getDriver().findElement(txtSeccionRedesChat).isDisplayed(),
				"Validar titulo Seccion Redes+Chat");
		objAux.getDriver().findElement(btnLoQuieroBonoRedesChat).click();
		objAux.AdminDocPdf.generaEvidencia("Pantalla 1 bono", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(btnCerrar).isDisplayed(), "Boton X - Cerrar");
		assertTrue(objAux.getDriver().findElement(txtTituloPaqueteRedesChat).isDisplayed(),
				"Texto titulo Paquete Internet Full");
		objAux.getDriver().findElement(btnOK).click();
		objAux.AdminDocPdf.generaEvidencia("Pantalla 2 bono", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(btnAceptar).isDisplayed(), "Boton Aceptar");
		objAux.getDriver().findElement(btnCancelar).click();
	}

	public void validacionMiplan() throws IOException, InterruptedException {
		Thread.sleep(10000);
		objAux.getDriver().findElement(btnMiPlan).click();
		objAux.AdminDocPdf.generaEvidencia("Quiero mas datos desde Mi Plan", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(txtTituloMiPlan).isDisplayed(), "Titulo Mi Plan");
		assertTrue(objAux.getDriver().findElement(btnQuieroMasDatos).isDisplayed(), "Boton Quiero mas datos");
	}

	// Metodos

	public void compraPaquetesPospago4GCargoFactura() throws IOException, InterruptedException {
		clicBtnConsumo();
		clicMenuInternet();
		clicBtnQuieroMasDatos();
		Thread.sleep(15000);
		validarTextoLoSentimos();
		validacionMiplan();
	}

	public void compraPaquetesCC4GCargoFactura() throws IOException, InterruptedException {
		clicBtnConsumo();
		clicMenuInternet();
		clicBtnQuieroMasDatos();
		Thread.sleep(15000);
		validarTapConFactura();
		validarTextoLoSentimos();
		validacionMiplan();
	}

	public void compraPaquetesCC4GCargoRecarga() throws IOException, InterruptedException {
		clicBtnConsumo();
		clicMenuInternet();
		clicBtnQuieroMasDatos();
		Thread.sleep(15000);
		validarEncabezadoQuieroMasDatos();
		validarTapConRecarga();
		Thread.sleep(5000);
		validarSeccionChat();
		objAux.desplazarPantalla(objAux.getDriver(), 2);
		validarSeccionInternet();
		objAux.desplazarPantalla(objAux.getDriver(), 2);
		validarSeccionRedesChat();
		clicBotonVolver();
		validacionMiplan();
	}

	public void compraPaquetesPospago3GCargoRecarga() throws IOException, InterruptedException {
		clicBtnConsumo();
		clicMenuInternet();
		clicBtnQuieroMasDatos();
		Thread.sleep(15000);
		validarTextoLoSentimos();
		validacionMiplan();
	}

	public void compraPaquetesCC3GCargoRecarga() throws IOException, InterruptedException {
		clicBtnConsumo();
		clicMenuInternet();
		clicBtnQuieroMasDatos();
		Thread.sleep(15000);
		validarEncabezadoQuieroMasDatos();
		validarTapConRecarga();
		Thread.sleep(5000);
		validarSeccionChat();
		objAux.desplazarPantalla(objAux.getDriver(), 2);
		validarSeccionInternet();
		objAux.desplazarPantalla(objAux.getDriver(), 2);
		validarSeccionRedesChat();
		clicBotonVolver();
		validacionMiplan();
	}

	// Metodos version 2

	public void compraPaquetesPospago4GCargoFactura_2() throws IOException, InterruptedException {
		Thread.sleep(10000);
		clicBtnMas();
		clicBtnQuieroMasDatosMenuMas();
		Thread.sleep(15000);
		validarTextoLoSentimos();
	}

	public void compraPaquetesCC4GCargoFactura_2() throws IOException, InterruptedException {
		Thread.sleep(10000);
		clicBtnMas();
		clicBtnQuieroMasDatosMenuMas();
		Thread.sleep(15000);
		validarTapConFactura();
		validarTextoLoSentimos();
		validacionMiplan();
	}
	
	public void compraPaquetesCC4GCargoRecarga_2() throws IOException, InterruptedException {
		Thread.sleep(10000);
		clicBtnMas();
		clicBtnQuieroMasDatosMenuMas();
		Thread.sleep(20000);
		validarEncabezadoQuieroMasDatos();
		validarTapConRecarga();
		Thread.sleep(5000);
		validarSeccionChat();
		objAux.desplazarPantalla(objAux.getDriver(), 2);
		validarSeccionInternet();
		objAux.desplazarPantalla(objAux.getDriver(), 2);
		validarSeccionRedesChat();
		clicBotonVolver();
	}

	public void compraPaquetesCC3GCargoRecarga_2() throws IOException, InterruptedException {
		Thread.sleep(10000);
		clicBtnMas();
		clicBtnQuieroMasDatosMenuMas();
		Thread.sleep(15000);
		validarEncabezadoQuieroMasDatos();
		validarTapConRecarga();
		Thread.sleep(5000);
		validarSeccionChat();
		objAux.desplazarPantalla(objAux.getDriver(), 2);
		validarSeccionInternet();
		objAux.desplazarPantalla(objAux.getDriver(), 2);
		validarSeccionRedesChat();
		clicBotonVolver();
	}

}
