package test;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.lowagie.text.DocumentException;

import configInicial.paginas.HomePages;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import manager.param.AdminParam;
import model.Ambientes;
import model.DispositivoPrueba;
import model.Estados;
import model.Navegadores;
import model.TipoCone;
import paginas.QuieroMasDatos;

public class TestQuieroMasDatos {
	
	ObjetosConfigAux objAux;
	QuieroMasDatos objQuieroMasDatos;
	HomePages objHomePages;
	
	@BeforeClass
	public void setup() throws IOException, InterruptedException {
		objAux = new ObjetosConfigAux("9d1f456c", true);
		objQuieroMasDatos = new QuieroMasDatos(objAux);
		objHomePages = new HomePages(objAux);
	}
	
	//CP_1 Compra de paquetes cargo a la factura pospago 4G
	@Test (priority = 1)
	public void compraPaquetesPospago4GCargoFactura() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "QuieroMasDatos");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objQuieroMasDatos.compraPaquetesPospago4GCargoFactura();
	}
	
	//CP_3 Compra de paquetes cargo a la Factura Cuenta Control 4G
	@Test (priority = 2)
	public void compraPaquetesCC4GCargoFactura() throws IOException, InterruptedException {
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "QuieroMasDatos");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objQuieroMasDatos.compraPaquetesCC4GCargoFactura();
	}
	
	//CP_4 Compra de paquetes cargo a la Recarga Cuenta Control 4G
	@Test (priority = 3)
	public void compraPaquetesCC4GCargoRecarga() throws IOException, InterruptedException {
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "QuieroMasDatos");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objQuieroMasDatos.compraPaquetesCC4GCargoRecarga();
	}
	
	//CP_5 Compra de paquetes cargo a la Recarga Cuenta Control 3G
	@Test (priority = 4)
	public void compraPaquetesCC3GCargoRecarga() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "QuieroMasDatos");
		objAux.AdminParam.ObtenerParametros();	
		Thread.sleep(20000);
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objQuieroMasDatos.compraPaquetesCC3GCargoRecarga();
	}
	
	// Version 2 de los flujos
	
	//CP_1 Compra de paquetes cargo a la factura pospago 4G
	@Test (priority = 5)
	public void compraPaquetesPospago4GCargoFactura_2() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "QuieroMasDatos_2");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objQuieroMasDatos.compraPaquetesPospago4GCargoFactura_2();
	}
	
	//CP_3 Compra de paquetes cargo a la Factura Cuenta Control 4G
	@Test (priority = 6)
	public void compraPaquetesCC4GCargoFactura_2() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "QuieroMasDatos_2");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objQuieroMasDatos.compraPaquetesCC4GCargoFactura_2();
	}
	
	//CP_4 Compra de paquetes cargo a la Recarga Cuenta Control 4G
	@Test (priority = 7)
	public void compraPaquetesCC4GCargoRecarga_2() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "QuieroMasDatos_2");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objQuieroMasDatos.compraPaquetesCC4GCargoRecarga_2();
	}
	
	//CP_5 Compra de paquetes cargo a la Recarga Cuenta Control 3G
	@Test (priority = 8)
	public void compraPaquetesCC3GCargoRecarga_2() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "QuieroMasDatos_2");
		objAux.AdminParam.ObtenerParametros();	
		Thread.sleep(20000);
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objQuieroMasDatos.compraPaquetesCC3GCargoRecarga_2();
	}
	
	@AfterMethod
	public void finalizeTest(ITestResult t) throws MalformedURLException, DocumentException, IOException {
		if (t.getStatus() == ITestResult.SUCCESS)
			objAux.AdminDocPdf.crearDocumento(Estados.SUCCESS);
		else {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			Throwable cause = t.getThrowable();
			if (null != cause) {
				cause.printStackTrace(pw);
				objAux.AdminDocPdf.generaEvidencia(
						"Resultado NO Esperado: "
								+ sw.getBuffer().toString().substring(0, sw.getBuffer().toString().indexOf("at ")),
						objAux.getDriver());
			} else {
				objAux.AdminDocPdf.generaEvidencia("Resultado NO Esperado: ", objAux.getDriver());
			}
			objAux.AdminDocPdf.crearDocumento(Estados.FAILED);
		}
	}
	
	@AfterClass
	public void tearDowns() {
		objAux.getDriver().quit();
	}

}
