package menuMas.paginas;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import control.elementos.ObjetosConfigAux;
import io.appium.java_client.android.AndroidDriver;

public class Mas {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By txtTransac = By.xpath("//span[contains(text(), 'Transacciones')]");
	By txtAsistencia = By.xpath("//span[contains(text(), 'Asistencia')]");
	By txtMas = By.xpath("//span[contains(text(), 'M�s')]");
	By txtSaludo = By.xpath("//p[@class='name ng-binding' and contains(text(), '')]");
	By txtTelefono = By.xpath("//p[@class='phone ng-binding' and contains(text(), '')]");

	By btnCompartir = By.xpath("//a[@class='icon icono-compartir-app' and contains(text(), '')]");
	By btnNotificacion = By.xpath("//a[@class='icon icono-notificaciones-white' and contains(text(), '')]");
	By btnFlechaAbajo = By.xpath("//i[@class=contains(text(), '')]");
	By btnBuscar = By.xpath("//div[@class='col-xs-12 col-sm-6']");
	By btnSeleccionaUnaMarca = By.xpath("(//div[@class='col-xs-12 col-sm-3'])[1]");
	By btnSeleccionaUnModelo = By.xpath("(//div[@class='col-xs-12 col-sm-3'])[2]");
	By btnConsumos = By.xpath("//span[text() = 'Consumos']");
	By btnRecargar = By.xpath("//*[@class='ng-binding' and contains(text(),'Recargar')]");
	By btnVolver = By.xpath("(//span[@class='icon icono-atras-white'])[1]");
	By btnCerrarVentaEmergente = By.xpath("//a[@class='wm-btn lightbox_close']");
	By btnPermitir = By.id("com.android.packageinstaller:id/permission_allow_button");
	By btnCargarMas = By.xpath("//a[@class= 'button buttonOutline' and contains(text(),'Cargar m�s')]");
	By btnTapPuntosDePago = By.xpath("//span[@class= 'ng-binding' and contains(text(),'Puntos de pago')]");
	By btnVerMas = By.xpath("(//*[@class= 'item' ])[3]");
	By btnPagarFactura = By.xpath("//a[@class= 'button buttonSolid' ]");
	By btnTapPagosEnLinea = By.xpath("//span[@class= 'ng-binding' and contains(text(),'Pagos en l�nea')]");
	By btnTapRecargasEnLinea = By.xpath("//span[@class= 'ng-binding' and contains(text(),'Recargas en l�nea')]");

	By imgPrincipal = By.xpath("//img[@class='pic' and contains(text(), '')]");
	By lstBuscarConfig = By.xpath("//*[@class= 'ui-autocomplete-input' ]");
	By frame = By.xpath("//*[@id=\"parentViewContainer\"]/ion-view/ion-content/div/iframe");
	By iframe = By.xpath("//*[@class='iframe']");
	By opcionesMenuMas = By.xpath("//a[@class='item-content']");
	By opcionesTituloMas = By.xpath("//ion-item[@class='category item']");
	By lblLoSentimos = By.xpath("//*[contains(text(),'�Lo sentimos!')]");
	By lblMensajeError = By.xpath("//P[@ng-bind-html='error.message']");
	By imgIconoAlerta = By.xpath("//span[contains(@class,'icon icono-alerta-error-off')]");
	By lblGuiasInter = By.xpath("//a[contains(text(),'Gu�as interactivas en l�nea')]");
	By iconoMovistar = By.xpath("//span[@class='logo icono-logo']");
	By msjTermCondic= By.xpath("//div[@ng-bind-html='data.result[0].text']");
	By lblMasPopulares = By.xpath("//*[contains(text(),'M�s populares')]");
	By tapConRecarga = By.xpath("//*[contains(text(),'Con recarga')]");
	By tapConFactura = By.xpath("//*[contains(text(),'Con factura')]");
	By imgCelular = By.xpath("//span[@class='icon icono-recargas-white ']");

	// TRANSACCIONES
	By btnMas = By.xpath("//span[@class='ng-binding'  and contains(text(),'M�s')]");
	By btnTransferir = By.xpath("//a[@class='item-content']/span[contains(text(),'Transferir')]");
	By btnRegistraTuEquipo = By.xpath("//a[@class='item-content']/span[contains(text(),'Registra tu equipo')]");
	By btnFamiliaYAmigos = By.xpath("//a[@class='item-content']/span[contains(text(),'Familia y amigos')]");
	By btnRecargaEnLinea = By.xpath("//a[@class='item-content']/span[contains(text(),'Recarga en l�nea')]");
	By btnQuieroMasDatos = By.xpath("//a[@class='item-content']/span[contains(text(),'Quiero m�s datos')]");
	By btnHistPagRec = By.xpath("//a[@class='item-content']/span[contains(text(),'Historial de pagos y recargas')]");
	By btnHistorialPagos = By.xpath("//span[contains(text(), 'Historial de pagos')]");
	By btnOfertasYPromociones = By.xpath("//a[@class='item-content']/span[contains(text(),'Ofertas y promociones')]");
	By btnTienda = By.xpath("//a[@class='item-content']/span[contains(text(),'Tienda')]");
	By btnRenovarEquipo = By.xpath("//span[contains(text(), 'Renovar equipo')]");

	// ASISTENCIA
	By btnConfigEquipo = By.xpath("//a[@class='item-content']/span[contains(text(),'Configura tu equipo')]");
	By btnConfigModem = By.xpath("//a[@class='item-content']/span[contains(text(),'Configura tu m�dem')]");
	By btnConfigDecod = By.xpath("//a[@class='item-content']/span[contains(text(),'Configura tu decodificador')]");
	By btnAsistenteVirtual = By.xpath("//a[@class='item-content']/span[contains(text(),'Asistente virtual')]");

	// M�S
	By btnCentrosDeExperiencia = By.xpath("//a[@class='item-content']/span[contains(text(),'Centros de experiencia')]");
	By btnTerminosYCondiciones = By.xpath("//a[@class='item-content']/span[contains(text(),'T�rminos y condiciones')]");
	By btnSalir = By.xpath("//span[contains(text(), 'Salir')]");

	// TITULOS
	By iconoCarrito = By.xpath("(//span[@class='icon icono-tienda-white '])[1]");
	By titComprarDatos = By.xpath("(//p[@class='ng-binding' and contains(text(),'Comprar datos')])[1]");
	By titHistPagRec = By.xpath("(//p[@class='ng-binding' and contains(text(),'Historial de pagos y recargas')])[1]");
	By titHistPagos = By.xpath("(//p[@class='ng-binding' and contains(text(),'Historial de pagos')])[1]");
	By titOfertasYProm = By.xpath("(//p[@class='ng-binding' and contains(text(),'Ofertas y promociones')])[1]");
	By titConfiguraEquipo = By.xpath("(//p[@class='ng-binding' and contains(text(),'Configurar equipo')])[1]");
	By titConfiguraModem = By.xpath("(//p[@class='ng-binding' and contains(text(),'Configurar m�dem')])[1]");
	By titConfDecod = By.xpath("(//p[@class='ng-binding' and contains(text(),'Configurar decodificador')])[1]"); // VALIDAR
	By titCentroExperiencia = By.xpath("(//p[@class='ng-binding' and contains(text(),'Centros de Experiencia')])[1]");
	By titTermYCondic = By.xpath("(//p[@class='ng-binding' and contains(text(),'T�rminos y Condiciones')])[1]");
	By titPagosEnLinea = By.xpath("//div[@class= 'title ng-binding' and contains(text(),'Pagos en l�nea')]");
	By titBancos = By.xpath("//div[@class= 'title ng-binding' and contains(text(),'Bancos')]");
	By titOtrosPuntosPago = By.xpath("//div[@class= 'title ng-binding' and contains(text(),'Otros Puntos de Pago')]");
	By titCercaDeTi = By.xpath("//div[@class= 'title' and contains(text(), 'Cerca de ti')]");

	List<WebElement> lstTitulos;
	List<WebElement> lstOpciones;

	/* Constructor */
	public Mas(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}

	/** EVENTOS (ACCIONES) */

	public void swichtIframe() {
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(frame));
	}

	public void clickBtnMas() throws IOException, InterruptedException {

		Thread.sleep(12000);
		objAux.getDriver().findElement(btnMas).click();
		objAux.AdminDocPdf.generaEvidencia("Vista del menu de bot�n Mas", objAux.getDriver());
	}
	
	public void clickBtnFlechaAbajoDoble() throws IOException, InterruptedException {

		Thread.sleep(2000);
		objAux.getDriver().findElement(btnFlechaAbajo).click();
		objAux.getDriver().findElement(btnFlechaAbajo).click();
	}

	public void validarCamposBusqueda() throws InterruptedException {

		Thread.sleep(3000);
		objAux.getDriver().findElement(btnBuscar).isDisplayed();
		assertTrue(objAux.getDriver().findElement(btnSeleccionaUnaMarca).isDisplayed(), "btnSeleccionaUnaMarca");
		assertTrue(objAux.getDriver().findElement(btnSeleccionaUnModelo).isDisplayed(), "btnSeleccionaUnModelo");
	}

	@SuppressWarnings("rawtypes")
	public void evaluarOpciones(List<By> opcionesMas, List<By> tituloMas) throws IOException {
		lstOpciones = objAux.getDriver().findElements(opcionesMenuMas);
		lstTitulos = objAux.getDriver().findElements(opcionesTituloMas);

		for (int i = 0; i < lstOpciones.size(); i++) {
			for (int j = 0; j < opcionesMas.size(); j++) {
				if (!lstOpciones.get(i).isDisplayed()) {
					objAux.desplazarPantalla(objAux.getDriver(), lstOpciones.get(i));
					objAux.AdminDocPdf.generaEvidencia("Dezplazamiento de pantalla.", objAux.getDriver());
				}

				if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), opcionesMas.get(j))) {
					if (lstOpciones.get(i).getText().toString()
							.equals(objAux.getDriver().findElement(opcionesMas.get(j)).getText())) {
						opcionesMas.remove(j);
						objAux.AdminDocPdf
						.generaEvidencia("Elemento existe: " + lstOpciones.get(i).getText().toString());

						break;
					}
				} else {
					objAux.AdminDocPdf
					.generaEvidencia("El elemento esperado no se encontr�:" + opcionesMas.get(i).toString());
					opcionesMas.remove(j);
				}

				if (j == opcionesMas.size() - 1) {
					objAux.AdminDocPdf
					.generaEvidencia("Elemento no encontrado: " + lstOpciones.get(i).getText().toString());
				}
			}
		}

		objAux.AdminDocPdf.generaEvidencia("Validacion Titulos Opci�n Mas");

		for (int i = 0; i < lstTitulos.size(); i++) {
			for (int j = 0; j < tituloMas.size(); j++) {
				if (lstTitulos.get(i).getText().toString()
						.equals(objAux.getDriver().findElement(tituloMas.get(j)).getText())) {
					tituloMas.remove(j);
					objAux.AdminDocPdf.generaEvidencia("Elemento existe:" + lstTitulos.get(i).getText().toString());
					break;
				}

				if (j == opcionesMas.size() - 1) {
					objAux.AdminDocPdf
					.generaEvidencia("Elemento no encontrado: " + lstOpciones.get(i).getText().toString());
				}
			}
		}

		if (opcionesMas.size() > 0) {
			for (int i = 0; i < opcionesMas.size(); i++) {
				objAux.AdminDocPdf.generaEvidencia(
						"El elemento esperado no se encontr�:" + opcionesMas.get(i).toString(), objAux.getDriver());
			}
		}

		if (tituloMas.size() > 0) {
			for (int i = 0; i < tituloMas.size(); i++) {
				objAux.AdminDocPdf.generaEvidencia("El elemento esperado no se encontr�:" + tituloMas.get(i).toString(),
						objAux.getDriver());
			}
		}
	}

	public void validarEncabezado() throws IOException {

		assertTrue(objAux.getDriver().findElement(txtSaludo).isDisplayed(), "txtSaludo");
		assertTrue(objAux.getDriver().findElement(txtTelefono).isDisplayed(), "txtTelefono");
		assertTrue(objAux.getDriver().findElement(btnCompartir).isDisplayed(), "btnCompartir");
		assertTrue(objAux.getDriver().findElement(btnNotificacion).isDisplayed(), "btnNotificacion");
		assertTrue(objAux.getDriver().findElement(btnFlechaAbajo).isDisplayed(), "btnFlechaAbajo");
		assertTrue(objAux.getDriver().findElement(imgPrincipal).isDisplayed(), "imgPrincipal");
	}

	@SuppressWarnings("rawtypes")
	public void clickBtnVolver() throws IOException, InterruptedException {

		Thread.sleep(10000);
		objAux.getDriver().switchTo().defaultContent();
		objAux.getDriver().findElement(btnVolver).click();
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtTransac), "Regreso al men� M�s");
		objAux.AdminDocPdf.generaEvidencia("Validar boton volver", objAux.getDriver());
	}

	public void clickBtnConfiguraTuEquipo() throws InterruptedException, IOException {

		objAux.EsperaElemento(objAux.getDriver(), btnConfigEquipo);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n men� m�s", objAux.getDriver());

		if (objAux.getDriver().findElement(btnConfigEquipo).isDisplayed()) {
			objAux.getDriver().findElement(btnConfigEquipo).click();

		} else {
			objAux.desplazarPantalla(objAux.getDriver(), btnConfigEquipo);
			objAux.getDriver().findElement(btnConfigEquipo).click();
			Thread.sleep(5000);
			objAux.AdminDocPdf.generaEvidencia("Configura tu Equipo", objAux.getDriver());
		}

		objAux.EsperaElemento(objAux.getDriver(), iframe);
	}

	public void ventaEmergente() throws IOException, InterruptedException {
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Ventana Emergente", objAux.getDriver());
		objAux.EsperaElemento(objAux.getDriver(), iframe);
		objAux.getDriver().findElement(btnCerrarVentaEmergente).click();
		objAux.AdminDocPdf.generaEvidencia("Cerrar ventana emergente", objAux.getDriver());
		String handle = objAux.getDriver().getWindowHandle();
		objAux.getDriver().switchTo().window(handle);
	}

	public void clickBtnQuieroMasDatos() throws IOException, InterruptedException {

		objAux.EsperaElemento(objAux.getDriver(), btnQuieroMasDatos);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n men� m�s", objAux.getDriver());
		objAux.getDriver().findElement(btnQuieroMasDatos).click();

		objAux.EsperaElemento(objAux.getDriver(), titComprarDatos);
		Thread.sleep(15000);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n Quiero mas datos", objAux.getDriver());
	}

	public void clickBtnHistorialDePagosYRecargas() throws IOException, InterruptedException {

		objAux.EsperaElemento(objAux.getDriver(), btnHistPagRec);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n men� m�s", objAux.getDriver());
		objAux.getDriver().findElement(btnHistPagRec).click();

		objAux.EsperaElemento(objAux.getDriver(), titHistPagRec);
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso Historial de pagos y recargas", objAux.getDriver());
	}
	
	public void clickBtnHistorialDePagos() throws IOException, InterruptedException {

		objAux.EsperaElemento(objAux.getDriver(), btnHistorialPagos);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n men� m�s", objAux.getDriver());
		objAux.getDriver().findElement(btnHistorialPagos).click();

		objAux.EsperaElemento(objAux.getDriver(), titHistPagos);
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso Historial de pagos", objAux.getDriver());
	}

	public void clickOfertasYPromociones() throws IOException, InterruptedException {
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n men� m�s", objAux.getDriver());
		objAux.getDriver().findElement(btnOfertasYPromociones).click();
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Validar boton Ofertas y Promociones", objAux.getDriver());
	}

	public void clickConfiguraModem() throws IOException, InterruptedException {

		objAux.EsperaElemento(objAux.getDriver(), btnConfigModem);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n men� m�s", objAux.getDriver());

		if (objAux.getDriver().findElement(btnConfigModem).isDisplayed()) {
			objAux.getDriver().findElement(btnConfigModem).click();
		} else {
			objAux.desplazarPantalla(objAux.getDriver(), btnConfigModem);
			objAux.getDriver().findElement(btnConfigModem).click();
		}

		objAux.EsperaElemento(objAux.getDriver(), lstBuscarConfig);
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Configura tu Modem", objAux.getDriver());
	}

	public void clickBtnPuntosDePago() throws InterruptedException, IOException {

		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n men� m�s", objAux.getDriver());
		objAux.getDriver().findElement(btnTapPuntosDePago).click();
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Validar boton puntos de pago", objAux.getDriver());
		Thread.sleep(5000);
	}

	public void clickConfiguraDecodificador() throws IOException, InterruptedException {

		objAux.EsperaElemento(objAux.getDriver(), btnConfigDecod);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n men� m�s", objAux.getDriver());

		if (objAux.getDriver().findElement(btnConfigDecod).isDisplayed()) {
			objAux.getDriver().findElement(btnConfigDecod).click();
		} else {
			objAux.desplazarPantalla(objAux.getDriver(), btnConfigDecod);
			objAux.getDriver().findElement(btnConfigDecod).click();
		}
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("Configura tu decodificador", objAux.getDriver());
	}

	@SuppressWarnings("rawtypes")
	public void clickBtnPermitir() throws IOException, InterruptedException {

		try {
			((AndroidDriver) objAux.getDriver()).context("NATIVE_APP");
			objAux.AdminDocPdf.generaEvidencia("boton Permitir", objAux.getDriver());
			objAux.getDriver().findElement(btnPermitir).click();
			((AndroidDriver) objAux.getDriver()).context("WEBVIEW");
		} catch (Exception e) {
			objAux.AdminDocPdf.generaEvidencia("No se encontro la ventana emergente - permitir uso GPS",
					objAux.getDriver());
			((AndroidDriver) objAux.getDriver()).context("WEBVIEW");
		}
	}

	public void clickCentroExperiencia() throws IOException, InterruptedException {

		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n men� m�s", objAux.getDriver());
		
		if (objAux.getDriver().findElement(btnCentrosDeExperiencia).isDisplayed()) {
			objAux.getDriver().findElement(btnCentrosDeExperiencia).click();
			Thread.sleep(20000);
		} else {
			objAux.desplazarPantalla(objAux.getDriver(), btnCentrosDeExperiencia);
			objAux.getDriver().findElement(btnCentrosDeExperiencia).click();
			Thread.sleep(20000);
		}
	}

	public void clickTerminosYCondiciones() throws IOException, InterruptedException {
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Validar ingreso opci�n men� m�s", objAux.getDriver());
		
		if (objAux.getDriver().findElement(btnTerminosYCondiciones).isDisplayed()) {
			objAux.getDriver().findElement(btnTerminosYCondiciones).click();
		} else {
			objAux.desplazarPantalla(objAux.getDriver(), btnTerminosYCondiciones);
			objAux.getDriver().findElement(btnTerminosYCondiciones).click();
		}

		objAux.EsperaElemento(objAux.getDriver(), titTermYCondic);
		objAux.AdminDocPdf.generaEvidencia("Terminos y condiciones", objAux.getDriver());
	}

	public void validarBtnCargarMas() throws IOException, InterruptedException {
		Thread.sleep(5000);
		objAux.getDriver().findElement(titCercaDeTi).isDisplayed();
		
		if (!(objAux.getDriver().findElement(btnCargarMas).isDisplayed())) {
			objAux.desplazarDespuesMitadPantalla(objAux.getDriver(), objAux.getDriver().findElement(btnCargarMas));
			objAux.getDriver().findElement(btnCargarMas).isDisplayed();
			objAux.AdminDocPdf.generaEvidencia("Validar boton cargar mas", objAux.getDriver());
		}
	}

	public void clickBtnVerMas() throws IOException {

		if (objAux.getDriver().findElement(btnVerMas).isDisplayed()) {
			objAux.getDriver().findElement(btnVerMas).click();
		} else {
			objAux.desplazarPantalla(objAux.getDriver(), btnVerMas);
			objAux.getDriver().findElement(btnVerMas).click();
		}

		objAux.AdminDocPdf.generaEvidencia("Validar boton ver mas", objAux.getDriver());
	}

	public void validarBtnPagarFactura() throws IOException {

		if ((objAux.getDriver().findElement(btnPagarFactura).isDisplayed())) {
			objAux.AdminDocPdf.generaEvidencia("Validar boton Pagar factura", objAux.getDriver());
		} else {
			objAux.desplazarPantalla(objAux.getDriver(), btnPagarFactura);
			objAux.getDriver().findElement(btnPagarFactura).isDisplayed();
			objAux.AdminDocPdf.generaEvidencia("Validar boton Pagar factura", objAux.getDriver());
		}
	}
	
	public void clickBtnTapPagosEnLinea() throws IOException, InterruptedException {
		
		objAux.getDriver().findElement(btnTapPagosEnLinea).click();
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Click en Tap Pagos en Linea", objAux.getDriver());
		Thread.sleep(5000);
	}
	
	public void clickBtnTapRecargasEnLinea() throws IOException, InterruptedException {
		
		objAux.getDriver().findElement(btnTapRecargasEnLinea).click();
		Thread.sleep(5000);
		objAux.AdminDocPdf.generaEvidencia("Click en Tap Recargas en Linea", objAux.getDriver());
		Thread.sleep(5000);
	}

	public void validarBtnSalir() throws IOException {

		if (!objAux.getDriver().findElement(btnSalir).isDisplayed())
			objAux.desplazarPantalla(objAux.getDriver(), btnSalir);

		objAux.AdminDocPdf.generaEvidencia("Boton salir Visible", objAux.getDriver());
	}

	/** METODOS */

	/* SANITY */

	public void ingresoMenuMasPrepago() throws InterruptedException, IOException {

		// MENU
		assertTrue(objAux.getDriver().findElement(btnConsumos).isDisplayed(), "btnConsumo");
		objAux.AdminDocPdf.generaEvidencia("Validar boton recarga", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(btnRecargar).isDisplayed(), "btnRecargar");
		clickBtnMas();
		validarEncabezado();

		List<By> opcionesMas = new ArrayList<By>();
		List<By> titulosMas = new ArrayList<By>();

		// TRANSACCIONES
		titulosMas.add(txtTransac);
		opcionesMas.add(btnRecargaEnLinea);
		opcionesMas.add(btnOfertasYPromociones);
		opcionesMas.add(btnTienda);
		opcionesMas.add(btnRenovarEquipo);

		// ASISTENCIA
		titulosMas.add(txtAsistencia);
		opcionesMas.add(btnConfigEquipo);
		opcionesMas.add(btnConfigModem);
		opcionesMas.add(btnConfigDecod);
		opcionesMas.add(btnAsistenteVirtual);

		// MAS
		titulosMas.add(txtMas);
		opcionesMas.add(btnCentrosDeExperiencia);
		opcionesMas.add(btnTerminosYCondiciones);
		evaluarOpciones(opcionesMas, titulosMas);
		validarBtnSalir();
	}

	public void ingresoMenuMasPospago() throws InterruptedException, IOException {

		// MENU
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), btnMas, 2), "btnMas Desaparece Elemento");
		clickBtnMas();
		validarEncabezado();

		List<By> opcionesMas = new ArrayList<By>();
		List<By> titulosMas = new ArrayList<By>();

		// TRANSACCIONES
		titulosMas.add(txtTransac);
		opcionesMas.add(btnRecargaEnLinea);
		opcionesMas.add(btnQuieroMasDatos);
		opcionesMas.add(btnHistorialPagos);
		opcionesMas.add(btnOfertasYPromociones);
		opcionesMas.add(btnTienda);
		opcionesMas.add(btnRenovarEquipo);

		// ASISTENCIA
		titulosMas.add(txtAsistencia);
		opcionesMas.add(btnConfigEquipo);
		opcionesMas.add(btnConfigModem);
		opcionesMas.add(btnConfigDecod);
		opcionesMas.add(btnAsistenteVirtual);

		// MAS
		titulosMas.add(txtMas);
		opcionesMas.add(btnCentrosDeExperiencia);
		opcionesMas.add(btnTerminosYCondiciones);
		validarBtnSalir();

		evaluarOpciones(opcionesMas, titulosMas);

	}

	public void ingresoMenuMasCuentaControl() throws InterruptedException, IOException {

		// MENU
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), btnMas, 2), "btnMas Desaparece Elemento");
		clickBtnMas();
		validarEncabezado();

		List<By> opcionesMas = new ArrayList<By>();
		List<By> titulosMas = new ArrayList<By>();

		// TRANSACCIONES
		titulosMas.add(txtTransac);
		opcionesMas.add(btnRecargaEnLinea);
		opcionesMas.add(btnQuieroMasDatos);
		opcionesMas.add(btnHistPagRec);
		opcionesMas.add(btnOfertasYPromociones);
		opcionesMas.add(btnTienda);
		opcionesMas.add(btnRenovarEquipo);

		// ASISTENCIA
		titulosMas.add(txtAsistencia);
		opcionesMas.add(btnConfigEquipo);
		opcionesMas.add(btnConfigModem);
		opcionesMas.add(btnConfigDecod);
		opcionesMas.add(btnAsistenteVirtual);

		// MAS
		titulosMas.add(txtMas);
		opcionesMas.add(btnCentrosDeExperiencia);
		opcionesMas.add(btnTerminosYCondiciones);
		validarBtnSalir();

		evaluarOpciones(opcionesMas, titulosMas);
	}

	public void ingresoMenuMasFija() throws InterruptedException, IOException {

		// MENU
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), btnMas, 2), "btnMas Desaparece Elemento");
		clickBtnMas();
		validarEncabezado();

		List<By> opcionesMas = new ArrayList<By>();
		List<By> titulosMas = new ArrayList<By>();

		// TRANSACCIONES
		titulosMas.add(txtTransac);
		opcionesMas.add(btnRecargaEnLinea);
		opcionesMas.add(btnOfertasYPromociones);
		opcionesMas.add(btnTienda);

		// ASISTENCIA
		titulosMas.add(txtAsistencia);
		opcionesMas.add(btnConfigEquipo);
		opcionesMas.add(btnConfigModem);
		opcionesMas.add(btnConfigDecod);
		opcionesMas.add(btnAsistenteVirtual);

		// MAS
		titulosMas.add(txtMas);
		opcionesMas.add(btnCentrosDeExperiencia);
		opcionesMas.add(btnTerminosYCondiciones);
		evaluarOpciones(opcionesMas, titulosMas);
		validarBtnSalir();
	}

	/* CONTINUIDAD */

	@SuppressWarnings("rawtypes")
	public void execMenuMasIngreso_Prepago() throws InterruptedException, IOException {

		validarEncabezado();
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnConsumos), "Bot�n Consumos visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnRecargar), "Bot�n Recargar visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnMas), "Bot�n M�s visible");
		List<By> opcionesMas = new ArrayList<By>();
		List<By> titulosMas = new ArrayList<By>();

		// TRANSACCIONES
		titulosMas.add(txtTransac);
//		opcionesMas.add(btnTransferir);
		opcionesMas.add(btnRegistraTuEquipo);
		opcionesMas.add(btnRecargaEnLinea);
		opcionesMas.add(btnOfertasYPromociones);
		opcionesMas.add(btnTienda);
		opcionesMas.add(btnFamiliaYAmigos);
//		opcionesMas.add(btnRenovarEquipo);

		// ASISTENCIA
		titulosMas.add(txtAsistencia);
		opcionesMas.add(btnConfigEquipo);
		opcionesMas.add(btnConfigModem);
		opcionesMas.add(btnConfigDecod);
		opcionesMas.add(btnAsistenteVirtual);

		// MAS
		titulosMas.add(txtMas);
		opcionesMas.add(btnCentrosDeExperiencia);
		opcionesMas.add(btnTerminosYCondiciones);

		evaluarOpciones(opcionesMas, titulosMas);

		objAux.desplazarPantalla(objAux.getDriver(), btnSalir);
		assertTrue(objAux.getDriver().findElement(btnSalir).isDisplayed(), "Boton salir Visible");
		objAux.AdminDocPdf.generaEvidencia("Boton Salir Visible", objAux.getDriver());
		clickBtnFlechaAbajoDoble();
	}

	public void execMenuMasIngreso_Pospago() throws InterruptedException, IOException {

		validarEncabezado();
		List<By> opcionesMas = new ArrayList<By>();
		List<By> titulosMas = new ArrayList<By>();

		// TRANSACCIONES
		titulosMas.add(txtTransac);
//		opcionesMas.add(btnTransferir);
		opcionesMas.add(btnRegistraTuEquipo);
		opcionesMas.add(btnRecargaEnLinea);
		opcionesMas.add(btnQuieroMasDatos);
		opcionesMas.add(btnHistorialPagos);
		opcionesMas.add(btnOfertasYPromociones);
		opcionesMas.add(btnTienda);
		opcionesMas.add(btnFamiliaYAmigos);
		opcionesMas.add(btnRenovarEquipo);

		// ASISTENCIA
		titulosMas.add(txtAsistencia);
		opcionesMas.add(btnConfigEquipo);
		opcionesMas.add(btnConfigModem);
		opcionesMas.add(btnConfigDecod);
		opcionesMas.add(btnAsistenteVirtual);

		// MAS
		titulosMas.add(txtMas);
		opcionesMas.add(btnCentrosDeExperiencia);
		opcionesMas.add(btnTerminosYCondiciones);

		evaluarOpciones(opcionesMas, titulosMas);

		objAux.desplazarPantalla(objAux.getDriver(), btnSalir);
		assertTrue(objAux.getDriver().findElement(btnSalir).isDisplayed(), "Boton salir Visible");
		objAux.AdminDocPdf.generaEvidencia("Boton Salir Visible", objAux.getDriver());
		clickBtnFlechaAbajoDoble();
	}

	public void execMenuMasIngreso_CtaControl() throws InterruptedException, IOException {

		validarEncabezado();
		List<By> opcionesMas = new ArrayList<By>();
		List<By> titulosMas = new ArrayList<By>();

		// TRANSACCIONES
		titulosMas.add(txtTransac);
//		opcionesMas.add(btnTransferir);
//		opcionesMas.add(btnRegistraTuEquipo);
		opcionesMas.add(btnRecargaEnLinea);
		opcionesMas.add(btnQuieroMasDatos);
		opcionesMas.add(btnHistPagRec);
		opcionesMas.add(btnOfertasYPromociones);
		opcionesMas.add(btnTienda);
//		opcionesMas.add(btnFamiliaYAmigos);
		opcionesMas.add(btnRenovarEquipo);

		// ASISTENCIA
		titulosMas.add(txtAsistencia);
		opcionesMas.add(btnConfigEquipo);
		opcionesMas.add(btnConfigModem);
		opcionesMas.add(btnConfigDecod);
		opcionesMas.add(btnAsistenteVirtual);

		// MAS
		titulosMas.add(txtMas);
		opcionesMas.add(btnCentrosDeExperiencia);
		opcionesMas.add(btnTerminosYCondiciones);

		evaluarOpciones(opcionesMas, titulosMas);
		
		objAux.desplazarPantalla(objAux.getDriver(), btnSalir);
		assertTrue(objAux.getDriver().findElement(btnSalir).isDisplayed(), "Boton salir Visible");
		objAux.AdminDocPdf.generaEvidencia("Boton Salir Visible", objAux.getDriver());
		clickBtnFlechaAbajoDoble();
	}

	public void execMenuMasIngreso_Fija() throws InterruptedException, IOException {

		validarEncabezado();
		List<By> opcionesMas = new ArrayList<By>();
		List<By> titulosMas = new ArrayList<By>();

		// TRANSACCIONES
		titulosMas.add(txtTransac);
//		opcionesMas.add(btnTransferir);
//		opcionesMas.add(btnRegistraTuEquipo);
		opcionesMas.add(btnRecargaEnLinea);
		opcionesMas.add(btnOfertasYPromociones);
		opcionesMas.add(btnTienda);
//		opcionesMas.add(btnFamiliaYAmigos);

		// ASISTENCIA
		titulosMas.add(txtAsistencia);
		opcionesMas.add(btnConfigEquipo);
		opcionesMas.add(btnConfigModem);
		opcionesMas.add(btnConfigDecod);
		opcionesMas.add(btnAsistenteVirtual);

		// MAS
		titulosMas.add(txtMas);
		opcionesMas.add(btnCentrosDeExperiencia);
		opcionesMas.add(btnTerminosYCondiciones);
		
		evaluarOpciones(opcionesMas, titulosMas);

		objAux.desplazarPantalla(objAux.getDriver(), btnSalir);
		assertTrue(objAux.getDriver().findElement(btnSalir).isDisplayed(), "Boton salir Visible");
		objAux.AdminDocPdf.generaEvidencia("Boton Salir Visible", objAux.getDriver());
		clickBtnFlechaAbajoDoble();
	}

	public void execQuieroMasDatos_CC() throws IOException, InterruptedException {

		objAux.getDriver().findElement(btnQuieroMasDatos).isDisplayed();
		clickBtnQuieroMasDatos();
		assertTrue(objAux.getDriver().findElement(btnVolver).isDisplayed(), "Opci�n Regresar");
		assertTrue(objAux.getDriver().findElement(titComprarDatos).isDisplayed(), "titComprarDatos");
		assertTrue(objAux.getDriver().findElement(tapConRecarga).isDisplayed(), "tapConRecarga");
		assertTrue(objAux.getDriver().findElement(tapConFactura).isDisplayed(), "tapConFactura");
		assertTrue(objAux.getDriver().findElement(imgCelular).isDisplayed(), "imgCelular");
		
		clickBtnVolver();
	}

	public void execQuieroMasDatos_Pospago() throws IOException, InterruptedException {

		objAux.getDriver().findElement(btnQuieroMasDatos).isDisplayed();
		clickBtnQuieroMasDatos();
		assertTrue(objAux.getDriver().findElement(lblLoSentimos).isDisplayed(), "lblLoSentimos");
		assertTrue(objAux.getDriver().findElement(lblMensajeError).isDisplayed(), "lblMensajeError");
		assertTrue(objAux.getDriver().findElement(imgIconoAlerta).isDisplayed(), "imgIconoAlerta");
		clickBtnMas();
	}

	public void execHistorialPagosRecargas_CC() throws IOException, InterruptedException {

		objAux.getDriver().findElement(btnHistPagRec).isDisplayed();
		clickBtnHistorialDePagosYRecargas();
		assertTrue(objAux.getDriver().findElement(btnVolver).isDisplayed(), "Opci�n Regresar");
		assertTrue(objAux.getDriver().findElement(titHistPagRec).isDisplayed(), "titHistorialPagosRecargas");
		assertTrue(objAux.getDriver().findElement(btnTapPagosEnLinea).isDisplayed(), "btnTapPagosEnLinea");
		assertTrue(objAux.getDriver().findElement(btnTapRecargasEnLinea).isDisplayed(), "btnTapRecargasEnLinea");
		clickBtnTapPagosEnLinea();
		clickBtnTapRecargasEnLinea();
		clickBtnVolver();
	}
	
	public void execHistorialPagos_Pospago() throws IOException, InterruptedException {

		objAux.getDriver().findElement(btnHistorialPagos).isDisplayed();
		clickBtnHistorialDePagos();
		assertTrue(objAux.getDriver().findElement(btnVolver).isDisplayed(), "Opci�n Regresar");
		assertTrue(objAux.getDriver().findElement(titHistPagos).isDisplayed(), "titHistorialPagos");
		assertTrue(objAux.getDriver().findElement(btnTapPagosEnLinea).isDisplayed(), "btnTapPagosEnLinea");
		clickBtnTapPagosEnLinea();
		clickBtnVolver();
	}

	public void execOfertasYPromociones() throws IOException, InterruptedException {

		objAux.getDriver().findElement(btnOfertasYPromociones).isDisplayed();
		clickOfertasYPromociones();
		assertTrue(objAux.getDriver().findElement(btnVolver).isDisplayed(), "Opci�n Regresar");
		assertTrue(objAux.getDriver().findElement(titOfertasYProm).isDisplayed(), "titOfertasYProm");
		clickBtnVolver();
	}

	public void execConfiguraTuEquipo() throws InterruptedException, IOException {

		objAux.getDriver().findElement(btnConfigEquipo).isDisplayed();
		clickBtnConfiguraTuEquipo();
		objAux.getDriver().switchTo().frame(objAux.getDriver().findElement(iframe));
		ventaEmergente();
		Thread.sleep(4000);
		assertTrue(objAux.getDriver().findElement(btnVolver).isDisplayed(), "Opci�n Regresar");
		assertTrue(objAux.getDriver().findElement(titConfiguraEquipo).isDisplayed(), "tituloConfiguraEquipo");
		assertTrue(objAux.getDriver().findElement(iconoCarrito).isDisplayed(), "iconoCarrito");
		swichtIframe();
		validarCamposBusqueda();
		assertTrue(objAux.getDriver().findElement(lblMasPopulares).isDisplayed(), "lblMasPopulares");
		objAux.desplazarPantalla(objAux.getDriver(), 4);
		objAux.AdminDocPdf.generaEvidencia("Configura tu equipo", objAux.getDriver());
		clickBtnVolver();
	}

	public void execConfiguraTuModem() throws IOException, InterruptedException {

		objAux.getDriver().findElement(btnConfigModem).isDisplayed();
		clickConfiguraModem();
		assertTrue(objAux.getDriver().findElement(btnVolver).isDisplayed(), "Opci�n Regresar");
		assertTrue(objAux.getDriver().findElement(titConfiguraModem).isDisplayed(), "tituloConfiguraModem");
		assertTrue(objAux.getDriver().findElement(iconoCarrito).isDisplayed(), "iconoCarrito");
		swichtIframe();
		assertTrue(objAux.getDriver().findElement(lblGuiasInter).isDisplayed(), "lblGuiasInteractivas");
		validarCamposBusqueda();
		objAux.desplazarPantalla(objAux.getDriver(), 3);
		objAux.AdminDocPdf.generaEvidencia("Configura tu Modem", objAux.getDriver());
		clickBtnVolver();
	}

	public void execConfiguraTuDecodificador() throws IOException, InterruptedException {

		objAux.getDriver().findElement(btnConfigDecod).isDisplayed();
		clickConfiguraDecodificador();
		assertTrue(objAux.getDriver().findElement(btnVolver).isDisplayed(), "Opci�n Regresar");
		assertTrue(objAux.getDriver().findElement(titConfDecod).isDisplayed(), "titConfDecod");
		assertTrue(objAux.getDriver().findElement(iconoCarrito).isDisplayed(), "iconoCarrito");
		swichtIframe();
		assertTrue(objAux.getDriver().findElement(lblGuiasInter).isDisplayed(), "lblGuiasInteractivas");
		validarCamposBusqueda();
		objAux.desplazarPantalla(objAux.getDriver(), 4);
		objAux.AdminDocPdf.generaEvidencia("Configura tu decodificador", objAux.getDriver());
		clickBtnVolver();
	}

	public void execCentrosDeExperiencia() throws IOException, InterruptedException {

		objAux.getDriver().findElement(btnCentrosDeExperiencia).isDisplayed();
		clickCentroExperiencia();
		clickBtnPermitir();
		Thread.sleep(7000);
		assertTrue(objAux.getDriver().findElement(btnVolver).isDisplayed(), "Opci�n Regresar");
		assertTrue(objAux.getDriver().findElement(titCentroExperiencia).isDisplayed(), "TituloCentroExperiencia");
		validarBtnCargarMas();
		Thread.sleep(3000);
		clickBtnPuntosDePago();
		assertTrue(objAux.getDriver().findElement(titPagosEnLinea).isDisplayed(), "TituloPagosEnLinea");
		assertTrue(objAux.getDriver().findElement(titBancos).isDisplayed(), "tituloBancos");
		objAux.desplazarPantalla(objAux.getDriver(), titOtrosPuntosPago);
		assertTrue(objAux.getDriver().findElement(titOtrosPuntosPago).isDisplayed(), "tituloOtrosPuntosPago");
		clickBtnVerMas();
		validarBtnPagarFactura();
		clickBtnVolver();
	}

	public void execTerminosYCondiciones() throws IOException, InterruptedException {

		objAux.getDriver().findElement(btnTerminosYCondiciones).isDisplayed();
		clickTerminosYCondiciones();
		assertTrue(objAux.getDriver().findElement(btnVolver).isDisplayed(), "Opci�n Regresar");
		assertTrue(objAux.getDriver().findElement(titTermYCondic).isDisplayed(), "tituloTerminosYCondiciones");
		assertTrue(objAux.getDriver().findElement(iconoMovistar).isDisplayed(), "Icono (M) movistar");
		assertTrue(objAux.getDriver().findElement(msjTermCondic).isDisplayed(), "Mensaje de Terminos y Condiciones");
		objAux.desplazarDespuesMitadPantalla(objAux.getDriver(), 11);
		objAux.AdminDocPdf.generaEvidencia("Terminos y condiciones seccion 2", objAux.getDriver());
		clickBtnVolver();
	}
}