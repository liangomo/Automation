package menuMas.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.lowagie.text.DocumentException;

import configInicial.paginas.HomePages;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import manager.param.AdminParam;
import menuMas.paginas.Mas;
import model.Ambientes;
import model.DispositivoPrueba;
import model.Estados;
import model.Navegadores;
import model.TipoCone;

public class TestMenuMasPrepago {

	ObjetosConfigAux objAux;
	Mas objMas;
	HomePages objHomePages;

	@BeforeClass
	public void setUpMasPrepago() throws IOException, InterruptedException {

		objAux = new ObjetosConfigAux("9d1f456c", true);
		objMas = new Mas(objAux);
		objHomePages = new HomePages(objAux);
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PRODUCCION, Navegadores.ANDROID, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "Mas");
		objAux.AdminParam.ObtenerParametros();
		Thread.sleep(10000);
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objMas.clickBtnMas();
	}
	
	@Test(priority = 1)
	public void menuMasIngreso_Prep() throws IOException, InterruptedException {

		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PRODUCCION, Navegadores.ANDROID, DispositivoPrueba.Movil);
		objMas.execMenuMasIngreso_Prepago();
	}
	
	@Test(priority = 2)
	public void menuMasOfertasYPromociones_Prep() throws IOException, InterruptedException {

		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PRODUCCION, Navegadores.ANDROID, DispositivoPrueba.Movil);
		objMas.execOfertasYPromociones();
	}

	@Test(priority = 3)
	public void menuMasConfiguraTuEquipo_Prep() throws IOException, InterruptedException {

		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PRODUCCION, Navegadores.ANDROID, DispositivoPrueba.Movil);
		objMas.execConfiguraTuEquipo();
	}

	@Test(priority = 4)
	public void menuMasConfiguraTuModem_Prep() throws IOException, InterruptedException {

		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PRODUCCION, Navegadores.ANDROID, DispositivoPrueba.Movil);
		objMas.execConfiguraTuModem();
	}

	@Test(priority = 5)
	public void menuMasConfiguraTuDecodificador_Prep() throws IOException, InterruptedException {

		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PRODUCCION, Navegadores.ANDROID, DispositivoPrueba.Movil);
		objMas.execConfiguraTuDecodificador();
	}

	@Test(priority = 6)
	public void menuMasCentrosDeExperiencia_Prep() throws IOException, InterruptedException {

		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PRODUCCION, Navegadores.ANDROID, DispositivoPrueba.Movil);
		objMas.execCentrosDeExperiencia();
	}

	@Test(priority = 7)
	public void menuMasTerminosYCondiciones_Prep() throws IOException, InterruptedException {

		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PRODUCCION, Navegadores.ANDROID, DispositivoPrueba.Movil);
		objMas.execTerminosYCondiciones();
	}

	@AfterMethod
	public void finalizeTest(ITestResult t) throws MalformedURLException, DocumentException, IOException {
		if (t.getStatus() == ITestResult.SUCCESS)
			objAux.AdminDocPdf.crearDocumento(Estados.SUCCESS);
		else {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			Throwable cause = t.getThrowable();
			if (null != cause) {
				cause.printStackTrace(pw);
				objAux.AdminDocPdf.generaEvidencia(
						"Resultado NO Esperado: "
								+ sw.getBuffer().toString().substring(0, sw.getBuffer().toString().indexOf("at ")),
						objAux.getDriver());
			} else {
				objAux.AdminDocPdf.generaEvidencia("Resultado NO Esperado: ", objAux.getDriver());
			}
			objAux.AdminDocPdf.crearDocumento(Estados.FAILED);
		}
	}

	@AfterClass
	public void tearDowns() {
		objAux.getDriver().quit();
	}
}