package recargas.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.lowagie.text.DocumentException;

import configInicial.paginas.HomePages;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import manager.param.AdminParam;
import model.Ambientes;
import model.DispositivoPrueba;
import model.Estados;
import model.Navegadores;
import model.TipoCone;
import recargas.paginas.Recargar;

public class TestRecargar {

	ObjetosConfigAux objAux;
	Recargar objRecarga;
	HomePages objHomePages;

	@BeforeClass
	public void setup() throws IOException, InterruptedException {
		objAux = new ObjetosConfigAux("9d1f456c", true);
		objRecarga = new Recargar(objAux);
		objHomePages = new HomePages(objAux);
	}

	@Test
	public void recargasPrepago() throws IOException, InterruptedException {
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PRODUCCION, Navegadores.ANDROID, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "Recargas");
		objAux.AdminParam.ObtenerParametros();
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objRecarga.ingresoRecarga();
	}

	@AfterMethod
	public void finalizeTest(ITestResult t) throws MalformedURLException, DocumentException, IOException {
		if (t.getStatus() == ITestResult.SUCCESS)
			objAux.AdminDocPdf.crearDocumento(Estados.SUCCESS);
		else {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			Throwable cause = t.getThrowable();
			if (null != cause) {
				cause.printStackTrace(pw);
				objAux.AdminDocPdf.generaEvidencia(
						"Resultado NO Esperado: "
								+ sw.getBuffer().toString().substring(0, sw.getBuffer().toString().indexOf("at ")),
						objAux.getDriver());
			} else {
				objAux.AdminDocPdf.generaEvidencia("Resultado NO Esperado: ", objAux.getDriver());
			}
			objAux.AdminDocPdf.crearDocumento(Estados.FAILED);
		}
	}

	@AfterClass
	public void tearDowns() {
		objAux.getDriver().quit();
	}
}
