package recargas.paginas;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import control.elementos.ObjetosConfigAux;

public class Recargar {

	ObjetosConfigAux objAux;
	By btnRecargar = By.xpath("//*[@class='ng-binding' and contains(text(),'Recargar')]");

	// Metodo Constructor
	public Recargar(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}

	// Eventos de los Elementos
	public void buscarBtnRecarga() throws IOException {
		
		objAux.AdminDocPdf.generaEvidencia("Validar boton recarga", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(btnRecargar).isDisplayed());
	}

	// Metodos
	public void ingresoRecarga() throws IOException, InterruptedException {
		Thread.sleep(15000);
		buscarBtnRecarga();
	}

}
