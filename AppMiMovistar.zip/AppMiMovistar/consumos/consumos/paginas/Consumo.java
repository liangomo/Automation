package consumos.paginas;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import control.elementos.ObjetosConfigAux;
import io.appium.java_client.android.AndroidDriver;

public class Consumo {

	ObjetosConfigAux objAux;
	ArrayList<WebElement> elements = new ArrayList<WebElement>();

	/** LISTA ELEMENTOS */

	By btnConsumo = By.xpath("//span[text() = 'Consumos']");
	By btnQuieroRecargar = By.xpath("//a[contains(text(),'Quiero recargar')]");
	By btnVerDetalles = By.xpath("//a[contains(text(),'Ver Detalles')]");
	By btnVerdetalle = By.xpath("//a[contains(text(),'Ver detalle')]");
	By btnVerdetalleConsumo = By.xpath("//a[contains(text(),'Ver detalle Consumo')]");
	By btnVerDetalle = By.xpath("//a[contains(text(),'Ver Detalle')]");
	By btnQuieroMasDatos = By.xpath("//a[@class = 'button buttonSolid']");
	By btnVolver = By.xpath("(//span[@class='icon icono-atras-white'])[1]");
	By btnCompartirDatos = By.xpath("//div[@class=\"shareDataButton forma-boton-circular1\"]");

	By iconoMovistar = By.xpath("(//span[@class='icon icono-logo-white'])[1]");
	By menuMensajes = By.xpath("//*[@class=\"ng-binding\" and contains(text(),\"Mensajes\")]");
	By menuInternet = By.xpath("//*[@class=\"ng-binding\" and contains(text(),\"Internet\")]");// *[@id="parentViewContainer"]/ion-view/tabs-underline/div[1]/div[1]
	By menuMiSaldo = By.xpath("//*[@class=\"ng-binding\" and contains(text(),\"Mi Saldo\")]");
	By menuVoz = By.xpath("//*[@class=\"ng-binding\" and contains(text(),\"Voz\")]");
	By tapInternet = By.xpath("//*[@class='ng-binding' and contains (text(),'Internet')]");
	By tapVoz = By.xpath("//*[@class='ng-binding' and contains (text(),'Voz')]");
	By tapMensajes = By.xpath("//*[@class='ng-binding' and contains (text(),'Mensajes')]");

	By lblMesA�oConsumo = By.xpath("//div[contains(@class,'title ng-binding')]");

	/* Tab Internet */
	By lblPrimerRegConsumoInt = By.xpath("(//div[contains(@class,'list')]/*/*/*/*/*/*/*/*/span)[1]");
	By lblPrimerRegCantConsumo = By
			.xpath("(//div[contains(@class,'list')]/*/*/*/*/*/*/*/*/span[contains(@class,'right ng-binding')])[1]");
	By lblNoHasConsumidoDatos = By.xpath("//p[contains(text(),'No has consumido datos.')]");

	/* Tab Voz y Mensajes */
	By lblEditar = By.xpath("//span[contains(text(),'Editar')]");
	By imgPrimerRegConsumo = By
			.xpath("(//div[contains(@class,'list')]/*/*/*/*/*/*/*/div[contains(@class,'image')])[1]");
	By lblPrimerRegValorConsumo = By.xpath(
			"(//div[contains(@class,'list')]/*/*/*/*/*/*/*/div/div/span[contains(@class,'right ng-binding')])[1]");
	By lblPrimerRegTextoLlamadaMsj = By.xpath(
			"(//div[contains(@class,'list')]/*/*/*/*/*/*/*/div/div[contains(@class,'info')]/span[contains(@class,'left small notInTablet ng-binding')])[1]");
	By lblPrimerRegNumCelularMsj = By.xpath(
			"(//div[contains(@class,'list')]/*/*/*/*/*/*/*/div/div[contains(@class,'info')]/div[contains(@class,'left notInTablet ng-binding')])[1]");
	By lblPrimerRegHoraLlamadaMsj = By.xpath(
			"(//div[contains(@class,'list')]/*/*/*/*/*/*/*/div/div[contains(@class,'detail')]/span[contains(@class,'left ng-binding')])[1]");
	By lblPrimerRegDuracionLlamada = By.xpath(
			"(//div[contains(@class,'list')]/*/*/*/*/*/*/*/div/div[contains(@class,'detail')]/span[contains(@class,'right ng-binding')])[1]");
	By lblNoHasRealizadoLlamadas = By.xpath("//p[contains(text(),'No has realizado llamadas.')]");
	By lblNoHasEnviadoMensajes = By.xpath("//p[contains(text(),'No has enviado mensajes.')]");

	By txtConsumos = By.xpath("(//p[text()='Consumos'])[1]");
	By txtDetalleDeConsumos = By.xpath("(//p[@class='ng-binding' and contains(text(), 'Detalle de consumos')])[1]");
	By txtTuPlanEs = By.xpath("(//div[contains(@class,'myPlan leftMarginContainer font-regular-bold')]/p)[1]");
	By txtNombreDelPlan = By.xpath("(//div[contains(@class,'myPlan leftMarginContainer font-regular-bold')]/p)[2]");
	By txtValorSaldo = By.xpath("//p[@class = 'font-light ng-binding']");
	By txtAliasProducto = By
			.xpath("//div[@class = 'icon']/p[contains(@class,'font-regular-bold icono-abajo2-white ng-binding')]");
	By txtNumeroInsumo = By.xpath("//div[@class = 'icon']/p[@class = 'ng-binding']");
	By txtTeQuedan = By.xpath("//p[contains(text(),'Te quedan')]");
	By lblInternoRueda = By.xpath("(//p[contains(@ng-show, 'bono.TIPO')])[1]");
	By lblInternoRuedaCC = By.xpath("//*[@class = 'gaugeDivLabel newLabel']");
	By txtDatos = By.xpath("//p[contains(text(),'Datos')]");
	By txtVencimiento = By.xpath("//p[contains(text(),'Vence en')]");
	By txtValorUltRecarga = By.xpath("(//strong[@class='ng-binding'])[1]");
	By txtFechaUltRecarga = By.xpath("(//strong[@class='ng-binding'])[2]");

	By lblProducto = By.xpath("//p[@class='font-regular-bold icono-abajo2-white ng-binding']");
	By lblTuPlan = By.xpath("//p[contains(text(),'Tu plan es')]");
	By lblNombrePlan = By.xpath("//p[contains(@class,'descriptionItem ng-binding')]");
	By lblSaldoVoz = By.xpath("//div[contains(text(),'Saldo de voz')]");
	By lblSaldoRecargas = By.xpath("//div[contains(text(),'Saldo de recargas')]");
	By lblTuSaldoEs = By.xpath("//p[contains(text(),'Hola, tu saldo es')]");
	By lblUltRecarga = By.xpath("//p[contains(text(),'El valor de la �ltima recarga es')]");
	By lblRealizadaEl = By.xpath("//span[contains(text(),'realizada el')]");
	By lblTeQuedan = By.xpath("//*[contains(text(),'Te quedan')]");
	By lblActualizadoHasta = By.xpath("//*[contains(text(),'Actualizado hasta el')]");

	/* Constructor */
	public Consumo(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}

	/** EVENTOS (ACCIONES) */

	public void clicBtnConsumo() throws IOException, InterruptedException {
		Thread.sleep(5000);
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), btnConsumo, 3), "Bot�n Consumo No Visible");
		objAux.getDriver().findElement(btnConsumo).click();
	}

	public void buscarBtnQuieroRecargar() throws IOException {
		assertTrue(objAux.getDriver().findElement(btnQuieroRecargar).isDisplayed(), "Bot�n Quiero Recargar Visible");
	}

	public void clicBtnVerDetalles() throws IOException {
		objAux.getDriver().findElement(btnVerDetalles).click();
	}

	@SuppressWarnings("rawtypes")
	public void clicBtnVerdetalle() throws IOException {

		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalle)) {
			objAux.getDriver().findElement(btnVerdetalle).click();
		} else {
			objAux.getDriver().findElement(btnVerDetalle).click();
		}
	}

	@SuppressWarnings("rawtypes")
	public void clicBtnVerdetalleConsumo() throws IOException {

		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalleConsumo)) {
			objAux.getDriver().findElement(btnVerdetalleConsumo).click();
		} else {
			objAux.getDriver().findElement(btnVerdetalleConsumo).click();
		}
	}

	@SuppressWarnings("rawtypes")
	public void buscarBtnQuieroMasDatos() throws IOException {

		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnQuieroMasDatos)) {
			objAux.getDriver().findElement(btnQuieroMasDatos).click();
			objAux.AdminDocPdf.generaEvidencia("Se visualiza el boton Quiero mas datos", objAux.getDriver());
		} else {
			objAux.AdminDocPdf.generaEvidencia("No se visualiza el boton Quiero mas datos", objAux.getDriver());
		}
	}

	public void clicBtnVolver() throws InterruptedException, IOException {
		Thread.sleep(5000);
		objAux.getDriver().findElement(btnVolver).click();
	}

	public void clicMenuMensajes() throws IOException, InterruptedException {
		objAux.getDriver().findElement(menuMensajes).click();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), menuMensajes, 4), "Men� Mensajes Visible");
		objAux.AdminDocPdf.generaEvidencia("Vista del Menu mensajes", objAux.getDriver());
	}

	public void clicMenuInternet() throws IOException, InterruptedException {
		objAux.getDriver().findElement(menuInternet).click();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), menuInternet, 4), "Men� Internet Visible");
		objAux.AdminDocPdf.generaEvidencia("Vista del Menu internet", objAux.getDriver());
	}

	public void clicMenuMiSaldo() throws IOException, InterruptedException {
		objAux.getDriver().findElement(menuMiSaldo).click();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), menuMiSaldo, 4), "Men� Mi Saldo Visible");
		objAux.AdminDocPdf.generaEvidencia("Vista del Menu de mi saldo", objAux.getDriver());
	}

	public void clicMenuVoz() throws IOException, InterruptedException {
		objAux.getDriver().findElement(menuVoz).click();
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), menuVoz, 4), "Men� Voz Visible");
		objAux.AdminDocPdf.generaEvidencia("Vista del Menu voz", objAux.getDriver());
	}

	@SuppressWarnings("rawtypes")
	public void clicTapInternet() throws IOException, InterruptedException {
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), tapInternet, 4), "Tap Internet Visible");
		objAux.getDriver().findElement(tapInternet).click();
		Thread.sleep(1500);
		elements = (ArrayList<WebElement>) objAux.getDriver().findElements(lblMesA�oConsumo);

		if (elements.size() > 0) {

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegConsumoInt),
					"Primer registro que indica consumos internet");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegCantConsumo),
					"Primer registro que indica la cantidad consumida internet");
		} else {
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblNoHasConsumidoDatos),
					"lblNoHasConsumidoDatos");
		}

		objAux.AdminDocPdf.generaEvidencia("Vista del Tap de internet", objAux.getDriver());
	}

	public void validarTituloTextoDetalleConsumos() throws IOException {
		assertTrue(objAux.getDriver().findElement(txtDetalleDeConsumos).isDisplayed(),
				"Texto Detalle Consumos Visible");
	}

	@SuppressWarnings("rawtypes")
	public void clicTapVoz() throws IOException, InterruptedException {
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), tapVoz, 4), "Tap Voz Visible");
		objAux.getDriver().findElement(tapVoz).click();
		Thread.sleep(15000);
		elements = (ArrayList<WebElement>) objAux.getDriver().findElements(lblMesA�oConsumo);

		if (elements.size() > 0) {

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblEditar), "Label Editar");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), imgPrimerRegConsumo),
					"Primer registro que muestra la imagen del tel�fono");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegValorConsumo),
					"Primer registro que indica el valor de la llamada");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegTextoLlamadaMsj),
					"Primer registro que indica el texto 'Llamada a'");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegNumCelularMsj),
					"Primer registro que indica el n�mero celular de la llamada");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegHoraLlamadaMsj),
					"Primer registro que indica la hora de la llamada");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegDuracionLlamada),
					"Primer registro que indica la duraci�n de la llamada");
		} else {
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblNoHasRealizadoLlamadas),
					"No has realizado llamadas.");
		}

		objAux.AdminDocPdf.generaEvidencia("Vista del Tap de voz", objAux.getDriver());
	}

	@SuppressWarnings("rawtypes")
	public void clicTapMensajes() throws IOException, InterruptedException {
		assertTrue(objAux.EsperaElemento(objAux.getDriver(), tapMensajes, 4), "Tap Mensajes Visible");
		objAux.getDriver().findElement(tapMensajes).click();
		Thread.sleep(15000);
		elements = (ArrayList<WebElement>) objAux.getDriver().findElements(lblMesA�oConsumo);

		if (elements.size() > 0) {

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblEditar), "Label Editar");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), imgPrimerRegConsumo),
					"Primer registro que muestra la imagen del mensaje");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegValorConsumo),
					"Primer registro que indica el valor del mensaje");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegTextoLlamadaMsj),
					"Primer registro que indica el texto 'Mensaje a'");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegNumCelularMsj),
					"Primer registro que indica el n�mero al que se envi� el mensaje");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblPrimerRegHoraLlamadaMsj),
					"Primer registro que indica la hora del mensaje");
		} else {
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblNoHasEnviadoMensajes),
					"No has enviado mensajes.");
		}

		objAux.AdminDocPdf.generaEvidencia("Vista del Tap de mensajes", objAux.getDriver());
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuMiSaldo() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuMiSaldo)) {
			clicMenuMiSaldo();
			validarNombreDelPlan();
			buscarBtnQuieroRecargar();
			clicBtnVerDetalles();
			Thread.sleep(15000);
			validarTituloTextoDetalleConsumos();
			clicTapInternet();
			clicTapVoz();
			clicTapMensajes();
			clicBtnVolver();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		} /*
		 * else { objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos",
		 * objAux.getDriver()); }
		 */
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuInternetCC() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuInternet)) {
			clicMenuInternet();
			validarEncabezadoConsumos();
			validarNombreDelPlan();

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
			validarNombreDelPlan();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTeQuedan), "Te quedan");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblInternoRuedaCC),
					"Texto Interno Rueda");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblActualizadoHasta),
					"Actualizado hasta el");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalle),
					"Boton Ver detalle Visible");

			clicBtnVerdetalleConsumo();
			Thread.sleep(20000);
			validarTituloTextoDetalleConsumos();
			clicTapInternet();
			clicTapVoz();
			clicTapMensajes();
			clicBtnVolver();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		} /*
		 * else { objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos",
		 * objAux.getDriver()); }
		 */
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuInternetPosp() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuInternet)) {
			clicMenuInternet();
			validarEncabezadoConsumos();
			validarNombreDelPlan();

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
			validarNombreDelPlan();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTeQuedan), "Te quedan");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblInternoRuedaCC),
					"Texto Interno Rueda");

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblActualizadoHasta),
					"Actualizado hasta el");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalle),
					"Boton Ver detalle Visible");

			clicBtnVerdetalleConsumo();
			Thread.sleep(20000);
			validarTituloTextoDetalleConsumos();
			clicTapInternet();
			clicTapVoz();
			clicTapMensajes();
			clicBtnVolver();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		} else { 
			objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos", objAux.getDriver()); 
		}
	}

	// Sanity
	@SuppressWarnings("rawtypes")
	public void seleccionarMenuInternet() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuInternet)) {
			clicMenuInternet();
			validarEncabezadoConsumos();
			validarNombreDelPlan();

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
			validarNombreDelPlan();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTeQuedan), "Te quedan");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblActualizadoHasta),
					"Actualizado hasta el");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalle),
					"Boton Ver detalle Visible");

			clicBtnVerdetalle();
			Thread.sleep(20000);
			validarTituloTextoDetalleConsumos();
			clicTapInternet();
			clicTapVoz();
			clicTapMensajes();
			clicBtnVolver();
		} /*
		 * else { objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos",
		 * objAux.getDriver()); }
		 */
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuSaldoPrepago() throws IOException, InterruptedException {
		clicMenuMiSaldo();
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		validarNombreDelPlan();
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuSaldoEs), "Hola, tu saldo es");
		assertTrue(objAux.getDriver().findElement(txtValorSaldo).isDisplayed(), "Texto Valor Saldo");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblUltRecarga),
				"El valor de la �ltima recarga es");
		assertTrue(objAux.getDriver().findElement(txtValorUltRecarga).isDisplayed(), "Texto Valor ultima recarga");
		//		assertTrue(objAux.getDriver().findElement(lblRealizadaEl).isDisplayed(), "Texto 'Realizada el'");
//		assertTrue(objAux.getDriver().findElement(txtFechaUltRecarga).isDisplayed(), "Texto fecha ultima recarga");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnQuieroRecargar), "Quiero recargar");

		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerDetalles), "Boton Ver Detalles");
		clicBtnVerDetalles();
		Thread.sleep(15000);
		validarTituloTextoDetalleConsumos();
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuMiSaldoCC() throws IOException, InterruptedException {
		clicMenuMiSaldo();
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		// assertTrue(objAux.ElementoPresente((AndroidDriver)
		// objAux.getDriver(), lblSaldoVoz), "Saldo de voz");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblSaldoRecargas), "Saldo de recargas");

		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnQuieroRecargar),
				"Bot�n Quiero recargar Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerDetalles),
				"Boton Ver Detalles Visible");

		clicBtnVerDetalles();
		Thread.sleep(15000);
		validarTituloTextoDetalleConsumos();
		clicTapInternet();
		clicTapVoz();
		clicTapMensajes();
		clicBtnVolver();
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuInternetPrepago() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuInternet)) {
			clicMenuInternet();
			validarEncabezadoConsumos();
			validarNombreDelPlan();

			assertTrue(objAux.getDriver().findElement(txtTeQuedan).isDisplayed(), "Texto Te quedan -: Visible");
			assertTrue(objAux.getDriver().findElement(lblInternoRueda).isDisplayed(), "Cantidad Internet: Visible");
			//			assertTrue(objAux.getDriver().findElement(txtDatos).isDisplayed(), "Texto Datos: Visible");
			assertTrue(objAux.getDriver().findElement(txtVencimiento).isDisplayed(), "Texto Dias Vencimiento: Visible");

			// clicBtnVerdetalle();
			// Thread.sleep(20000);
			// validarTituloTextoDetalleConsumos();
			// clicTapInternet();
			// clicTapVoz();
			// clicTapMensajes();
			// clicBtnVolver();
		} else {
			objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos", objAux.getDriver()); 
		}
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuMensajes() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuMensajes)) {
			clicMenuMensajes();
			validarEncabezadoConsumos();

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
			validarNombreDelPlan();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTeQuedan), "Te quedan");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblInternoRuedaCC),
					"Texto Interno Rueda");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblActualizadoHasta),
					"Actualizado hasta el");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalle),
					"Boton Ver detalle Visible");

			clicBtnVerdetalle();
			Thread.sleep(20000);
			validarTituloTextoDetalleConsumos();
			clicTapInternet();
			clicTapVoz();
			clicTapMensajes();
			clicBtnVolver();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		} else {
			objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuMensajesCC() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuMensajes)) {
			clicMenuMensajes();
			validarEncabezadoConsumos();

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
			validarNombreDelPlan();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTeQuedan), "Te quedan");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblInternoRuedaCC),
					"Texto Interno Rueda");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblActualizadoHasta),
					"Actualizado hasta el");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalle),
					"Boton Ver detalle Visible");

			clicBtnVerdetalle();
			Thread.sleep(20000);
			validarTituloTextoDetalleConsumos();
			clicTapInternet();
			clicTapVoz();
			clicTapMensajes();
			clicBtnVolver();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		} else {
			objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuMensajesPosp() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuMensajes)) {
			clicMenuMensajes();
			validarEncabezadoConsumos();

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
			validarNombreDelPlan();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTeQuedan), "Te quedan");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblInternoRuedaCC),
					"Texto Interno Rueda");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblActualizadoHasta),
					"Actualizado hasta el");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalle),
					"Boton Ver detalle Visible");

			clicBtnVerdetalle();
			Thread.sleep(20000);
			validarTituloTextoDetalleConsumos();
			clicTapInternet();
			clicTapVoz();
			clicTapMensajes();
			clicBtnVolver();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		} else {
			objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuMensajesPrepago() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuMensajes)) {
			clicMenuMensajes();
			validarEncabezadoConsumos();
			validarNombreDelPlan();

			assertTrue(objAux.getDriver().findElement(txtTeQuedan).isDisplayed(), "Texto Te quedan -: Visible");

			// clicBtnVerdetalle();
			// Thread.sleep(20000);
			// validarTituloTextoDetalleConsumos();
			// clicTapInternet();
			// clicTapVoz();
			// clicTapMensajes();
			// clicBtnVolver();
		} else {
			objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuVoz() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuVoz)) {
			clicMenuVoz();
			validarEncabezadoConsumos();

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
			validarNombreDelPlan();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTeQuedan), "Te quedan");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblInternoRuedaCC),
					"Texto Interno Rueda");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblActualizadoHasta),
					"Actualizado hasta el");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalle),
					"Boton Ver detalle Visible");

			clicBtnVerdetalle();
			Thread.sleep(20000);
			validarTituloTextoDetalleConsumos();
			clicTapInternet();
			clicTapVoz();
			clicTapMensajes();
			clicBtnVolver();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		} else {
			objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuVozCC() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuVoz)) {
			clicMenuVoz();
			validarEncabezadoConsumos();

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
			validarNombreDelPlan();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTeQuedan), "Te quedan");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblInternoRuedaCC),
					"Texto Interno Rueda");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblActualizadoHasta),
					"Actualizado hasta el");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalle),
					"Boton Ver detalle Visible");

			clicBtnVerdetalle();
			Thread.sleep(20000);
			validarTituloTextoDetalleConsumos();
			clicTapInternet();
			clicTapVoz();
			clicTapMensajes();
			clicBtnVolver();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		} else {
			objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuVozPosp() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuVoz)) {
			clicMenuVoz();
			validarEncabezadoConsumos();

			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
			validarNombreDelPlan();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTeQuedan), "Te quedan");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblInternoRuedaCC),
					"Texto Interno Rueda");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblActualizadoHasta),
					"Actualizado hasta el");
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerdetalle),
					"Boton Ver detalle Visible");

			clicBtnVerdetalle();
			Thread.sleep(20000);
			validarTituloTextoDetalleConsumos();
			clicTapInternet();
			clicTapVoz();
			clicTapMensajes();
			clicBtnVolver();
			assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		} else {
			objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void seleccionarMenuVozPrepago() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), menuVoz)) {
			clicMenuVoz();
			validarEncabezadoConsumos();
			validarNombreDelPlan();

			assertTrue(objAux.getDriver().findElement(txtTeQuedan).isDisplayed(), "Texto Te quedan -: Visible");

			// clicBtnVerdetalle();
			// Thread.sleep(20000);
			// validarTituloTextoDetalleConsumos();
			// clicTapInternet();
			// clicTapVoz();
			// clicTapMensajes();
			// clicBtnVolver();
		} else {
			objAux.AdminDocPdf.generaEvidencia("Vista Opcion Cosumos", objAux.getDriver());
		}
	}

	public void validarTextoTituloConsumos() throws IOException {
		assertTrue(objAux.getDriver().findElement(txtConsumos).isDisplayed(), "Texto Consumos Visible");
	}

	public void validarNombreDelPlan() {
		assertTrue(objAux.getDriver().findElement(txtTuPlanEs).isDisplayed(), "Texto Tu Plan es: Visible");
		assertTrue(!objAux.getDriver().findElement(txtNombreDelPlan).getText().equals(""), "Nombre del plan no vac�o");
	}

	/* Continuidad */

	public String getLblProducto() {
		return objAux.getDriver().findElement(lblProducto).getText();
	}

	public void validarEncabezadoConsumos() {
		assertTrue(objAux.getDriver().findElement(txtConsumos).isDisplayed(), "Texto Consumos Visible");
		assertTrue(objAux.getDriver().findElement(iconoMovistar).isDisplayed(), "Icono (M) movistar");
		assertEquals(getLblProducto(), objAux.buscaElementoParametro("Producto"), "Alias del producto");
		assertTrue(objAux.getDriver().findElement(txtNumeroInsumo).isDisplayed(), "Numero del insumo");
	}

	/** METODOS */

	public void ingresoConsumoCuentaControl() throws IOException, InterruptedException {

		clicBtnConsumo();
		validarTextoTituloConsumos();
		seleccionarMenuMiSaldo();
		seleccionarMenuInternet();
		seleccionarMenuMensajes();
		seleccionarMenuVoz();
	}

	public void ingresoConsumoPrepago() throws IOException, InterruptedException {

		clicBtnConsumo();
		validarTextoTituloConsumos();
		seleccionarMenuMiSaldo();
		seleccionarMenuInternetPrepago();
		seleccionarMenuMensajesPrepago();
		seleccionarMenuVozPrepago();
	}

	public void ingresoConsumoPospago() throws IOException, InterruptedException {

		clicBtnConsumo();
		validarTextoTituloConsumos();
		assertTrue(objAux.getDriver().findElement(btnCompartirDatos).isDisplayed());
		objAux.AdminDocPdf.generaEvidencia("Se visualiza el boton de compartir datos", objAux.getDriver());

		validarTextoTituloConsumos();
		seleccionarMenuInternet();
		seleccionarMenuMensajes();
		seleccionarMenuVoz();
	}

	public void validarBtnCompartirDatosPospago() throws IOException, InterruptedException {

		clicBtnConsumo();
		clicMenuInternet();
		assertTrue(objAux.getDriver().findElement(btnCompartirDatos).isDisplayed());

	}

	/* Continuidad */

	@SuppressWarnings("rawtypes")
	public void consumosNavegacionPestanas_Prepago() throws IOException, InterruptedException {

		clicBtnConsumo();
		validarEncabezadoConsumos();
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");

		seleccionarMenuSaldoPrepago();
		seleccionarMenuInternetPrepago();
		seleccionarMenuVozPrepago();
		seleccionarMenuMensajesPrepago();
	}

	public void consumosNavegacionPestanas_CC() throws IOException, InterruptedException {

		clicBtnConsumo();
		validarEncabezadoConsumos();

		seleccionarMenuMiSaldoCC();
		seleccionarMenuInternetCC();
		seleccionarMenuVozCC();
		seleccionarMenuMensajesCC();
	}

	@SuppressWarnings("rawtypes")
	public void consumosNavegacionPestanas_Pospago() throws IOException, InterruptedException {

		clicBtnConsumo();
		validarEncabezadoConsumos();

		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblTuPlan), "Tu plan es");
		seleccionarMenuInternetPosp();
		seleccionarMenuVozPosp();
		seleccionarMenuMensajesPosp();
	}

	public void CompartirDatos_Pospago() throws IOException, InterruptedException {
		validarBtnCompartirDatosPospago();
	}
}