package facturas.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.lowagie.text.DocumentException;

import configInicial.paginas.HomePages;
import control.elementos.ObjetosConfigAux;
import evidencia.doc.pdf.AdminDocPdf;
import facturas.paginas.Facturas;
import manager.param.AdminParam;
import model.Ambientes;
import model.DispositivoPrueba;
import model.Estados;
import model.Navegadores;
import model.TipoCone;

public class TestFacturas_Continuidad {

	ObjetosConfigAux objAux;
	Facturas objFacturas;
	HomePages objHomePages;

	@BeforeClass
	public void setup() throws IOException, InterruptedException {
		objAux = new ObjetosConfigAux("9d1f456c", true);
		objFacturas = new Facturas(objAux);
		objHomePages = new HomePages(objAux);
	}
	
	//CP_1 Facturas Cuenta Control con deuda
	@Test
	public void facturasCuentaControlConDeuda() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "Facturas");
		objAux.AdminParam.ObtenerParametros();		Thread.sleep(5000);
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objFacturas.facturasCuentaControlConDeuda();
	}
	
	//CP_2 Facturas Cuenta Control sin deuda
	@Test
	public void facturasCuentaControlSinDeuda() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "Facturas");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objFacturas.facturasCuentaControlSinDeuda();
	}
	
	//CP_3 Facturas Pospago sin deuda
	@Test
	public void facturasPospagoSinDeuda() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "Facturas");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objFacturas.facturasPospagoSinDeuda();
	}
	
	//CP_4 Facturas Pospago con deuda
	@Test
	public void facturasPospagoConDeuda() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "Facturas");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objFacturas.facturasPospagoConDeuda();
	}
	
	//CP_5 Facturas fijo con deuda
	@Test
	public void facturasFijoConDeuda() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "Facturas");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objFacturas.facturasFijoConDeuda();
	}
	
	//CP_6 Facturas fijo sin deuda
	@Test
	public void facturasFijoSinDeuda() throws IOException, InterruptedException{
		objAux.AdminDocPdf = new AdminDocPdf(Ambientes.PROYECTOS, Navegadores.CHROME, DispositivoPrueba.Movil);
		objAux.AdminParam = new AdminParam(TipoCone.EXCEL, "Facturas");
		objAux.AdminParam.ObtenerParametros();		
		objHomePages.clicBtnProducto(objAux.buscaElementoParametro("Producto"));
		objFacturas.facturasFijoSinDeuda();
	}

	@AfterMethod
	public void finalizeTest(ITestResult t) throws MalformedURLException, DocumentException, IOException {
		if (t.getStatus() == ITestResult.SUCCESS)
			objAux.AdminDocPdf.crearDocumento(Estados.SUCCESS);
		else {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			Throwable cause = t.getThrowable();
			if (null != cause) {
				cause.printStackTrace(pw);
				objAux.AdminDocPdf.generaEvidencia(
						"Resultado NO Esperado: "
								+ sw.getBuffer().toString().substring(0, sw.getBuffer().toString().indexOf("at ")),
						objAux.getDriver());
			} else {
				objAux.AdminDocPdf.generaEvidencia("Resultado NO Esperado: ", objAux.getDriver());
			}
			objAux.AdminDocPdf.crearDocumento(Estados.FAILED);
		}
	}

	@AfterClass
	public void tearDowns() {
		objAux.getDriver().quit();
	}
}
