package facturas.paginas;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;

import control.elementos.ObjetosConfigAux;
import io.appium.java_client.android.AndroidDriver;

public class Facturas {

	ObjetosConfigAux objAux;

	// ELEMENTOS
	By btnFacturas = By.xpath("//span[@class='ng-binding' and contains(text(), 'Facturas')]");
	By btnVerHistPagos = By.xpath("//*[contains (text(),'Ver historial de pagos')]");
	By btnPagarFactura = By.xpath("//*[contains (text(),'Pagar factura')]");
	By btnDescargarFactura = By.xpath("(//*[contains (text(),'Descargar factura')])[1]");
	By btnVerMas = By.xpath("//*[contains (text(),'Ver m�s')]");
	By btnPagosEnLinea = By.xpath("//*[@class='ng-binding'   and contains(text(),'Pagos en l�nea')]");
	By btnRecargasEnLinea = By.xpath("//*[@class='ng-binding'   and contains(text(),'Recargas en l�nea')]");
	By btnVolver = By.xpath("//span[@class='icon icono-atras-white']");
	By txtConDeuda = By.xpath("//p[text() = 'Hola, tu valor a pagar es:']");
	By txtSinDeuda = By.xpath("//*[contains(text(),'Hola, no tienes pagos pendientes.')]");
	By txtHistorialDePagos = By.xpath("(//p[text()='Historial de pagos'])[1]");
	By txtHistorialDePagosyRecargas = By.xpath("(//p[text()='Historial de pagos y recargas'])[1]");
	By txtValidarTextoFacturas = By.xpath("(//p[@class= 'big' and contains(text(),'')])[1]");
	By txtMisFacturas = By.xpath("(//p[text()='Mis Facturas'])[1]");
	By txtPagosEnLinea = By.xpath("//span[@class = 'ng-binding' and contains(text(), 'Pagos en l�nea')]");
	By iconoMovistar = By.xpath("(//span[@class='icon icono-logo-white'])[1]");
	By txtAliasProducto = By.xpath("//div[@class = 'icon']/p[contains(@class,'font-regular-bold icono-abajo2-white ng-binding')]");
	By txtNumeroInsumo = By.xpath("//div[@class = 'icon']/p[@class = 'ng-binding']");
	
	//Elementos facturas con deuda
	By txtInicialConDeuda = By.xpath("//p[text() = 'Hola, tu valor a pagar es:']");
	By txtValorPagar = By.xpath("//p[@class = 'big price1 green tabletPrice1 ng-binding']");
	By txtFechaLimitePago = By.xpath("//p[contains(text(),'Fecha l�mite de pago')]");
	By txtProximoCorte = By.xpath("//p[contains(text(),'Pr�ximo corte')]");
	By txtNumeroParaPagos = By.xpath("//p[contains(text(),'N�mero para pagos')]"); 
	By txtValorServicio = By.xpath("//p[contains(text(),'Valor servicio:')]");
	By lstBarrasFacturas = By.xpath("//*[contains(@class ,'highcharts-point')]");
	By lstFactura = By.xpath("//div[contains(@class ,'list')]/*");
	
	By txtDescargarFactura = By.xpath("(//span[contains(text(),'Descargar factura')])[1]");
	By txtMesFactura = By.xpath("//div[@class = 'list']/ion-item[1]/p[1][@class='small grey ng-binding']");
	By txtValorFactura = By.xpath("//div[@class = 'list']/ion-item[1]/p[2]");
	By txtFechaFactura = By.xpath("//div[@class = 'list']/ion-item[1]/p[3][@class = 'small grey ng-binding']");
	By txtNumeroFactura = By.xpath("//div[@class = 'list']/ion-item[1]/p[3]/span[1][@class = 'small grey account ng-binding']");
	
	//Elementos movil sin deuda
	By txtInicialSinDeduda = By.xpath("//p[contains(text(),'Hola, no tienes pagos pendientes.')]");
	By txtTuProximoCorte = By.xpath("//p[contains(text(),'Tu pr�ximo corte es el')]");
	
	//Elementos Fijo con deuda
	By txtDireccion = By.xpath("//p[contains(text(),'Direcci�n')]");
	By txtCiudad = By.xpath("//p[contains(text(),'Ciudad')]");
	

	// CONSTRUCTOR
	public Facturas(ObjetosConfigAux objConfAux) {
		this.objAux = objConfAux;
	}

	// EVENTOS
	public void clicBtnFacturas() throws IOException, InterruptedException {
		objAux.getDriver().findElement(btnFacturas).click();
		Thread.sleep(6000);
		objAux.AdminDocPdf.generaEvidencia("Vista del boton de Facturas", objAux.getDriver());
	}

	public void clicBtnVerHistPagos() throws IOException {
		objAux.getDriver().findElement(btnVerHistPagos).click();
		
	}

	public void clicBtnDescargarFactura() throws IOException {
		objAux.getDriver().findElement(btnDescargarFactura).click();
		objAux.AdminDocPdf.generaEvidencia("Vista clic de Descarga Factura", objAux.getDriver());
	}

	public void clicBtnVerMas() throws IOException {
		objAux.getDriver().findElement(btnVerMas).click();
		objAux.AdminDocPdf.generaEvidencia("Vista clic de Mas", objAux.getDriver());
	}

	public void clicPagosEnLinea() throws InterruptedException, IOException {
		objAux.getDriver().findElement(btnPagosEnLinea).click();
	}

	public void clicBtnRecargasEnLinea() throws IOException {
		objAux.getDriver().findElement(btnRecargasEnLinea).click();
		objAux.AdminDocPdf.generaEvidencia("Vista clic de Recargas en Linea", objAux.getDriver());
	}

	public void clicBtnVolver() {
		objAux.getDriver().findElement(btnVolver).click();
	}

	public void validarTextHistorialDePagos() throws IOException {		
		assertTrue(objAux.getDriver().findElement(txtHistorialDePagos).isDisplayed(), "Titulo historial de pagos");
	}
	
	
	public void ValidarTextoPagosEnLinea() throws IOException {
		objAux.AdminDocPdf.generaEvidencia("Validar texto Pagos en linea", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(txtPagosEnLinea).isDisplayed(), "Texto pagos en linea");
	}


	public void validarTextHistorialDePagosyRecargas() throws IOException {
		objAux.AdminDocPdf.generaEvidencia("Validar texto historial de pagos y recargas", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(txtHistorialDePagosyRecargas).isDisplayed(), "Titulo historial de pagos y recargas");
	}

	@SuppressWarnings("rawtypes")
	public void buscarBtnDescargarFactura() throws IOException {

		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnDescargarFactura)) {
			if (objAux.desplazarPantalla(objAux.getDriver(), btnDescargarFactura)) {
				objAux.AdminDocPdf.generaEvidencia("Validar boton descargar factura", objAux.getDriver());
			} else {
				assertFalse(objAux.getDriver().findElement(btnDescargarFactura).isDisplayed());
				objAux.AdminDocPdf.generaEvidencia("No aparece boton descargar factura", objAux.getDriver());
			}
		}
	}

	public void buscarBtnPagarFactura() throws IOException {
		
		assertTrue(objAux.getDriver().findElement(btnPagarFactura).isDisplayed(), "Validar boton pagar factura");
		
	}

	@SuppressWarnings("rawtypes")
	public void validarTextoInicial() throws IOException {
		objAux.AdminDocPdf.generaEvidencia("Validando texto inicial", objAux.getDriver());
		assertFalse(objAux.EsperaElemento(objAux.getDriver(), txtValidarTextoFacturas, 1));
		assertFalse(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtValidarTextoFacturas));
		}

	public void ValidarTextoMisFacturas() throws IOException {
		assertTrue(objAux.getDriver().findElement(txtMisFacturas).isDisplayed());
	}
	
	
	public void validarEncabezadoMisFacturas(){
		assertTrue(objAux.getDriver().findElement(txtMisFacturas).isDisplayed(), "Titulo Mis Facturas");
		assertTrue(objAux.getDriver().findElement(iconoMovistar).isDisplayed(), "Icono (M) movistar");
		assertTrue(objAux.getDriver().findElement(txtAliasProducto).isDisplayed(), "Alisas del producto");
		assertTrue(objAux.getDriver().findElement(txtNumeroInsumo).isDisplayed(), "Numero del insumo");
	}
	
	public void validarTextosFacturaCuentaControlConDeuda(){
		assertTrue(objAux.getDriver().findElement(txtInicialConDeuda).isDisplayed(), "Texto Hola, tu valor a pagar es:");
		assertTrue(objAux.getDriver().findElement(txtValorPagar).isDisplayed(), "Texto Valor a pagar");
		assertTrue(objAux.getDriver().findElement(txtFechaLimitePago).isDisplayed(), "Texto Fecha limite de pago");
		assertTrue(objAux.getDriver().findElement(txtProximoCorte).isDisplayed(), "Texto proximo corte");
		assertTrue(objAux.getDriver().findElement(txtNumeroParaPagos).isDisplayed(), "Texto numero de pago");		
	}
	
	public void validarTextosFacturaCuentaControlSinDeuda(){
		assertTrue(objAux.getDriver().findElement(txtInicialSinDeduda).isDisplayed(), "Texto Hola, no tienes pagos pendientes.");
		assertTrue(objAux.getDriver().findElement(txtTuProximoCorte).isDisplayed(),"Texto Proximo Corte");
	}
	
	public void validarTextosFacturaPospagoSinDeuda(){
		assertTrue(objAux.getDriver().findElement(txtInicialSinDeduda).isDisplayed(), "Texto Hola, no tienes pagos pendientes.");
		assertTrue(objAux.getDriver().findElement(txtTuProximoCorte).isDisplayed(),"Texto Proximo Corte");
	}
	
	public void validarTextosFacturaPospagoConDeuda(){
		assertTrue(objAux.getDriver().findElement(txtInicialConDeuda).isDisplayed(), "Texto Hola, tu valor a pagar es:");
		assertTrue(objAux.getDriver().findElement(txtValorPagar).isDisplayed(), "Texto Valor a pagar");
		assertTrue(objAux.getDriver().findElement(txtFechaLimitePago).isDisplayed(), "Texto Fecha limite de pago");
		assertTrue(objAux.getDriver().findElement(txtProximoCorte).isDisplayed(), "Texto proximo corte");
		assertTrue(objAux.getDriver().findElement(txtNumeroParaPagos).isDisplayed(), "Texto numero de pago");
		
	}
	
	public void validarTextosFacturasFijoConDeuda(){
		assertTrue(objAux.getDriver().findElement(txtInicialConDeuda).isDisplayed(), "Texto Hola, tu valor a pagar es:");
		assertTrue(objAux.getDriver().findElement(txtValorPagar).isDisplayed(),"Texto Valor a pagar");
		assertTrue(objAux.getDriver().findElement(txtFechaLimitePago).isDisplayed(), "Texto Fecha limite de pago");
		assertTrue(objAux.getDriver().findElement(txtNumeroParaPagos).isDisplayed(), "Texto numero de pago");
		assertTrue(objAux.getDriver().findElement(txtDireccion).isDisplayed(), "Texto Direccion");
		assertTrue(objAux.getDriver().findElement(txtCiudad).isDisplayed(), "Texto Ciudad");		
	}
	
	public void validarTextosFacturasFijoSinDeuda(){
		assertTrue(objAux.getDriver().findElement(txtInicialSinDeduda).isDisplayed(), "Texto Hola, no tienes pagos pendientes.");	
		assertTrue(objAux.getDriver().findElement(txtDireccion).isDisplayed(), "Texto Direccion");
		assertTrue(objAux.getDriver().findElement(txtCiudad).isDisplayed(), "Texto Ciudad");				
	}
	
	
	public void validarBarrasFacturas() throws IOException{
		ArrayList<WebElement> listaBarrasFacturas = (ArrayList<WebElement>) objAux.getDriver().findElements(lstBarrasFacturas);
		
		for(int i=0; i<listaBarrasFacturas.size();i++) {			
			if(listaBarrasFacturas.get(i).isDisplayed() == true) {				
				listaBarrasFacturas.get(i).click();
				objAux.AdminDocPdf.generaEvidencia("Validar boton descargar factura", objAux.getDriver());
				//driverA.context("WEBVIEW");
			}
		}
	}
	
	@SuppressWarnings("rawtypes")
	public void validarInformacionFactura() throws IOException{
		ArrayList<WebElement> listaFacturas = (ArrayList<WebElement>) objAux.getDriver().findElements(lstFactura);
		
		if(listaFacturas.size() > 0){
			((AndroidDriver) objAux.getDriver()).context("NATIVE_APP");
			Dimension size=objAux.getDriver().manage().window().getSize();
			int y_start=(int)(size.height*0.60);
	        int y_end=(int)(size.height*0.30);
	        int x= size.width / 2; 
	        ((AndroidDriver) objAux.getDriver()).swipe(x,y_start,x,y_end,2000);
	        ((AndroidDriver) objAux.getDriver()).context("WEBVIEW"); 
	        
	        assertTrue(objAux.getDriver().findElement(txtDescargarFactura).isDisplayed(), "Texto Descargar factura");
	        assertTrue(objAux.getDriver().findElement(txtMesFactura).isDisplayed(), "Texto mes factura");
	        assertTrue(objAux.getDriver().findElement(txtValorFactura).isDisplayed(), "Texto Valor factura");
	        assertTrue(objAux.getDriver().findElement(txtFechaFactura).isDisplayed(), "Texto fecha factura");
	        assertTrue(objAux.getDriver().findElement(txtNumeroFactura).isDisplayed(), "Texto numero factura");
	        
	        objAux.AdminDocPdf.generaEvidencia("Informacion de factura", objAux.getDriver());
		}
		
	}
	
	public void validarBotonVerMasFactura() throws IOException{
		ArrayList<WebElement> listaFacturas = (ArrayList<WebElement>) objAux.getDriver().findElements(lstFactura);
		
		if(listaFacturas.size() > 6){
			objAux.desplazarPantalla(objAux.getDriver(), btnVerMas); 	        
	        objAux.AdminDocPdf.generaEvidencia("Boton ver mas", objAux.getDriver());
		}
		
	}

	// METODOS
	public void ingresarFacturasPospago() throws IOException, InterruptedException {

		Thread.sleep(5000);
		clicBtnFacturas();
		ValidarTextoMisFacturas();
		clicBtnVerHistPagos();
		validarTextHistorialDePagos();
		ValidarTextoPagosEnLinea();		
		Thread.sleep(5000);
		clicBtnVolver();
		buscarBtnPagarFactura();
		buscarBtnDescargarFactura();
	}

	public void ingresarFacturasCuentaControl() throws InterruptedException, IOException {

		Thread.sleep(3000);
		clicBtnFacturas();
		ValidarTextoMisFacturas();
		buscarBtnPagarFactura();
		clicBtnVerHistPagos();
		validarTextHistorialDePagosyRecargas();
		clicPagosEnLinea();
		clicBtnRecargasEnLinea();
		clicBtnVolver();
		buscarBtnDescargarFactura();

	}

	public void ingresarFacturaFija() throws IOException, InterruptedException {

		Thread.sleep(3000);
		clicBtnFacturas();
		ValidarTextoMisFacturas();
		buscarBtnDescargarFactura();
	}
	
	
	//Metodos Continuidad
	
	public void facturasCuentaControlConDeuda () throws IOException, InterruptedException{
		Thread.sleep(5000);
		clicBtnFacturas();
		validarEncabezadoMisFacturas();
		validarTextosFacturaCuentaControlConDeuda();
		buscarBtnPagarFactura();
		clicBtnVerHistPagos();
		Thread.sleep(5000);
		validarTextHistorialDePagosyRecargas();
		clicPagosEnLinea();
		clicBtnRecargasEnLinea();
		clicBtnVolver();
		buscarBtnDescargarFactura();
		validarBarrasFacturas();
		validarInformacionFactura();
		validarBotonVerMasFactura();			
	}
	
	public void facturasCuentaControlSinDeuda () throws IOException, InterruptedException{
		Thread.sleep(5000);
		clicBtnFacturas();
		validarEncabezadoMisFacturas();
		validarTextosFacturaCuentaControlSinDeuda();
		buscarBtnPagarFactura();
		clicBtnVerHistPagos();
		Thread.sleep(5000);
		validarTextHistorialDePagosyRecargas();
		clicPagosEnLinea();
		clicBtnRecargasEnLinea();
		clicBtnVolver();
		buscarBtnDescargarFactura();
		validarBarrasFacturas();
		validarInformacionFactura();
		validarBotonVerMasFactura();
	}
	
	public void facturasPospagoConDeuda() throws IOException, InterruptedException{
		Thread.sleep(5000);
		clicBtnFacturas();
		validarEncabezadoMisFacturas();
		validarTextosFacturaPospagoConDeuda();
		buscarBtnPagarFactura();
		clicBtnVerHistPagos();
		Thread.sleep(5000);
		validarTextHistorialDePagos();
		ValidarTextoPagosEnLinea();		
		Thread.sleep(5000);
		clicBtnVolver();
		buscarBtnDescargarFactura();
		validarBarrasFacturas();
		validarInformacionFactura();
		validarBotonVerMasFactura();
	}
	
	public void facturasPospagoSinDeuda () throws IOException, InterruptedException{
		Thread.sleep(5000);
		clicBtnFacturas();
		validarEncabezadoMisFacturas();
		validarTextosFacturaPospagoSinDeuda();
		buscarBtnPagarFactura();
		clicBtnVerHistPagos();
		Thread.sleep(5000);
		validarTextHistorialDePagos();
		ValidarTextoPagosEnLinea();		
		Thread.sleep(5000);
		clicBtnVolver();
		buscarBtnDescargarFactura();
		validarBarrasFacturas();
		validarInformacionFactura();
		validarBotonVerMasFactura();
	}
		
	public void facturasFijoConDeuda() throws IOException, InterruptedException{
		Thread.sleep(5000);
		clicBtnFacturas();
		Thread.sleep(5000);
		validarEncabezadoMisFacturas();
		validarTextosFacturasFijoConDeuda();
		buscarBtnPagarFactura();
		buscarBtnDescargarFactura();
		validarBarrasFacturas();
		validarInformacionFactura();
		validarBotonVerMasFactura();		
	}
	
	public void facturasFijoSinDeuda() throws IOException, InterruptedException{
		Thread.sleep(5000);
		clicBtnFacturas();
		Thread.sleep(5000);
		validarEncabezadoMisFacturas();
		validarTextosFacturasFijoSinDeuda();		
		buscarBtnDescargarFactura();
		validarBarrasFacturas();
		validarInformacionFactura();
		validarBotonVerMasFactura();		
	}
}
