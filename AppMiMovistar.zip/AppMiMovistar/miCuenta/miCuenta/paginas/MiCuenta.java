package miCuenta.paginas;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import control.elementos.ObjetosConfigAux;
import io.appium.java_client.android.AndroidDriver;

public class MiCuenta {

	ObjetosConfigAux objAux;

	/** LISTA ELEMENTOS */

	By btnMiCuenta = By.xpath("//span[text()='Mi Cuenta']");
	By btnPagarFactura = By.xpath("//*[contains(text(),'Pagar factura')]");
	By btnVerHistorialPagos = By.xpath("//*[contains(text(),'Ver historial de pagos')]");
	By btnVolver = By.xpath("//span[@class='icon icono-atras-white']");
	By btnVerDetalle = By.xpath("//*[contains(text(),'Ver detalle')]");
	
	By btnConsumos = By.xpath("//*[contains(text(),'Consumos')]");
	By btnMiPlan = By.xpath("//*[contains(text(),'Mi Plan')]");
	By btnFacturas = By.xpath("//*[contains(text(),'Facturas')]");
	By btnMas = By.xpath("//*[contains(text(),'M�s')]");
	
	By iconoMovistar = By.xpath("(//span[@class='icon icono-logo-white'])[1]");
	
	By tapPagosEnLinea = By.xpath("//span[contains (text(),'Pagos en l�nea')]");
	By tapRecargasEnLinea = By.xpath("//span[contains (text(),'Recargas en l�nea')]");
	By txtMiCuenta = By.xpath("(//p[text()='Mi Cuenta'])[1]");
	By txtNumeroInsumo = By.xpath("//div[@class = 'icon']/p[@class = 'ng-binding']");
	By txtMisFacturas = By.xpath("(//p[text()='Mis Facturas'])[1]");
	By txtConDeuda = By.xpath("//p[text() = 'Hola, tu valor a pagar es:']");
	By txtSinDeuda = By.xpath("//*[contains(text(),'Hola, no tienes pagos pendientes.')]");
	By txtUltimoPago = By.xpath("//*[contains(text(),'Tu �ltimo pago fue de')]");
	By txtHistorialDePagosyRecargas = By.xpath("(//p[text()='Historial de pagos y recargas'])[1]");
	By txtHistorialDePagos = By.xpath("(//p[contains (text(),'Historial de pagos')])[1]");
	By txtFechaProxCorte = By.xpath("//span[@class='green ng-binding']");

	By lblProducto = By.xpath("//p[@class='font-regular-bold icono-abajo2-white ng-binding']");
	By lblProximoCorte = By.xpath("//*[contains(text(),'Tu pr�ximo corte es el')]");
	By lblUltimoPago = By.xpath("//*[contains(text(),'�ltimo pago realizado')]");
	By lblLimitePago = By.xpath("//*[contains(text(),'Fecha l�mite de pago')]");
	By lblProximoCorteCD = By.xpath("//*[contains(text(),'Pr�ximo corte')]");
	By lblNumeroPagos = By.xpath("//*[contains(text(),'N�mero para pagos')]");
	By lblDireccion = By.xpath("//*[contains(text(),'Direcci�n')]");
	By lblCiudad = By.xpath("//*[contains(text(),'Ciudad')]");
	By lblFechaPago = By.xpath("//*[contains(text(),'Fecha de pago')]");

	/* Constructor */
	public MiCuenta(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}

	/** EVENTOS (ACCIONES) */

	public void clicBtnMiCuenta() throws IOException, InterruptedException {
		Thread.sleep(3000);
		objAux.getDriver().findElement(btnMiCuenta).click();
	}

	public void buscarBtnPagarFactura() throws IOException, InterruptedException {
		objAux.AdminDocPdf.generaEvidencia("Validar boton pagar factura", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(btnPagarFactura).isDisplayed());
	}

	public void clicBtnVerHistorialPagos() throws IOException, InterruptedException {
		Thread.sleep(3000);
		objAux.getDriver().findElement(btnVerHistorialPagos).click();
	}

	public void clicTapPagosEnLinea() throws IOException, InterruptedException {
		Thread.sleep(3000);
		objAux.getDriver().findElement(tapPagosEnLinea).click();
		objAux.AdminDocPdf.generaEvidencia("Vista del tap de pagos en linea", objAux.getDriver());
	}

	public void clicTapRecargasEnLinea() throws IOException, InterruptedException {
		Thread.sleep(3000);
		objAux.getDriver().findElement(tapRecargasEnLinea).click();
		objAux.AdminDocPdf.generaEvidencia("Vista del tap de recargas en linea", objAux.getDriver());
	}

	public void clicBtnVolver() throws InterruptedException, IOException {
		Thread.sleep(3000);
		objAux.getDriver().findElement(btnVolver).click();
		Thread.sleep(3000);
		objAux.AdminDocPdf.generaEvidencia("boton volver", objAux.getDriver());
	}

	@SuppressWarnings("rawtypes")
	public void clicBtnVerDetalle() throws IOException, InterruptedException {
		Thread.sleep(3000);
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerDetalle))
			objAux.getDriver().findElement(btnVerDetalle).click();
	}

	public void validarTextHistorialDePagosyRecargas() throws IOException, InterruptedException {
		Thread.sleep(5000);
		assertTrue(objAux.getDriver().findElement(txtHistorialDePagosyRecargas).isDisplayed());
	}

	@SuppressWarnings("rawtypes")
	public void validarTextHistorialDePagos() throws IOException, InterruptedException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtHistorialDePagos)) {
			Thread.sleep(10000);
			objAux.AdminDocPdf.generaEvidencia("Aparece el texto Historial de Pagos", objAux.getDriver());
		} else {
			objAux.AdminDocPdf.generaEvidencia("NO Aparece el texto Historial de Pagos", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void validarTextUltimoPago() throws IOException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtUltimoPago)) {
			objAux.AdminDocPdf.generaEvidencia("Aparece el texto Tu ultimo pago fue de", objAux.getDriver());
		} else {
			objAux.AdminDocPdf.generaEvidencia("NO Aparece el texto Tu ultimo pago fue de", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void validarTexto() throws IOException, InterruptedException {
		Thread.sleep(3000);
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtConDeuda)) {
			objAux.AdminDocPdf.generaEvidencia("Vista del mensaje Hola, tu valor a pagar es", objAux.getDriver());
		} else if ((objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtSinDeuda))) {
			objAux.AdminDocPdf.generaEvidencia("Vista del mensaje Hola, no tienes pagos pendientes",
					objAux.getDriver());
		} else {
			objAux.AdminDocPdf.generaEvidencia("No se muestra en pantalla ningun mensaje", objAux.getDriver());
		}
	}

	public void validarTextoTituloMiCuenta() throws IOException, InterruptedException {
		Thread.sleep(3000);
		assertTrue(objAux.getDriver().findElement(txtMiCuenta).isDisplayed(), "Titulo Mi Cuenta");
		objAux.AdminDocPdf.generaEvidencia("Titulo Mi cuenta", objAux.getDriver());
	}
	
	public void validarTextoTituloMisFacturas() throws IOException, InterruptedException {
		Thread.sleep(3000);
		assertTrue(objAux.getDriver().findElement(txtMisFacturas).isDisplayed(), "Titulo Mis Facturas");
		assertTrue(objAux.getDriver().findElement(iconoMovistar).isDisplayed(), "Icono (M) movistar");
		assertEquals(getLblProducto(), objAux.buscaElementoParametro("Producto"), "Alias del producto");
		assertTrue(objAux.getDriver().findElement(txtNumeroInsumo).isDisplayed(), "Numero del insumo");
		Thread.sleep(10000);
		objAux.AdminDocPdf.generaEvidencia("Direcciona a Mis Facturas", objAux.getDriver());
	}
	

	/* Continuidad */

	public String getLblProducto() {
		return objAux.getDriver().findElement(lblProducto).getText();
	}

	public String getLblProximoCorte() {
		return objAux.getDriver().findElement(lblProximoCorte).getText();
	}

	public String getLblUltimoPago() {
		return objAux.getDriver().findElement(lblUltimoPago).getText();
	}
	
	public void validarEncabezadoConsumos() throws InterruptedException {
		Thread.sleep(3000);
		assertTrue(objAux.getDriver().findElement(txtMiCuenta).isDisplayed(), "Texto Mi Cuenta Visible");
		assertTrue(objAux.getDriver().findElement(iconoMovistar).isDisplayed(), "Icono (M) movistar");
		assertEquals(getLblProducto(), objAux.buscaElementoParametro("Producto"), "Alias del producto");
		assertTrue(objAux.getDriver().findElement(txtNumeroInsumo).isDisplayed(), "Numero del insumo");
	}

	/** METODOS */

	public void ingresoMiCuentaCuentaControl() throws IOException, InterruptedException {

		Thread.sleep(50000);
		clicBtnMiCuenta();
		validarTextoTituloMiCuenta();
		buscarBtnPagarFactura();
		clicBtnVerHistorialPagos();
		validarTextHistorialDePagosyRecargas();
		clicTapPagosEnLinea();
		clicTapRecargasEnLinea();
		clicBtnVolver();
	}

	public void ingresoMiCuentaPospago() throws IOException, InterruptedException {

		Thread.sleep(50000);
		clicBtnMiCuenta();
		validarTextoTituloMiCuenta();
		buscarBtnPagarFactura();
		clicBtnVerHistorialPagos();
		validarTextHistorialDePagos();
		clicTapPagosEnLinea();
		clicBtnVolver();
	}

	public void ingresoMiCuentaFija() throws IOException, InterruptedException {

		Thread.sleep(50000);
		clicBtnMiCuenta();
		validarTextoTituloMiCuenta();
	}

	/* Continuidad */

	@SuppressWarnings("rawtypes")
	public void validarDatosMiCuentaSinDeuda() throws IOException, InterruptedException {
		Thread.sleep(10000);
		clicBtnMiCuenta();
		validarEncabezadoConsumos();

		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtSinDeuda),
				"Hola, no tienes pagos pendientes");
		assertTrue(getLblProximoCorte().contains("Tu pr�ximo corte es el"), "Tu pr�ximo corte es el");
		assertTrue(objAux.getDriver().findElement(txtFechaProxCorte).isDisplayed(), "Texto Fecha Pr�ximo Corte");

		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerHistorialPagos),
				"Boton Historial de Pagos Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnPagarFactura),
				"Bot�n Pagar Factura Visible");
		assertTrue(getLblUltimoPago().contains("�ltimo pago realizado"));

		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnMiCuenta), "Bot�n Mi Cuenta visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnConsumos), "Bot�n Consumos visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnMiPlan), "Bot�n Mi Plan visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnFacturas), "Bot�n Facturas visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnMas), "Bot�n Mas visible");

		objAux.AdminDocPdf.generaEvidencia("Validaci�n datos Mi Cuenta Producto Sin Deuda", objAux.getDriver());
	}
	
	@SuppressWarnings("rawtypes")
	public void validarDatosMiCuentaConDeuda() throws IOException, InterruptedException  {
		Thread.sleep(10000);
		clicBtnMiCuenta();

		validarEncabezadoConsumos();
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtConDeuda),
				"Hola, tu valor a pagar es");
		
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblLimitePago),
				"Texto Fecha l�mite de pago Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblProximoCorteCD),
				"Texto Pr�ximo corte Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblNumeroPagos),
				"Texto N�mero para pagos Visible");
		
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnPagarFactura),
				"Bot�n Pagar Factura Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerHistorialPagos),
				"Boton Historial de Pagos Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerDetalle),
				"Boton Ver Detalle Visible");
		
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnMiCuenta), "Bot�n Mi Cuenta visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnConsumos), "Bot�n Consumos visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnMiPlan), "Bot�n Mi Plan visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnFacturas), "Bot�n Facturas visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnMas), "Bot�n Mas visible");

		objAux.AdminDocPdf.generaEvidencia("Validaci�n datos Mi Cuenta Producto Sin Deuda", objAux.getDriver());
	}

	public void miCuentaHistorialPagosCC_SinDeuda() throws IOException, InterruptedException {
		validarDatosMiCuentaSinDeuda();
		clicBtnVerHistorialPagos();
		validarTextHistorialDePagos();
		clicTapPagosEnLinea();
		clicTapRecargasEnLinea();
		clicBtnVolver();
		validarEncabezadoConsumos();
	}
	
	public void miCuentaHistorialPagosPosp_SinDeuda() throws IOException, InterruptedException {
		validarDatosMiCuentaSinDeuda();
		clicBtnVerHistorialPagos();
		validarTextHistorialDePagos();
		clicTapPagosEnLinea();
		clicBtnVolver();
		validarEncabezadoConsumos();
	}
	
	public void miCuentaVerDetalle_ConDeudaCC() throws IOException, InterruptedException {
		validarDatosMiCuentaConDeuda();
		clicBtnVerHistorialPagos();
		validarTextHistorialDePagos();
		clicTapPagosEnLinea();
		clicTapRecargasEnLinea();
		clicBtnVolver();
		clicBtnVerDetalle();
		validarTextoTituloMisFacturas();
	}
	
	public void miCuentaVerDetalle_ConDeudaPospago() throws IOException, InterruptedException {
		validarDatosMiCuentaConDeuda();
		clicBtnVerHistorialPagos();
		validarTextHistorialDePagos();
		clicTapPagosEnLinea();
		clicBtnVolver();
		clicBtnVerDetalle();
		validarTextoTituloMisFacturas();
	}
	
	@SuppressWarnings("rawtypes")
	public void miCuentaIngreso_FijoSinDeuda() throws IOException, InterruptedException {
		Thread.sleep(30000);
		clicBtnMiCuenta();
		
		validarEncabezadoConsumos();
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtSinDeuda),
				"Hola, no tienes pagos pendientes");
		
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblDireccion),
				"Texto Direcci�n Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblCiudad),
				"Texto Ciudad Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblUltimoPago),
				"Texto �ltimo pago realizado Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblFechaPago),
				"Texto Fecha de pago Visible");
		objAux.AdminDocPdf.generaEvidencia("Ingreso producto fijo sin deuda", objAux.getDriver());
	}
	
	@SuppressWarnings("rawtypes")
	public void miCuentaVerDetalle_FijoConDeuda() throws IOException, InterruptedException {
		Thread.sleep(30000);
		clicBtnMiCuenta();
		
		validarEncabezadoConsumos();
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtConDeuda),
				"Hola, tu valor a pagar es");
		
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblLimitePago),
				"Texto Fecha l�mite de pago Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblNumeroPagos),
				"Texto N�mero para pagos Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblDireccion),
				"Texto Direcci�n Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), lblCiudad),
				"Texto Ciudad Visible");
		
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnPagarFactura),
				"Bot�n Pagar Factura Visible");
		assertTrue(objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), btnVerDetalle),
				"Boton Ver Detalle Visible");
		objAux.AdminDocPdf.generaEvidencia("Ingreso producto fijo con deuda", objAux.getDriver());
		
		clicBtnVerDetalle();
		validarTextoTituloMisFacturas();
	}
}