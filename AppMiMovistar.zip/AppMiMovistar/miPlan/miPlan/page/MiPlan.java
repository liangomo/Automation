package miPlan.page;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;

import control.elementos.ObjetosConfigAux;
import io.appium.java_client.android.AndroidDriver;

public class MiPlan {

	ObjetosConfigAux objAux;

	// Elementos

	By btnMiPlan = By.xpath("//*[contains(text(),'Mi Plan')]");
	By txtTuPlan = By.xpath("//p[@class= 'big ng-binding' and contains(text(),'')]");
	By txtTuPlanInfluyeFijo = By.xpath("//p[@class= 'small grey' and contains(text(),'Tu plan incluye:')]");
	By txtMiPlan = By.xpath("(//p[text()='Mi Plan'])[1]");
	By txtInternet = By.xpath("(//div[contains(@class,'service')])[1]");
	By txtVoz = By.xpath("(//div[contains(@class,'service')])[2]");
	By txtMensajes = By.xpath("(//div[contains(@class,'service')])[3]");
	By txtTuPlanInfluye = By.xpath("(//div[contains(@class,'service')])[4]");
	By btnQuieroCambiarMiPlan = By.xpath("//a[contains(text(),'Quiero cambiar mi plan')]");

	By iconoMovistar = By.xpath("(//span[@class='icon icono-logo-white'])[1]");
	By txtAliasProducto = By
			.xpath("//div[@class = 'icon']/p[contains(@class,'font-regular-bold icono-abajo2-white ng-binding')]");
	By txtNumeroInsumo = By.xpath("//div[@class = 'icon']/p[@class = 'ng-binding']");

	// Constructor

	public MiPlan(ObjetosConfigAux objAux) {
		this.objAux = objAux;
	}

	// Eventos

	public void clickBtnMiPlan() {
		assertFalse(objAux.EsperaDesapareceElemento(objAux.getDriver(), btnMiPlan, 2));
		objAux.getDriver().findElement(btnMiPlan).click();
	}

	public void validarTextotituloMiPlan() throws IOException, InterruptedException {
		Thread.sleep(5000);
		assertTrue(objAux.getDriver().findElement(txtMiPlan).isDisplayed());
	}

	public void validarTexTuPlanEs() throws IOException {

		assertTrue(objAux.getDriver().findElement(txtTuPlan).isDisplayed());
	}

	public void validarTexTuPlanIncluyeFijo() throws IOException {

		assertTrue(objAux.getDriver().findElement(txtTuPlanInfluyeFijo).isDisplayed());
	}

	@SuppressWarnings("rawtypes")
	public void validarTextVoz() throws IOException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtVoz)) {
			if (objAux.desplazarPantalla(objAux.getDriver(), txtVoz)) {
				objAux.AdminDocPdf.generaEvidencia("Aparece el texto voz", objAux.getDriver());
			} else {
				objAux.AdminDocPdf.generaEvidencia("No se ubico el texto voz en la pantalla", objAux.getDriver());
			}
		} else {
			objAux.AdminDocPdf.generaEvidencia("NO Aparece el texto voz", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void validarTexMensajes() throws IOException {

		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtMensajes)) {
			if (objAux.desplazarPantalla(objAux.getDriver(), txtMensajes)) {
				objAux.desplazarPantalla(objAux.getDriver(), 1);
				objAux.AdminDocPdf.generaEvidencia("Aparece el texto mensajes", objAux.getDriver());
			} else {
				objAux.AdminDocPdf.generaEvidencia("No se ubico el texto mensajes en la pantalla", objAux.getDriver());
			}
		} else {
			objAux.AdminDocPdf.generaEvidencia("NO Aparece el texto mensajes", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void validarTextInternet() throws IOException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtInternet)) {
			if (objAux.desplazarPantalla(objAux.getDriver(), txtInternet)) {
				objAux.AdminDocPdf.generaEvidencia("Aparece el texto internet", objAux.getDriver());
			} else {
				objAux.AdminDocPdf.generaEvidencia("No se ubico el texto internet en la pantalla", objAux.getDriver());
			}
		} else {
			objAux.AdminDocPdf.generaEvidencia("NO Aparece el texto internet", objAux.getDriver());
		}
	}

	@SuppressWarnings("rawtypes")
	public void validarTexTuPlanTambienIncluye() throws IOException {
		if (objAux.ElementoPresente((AndroidDriver) objAux.getDriver(), txtTuPlanInfluye)) {
			if (objAux.desplazarPantalla(objAux.getDriver(), txtTuPlanInfluye)) {
				objAux.desplazarPantalla(objAux.getDriver(), 1);
				objAux.AdminDocPdf.generaEvidencia("Aparece el texto tu plan influye", objAux.getDriver());
			} else {
				objAux.AdminDocPdf.generaEvidencia("No se ubico el texto tu plan influye en la pantalla",
						objAux.getDriver());
			}
		} else {
			objAux.AdminDocPdf.generaEvidencia("NO Aparece el texto tu plan influye", objAux.getDriver());
		}
	}

	public void validarBtnQuieroCambiarMiPlan() throws IOException {

		objAux.AdminDocPdf.generaEvidencia("Validar boton quiero cambiar mi plan", objAux.getDriver());
		assertTrue(objAux.getDriver().findElement(btnQuieroCambiarMiPlan).isDisplayed());
	}

	public void validarEncabezadoMiPlan() throws IOException {
		assertTrue(objAux.getDriver().findElement(txtMiPlan).isDisplayed(), "Texto Mi plan");
		assertTrue(objAux.getDriver().findElement(iconoMovistar).isDisplayed(), "Icono (M) movistar");
		assertTrue(objAux.getDriver().findElement(txtAliasProducto).isDisplayed(), "Alisas del producto");
		assertTrue(objAux.getDriver().findElement(txtNumeroInsumo).isDisplayed(), "Numero del insumo");
	}

	// Metodo
	public void ingresoMiPlanPospago() throws IOException, InterruptedException {

		clickBtnMiPlan();
		validarEncabezadoMiPlan();
		validarTexTuPlanEs();
		validarTextInternet();
		validarTextVoz();
		validarTexMensajes();
		validarTexTuPlanTambienIncluye();
	}

	public void ingresoMiPlanCuentaControl() throws IOException, InterruptedException {
		clickBtnMiPlan();
		validarEncabezadoMiPlan();
		validarTexTuPlanEs();
		validarTextInternet();
		validarTextVoz();
		validarTexMensajes();
	}

	public void ingresoMiPlanFija() throws IOException, InterruptedException {
		clickBtnMiPlan();
		Thread.sleep(10000);
		validarEncabezadoMiPlan();
		validarTexTuPlanIncluyeFijo();
		validarBtnQuieroCambiarMiPlan();
	}
}