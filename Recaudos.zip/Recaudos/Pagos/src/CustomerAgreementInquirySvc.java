/**
 * CustomerAgreementInquirySvc.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public interface CustomerAgreementInquirySvc extends javax.xml.rpc.Service {
    public java.lang.String getCustomerAgreementInquiryPortAddress();

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort() throws javax.xml.rpc.ServiceException;

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getCustomerAgreementInquiryPort0Address();

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort0() throws javax.xml.rpc.ServiceException;

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort0(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getCustomerAgreementInquiryPort1Address();

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort1() throws javax.xml.rpc.ServiceException;

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort1(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
