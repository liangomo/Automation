/**
 * CustomerAgreementInqRq_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public class CustomerAgreementInqRq_Type  extends SvcRq_Type  implements java.io.Serializable {
    private java.lang.String trnType;

    private java.lang.String branchId;

    private java.lang.String branchName;

    private java.lang.String eanCode;

    private java.lang.String acctId;

    private java.lang.String indCtrCje;

    private java.lang.String indCtaNal;

    private TINInfo_Type TINInfo;

    private java.lang.String billRefInfo;

    public CustomerAgreementInqRq_Type() {
    }

    public CustomerAgreementInqRq_Type(
           java.lang.String rqUID,
           java.lang.String asyncRqUID,
           java.lang.String revClientTrnSeq,
           CustId_Type custId,
           Boolean_Type nextDay,
           BaseEnvr_Type baseEnvr,
           java.lang.String clientTerminalSeqId,
           java.lang.String trnStatusType,
           NetworkTrnInfo_Type networkTrnInfo,
           java.lang.String clientDt,
           java.lang.String trnType,
           java.lang.String branchId,
           java.lang.String branchName,
           java.lang.String eanCode,
           java.lang.String acctId,
           java.lang.String indCtrCje,
           java.lang.String indCtaNal,
           TINInfo_Type TINInfo,
           java.lang.String billRefInfo) {
        super(
            rqUID,
            asyncRqUID,
            revClientTrnSeq,
            custId,
            nextDay,
            baseEnvr,
            clientTerminalSeqId,
            trnStatusType,
            networkTrnInfo,
            clientDt);
        this.trnType = trnType;
        this.branchId = branchId;
        this.branchName = branchName;
        this.eanCode = eanCode;
        this.acctId = acctId;
        this.indCtrCje = indCtrCje;
        this.indCtaNal = indCtaNal;
        this.TINInfo = TINInfo;
        this.billRefInfo = billRefInfo;
    }


    /**
     * Gets the trnType value for this CustomerAgreementInqRq_Type.
     * 
     * @return trnType
     */
    public java.lang.String getTrnType() {
        return trnType;
    }


    /**
     * Sets the trnType value for this CustomerAgreementInqRq_Type.
     * 
     * @param trnType
     */
    public void setTrnType(java.lang.String trnType) {
        this.trnType = trnType;
    }


    /**
     * Gets the branchId value for this CustomerAgreementInqRq_Type.
     * 
     * @return branchId
     */
    public java.lang.String getBranchId() {
        return branchId;
    }


    /**
     * Sets the branchId value for this CustomerAgreementInqRq_Type.
     * 
     * @param branchId
     */
    public void setBranchId(java.lang.String branchId) {
        this.branchId = branchId;
    }


    /**
     * Gets the branchName value for this CustomerAgreementInqRq_Type.
     * 
     * @return branchName
     */
    public java.lang.String getBranchName() {
        return branchName;
    }


    /**
     * Sets the branchName value for this CustomerAgreementInqRq_Type.
     * 
     * @param branchName
     */
    public void setBranchName(java.lang.String branchName) {
        this.branchName = branchName;
    }


    /**
     * Gets the eanCode value for this CustomerAgreementInqRq_Type.
     * 
     * @return eanCode
     */
    public java.lang.String getEanCode() {
        return eanCode;
    }


    /**
     * Sets the eanCode value for this CustomerAgreementInqRq_Type.
     * 
     * @param eanCode
     */
    public void setEanCode(java.lang.String eanCode) {
        this.eanCode = eanCode;
    }


    /**
     * Gets the acctId value for this CustomerAgreementInqRq_Type.
     * 
     * @return acctId
     */
    public java.lang.String getAcctId() {
        return acctId;
    }


    /**
     * Sets the acctId value for this CustomerAgreementInqRq_Type.
     * 
     * @param acctId
     */
    public void setAcctId(java.lang.String acctId) {
        this.acctId = acctId;
    }


    /**
     * Gets the indCtrCje value for this CustomerAgreementInqRq_Type.
     * 
     * @return indCtrCje
     */
    public java.lang.String getIndCtrCje() {
        return indCtrCje;
    }


    /**
     * Sets the indCtrCje value for this CustomerAgreementInqRq_Type.
     * 
     * @param indCtrCje
     */
    public void setIndCtrCje(java.lang.String indCtrCje) {
        this.indCtrCje = indCtrCje;
    }


    /**
     * Gets the indCtaNal value for this CustomerAgreementInqRq_Type.
     * 
     * @return indCtaNal
     */
    public java.lang.String getIndCtaNal() {
        return indCtaNal;
    }


    /**
     * Sets the indCtaNal value for this CustomerAgreementInqRq_Type.
     * 
     * @param indCtaNal
     */
    public void setIndCtaNal(java.lang.String indCtaNal) {
        this.indCtaNal = indCtaNal;
    }


    /**
     * Gets the TINInfo value for this CustomerAgreementInqRq_Type.
     * 
     * @return TINInfo
     */
    public TINInfo_Type getTINInfo() {
        return TINInfo;
    }


    /**
     * Sets the TINInfo value for this CustomerAgreementInqRq_Type.
     * 
     * @param TINInfo
     */
    public void setTINInfo(TINInfo_Type TINInfo) {
        this.TINInfo = TINInfo;
    }


    /**
     * Gets the billRefInfo value for this CustomerAgreementInqRq_Type.
     * 
     * @return billRefInfo
     */
    public java.lang.String getBillRefInfo() {
        return billRefInfo;
    }


    /**
     * Sets the billRefInfo value for this CustomerAgreementInqRq_Type.
     * 
     * @param billRefInfo
     */
    public void setBillRefInfo(java.lang.String billRefInfo) {
        this.billRefInfo = billRefInfo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CustomerAgreementInqRq_Type)) return false;
        CustomerAgreementInqRq_Type other = (CustomerAgreementInqRq_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.trnType==null && other.getTrnType()==null) || 
             (this.trnType!=null &&
              this.trnType.equals(other.getTrnType()))) &&
            ((this.branchId==null && other.getBranchId()==null) || 
             (this.branchId!=null &&
              this.branchId.equals(other.getBranchId()))) &&
            ((this.branchName==null && other.getBranchName()==null) || 
             (this.branchName!=null &&
              this.branchName.equals(other.getBranchName()))) &&
            ((this.eanCode==null && other.getEanCode()==null) || 
             (this.eanCode!=null &&
              this.eanCode.equals(other.getEanCode()))) &&
            ((this.acctId==null && other.getAcctId()==null) || 
             (this.acctId!=null &&
              this.acctId.equals(other.getAcctId()))) &&
            ((this.indCtrCje==null && other.getIndCtrCje()==null) || 
             (this.indCtrCje!=null &&
              this.indCtrCje.equals(other.getIndCtrCje()))) &&
            ((this.indCtaNal==null && other.getIndCtaNal()==null) || 
             (this.indCtaNal!=null &&
              this.indCtaNal.equals(other.getIndCtaNal()))) &&
            ((this.TINInfo==null && other.getTINInfo()==null) || 
             (this.TINInfo!=null &&
              this.TINInfo.equals(other.getTINInfo()))) &&
            ((this.billRefInfo==null && other.getBillRefInfo()==null) || 
             (this.billRefInfo!=null &&
              this.billRefInfo.equals(other.getBillRefInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getTrnType() != null) {
            _hashCode += getTrnType().hashCode();
        }
        if (getBranchId() != null) {
            _hashCode += getBranchId().hashCode();
        }
        if (getBranchName() != null) {
            _hashCode += getBranchName().hashCode();
        }
        if (getEanCode() != null) {
            _hashCode += getEanCode().hashCode();
        }
        if (getAcctId() != null) {
            _hashCode += getAcctId().hashCode();
        }
        if (getIndCtrCje() != null) {
            _hashCode += getIndCtrCje().hashCode();
        }
        if (getIndCtaNal() != null) {
            _hashCode += getIndCtaNal().hashCode();
        }
        if (getTINInfo() != null) {
            _hashCode += getTINInfo().hashCode();
        }
        if (getBillRefInfo() != null) {
            _hashCode += getBillRefInfo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CustomerAgreementInqRq_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/customeragreement/event/", "CustomerAgreementInqRq_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trnType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TrnType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "OpenEnum_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("branchId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BranchId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BranchId_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("branchName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BranchName"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BranchName_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("eanCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "EanCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "OpenEnum_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("acctId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AcctId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AcctId_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indCtrCje");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IndCtrCje"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indCtaNal");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IndCtaNal"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TINInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TINInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TINInfo_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billRefInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BillRefInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BillRefInfo_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
