/**
 * AdditionalStatus_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public class AdditionalStatus_Type  implements java.io.Serializable {
    /* En este campo se parametriza el código de estatus. */
    private java.lang.String statusCode;

    /* En este campo se parametriza el código de estatus del servidor. */
    private java.lang.String serverStatusCode;

    /* En este campo se parametriza la severidad. */
    private java.lang.String severity;

    /* En este campo se parametriza la descripción del estatus. */
    private java.lang.String statusDesc;

    public AdditionalStatus_Type() {
    }

    public AdditionalStatus_Type(
           java.lang.String statusCode,
           java.lang.String serverStatusCode,
           java.lang.String severity,
           java.lang.String statusDesc) {
           this.statusCode = statusCode;
           this.serverStatusCode = serverStatusCode;
           this.severity = severity;
           this.statusDesc = statusDesc;
    }


    /**
     * Gets the statusCode value for this AdditionalStatus_Type.
     * 
     * @return statusCode   * En este campo se parametriza el código de estatus.
     */
    public java.lang.String getStatusCode() {
        return statusCode;
    }


    /**
     * Sets the statusCode value for this AdditionalStatus_Type.
     * 
     * @param statusCode   * En este campo se parametriza el código de estatus.
     */
    public void setStatusCode(java.lang.String statusCode) {
        this.statusCode = statusCode;
    }


    /**
     * Gets the serverStatusCode value for this AdditionalStatus_Type.
     * 
     * @return serverStatusCode   * En este campo se parametriza el código de estatus del servidor.
     */
    public java.lang.String getServerStatusCode() {
        return serverStatusCode;
    }


    /**
     * Sets the serverStatusCode value for this AdditionalStatus_Type.
     * 
     * @param serverStatusCode   * En este campo se parametriza el código de estatus del servidor.
     */
    public void setServerStatusCode(java.lang.String serverStatusCode) {
        this.serverStatusCode = serverStatusCode;
    }


    /**
     * Gets the severity value for this AdditionalStatus_Type.
     * 
     * @return severity   * En este campo se parametriza la severidad.
     */
    public java.lang.String getSeverity() {
        return severity;
    }


    /**
     * Sets the severity value for this AdditionalStatus_Type.
     * 
     * @param severity   * En este campo se parametriza la severidad.
     */
    public void setSeverity(java.lang.String severity) {
        this.severity = severity;
    }


    /**
     * Gets the statusDesc value for this AdditionalStatus_Type.
     * 
     * @return statusDesc   * En este campo se parametriza la descripción del estatus.
     */
    public java.lang.String getStatusDesc() {
        return statusDesc;
    }


    /**
     * Sets the statusDesc value for this AdditionalStatus_Type.
     * 
     * @param statusDesc   * En este campo se parametriza la descripción del estatus.
     */
    public void setStatusDesc(java.lang.String statusDesc) {
        this.statusDesc = statusDesc;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AdditionalStatus_Type)) return false;
        AdditionalStatus_Type other = (AdditionalStatus_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.statusCode==null && other.getStatusCode()==null) || 
             (this.statusCode!=null &&
              this.statusCode.equals(other.getStatusCode()))) &&
            ((this.serverStatusCode==null && other.getServerStatusCode()==null) || 
             (this.serverStatusCode!=null &&
              this.serverStatusCode.equals(other.getServerStatusCode()))) &&
            ((this.severity==null && other.getSeverity()==null) || 
             (this.severity!=null &&
              this.severity.equals(other.getSeverity()))) &&
            ((this.statusDesc==null && other.getStatusDesc()==null) || 
             (this.statusDesc!=null &&
              this.statusDesc.equals(other.getStatusDesc())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStatusCode() != null) {
            _hashCode += getStatusCode().hashCode();
        }
        if (getServerStatusCode() != null) {
            _hashCode += getServerStatusCode().hashCode();
        }
        if (getSeverity() != null) {
            _hashCode += getSeverity().hashCode();
        }
        if (getStatusDesc() != null) {
            _hashCode += getStatusDesc().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AdditionalStatus_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AdditionalStatus_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "StatusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "StatusCode_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverStatusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "ServerStatusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "ServerStatusCode_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("severity");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Severity"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Severity_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusDesc");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "StatusDesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "StatusDesc_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
