/**
 * RefInfo_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public class RefInfo_Type  implements java.io.Serializable {
    /* Tipo de referencia. */
    private java.lang.String refType;

    /* Identificador de referencia. */
    private java.lang.String[] refId;

    /* Nombre de la referencia. */
    private java.lang.String[] name;

    /* Descripción de la referencia. */
    private java.lang.String[] desc;

    public RefInfo_Type() {
    }

    public RefInfo_Type(
           java.lang.String refType,
           java.lang.String[] refId,
           java.lang.String[] name,
           java.lang.String[] desc) {
           this.refType = refType;
           this.refId = refId;
           this.name = name;
           this.desc = desc;
    }


    /**
     * Gets the refType value for this RefInfo_Type.
     * 
     * @return refType   * Tipo de referencia.
     */
    public java.lang.String getRefType() {
        return refType;
    }


    /**
     * Sets the refType value for this RefInfo_Type.
     * 
     * @param refType   * Tipo de referencia.
     */
    public void setRefType(java.lang.String refType) {
        this.refType = refType;
    }


    /**
     * Gets the refId value for this RefInfo_Type.
     * 
     * @return refId   * Identificador de referencia.
     */
    public java.lang.String[] getRefId() {
        return refId;
    }


    /**
     * Sets the refId value for this RefInfo_Type.
     * 
     * @param refId   * Identificador de referencia.
     */
    public void setRefId(java.lang.String[] refId) {
        this.refId = refId;
    }

    public java.lang.String getRefId(int i) {
        return this.refId[i];
    }

    public void setRefId(int i, java.lang.String _value) {
        this.refId[i] = _value;
    }


    /**
     * Gets the name value for this RefInfo_Type.
     * 
     * @return name   * Nombre de la referencia.
     */
    public java.lang.String[] getName() {
        return name;
    }


    /**
     * Sets the name value for this RefInfo_Type.
     * 
     * @param name   * Nombre de la referencia.
     */
    public void setName(java.lang.String[] name) {
        this.name = name;
    }

    public java.lang.String getName(int i) {
        return this.name[i];
    }

    public void setName(int i, java.lang.String _value) {
        this.name[i] = _value;
    }


    /**
     * Gets the desc value for this RefInfo_Type.
     * 
     * @return desc   * Descripción de la referencia.
     */
    public java.lang.String[] getDesc() {
        return desc;
    }


    /**
     * Sets the desc value for this RefInfo_Type.
     * 
     * @param desc   * Descripción de la referencia.
     */
    public void setDesc(java.lang.String[] desc) {
        this.desc = desc;
    }

    public java.lang.String getDesc(int i) {
        return this.desc[i];
    }

    public void setDesc(int i, java.lang.String _value) {
        this.desc[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RefInfo_Type)) return false;
        RefInfo_Type other = (RefInfo_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.refType==null && other.getRefType()==null) || 
             (this.refType!=null &&
              this.refType.equals(other.getRefType()))) &&
            ((this.refId==null && other.getRefId()==null) || 
             (this.refId!=null &&
              java.util.Arrays.equals(this.refId, other.getRefId()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              java.util.Arrays.equals(this.name, other.getName()))) &&
            ((this.desc==null && other.getDesc()==null) || 
             (this.desc!=null &&
              java.util.Arrays.equals(this.desc, other.getDesc())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getRefType() != null) {
            _hashCode += getRefType().hashCode();
        }
        if (getRefId() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRefId());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRefId(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getName() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getName());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getName(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDesc() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDesc());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDesc(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RefInfo_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "RefInfo_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "RefType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "RefId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Identifier_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Name_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desc");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Desc"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Desc_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
