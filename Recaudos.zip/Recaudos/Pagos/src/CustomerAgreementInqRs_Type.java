/**
 * CustomerAgreementInqRs_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public class CustomerAgreementInqRs_Type  extends SvcRs_Type  implements java.io.Serializable {
    private java.lang.String terminalId;

    private java.lang.String acctType;

    private java.lang.String acctId;

    private java.math.BigDecimal curRate;

    private java.lang.String branchId;

    private java.lang.String branchName;

    private java.lang.String[] desc;

    private RefInfo_Type[] refInfo;

    private CompanyAgreement_Type companyAgreement;

    public CustomerAgreementInqRs_Type() {
    }

    public CustomerAgreementInqRs_Type(
           java.lang.String rqUID,
           java.lang.String asyncRqUID,
           java.lang.String revClientTrnSeq,
           Status_Type status,
           CustId_Type custId,
           Boolean_Type nextDay,
           java.lang.String serverTerminalSeqId,
           NetworkTrnInfo_Type networkTrnInfo,
           java.lang.String serverDt,
           java.lang.String terminalId,
           java.lang.String acctType,
           java.lang.String acctId,
           java.math.BigDecimal curRate,
           java.lang.String branchId,
           java.lang.String branchName,
           java.lang.String[] desc,
           RefInfo_Type[] refInfo,
           CompanyAgreement_Type companyAgreement) {
        super(
            rqUID,
            asyncRqUID,
            revClientTrnSeq,
            status,
            custId,
            nextDay,
            serverTerminalSeqId,
            networkTrnInfo,
            serverDt);
        this.terminalId = terminalId;
        this.acctType = acctType;
        this.acctId = acctId;
        this.curRate = curRate;
        this.branchId = branchId;
        this.branchName = branchName;
        this.desc = desc;
        this.refInfo = refInfo;
        this.companyAgreement = companyAgreement;
    }


    /**
     * Gets the terminalId value for this CustomerAgreementInqRs_Type.
     * 
     * @return terminalId
     */
    public java.lang.String getTerminalId() {
        return terminalId;
    }


    /**
     * Sets the terminalId value for this CustomerAgreementInqRs_Type.
     * 
     * @param terminalId
     */
    public void setTerminalId(java.lang.String terminalId) {
        this.terminalId = terminalId;
    }


    /**
     * Gets the acctType value for this CustomerAgreementInqRs_Type.
     * 
     * @return acctType
     */
    public java.lang.String getAcctType() {
        return acctType;
    }


    /**
     * Sets the acctType value for this CustomerAgreementInqRs_Type.
     * 
     * @param acctType
     */
    public void setAcctType(java.lang.String acctType) {
        this.acctType = acctType;
    }


    /**
     * Gets the acctId value for this CustomerAgreementInqRs_Type.
     * 
     * @return acctId
     */
    public java.lang.String getAcctId() {
        return acctId;
    }


    /**
     * Sets the acctId value for this CustomerAgreementInqRs_Type.
     * 
     * @param acctId
     */
    public void setAcctId(java.lang.String acctId) {
        this.acctId = acctId;
    }


    /**
     * Gets the curRate value for this CustomerAgreementInqRs_Type.
     * 
     * @return curRate
     */
    public java.math.BigDecimal getCurRate() {
        return curRate;
    }


    /**
     * Sets the curRate value for this CustomerAgreementInqRs_Type.
     * 
     * @param curRate
     */
    public void setCurRate(java.math.BigDecimal curRate) {
        this.curRate = curRate;
    }


    /**
     * Gets the branchId value for this CustomerAgreementInqRs_Type.
     * 
     * @return branchId
     */
    public java.lang.String getBranchId() {
        return branchId;
    }


    /**
     * Sets the branchId value for this CustomerAgreementInqRs_Type.
     * 
     * @param branchId
     */
    public void setBranchId(java.lang.String branchId) {
        this.branchId = branchId;
    }


    /**
     * Gets the branchName value for this CustomerAgreementInqRs_Type.
     * 
     * @return branchName
     */
    public java.lang.String getBranchName() {
        return branchName;
    }


    /**
     * Sets the branchName value for this CustomerAgreementInqRs_Type.
     * 
     * @param branchName
     */
    public void setBranchName(java.lang.String branchName) {
        this.branchName = branchName;
    }


    /**
     * Gets the desc value for this CustomerAgreementInqRs_Type.
     * 
     * @return desc
     */
    public java.lang.String[] getDesc() {
        return desc;
    }


    /**
     * Sets the desc value for this CustomerAgreementInqRs_Type.
     * 
     * @param desc
     */
    public void setDesc(java.lang.String[] desc) {
        this.desc = desc;
    }

    public java.lang.String getDesc(int i) {
        return this.desc[i];
    }

    public void setDesc(int i, java.lang.String _value) {
        this.desc[i] = _value;
    }


    /**
     * Gets the refInfo value for this CustomerAgreementInqRs_Type.
     * 
     * @return refInfo
     */
    public RefInfo_Type[] getRefInfo() {
        return refInfo;
    }


    /**
     * Sets the refInfo value for this CustomerAgreementInqRs_Type.
     * 
     * @param refInfo
     */
    public void setRefInfo(RefInfo_Type[] refInfo) {
        this.refInfo = refInfo;
    }

    public RefInfo_Type getRefInfo(int i) {
        return this.refInfo[i];
    }

    public void setRefInfo(int i, RefInfo_Type _value) {
        this.refInfo[i] = _value;
    }


    /**
     * Gets the companyAgreement value for this CustomerAgreementInqRs_Type.
     * 
     * @return companyAgreement
     */
    public CompanyAgreement_Type getCompanyAgreement() {
        return companyAgreement;
    }


    /**
     * Sets the companyAgreement value for this CustomerAgreementInqRs_Type.
     * 
     * @param companyAgreement
     */
    public void setCompanyAgreement(CompanyAgreement_Type companyAgreement) {
        this.companyAgreement = companyAgreement;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CustomerAgreementInqRs_Type)) return false;
        CustomerAgreementInqRs_Type other = (CustomerAgreementInqRs_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.terminalId==null && other.getTerminalId()==null) || 
             (this.terminalId!=null &&
              this.terminalId.equals(other.getTerminalId()))) &&
            ((this.acctType==null && other.getAcctType()==null) || 
             (this.acctType!=null &&
              this.acctType.equals(other.getAcctType()))) &&
            ((this.acctId==null && other.getAcctId()==null) || 
             (this.acctId!=null &&
              this.acctId.equals(other.getAcctId()))) &&
            ((this.curRate==null && other.getCurRate()==null) || 
             (this.curRate!=null &&
              this.curRate.equals(other.getCurRate()))) &&
            ((this.branchId==null && other.getBranchId()==null) || 
             (this.branchId!=null &&
              this.branchId.equals(other.getBranchId()))) &&
            ((this.branchName==null && other.getBranchName()==null) || 
             (this.branchName!=null &&
              this.branchName.equals(other.getBranchName()))) &&
            ((this.desc==null && other.getDesc()==null) || 
             (this.desc!=null &&
              java.util.Arrays.equals(this.desc, other.getDesc()))) &&
            ((this.refInfo==null && other.getRefInfo()==null) || 
             (this.refInfo!=null &&
              java.util.Arrays.equals(this.refInfo, other.getRefInfo()))) &&
            ((this.companyAgreement==null && other.getCompanyAgreement()==null) || 
             (this.companyAgreement!=null &&
              this.companyAgreement.equals(other.getCompanyAgreement())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getTerminalId() != null) {
            _hashCode += getTerminalId().hashCode();
        }
        if (getAcctType() != null) {
            _hashCode += getAcctType().hashCode();
        }
        if (getAcctId() != null) {
            _hashCode += getAcctId().hashCode();
        }
        if (getCurRate() != null) {
            _hashCode += getCurRate().hashCode();
        }
        if (getBranchId() != null) {
            _hashCode += getBranchId().hashCode();
        }
        if (getBranchName() != null) {
            _hashCode += getBranchName().hashCode();
        }
        if (getDesc() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDesc());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDesc(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRefInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRefInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRefInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCompanyAgreement() != null) {
            _hashCode += getCompanyAgreement().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CustomerAgreementInqRs_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/customeragreement/event/", "CustomerAgreementInqRs_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terminalId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TerminalId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Identifier_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("acctType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AcctType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "OpenEnum_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("acctId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AcctId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AcctId_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("curRate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CurRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Decimal_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("branchId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BranchId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BranchId_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("branchName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BranchName"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BranchName_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desc");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Desc"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Desc"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/product/v1/", "RefInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/product/v1/", "RefInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("companyAgreement");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/agreement/v1/", "CompanyAgreement"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/agreement/v1/", "CompanyAgreement_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
