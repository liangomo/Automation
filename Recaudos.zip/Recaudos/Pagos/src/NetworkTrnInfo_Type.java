/**
 * NetworkTrnInfo_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public class NetworkTrnInfo_Type  implements java.io.Serializable {
    /* En este campo se parametriza el propietario de Red, el nombre
     * de la persona u organización 
     * 						que posee la red de origen, los valores definidos son ATM, POS,
     * ACH, FedNet, SWIFT, Rama, 
     * 						CallCenter, Otros. */
    private java.lang.String networkOwner;

    /* En este campo se parametriza el identificador de terminal,
     * tal como el código de terminal o
     * 						número de terminal ATM. */
    private java.lang.String terminalId;

    /* En este campo se parametriza el tipo de terminal, valores definidos
     * AdminTerm, ATM, POS, 
     * 						CustomerDevice, ECR, DialCash, TravelerCheckDispenser, FuelPump,
     * ScripTerm, CouponTerm, 
     * 						TicketTerm, POBTerm, Teller, Utility, Vending, Payment, VRU. */
    private java.lang.String terminalType;

    /* En este campo se parametriza el código bancario el cual viene
     * de CRM.
     * 	    				Indica cual banco dentro del holding esta asociado a la cuenta. */
    private java.lang.String bankId;

    /* En este campo se parametriza la descripción. */
    private java.lang.String desc;

    /* En este campo se parametriza el nombre. */
    private java.lang.String name;

    public NetworkTrnInfo_Type() {
    }

    public NetworkTrnInfo_Type(
           java.lang.String networkOwner,
           java.lang.String terminalId,
           java.lang.String terminalType,
           java.lang.String bankId,
           java.lang.String desc,
           java.lang.String name) {
           this.networkOwner = networkOwner;
           this.terminalId = terminalId;
           this.terminalType = terminalType;
           this.bankId = bankId;
           this.desc = desc;
           this.name = name;
    }


    /**
     * Gets the networkOwner value for this NetworkTrnInfo_Type.
     * 
     * @return networkOwner   * En este campo se parametriza el propietario de Red, el nombre
     * de la persona u organización 
     * 						que posee la red de origen, los valores definidos son ATM, POS,
     * ACH, FedNet, SWIFT, Rama, 
     * 						CallCenter, Otros.
     */
    public java.lang.String getNetworkOwner() {
        return networkOwner;
    }


    /**
     * Sets the networkOwner value for this NetworkTrnInfo_Type.
     * 
     * @param networkOwner   * En este campo se parametriza el propietario de Red, el nombre
     * de la persona u organización 
     * 						que posee la red de origen, los valores definidos son ATM, POS,
     * ACH, FedNet, SWIFT, Rama, 
     * 						CallCenter, Otros.
     */
    public void setNetworkOwner(java.lang.String networkOwner) {
        this.networkOwner = networkOwner;
    }


    /**
     * Gets the terminalId value for this NetworkTrnInfo_Type.
     * 
     * @return terminalId   * En este campo se parametriza el identificador de terminal,
     * tal como el código de terminal o
     * 						número de terminal ATM.
     */
    public java.lang.String getTerminalId() {
        return terminalId;
    }


    /**
     * Sets the terminalId value for this NetworkTrnInfo_Type.
     * 
     * @param terminalId   * En este campo se parametriza el identificador de terminal,
     * tal como el código de terminal o
     * 						número de terminal ATM.
     */
    public void setTerminalId(java.lang.String terminalId) {
        this.terminalId = terminalId;
    }


    /**
     * Gets the terminalType value for this NetworkTrnInfo_Type.
     * 
     * @return terminalType   * En este campo se parametriza el tipo de terminal, valores definidos
     * AdminTerm, ATM, POS, 
     * 						CustomerDevice, ECR, DialCash, TravelerCheckDispenser, FuelPump,
     * ScripTerm, CouponTerm, 
     * 						TicketTerm, POBTerm, Teller, Utility, Vending, Payment, VRU.
     */
    public java.lang.String getTerminalType() {
        return terminalType;
    }


    /**
     * Sets the terminalType value for this NetworkTrnInfo_Type.
     * 
     * @param terminalType   * En este campo se parametriza el tipo de terminal, valores definidos
     * AdminTerm, ATM, POS, 
     * 						CustomerDevice, ECR, DialCash, TravelerCheckDispenser, FuelPump,
     * ScripTerm, CouponTerm, 
     * 						TicketTerm, POBTerm, Teller, Utility, Vending, Payment, VRU.
     */
    public void setTerminalType(java.lang.String terminalType) {
        this.terminalType = terminalType;
    }


    /**
     * Gets the bankId value for this NetworkTrnInfo_Type.
     * 
     * @return bankId   * En este campo se parametriza el código bancario el cual viene
     * de CRM.
     * 	    				Indica cual banco dentro del holding esta asociado a la cuenta.
     */
    public java.lang.String getBankId() {
        return bankId;
    }


    /**
     * Sets the bankId value for this NetworkTrnInfo_Type.
     * 
     * @param bankId   * En este campo se parametriza el código bancario el cual viene
     * de CRM.
     * 	    				Indica cual banco dentro del holding esta asociado a la cuenta.
     */
    public void setBankId(java.lang.String bankId) {
        this.bankId = bankId;
    }


    /**
     * Gets the desc value for this NetworkTrnInfo_Type.
     * 
     * @return desc   * En este campo se parametriza la descripción.
     */
    public java.lang.String getDesc() {
        return desc;
    }


    /**
     * Sets the desc value for this NetworkTrnInfo_Type.
     * 
     * @param desc   * En este campo se parametriza la descripción.
     */
    public void setDesc(java.lang.String desc) {
        this.desc = desc;
    }


    /**
     * Gets the name value for this NetworkTrnInfo_Type.
     * 
     * @return name   * En este campo se parametriza el nombre.
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this NetworkTrnInfo_Type.
     * 
     * @param name   * En este campo se parametriza el nombre.
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NetworkTrnInfo_Type)) return false;
        NetworkTrnInfo_Type other = (NetworkTrnInfo_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.networkOwner==null && other.getNetworkOwner()==null) || 
             (this.networkOwner!=null &&
              this.networkOwner.equals(other.getNetworkOwner()))) &&
            ((this.terminalId==null && other.getTerminalId()==null) || 
             (this.terminalId!=null &&
              this.terminalId.equals(other.getTerminalId()))) &&
            ((this.terminalType==null && other.getTerminalType()==null) || 
             (this.terminalType!=null &&
              this.terminalType.equals(other.getTerminalType()))) &&
            ((this.bankId==null && other.getBankId()==null) || 
             (this.bankId!=null &&
              this.bankId.equals(other.getBankId()))) &&
            ((this.desc==null && other.getDesc()==null) || 
             (this.desc!=null &&
              this.desc.equals(other.getDesc()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNetworkOwner() != null) {
            _hashCode += getNetworkOwner().hashCode();
        }
        if (getTerminalId() != null) {
            _hashCode += getTerminalId().hashCode();
        }
        if (getTerminalType() != null) {
            _hashCode += getTerminalType().hashCode();
        }
        if (getBankId() != null) {
            _hashCode += getBankId().hashCode();
        }
        if (getDesc() != null) {
            _hashCode += getDesc().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NetworkTrnInfo_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "NetworkTrnInfo_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("networkOwner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "NetworkOwner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "OpenEnum_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terminalId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TerminalId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Identifier_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terminalType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TerminalType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "OpenEnum_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BankId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BankId_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desc");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Desc"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Desc_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Name_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
