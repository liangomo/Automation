/**
 * CustomerAgreementInquirySvcLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public class CustomerAgreementInquirySvcLocator extends org.apache.axis.client.Service implements CustomerAgreementInquirySvc {

    public CustomerAgreementInquirySvcLocator() {
    }


    public CustomerAgreementInquirySvcLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public CustomerAgreementInquirySvcLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for CustomerAgreementInquiryPort
    private java.lang.String CustomerAgreementInquiryPort_address = "http://10.87.52.11:30088/customers/product/CustomerAgreementInquiry";

    public java.lang.String getCustomerAgreementInquiryPortAddress() {
        return CustomerAgreementInquiryPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CustomerAgreementInquiryPortWSDDServiceName = "CustomerAgreementInquiryPort";

    public java.lang.String getCustomerAgreementInquiryPortWSDDServiceName() {
        return CustomerAgreementInquiryPortWSDDServiceName;
    }

    public void setCustomerAgreementInquiryPortWSDDServiceName(java.lang.String name) {
        CustomerAgreementInquiryPortWSDDServiceName = name;
    }

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CustomerAgreementInquiryPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCustomerAgreementInquiryPort(endpoint);
    }

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            CustomerAgreementInquiryBindingStub _stub = new CustomerAgreementInquiryBindingStub(portAddress, this);
            _stub.setPortName(getCustomerAgreementInquiryPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCustomerAgreementInquiryPortEndpointAddress(java.lang.String address) {
        CustomerAgreementInquiryPort_address = address;
    }


    // Use to get a proxy class for CustomerAgreementInquiryPort0
    private java.lang.String CustomerAgreementInquiryPort0_address = "https://10.87.52.11:30099/customers/product/CustomerAgreementInquiry";

    public java.lang.String getCustomerAgreementInquiryPort0Address() {
        return CustomerAgreementInquiryPort0_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CustomerAgreementInquiryPort0WSDDServiceName = "CustomerAgreementInquiryPort.0";

    public java.lang.String getCustomerAgreementInquiryPort0WSDDServiceName() {
        return CustomerAgreementInquiryPort0WSDDServiceName;
    }

    public void setCustomerAgreementInquiryPort0WSDDServiceName(java.lang.String name) {
        CustomerAgreementInquiryPort0WSDDServiceName = name;
    }

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort0() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CustomerAgreementInquiryPort0_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCustomerAgreementInquiryPort0(endpoint);
    }

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort0(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            CustomerAgreementInquiryBindingStub _stub = new CustomerAgreementInquiryBindingStub(portAddress, this);
            _stub.setPortName(getCustomerAgreementInquiryPort0WSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCustomerAgreementInquiryPort0EndpointAddress(java.lang.String address) {
        CustomerAgreementInquiryPort0_address = address;
    }


    // Use to get a proxy class for CustomerAgreementInquiryPort1
    private java.lang.String CustomerAgreementInquiryPort1_address = "http://10.87.52.11:38088/customers/product/CustomerAgreementInquiry";

    public java.lang.String getCustomerAgreementInquiryPort1Address() {
        return CustomerAgreementInquiryPort1_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CustomerAgreementInquiryPort1WSDDServiceName = "CustomerAgreementInquiryPort.1";

    public java.lang.String getCustomerAgreementInquiryPort1WSDDServiceName() {
        return CustomerAgreementInquiryPort1WSDDServiceName;
    }

    public void setCustomerAgreementInquiryPort1WSDDServiceName(java.lang.String name) {
        CustomerAgreementInquiryPort1WSDDServiceName = name;
    }

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort1() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CustomerAgreementInquiryPort1_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCustomerAgreementInquiryPort1(endpoint);
    }

    public CustomerAgreementInquiry getCustomerAgreementInquiryPort1(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            CustomerAgreementInquiryBindingStub _stub = new CustomerAgreementInquiryBindingStub(portAddress, this);
            _stub.setPortName(getCustomerAgreementInquiryPort1WSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCustomerAgreementInquiryPort1EndpointAddress(java.lang.String address) {
        CustomerAgreementInquiryPort1_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     * This service has multiple ports for a given interface;
     * the proxy implementation returned may be indeterminate.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (CustomerAgreementInquiry.class.isAssignableFrom(serviceEndpointInterface)) {
                CustomerAgreementInquiryBindingStub _stub = new CustomerAgreementInquiryBindingStub(new java.net.URL(CustomerAgreementInquiryPort_address), this);
                _stub.setPortName(getCustomerAgreementInquiryPortWSDDServiceName());
                return _stub;
            }
            if (CustomerAgreementInquiry.class.isAssignableFrom(serviceEndpointInterface)) {
                CustomerAgreementInquiryBindingStub _stub = new CustomerAgreementInquiryBindingStub(new java.net.URL(CustomerAgreementInquiryPort0_address), this);
                _stub.setPortName(getCustomerAgreementInquiryPort0WSDDServiceName());
                return _stub;
            }
            if (CustomerAgreementInquiry.class.isAssignableFrom(serviceEndpointInterface)) {
                CustomerAgreementInquiryBindingStub _stub = new CustomerAgreementInquiryBindingStub(new java.net.URL(CustomerAgreementInquiryPort1_address), this);
                _stub.setPortName(getCustomerAgreementInquiryPort1WSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CustomerAgreementInquiryPort".equals(inputPortName)) {
            return getCustomerAgreementInquiryPort();
        }
        else if ("CustomerAgreementInquiryPort.0".equals(inputPortName)) {
            return getCustomerAgreementInquiryPort0();
        }
        else if ("CustomerAgreementInquiryPort.1".equals(inputPortName)) {
            return getCustomerAgreementInquiryPort1();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn://bancodebogota.com/customers/product/service/", "CustomerAgreementInquirySvc");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/product/service/", "CustomerAgreementInquiryPort"));
            ports.add(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/product/service/", "CustomerAgreementInquiryPort.0"));
            ports.add(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/product/service/", "CustomerAgreementInquiryPort.1"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CustomerAgreementInquiryPort".equals(portName)) {
            setCustomerAgreementInquiryPortEndpointAddress(address);
        }
        else 
if ("CustomerAgreementInquiryPort0".equals(portName)) {
            setCustomerAgreementInquiryPort0EndpointAddress(address);
        }
        else 
if ("CustomerAgreementInquiryPort1".equals(portName)) {
            setCustomerAgreementInquiryPort1EndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
