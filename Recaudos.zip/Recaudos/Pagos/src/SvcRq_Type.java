/**
 * SvcRq_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public class SvcRq_Type  implements java.io.Serializable {
    /* Identificador único del mensaje que entrega la aplicación. */
    private java.lang.String rqUID;

    /* Identificador de solicitud asincrónica, enviado por un cliente
     * para obtener una respuesta asíncrona 
     * 						generada por un servidor, por lo general, en el caso de que
     * la respuesta ha tomado demasiado tiempo 
     * 						para construir y ser capaz de ser enviados de manera sincrónica. */
    private java.lang.String asyncRqUID;

    /* Secuencia de transación del cliente para reversos. */
    private java.lang.String revClientTrnSeq;

    /* En este campo se parametriza la información del usuario que
     * autentica el servicio. */
    private CustId_Type custId;

    /* El proveedor del pago indica que éste debe realizarse normalmente
     * para el próximo día. */
    private Boolean_Type nextDay;

    /* En este campo se parametriza la información del ambiente que
     * origina la invocación. */
    private BaseEnvr_Type baseEnvr;

    /* Identificador de secuencia generado por la terminal del cliente
     * 
     * 						 en un ambiente de oficina/CallCenter/cajero. */
    private java.lang.String clientTerminalSeqId;

    /* Tipo de estado de la transacción. */
    private java.lang.String trnStatusType;

    /* En este campo se parametriza la información de la transacción
     * en la Red sobre el procesamiento de la red, 
     * 						es decir, propietario, ubicación, código de banco y el número
     * de referencia asignado por la red durante 
     * 						el procesamiento de la transacción. */
    private NetworkTrnInfo_Type networkTrnInfo;

    /* Tiempo de acuerdo con el cliente, se puede comparar con el
     * tiempo del servidor
     * 						para determinar si hay una discrepancia. */
    private java.lang.String clientDt;

    public SvcRq_Type() {
    }

    public SvcRq_Type(
           java.lang.String rqUID,
           java.lang.String asyncRqUID,
           java.lang.String revClientTrnSeq,
           CustId_Type custId,
           Boolean_Type nextDay,
           BaseEnvr_Type baseEnvr,
           java.lang.String clientTerminalSeqId,
           java.lang.String trnStatusType,
           NetworkTrnInfo_Type networkTrnInfo,
           java.lang.String clientDt) {
           this.rqUID = rqUID;
           this.asyncRqUID = asyncRqUID;
           this.revClientTrnSeq = revClientTrnSeq;
           this.custId = custId;
           this.nextDay = nextDay;
           this.baseEnvr = baseEnvr;
           this.clientTerminalSeqId = clientTerminalSeqId;
           this.trnStatusType = trnStatusType;
           this.networkTrnInfo = networkTrnInfo;
           this.clientDt = clientDt;
    }


    /**
     * Gets the rqUID value for this SvcRq_Type.
     * 
     * @return rqUID   * Identificador único del mensaje que entrega la aplicación.
     */
    public java.lang.String getRqUID() {
        return rqUID;
    }


    /**
     * Sets the rqUID value for this SvcRq_Type.
     * 
     * @param rqUID   * Identificador único del mensaje que entrega la aplicación.
     */
    public void setRqUID(java.lang.String rqUID) {
        this.rqUID = rqUID;
    }


    /**
     * Gets the asyncRqUID value for this SvcRq_Type.
     * 
     * @return asyncRqUID   * Identificador de solicitud asincrónica, enviado por un cliente
     * para obtener una respuesta asíncrona 
     * 						generada por un servidor, por lo general, en el caso de que
     * la respuesta ha tomado demasiado tiempo 
     * 						para construir y ser capaz de ser enviados de manera sincrónica.
     */
    public java.lang.String getAsyncRqUID() {
        return asyncRqUID;
    }


    /**
     * Sets the asyncRqUID value for this SvcRq_Type.
     * 
     * @param asyncRqUID   * Identificador de solicitud asincrónica, enviado por un cliente
     * para obtener una respuesta asíncrona 
     * 						generada por un servidor, por lo general, en el caso de que
     * la respuesta ha tomado demasiado tiempo 
     * 						para construir y ser capaz de ser enviados de manera sincrónica.
     */
    public void setAsyncRqUID(java.lang.String asyncRqUID) {
        this.asyncRqUID = asyncRqUID;
    }


    /**
     * Gets the revClientTrnSeq value for this SvcRq_Type.
     * 
     * @return revClientTrnSeq   * Secuencia de transación del cliente para reversos.
     */
    public java.lang.String getRevClientTrnSeq() {
        return revClientTrnSeq;
    }


    /**
     * Sets the revClientTrnSeq value for this SvcRq_Type.
     * 
     * @param revClientTrnSeq   * Secuencia de transación del cliente para reversos.
     */
    public void setRevClientTrnSeq(java.lang.String revClientTrnSeq) {
        this.revClientTrnSeq = revClientTrnSeq;
    }


    /**
     * Gets the custId value for this SvcRq_Type.
     * 
     * @return custId   * En este campo se parametriza la información del usuario que
     * autentica el servicio.
     */
    public CustId_Type getCustId() {
        return custId;
    }


    /**
     * Sets the custId value for this SvcRq_Type.
     * 
     * @param custId   * En este campo se parametriza la información del usuario que
     * autentica el servicio.
     */
    public void setCustId(CustId_Type custId) {
        this.custId = custId;
    }


    /**
     * Gets the nextDay value for this SvcRq_Type.
     * 
     * @return nextDay   * El proveedor del pago indica que éste debe realizarse normalmente
     * para el próximo día.
     */
    public Boolean_Type getNextDay() {
        return nextDay;
    }


    /**
     * Sets the nextDay value for this SvcRq_Type.
     * 
     * @param nextDay   * El proveedor del pago indica que éste debe realizarse normalmente
     * para el próximo día.
     */
    public void setNextDay(Boolean_Type nextDay) {
        this.nextDay = nextDay;
    }


    /**
     * Gets the baseEnvr value for this SvcRq_Type.
     * 
     * @return baseEnvr   * En este campo se parametriza la información del ambiente que
     * origina la invocación.
     */
    public BaseEnvr_Type getBaseEnvr() {
        return baseEnvr;
    }


    /**
     * Sets the baseEnvr value for this SvcRq_Type.
     * 
     * @param baseEnvr   * En este campo se parametriza la información del ambiente que
     * origina la invocación.
     */
    public void setBaseEnvr(BaseEnvr_Type baseEnvr) {
        this.baseEnvr = baseEnvr;
    }


    /**
     * Gets the clientTerminalSeqId value for this SvcRq_Type.
     * 
     * @return clientTerminalSeqId   * Identificador de secuencia generado por la terminal del cliente
     * 
     * 						 en un ambiente de oficina/CallCenter/cajero.
     */
    public java.lang.String getClientTerminalSeqId() {
        return clientTerminalSeqId;
    }


    /**
     * Sets the clientTerminalSeqId value for this SvcRq_Type.
     * 
     * @param clientTerminalSeqId   * Identificador de secuencia generado por la terminal del cliente
     * 
     * 						 en un ambiente de oficina/CallCenter/cajero.
     */
    public void setClientTerminalSeqId(java.lang.String clientTerminalSeqId) {
        this.clientTerminalSeqId = clientTerminalSeqId;
    }


    /**
     * Gets the trnStatusType value for this SvcRq_Type.
     * 
     * @return trnStatusType   * Tipo de estado de la transacción.
     */
    public java.lang.String getTrnStatusType() {
        return trnStatusType;
    }


    /**
     * Sets the trnStatusType value for this SvcRq_Type.
     * 
     * @param trnStatusType   * Tipo de estado de la transacción.
     */
    public void setTrnStatusType(java.lang.String trnStatusType) {
        this.trnStatusType = trnStatusType;
    }


    /**
     * Gets the networkTrnInfo value for this SvcRq_Type.
     * 
     * @return networkTrnInfo   * En este campo se parametriza la información de la transacción
     * en la Red sobre el procesamiento de la red, 
     * 						es decir, propietario, ubicación, código de banco y el número
     * de referencia asignado por la red durante 
     * 						el procesamiento de la transacción.
     */
    public NetworkTrnInfo_Type getNetworkTrnInfo() {
        return networkTrnInfo;
    }


    /**
     * Sets the networkTrnInfo value for this SvcRq_Type.
     * 
     * @param networkTrnInfo   * En este campo se parametriza la información de la transacción
     * en la Red sobre el procesamiento de la red, 
     * 						es decir, propietario, ubicación, código de banco y el número
     * de referencia asignado por la red durante 
     * 						el procesamiento de la transacción.
     */
    public void setNetworkTrnInfo(NetworkTrnInfo_Type networkTrnInfo) {
        this.networkTrnInfo = networkTrnInfo;
    }


    /**
     * Gets the clientDt value for this SvcRq_Type.
     * 
     * @return clientDt   * Tiempo de acuerdo con el cliente, se puede comparar con el
     * tiempo del servidor
     * 						para determinar si hay una discrepancia.
     */
    public java.lang.String getClientDt() {
        return clientDt;
    }


    /**
     * Sets the clientDt value for this SvcRq_Type.
     * 
     * @param clientDt   * Tiempo de acuerdo con el cliente, se puede comparar con el
     * tiempo del servidor
     * 						para determinar si hay una discrepancia.
     */
    public void setClientDt(java.lang.String clientDt) {
        this.clientDt = clientDt;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SvcRq_Type)) return false;
        SvcRq_Type other = (SvcRq_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.rqUID==null && other.getRqUID()==null) || 
             (this.rqUID!=null &&
              this.rqUID.equals(other.getRqUID()))) &&
            ((this.asyncRqUID==null && other.getAsyncRqUID()==null) || 
             (this.asyncRqUID!=null &&
              this.asyncRqUID.equals(other.getAsyncRqUID()))) &&
            ((this.revClientTrnSeq==null && other.getRevClientTrnSeq()==null) || 
             (this.revClientTrnSeq!=null &&
              this.revClientTrnSeq.equals(other.getRevClientTrnSeq()))) &&
            ((this.custId==null && other.getCustId()==null) || 
             (this.custId!=null &&
              this.custId.equals(other.getCustId()))) &&
            ((this.nextDay==null && other.getNextDay()==null) || 
             (this.nextDay!=null &&
              this.nextDay.equals(other.getNextDay()))) &&
            ((this.baseEnvr==null && other.getBaseEnvr()==null) || 
             (this.baseEnvr!=null &&
              this.baseEnvr.equals(other.getBaseEnvr()))) &&
            ((this.clientTerminalSeqId==null && other.getClientTerminalSeqId()==null) || 
             (this.clientTerminalSeqId!=null &&
              this.clientTerminalSeqId.equals(other.getClientTerminalSeqId()))) &&
            ((this.trnStatusType==null && other.getTrnStatusType()==null) || 
             (this.trnStatusType!=null &&
              this.trnStatusType.equals(other.getTrnStatusType()))) &&
            ((this.networkTrnInfo==null && other.getNetworkTrnInfo()==null) || 
             (this.networkTrnInfo!=null &&
              this.networkTrnInfo.equals(other.getNetworkTrnInfo()))) &&
            ((this.clientDt==null && other.getClientDt()==null) || 
             (this.clientDt!=null &&
              this.clientDt.equals(other.getClientDt())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getRqUID() != null) {
            _hashCode += getRqUID().hashCode();
        }
        if (getAsyncRqUID() != null) {
            _hashCode += getAsyncRqUID().hashCode();
        }
        if (getRevClientTrnSeq() != null) {
            _hashCode += getRevClientTrnSeq().hashCode();
        }
        if (getCustId() != null) {
            _hashCode += getCustId().hashCode();
        }
        if (getNextDay() != null) {
            _hashCode += getNextDay().hashCode();
        }
        if (getBaseEnvr() != null) {
            _hashCode += getBaseEnvr().hashCode();
        }
        if (getClientTerminalSeqId() != null) {
            _hashCode += getClientTerminalSeqId().hashCode();
        }
        if (getTrnStatusType() != null) {
            _hashCode += getTrnStatusType().hashCode();
        }
        if (getNetworkTrnInfo() != null) {
            _hashCode += getNetworkTrnInfo().hashCode();
        }
        if (getClientDt() != null) {
            _hashCode += getClientDt().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SvcRq_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "SvcRq_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rqUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "RqUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "UUID_Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("asyncRqUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AsyncRqUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "UUID_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("revClientTrnSeq");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "RevClientTrnSeq"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Identifier_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("custId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustId_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nextDay");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "NextDay"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Boolean_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("baseEnvr");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BaseEnvr"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BaseEnvr_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientTerminalSeqId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "ClientTerminalSeqId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Identifier_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trnStatusType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TrnStatusType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "OpenEnum_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("networkTrnInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "NetworkTrnInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "NetworkTrnInfo_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientDt");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "ClientDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "DateTime_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
