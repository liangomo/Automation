/**
 * Status_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */


/**
 * En este campo se parametriza la información del estado de la respuesta
 * de la transacción.
 */
public class Status_Type  implements java.io.Serializable {
    /* En este campo estan paramentrizados todos los posibles estados
     * en 
     * 	    				los cuales se puede encontrar una cuenta perteneciente a
     * la entidad. */
    private java.lang.String statusCode;

    /* En este campo se parametriza el código de estado del servidor,
     * 	    				Si el valor es mayor a 0; la consulta fue exitosa. 
     * 	    				Si el valor es igual a 0 la consulta no retornó datos pero
     * la comunicación fue exitosa. */
    private java.lang.String serverStatusCode;

    /* En este campo se parametriza la severidad de la transacción. */
    private java.lang.String severity;

    /* En este campo se parametriza la descripción del estado. */
    private java.lang.String statusDesc;

    /* En este campo se parametriza la descripción estado del servidor. */
    private java.lang.String serverStatusDesc;

    /* En este campo se parametriza el estado adicional, el "StatusCode"
     * debe contener
     * 						el código de respuesta primario, si el número de cuenta, fecha
     * son inválidos el 
     * 						"StatusCode" podría contener uno de los dos errores y éste agregado
     * puede 
     * 						contener el otro. */
    private AdditionalStatus_Type[] additionalStatus;

    /* En este campo se parametriza la información de respuesta asíncrona. */
    private AsyncRsInfo_Type asyncRsInfo;

    public Status_Type() {
    }

    public Status_Type(
           java.lang.String statusCode,
           java.lang.String serverStatusCode,
           java.lang.String severity,
           java.lang.String statusDesc,
           java.lang.String serverStatusDesc,
           AdditionalStatus_Type[] additionalStatus,
           AsyncRsInfo_Type asyncRsInfo) {
           this.statusCode = statusCode;
           this.serverStatusCode = serverStatusCode;
           this.severity = severity;
           this.statusDesc = statusDesc;
           this.serverStatusDesc = serverStatusDesc;
           this.additionalStatus = additionalStatus;
           this.asyncRsInfo = asyncRsInfo;
    }


    /**
     * Gets the statusCode value for this Status_Type.
     * 
     * @return statusCode   * En este campo estan paramentrizados todos los posibles estados
     * en 
     * 	    				los cuales se puede encontrar una cuenta perteneciente a
     * la entidad.
     */
    public java.lang.String getStatusCode() {
        return statusCode;
    }


    /**
     * Sets the statusCode value for this Status_Type.
     * 
     * @param statusCode   * En este campo estan paramentrizados todos los posibles estados
     * en 
     * 	    				los cuales se puede encontrar una cuenta perteneciente a
     * la entidad.
     */
    public void setStatusCode(java.lang.String statusCode) {
        this.statusCode = statusCode;
    }


    /**
     * Gets the serverStatusCode value for this Status_Type.
     * 
     * @return serverStatusCode   * En este campo se parametriza el código de estado del servidor,
     * 	    				Si el valor es mayor a 0; la consulta fue exitosa. 
     * 	    				Si el valor es igual a 0 la consulta no retornó datos pero
     * la comunicación fue exitosa.
     */
    public java.lang.String getServerStatusCode() {
        return serverStatusCode;
    }


    /**
     * Sets the serverStatusCode value for this Status_Type.
     * 
     * @param serverStatusCode   * En este campo se parametriza el código de estado del servidor,
     * 	    				Si el valor es mayor a 0; la consulta fue exitosa. 
     * 	    				Si el valor es igual a 0 la consulta no retornó datos pero
     * la comunicación fue exitosa.
     */
    public void setServerStatusCode(java.lang.String serverStatusCode) {
        this.serverStatusCode = serverStatusCode;
    }


    /**
     * Gets the severity value for this Status_Type.
     * 
     * @return severity   * En este campo se parametriza la severidad de la transacción.
     */
    public java.lang.String getSeverity() {
        return severity;
    }


    /**
     * Sets the severity value for this Status_Type.
     * 
     * @param severity   * En este campo se parametriza la severidad de la transacción.
     */
    public void setSeverity(java.lang.String severity) {
        this.severity = severity;
    }


    /**
     * Gets the statusDesc value for this Status_Type.
     * 
     * @return statusDesc   * En este campo se parametriza la descripción del estado.
     */
    public java.lang.String getStatusDesc() {
        return statusDesc;
    }


    /**
     * Sets the statusDesc value for this Status_Type.
     * 
     * @param statusDesc   * En este campo se parametriza la descripción del estado.
     */
    public void setStatusDesc(java.lang.String statusDesc) {
        this.statusDesc = statusDesc;
    }


    /**
     * Gets the serverStatusDesc value for this Status_Type.
     * 
     * @return serverStatusDesc   * En este campo se parametriza la descripción estado del servidor.
     */
    public java.lang.String getServerStatusDesc() {
        return serverStatusDesc;
    }


    /**
     * Sets the serverStatusDesc value for this Status_Type.
     * 
     * @param serverStatusDesc   * En este campo se parametriza la descripción estado del servidor.
     */
    public void setServerStatusDesc(java.lang.String serverStatusDesc) {
        this.serverStatusDesc = serverStatusDesc;
    }


    /**
     * Gets the additionalStatus value for this Status_Type.
     * 
     * @return additionalStatus   * En este campo se parametriza el estado adicional, el "StatusCode"
     * debe contener
     * 						el código de respuesta primario, si el número de cuenta, fecha
     * son inválidos el 
     * 						"StatusCode" podría contener uno de los dos errores y éste agregado
     * puede 
     * 						contener el otro.
     */
    public AdditionalStatus_Type[] getAdditionalStatus() {
        return additionalStatus;
    }


    /**
     * Sets the additionalStatus value for this Status_Type.
     * 
     * @param additionalStatus   * En este campo se parametriza el estado adicional, el "StatusCode"
     * debe contener
     * 						el código de respuesta primario, si el número de cuenta, fecha
     * son inválidos el 
     * 						"StatusCode" podría contener uno de los dos errores y éste agregado
     * puede 
     * 						contener el otro.
     */
    public void setAdditionalStatus(AdditionalStatus_Type[] additionalStatus) {
        this.additionalStatus = additionalStatus;
    }

    public AdditionalStatus_Type getAdditionalStatus(int i) {
        return this.additionalStatus[i];
    }

    public void setAdditionalStatus(int i, AdditionalStatus_Type _value) {
        this.additionalStatus[i] = _value;
    }


    /**
     * Gets the asyncRsInfo value for this Status_Type.
     * 
     * @return asyncRsInfo   * En este campo se parametriza la información de respuesta asíncrona.
     */
    public AsyncRsInfo_Type getAsyncRsInfo() {
        return asyncRsInfo;
    }


    /**
     * Sets the asyncRsInfo value for this Status_Type.
     * 
     * @param asyncRsInfo   * En este campo se parametriza la información de respuesta asíncrona.
     */
    public void setAsyncRsInfo(AsyncRsInfo_Type asyncRsInfo) {
        this.asyncRsInfo = asyncRsInfo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Status_Type)) return false;
        Status_Type other = (Status_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.statusCode==null && other.getStatusCode()==null) || 
             (this.statusCode!=null &&
              this.statusCode.equals(other.getStatusCode()))) &&
            ((this.serverStatusCode==null && other.getServerStatusCode()==null) || 
             (this.serverStatusCode!=null &&
              this.serverStatusCode.equals(other.getServerStatusCode()))) &&
            ((this.severity==null && other.getSeverity()==null) || 
             (this.severity!=null &&
              this.severity.equals(other.getSeverity()))) &&
            ((this.statusDesc==null && other.getStatusDesc()==null) || 
             (this.statusDesc!=null &&
              this.statusDesc.equals(other.getStatusDesc()))) &&
            ((this.serverStatusDesc==null && other.getServerStatusDesc()==null) || 
             (this.serverStatusDesc!=null &&
              this.serverStatusDesc.equals(other.getServerStatusDesc()))) &&
            ((this.additionalStatus==null && other.getAdditionalStatus()==null) || 
             (this.additionalStatus!=null &&
              java.util.Arrays.equals(this.additionalStatus, other.getAdditionalStatus()))) &&
            ((this.asyncRsInfo==null && other.getAsyncRsInfo()==null) || 
             (this.asyncRsInfo!=null &&
              this.asyncRsInfo.equals(other.getAsyncRsInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStatusCode() != null) {
            _hashCode += getStatusCode().hashCode();
        }
        if (getServerStatusCode() != null) {
            _hashCode += getServerStatusCode().hashCode();
        }
        if (getSeverity() != null) {
            _hashCode += getSeverity().hashCode();
        }
        if (getStatusDesc() != null) {
            _hashCode += getStatusDesc().hashCode();
        }
        if (getServerStatusDesc() != null) {
            _hashCode += getServerStatusDesc().hashCode();
        }
        if (getAdditionalStatus() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAdditionalStatus());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAdditionalStatus(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAsyncRsInfo() != null) {
            _hashCode += getAsyncRsInfo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Status_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Status_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "StatusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "StatusCode_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverStatusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "ServerStatusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "ServerStatusCode_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("severity");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Severity"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Severity_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusDesc");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "StatusDesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "StatusDesc_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverStatusDesc");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "ServerStatusDesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "StatusDesc_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additionalStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AdditionalStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AdditionalStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("asyncRsInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AsyncRsInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AsyncRsInfo_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
