/**
 * SvcRs_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */


/**
 * Define los campos obligatorios y opcionales de cualquier mensaje
 * de 
 * 				respuesta enviado por un servicio con adopción	del estandar IFX.
 */
public class SvcRs_Type  implements java.io.Serializable {
    /* Identificador único del mensaje que entrega la aplicación consumidora. */
    private java.lang.String rqUID;

    /* Identificador de solicitud asincrónica, enviado por un cliente
     * para obtener una respuesta asíncrona 
     * 						generada por un servidor, por lo general, en el caso de que
     * la respuesta ha tomado demasiado tiempo 
     * 						para construir y ser capaz de ser enviados de manera sincrónica. */
    private java.lang.String asyncRqUID;

    /* Secuencia de transación del cliente para reversos. */
    private java.lang.String revClientTrnSeq;

    /* En este campo se parametriza la información del estado de la
     * respuesta de la transacción. */
    private Status_Type status;

    /* En este campo se parametriza la información del usuario que
     * autentica el servicio. */
    private CustId_Type custId;

    /* El proveedor del pago indica que éste debe realizarse normalmente
     * para el próximo día. */
    private Boolean_Type nextDay;

    /* Identifiador secuencia termianl generado por el servidor (CSP)
     * en un ambiente ATM o POS. */
    private java.lang.String serverTerminalSeqId;

    /* En este campo se parametriza la información de la transacción
     * en la Red sobre el procesamiento de la red, 
     * 						es decir, propietario, ubicación, código de banco y el número
     * de referencia asignado por la red durante 
     * 						el procesamiento de la transacción. */
    private NetworkTrnInfo_Type networkTrnInfo;

    /* Fecha del servidor. */
    private java.lang.String serverDt;

    public SvcRs_Type() {
    }

    public SvcRs_Type(
           java.lang.String rqUID,
           java.lang.String asyncRqUID,
           java.lang.String revClientTrnSeq,
           Status_Type status,
           CustId_Type custId,
           Boolean_Type nextDay,
           java.lang.String serverTerminalSeqId,
           NetworkTrnInfo_Type networkTrnInfo,
           java.lang.String serverDt) {
           this.rqUID = rqUID;
           this.asyncRqUID = asyncRqUID;
           this.revClientTrnSeq = revClientTrnSeq;
           this.status = status;
           this.custId = custId;
           this.nextDay = nextDay;
           this.serverTerminalSeqId = serverTerminalSeqId;
           this.networkTrnInfo = networkTrnInfo;
           this.serverDt = serverDt;
    }


    /**
     * Gets the rqUID value for this SvcRs_Type.
     * 
     * @return rqUID   * Identificador único del mensaje que entrega la aplicación consumidora.
     */
    public java.lang.String getRqUID() {
        return rqUID;
    }


    /**
     * Sets the rqUID value for this SvcRs_Type.
     * 
     * @param rqUID   * Identificador único del mensaje que entrega la aplicación consumidora.
     */
    public void setRqUID(java.lang.String rqUID) {
        this.rqUID = rqUID;
    }


    /**
     * Gets the asyncRqUID value for this SvcRs_Type.
     * 
     * @return asyncRqUID   * Identificador de solicitud asincrónica, enviado por un cliente
     * para obtener una respuesta asíncrona 
     * 						generada por un servidor, por lo general, en el caso de que
     * la respuesta ha tomado demasiado tiempo 
     * 						para construir y ser capaz de ser enviados de manera sincrónica.
     */
    public java.lang.String getAsyncRqUID() {
        return asyncRqUID;
    }


    /**
     * Sets the asyncRqUID value for this SvcRs_Type.
     * 
     * @param asyncRqUID   * Identificador de solicitud asincrónica, enviado por un cliente
     * para obtener una respuesta asíncrona 
     * 						generada por un servidor, por lo general, en el caso de que
     * la respuesta ha tomado demasiado tiempo 
     * 						para construir y ser capaz de ser enviados de manera sincrónica.
     */
    public void setAsyncRqUID(java.lang.String asyncRqUID) {
        this.asyncRqUID = asyncRqUID;
    }


    /**
     * Gets the revClientTrnSeq value for this SvcRs_Type.
     * 
     * @return revClientTrnSeq   * Secuencia de transación del cliente para reversos.
     */
    public java.lang.String getRevClientTrnSeq() {
        return revClientTrnSeq;
    }


    /**
     * Sets the revClientTrnSeq value for this SvcRs_Type.
     * 
     * @param revClientTrnSeq   * Secuencia de transación del cliente para reversos.
     */
    public void setRevClientTrnSeq(java.lang.String revClientTrnSeq) {
        this.revClientTrnSeq = revClientTrnSeq;
    }


    /**
     * Gets the status value for this SvcRs_Type.
     * 
     * @return status   * En este campo se parametriza la información del estado de la
     * respuesta de la transacción.
     */
    public Status_Type getStatus() {
        return status;
    }


    /**
     * Sets the status value for this SvcRs_Type.
     * 
     * @param status   * En este campo se parametriza la información del estado de la
     * respuesta de la transacción.
     */
    public void setStatus(Status_Type status) {
        this.status = status;
    }


    /**
     * Gets the custId value for this SvcRs_Type.
     * 
     * @return custId   * En este campo se parametriza la información del usuario que
     * autentica el servicio.
     */
    public CustId_Type getCustId() {
        return custId;
    }


    /**
     * Sets the custId value for this SvcRs_Type.
     * 
     * @param custId   * En este campo se parametriza la información del usuario que
     * autentica el servicio.
     */
    public void setCustId(CustId_Type custId) {
        this.custId = custId;
    }


    /**
     * Gets the nextDay value for this SvcRs_Type.
     * 
     * @return nextDay   * El proveedor del pago indica que éste debe realizarse normalmente
     * para el próximo día.
     */
    public Boolean_Type getNextDay() {
        return nextDay;
    }


    /**
     * Sets the nextDay value for this SvcRs_Type.
     * 
     * @param nextDay   * El proveedor del pago indica que éste debe realizarse normalmente
     * para el próximo día.
     */
    public void setNextDay(Boolean_Type nextDay) {
        this.nextDay = nextDay;
    }


    /**
     * Gets the serverTerminalSeqId value for this SvcRs_Type.
     * 
     * @return serverTerminalSeqId   * Identifiador secuencia termianl generado por el servidor (CSP)
     * en un ambiente ATM o POS.
     */
    public java.lang.String getServerTerminalSeqId() {
        return serverTerminalSeqId;
    }


    /**
     * Sets the serverTerminalSeqId value for this SvcRs_Type.
     * 
     * @param serverTerminalSeqId   * Identifiador secuencia termianl generado por el servidor (CSP)
     * en un ambiente ATM o POS.
     */
    public void setServerTerminalSeqId(java.lang.String serverTerminalSeqId) {
        this.serverTerminalSeqId = serverTerminalSeqId;
    }


    /**
     * Gets the networkTrnInfo value for this SvcRs_Type.
     * 
     * @return networkTrnInfo   * En este campo se parametriza la información de la transacción
     * en la Red sobre el procesamiento de la red, 
     * 						es decir, propietario, ubicación, código de banco y el número
     * de referencia asignado por la red durante 
     * 						el procesamiento de la transacción.
     */
    public NetworkTrnInfo_Type getNetworkTrnInfo() {
        return networkTrnInfo;
    }


    /**
     * Sets the networkTrnInfo value for this SvcRs_Type.
     * 
     * @param networkTrnInfo   * En este campo se parametriza la información de la transacción
     * en la Red sobre el procesamiento de la red, 
     * 						es decir, propietario, ubicación, código de banco y el número
     * de referencia asignado por la red durante 
     * 						el procesamiento de la transacción.
     */
    public void setNetworkTrnInfo(NetworkTrnInfo_Type networkTrnInfo) {
        this.networkTrnInfo = networkTrnInfo;
    }


    /**
     * Gets the serverDt value for this SvcRs_Type.
     * 
     * @return serverDt   * Fecha del servidor.
     */
    public java.lang.String getServerDt() {
        return serverDt;
    }


    /**
     * Sets the serverDt value for this SvcRs_Type.
     * 
     * @param serverDt   * Fecha del servidor.
     */
    public void setServerDt(java.lang.String serverDt) {
        this.serverDt = serverDt;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SvcRs_Type)) return false;
        SvcRs_Type other = (SvcRs_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.rqUID==null && other.getRqUID()==null) || 
             (this.rqUID!=null &&
              this.rqUID.equals(other.getRqUID()))) &&
            ((this.asyncRqUID==null && other.getAsyncRqUID()==null) || 
             (this.asyncRqUID!=null &&
              this.asyncRqUID.equals(other.getAsyncRqUID()))) &&
            ((this.revClientTrnSeq==null && other.getRevClientTrnSeq()==null) || 
             (this.revClientTrnSeq!=null &&
              this.revClientTrnSeq.equals(other.getRevClientTrnSeq()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.custId==null && other.getCustId()==null) || 
             (this.custId!=null &&
              this.custId.equals(other.getCustId()))) &&
            ((this.nextDay==null && other.getNextDay()==null) || 
             (this.nextDay!=null &&
              this.nextDay.equals(other.getNextDay()))) &&
            ((this.serverTerminalSeqId==null && other.getServerTerminalSeqId()==null) || 
             (this.serverTerminalSeqId!=null &&
              this.serverTerminalSeqId.equals(other.getServerTerminalSeqId()))) &&
            ((this.networkTrnInfo==null && other.getNetworkTrnInfo()==null) || 
             (this.networkTrnInfo!=null &&
              this.networkTrnInfo.equals(other.getNetworkTrnInfo()))) &&
            ((this.serverDt==null && other.getServerDt()==null) || 
             (this.serverDt!=null &&
              this.serverDt.equals(other.getServerDt())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getRqUID() != null) {
            _hashCode += getRqUID().hashCode();
        }
        if (getAsyncRqUID() != null) {
            _hashCode += getAsyncRqUID().hashCode();
        }
        if (getRevClientTrnSeq() != null) {
            _hashCode += getRevClientTrnSeq().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getCustId() != null) {
            _hashCode += getCustId().hashCode();
        }
        if (getNextDay() != null) {
            _hashCode += getNextDay().hashCode();
        }
        if (getServerTerminalSeqId() != null) {
            _hashCode += getServerTerminalSeqId().hashCode();
        }
        if (getNetworkTrnInfo() != null) {
            _hashCode += getNetworkTrnInfo().hashCode();
        }
        if (getServerDt() != null) {
            _hashCode += getServerDt().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SvcRs_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "SvcRs_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rqUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "RqUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "UUID_Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("asyncRqUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "AsyncRqUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "UUID_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("revClientTrnSeq");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "RevClientTrnSeq"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Identifier_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Status_Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("custId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustId_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nextDay");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "NextDay"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Boolean_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverTerminalSeqId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "ServerTerminalSeqId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Identifier_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("networkTrnInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "NetworkTrnInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "NetworkTrnInfo_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverDt");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "ServerDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "DateTime_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
