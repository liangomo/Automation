/**
 * BaseEnvr_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public class BaseEnvr_Type  implements java.io.Serializable {
    /* En este campo se parametriza la descripción del ambiente origen. */
    private java.lang.String desc;

    /* En este campo se parametriza el código único que identifica
     * al ambiente origen. */
    private java.lang.String name;

    /* En este campo se parametriza la fecha y hora del ambiente. */
    private java.lang.String clientBusinessDt;

    public BaseEnvr_Type() {
    }

    public BaseEnvr_Type(
           java.lang.String desc,
           java.lang.String name,
           java.lang.String clientBusinessDt) {
           this.desc = desc;
           this.name = name;
           this.clientBusinessDt = clientBusinessDt;
    }


    /**
     * Gets the desc value for this BaseEnvr_Type.
     * 
     * @return desc   * En este campo se parametriza la descripción del ambiente origen.
     */
    public java.lang.String getDesc() {
        return desc;
    }


    /**
     * Sets the desc value for this BaseEnvr_Type.
     * 
     * @param desc   * En este campo se parametriza la descripción del ambiente origen.
     */
    public void setDesc(java.lang.String desc) {
        this.desc = desc;
    }


    /**
     * Gets the name value for this BaseEnvr_Type.
     * 
     * @return name   * En este campo se parametriza el código único que identifica
     * al ambiente origen.
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this BaseEnvr_Type.
     * 
     * @param name   * En este campo se parametriza el código único que identifica
     * al ambiente origen.
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the clientBusinessDt value for this BaseEnvr_Type.
     * 
     * @return clientBusinessDt   * En este campo se parametriza la fecha y hora del ambiente.
     */
    public java.lang.String getClientBusinessDt() {
        return clientBusinessDt;
    }


    /**
     * Sets the clientBusinessDt value for this BaseEnvr_Type.
     * 
     * @param clientBusinessDt   * En este campo se parametriza la fecha y hora del ambiente.
     */
    public void setClientBusinessDt(java.lang.String clientBusinessDt) {
        this.clientBusinessDt = clientBusinessDt;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BaseEnvr_Type)) return false;
        BaseEnvr_Type other = (BaseEnvr_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.desc==null && other.getDesc()==null) || 
             (this.desc!=null &&
              this.desc.equals(other.getDesc()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.clientBusinessDt==null && other.getClientBusinessDt()==null) || 
             (this.clientBusinessDt!=null &&
              this.clientBusinessDt.equals(other.getClientBusinessDt())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDesc() != null) {
            _hashCode += getDesc().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getClientBusinessDt() != null) {
            _hashCode += getClientBusinessDt().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BaseEnvr_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BaseEnvr_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desc");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Desc"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Desc_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Name_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientBusinessDt");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "ClientBusinessDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "DateTime_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
