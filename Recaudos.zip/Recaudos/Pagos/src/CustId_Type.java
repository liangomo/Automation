/**
 * CustId_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public class CustId_Type  implements java.io.Serializable {
    /* En este campo se parametriza el nombre del proveedor de servicio. */
    private java.lang.String SPName;

    /* En este campo se parametriza ID permanente del cliente, usado
     * como una 
     * 	    					llave de base de datos para identificar de forma única un
     * intercambio
     * 	    					financiero o cliente CSP. No puede ser modificado por el
     * cliente. */
    private java.lang.String custPermId;

    /* En este campo se parametriza el ID inicio sesión del cliente.
     * 							Usuario STA Campo de tres partes, el tercero  muestra el ID
     * 
     * 							del usuario que realizó la modificación. */
    private java.lang.String custLoginId;

    /* En este campo se parametriza el tipo de cliente. */
    private java.lang.String custType;

    public CustId_Type() {
    }

    public CustId_Type(
           java.lang.String SPName,
           java.lang.String custPermId,
           java.lang.String custLoginId,
           java.lang.String custType) {
           this.SPName = SPName;
           this.custPermId = custPermId;
           this.custLoginId = custLoginId;
           this.custType = custType;
    }


    /**
     * Gets the SPName value for this CustId_Type.
     * 
     * @return SPName   * En este campo se parametriza el nombre del proveedor de servicio.
     */
    public java.lang.String getSPName() {
        return SPName;
    }


    /**
     * Sets the SPName value for this CustId_Type.
     * 
     * @param SPName   * En este campo se parametriza el nombre del proveedor de servicio.
     */
    public void setSPName(java.lang.String SPName) {
        this.SPName = SPName;
    }


    /**
     * Gets the custPermId value for this CustId_Type.
     * 
     * @return custPermId   * En este campo se parametriza ID permanente del cliente, usado
     * como una 
     * 	    					llave de base de datos para identificar de forma única un
     * intercambio
     * 	    					financiero o cliente CSP. No puede ser modificado por el
     * cliente.
     */
    public java.lang.String getCustPermId() {
        return custPermId;
    }


    /**
     * Sets the custPermId value for this CustId_Type.
     * 
     * @param custPermId   * En este campo se parametriza ID permanente del cliente, usado
     * como una 
     * 	    					llave de base de datos para identificar de forma única un
     * intercambio
     * 	    					financiero o cliente CSP. No puede ser modificado por el
     * cliente.
     */
    public void setCustPermId(java.lang.String custPermId) {
        this.custPermId = custPermId;
    }


    /**
     * Gets the custLoginId value for this CustId_Type.
     * 
     * @return custLoginId   * En este campo se parametriza el ID inicio sesión del cliente.
     * 							Usuario STA Campo de tres partes, el tercero  muestra el ID
     * 
     * 							del usuario que realizó la modificación.
     */
    public java.lang.String getCustLoginId() {
        return custLoginId;
    }


    /**
     * Sets the custLoginId value for this CustId_Type.
     * 
     * @param custLoginId   * En este campo se parametriza el ID inicio sesión del cliente.
     * 							Usuario STA Campo de tres partes, el tercero  muestra el ID
     * 
     * 							del usuario que realizó la modificación.
     */
    public void setCustLoginId(java.lang.String custLoginId) {
        this.custLoginId = custLoginId;
    }


    /**
     * Gets the custType value for this CustId_Type.
     * 
     * @return custType   * En este campo se parametriza el tipo de cliente.
     */
    public java.lang.String getCustType() {
        return custType;
    }


    /**
     * Sets the custType value for this CustId_Type.
     * 
     * @param custType   * En este campo se parametriza el tipo de cliente.
     */
    public void setCustType(java.lang.String custType) {
        this.custType = custType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CustId_Type)) return false;
        CustId_Type other = (CustId_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.SPName==null && other.getSPName()==null) || 
             (this.SPName!=null &&
              this.SPName.equals(other.getSPName()))) &&
            ((this.custPermId==null && other.getCustPermId()==null) || 
             (this.custPermId!=null &&
              this.custPermId.equals(other.getCustPermId()))) &&
            ((this.custLoginId==null && other.getCustLoginId()==null) || 
             (this.custLoginId!=null &&
              this.custLoginId.equals(other.getCustLoginId()))) &&
            ((this.custType==null && other.getCustType()==null) || 
             (this.custType!=null &&
              this.custType.equals(other.getCustType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSPName() != null) {
            _hashCode += getSPName().hashCode();
        }
        if (getCustPermId() != null) {
            _hashCode += getCustPermId().hashCode();
        }
        if (getCustLoginId() != null) {
            _hashCode += getCustLoginId().hashCode();
        }
        if (getCustType() != null) {
            _hashCode += getCustType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CustId_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustId_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SPName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "SPName"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Identifier_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("custPermId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustPermId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustPermId_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("custLoginId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustLoginId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustLoginId_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("custType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "OpenEnum_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
