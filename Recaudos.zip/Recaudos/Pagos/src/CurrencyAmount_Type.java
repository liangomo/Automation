/**
 * CurrencyAmount_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */


/**
 * Tipo de dato que se utilizará para todos los datos de tipo valores
 * monetarios.
 */
public class CurrencyAmount_Type  implements java.io.Serializable {
    private java.math.BigDecimal amt;

    private java.lang.String curCode;

    private java.math.BigDecimal curRate;

    private java.lang.String curConvertRule;

    public CurrencyAmount_Type() {
    }

    public CurrencyAmount_Type(
           java.math.BigDecimal amt,
           java.lang.String curCode,
           java.math.BigDecimal curRate,
           java.lang.String curConvertRule) {
           this.amt = amt;
           this.curCode = curCode;
           this.curRate = curRate;
           this.curConvertRule = curConvertRule;
    }


    /**
     * Gets the amt value for this CurrencyAmount_Type.
     * 
     * @return amt
     */
    public java.math.BigDecimal getAmt() {
        return amt;
    }


    /**
     * Sets the amt value for this CurrencyAmount_Type.
     * 
     * @param amt
     */
    public void setAmt(java.math.BigDecimal amt) {
        this.amt = amt;
    }


    /**
     * Gets the curCode value for this CurrencyAmount_Type.
     * 
     * @return curCode
     */
    public java.lang.String getCurCode() {
        return curCode;
    }


    /**
     * Sets the curCode value for this CurrencyAmount_Type.
     * 
     * @param curCode
     */
    public void setCurCode(java.lang.String curCode) {
        this.curCode = curCode;
    }


    /**
     * Gets the curRate value for this CurrencyAmount_Type.
     * 
     * @return curRate
     */
    public java.math.BigDecimal getCurRate() {
        return curRate;
    }


    /**
     * Sets the curRate value for this CurrencyAmount_Type.
     * 
     * @param curRate
     */
    public void setCurRate(java.math.BigDecimal curRate) {
        this.curRate = curRate;
    }


    /**
     * Gets the curConvertRule value for this CurrencyAmount_Type.
     * 
     * @return curConvertRule
     */
    public java.lang.String getCurConvertRule() {
        return curConvertRule;
    }


    /**
     * Sets the curConvertRule value for this CurrencyAmount_Type.
     * 
     * @param curConvertRule
     */
    public void setCurConvertRule(java.lang.String curConvertRule) {
        this.curConvertRule = curConvertRule;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CurrencyAmount_Type)) return false;
        CurrencyAmount_Type other = (CurrencyAmount_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.amt==null && other.getAmt()==null) || 
             (this.amt!=null &&
              this.amt.equals(other.getAmt()))) &&
            ((this.curCode==null && other.getCurCode()==null) || 
             (this.curCode!=null &&
              this.curCode.equals(other.getCurCode()))) &&
            ((this.curRate==null && other.getCurRate()==null) || 
             (this.curRate!=null &&
              this.curRate.equals(other.getCurRate()))) &&
            ((this.curConvertRule==null && other.getCurConvertRule()==null) || 
             (this.curConvertRule!=null &&
              this.curConvertRule.equals(other.getCurConvertRule())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAmt() != null) {
            _hashCode += getAmt().hashCode();
        }
        if (getCurCode() != null) {
            _hashCode += getCurCode().hashCode();
        }
        if (getCurRate() != null) {
            _hashCode += getCurRate().hashCode();
        }
        if (getCurConvertRule() != null) {
            _hashCode += getCurConvertRule().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CurrencyAmount_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CurrencyAmount_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amt");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Amt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("curCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CurCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("curRate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CurRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("curConvertRule");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CurConvertRule"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
