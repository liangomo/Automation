
public class CustomerAgreementInquiryProxy implements .CustomerAgreementInquiry {
  private String _endpoint = null;
  private .CustomerAgreementInquiry customerAgreementInquiry = null;
  
  public CustomerAgreementInquiryProxy() {
    _initCustomerAgreementInquiryProxy();
  }
  
  public CustomerAgreementInquiryProxy(String endpoint) {
    _endpoint = endpoint;
    _initCustomerAgreementInquiryProxy();
  }
  
  private void _initCustomerAgreementInquiryProxy() {
    try {
      customerAgreementInquiry = (new .CustomerAgreementInquirySvcLocator()).getCustomerAgreementInquiryPort();
      if (customerAgreementInquiry != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)customerAgreementInquiry)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)customerAgreementInquiry)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (customerAgreementInquiry != null)
      ((javax.xml.rpc.Stub)customerAgreementInquiry)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public .CustomerAgreementInquiry getCustomerAgreementInquiry() {
    if (customerAgreementInquiry == null)
      _initCustomerAgreementInquiryProxy();
    return customerAgreementInquiry;
  }
  
  public GetCustomerAgreementResponse getCustomerAgreement(GetCustomerAgreementRequest customerAgreementInqRq) throws java.rmi.RemoteException{
    if (customerAgreementInquiry == null)
      _initCustomerAgreementInquiryProxy();
    return customerAgreementInquiry.getCustomerAgreement(customerAgreementInqRq);
  }
  
  
}