
package cliente;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bancodebogota.customers.customercollect.event.CustomerCollectAddRsType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/customercollect/event/}CustomerCollectAddRs"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "customerCollectAddRs"
})
@XmlRootElement(name = "setCustomerCollectResponse")
public class SetCustomerCollectResponse {

    @XmlElement(name = "CustomerCollectAddRs", namespace = "urn://bancodebogota.com/customers/customercollect/event/", required = true)
    protected CustomerCollectAddRsType customerCollectAddRs;

    /**
     * Obtiene el valor de la propiedad customerCollectAddRs.
     * 
     * @return
     *     possible object is
     *     {@link CustomerCollectAddRsType }
     *     
     */
    public CustomerCollectAddRsType getCustomerCollectAddRs() {
        return customerCollectAddRs;
    }

    /**
     * Define el valor de la propiedad customerCollectAddRs.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerCollectAddRsType }
     *     
     */
    public void setCustomerCollectAddRs(CustomerCollectAddRsType value) {
        this.customerCollectAddRs = value;
    }

}
