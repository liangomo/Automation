
package cliente;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bancodebogota.customers.customercollect.event.CustomerCollectAddRqType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/customercollect/event/}CustomerCollectAddRq"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "customerCollectAddRq"
})
@XmlRootElement(name = "setCustomerCollectRequest")
public class SetCustomerCollectRequest {

    @XmlElement(name = "CustomerCollectAddRq", namespace = "urn://bancodebogota.com/customers/customercollect/event/", required = true)
    protected CustomerCollectAddRqType customerCollectAddRq;

    /**
     * Obtiene el valor de la propiedad customerCollectAddRq.
     * 
     * @return
     *     possible object is
     *     {@link CustomerCollectAddRqType }
     *     
     */
    public CustomerCollectAddRqType getCustomerCollectAddRq() {
        return customerCollectAddRq;
    }

    /**
     * Define el valor de la propiedad customerCollectAddRq.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerCollectAddRqType }
     *     
     */
    public void setCustomerCollectAddRq(CustomerCollectAddRqType value) {
        this.customerCollectAddRq = value;
    }

}
