@javax.xml.bind.annotation.XmlSchema(namespace = "urn://bancodebogota.com/customers/product/service/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package cliente;
