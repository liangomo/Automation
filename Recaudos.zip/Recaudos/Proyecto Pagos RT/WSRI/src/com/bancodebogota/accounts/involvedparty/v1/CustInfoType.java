
package com.bancodebogota.accounts.involvedparty.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.bancodebogota.ifx.base.v1.CustIdType;
import com.bancodebogota.ifx.base.v1.OtherIdentDocType;
import com.bancodebogota.ifx.base.v1.PersonNameType;


/**
 * <p>Clase Java para CustInfo_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustInfo_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;sequence&gt;
 *             &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}TypeId" minOccurs="0"/&gt;
 *             &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}ParticipantId" minOccurs="0"/&gt;
 *           &lt;/sequence&gt;
 *           &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}OtherIdentDoc" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}CustType" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}PersonName" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}CustId" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustInfo_Type", propOrder = {
    "typeId",
    "participantId",
    "otherIdentDoc",
    "custType",
    "personName",
    "custId"
})
public class CustInfoType {

    @XmlElement(name = "TypeId", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String typeId;
    @XmlElement(name = "ParticipantId", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String participantId;
    @XmlElement(name = "OtherIdentDoc", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected OtherIdentDocType otherIdentDoc;
    @XmlElement(name = "CustType", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String custType;
    @XmlElement(name = "PersonName", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected PersonNameType personName;
    @XmlElement(name = "CustId", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected CustIdType custId;

    /**
     * 
     * 						En este campo se parametriza el tipo de
     * 						identificaci�n, de cliente o persona natural o
     * 						jur�dica.
     * 					
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeId() {
        return typeId;
    }

    /**
     * Define el valor de la propiedad typeId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeId(String value) {
        this.typeId = value;
    }

    /**
     * 
     * 						En este campo se parametriza el n�mero de
     * 						identificaci�n, de cliente o persona natural o
     * 						jur�dica.
     * 					
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParticipantId() {
        return participantId;
    }

    /**
     * Define el valor de la propiedad participantId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParticipantId(String value) {
        this.participantId = value;
    }

    /**
     * Obtiene el valor de la propiedad otherIdentDoc.
     * 
     * @return
     *     possible object is
     *     {@link OtherIdentDocType }
     *     
     */
    public OtherIdentDocType getOtherIdentDoc() {
        return otherIdentDoc;
    }

    /**
     * Define el valor de la propiedad otherIdentDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link OtherIdentDocType }
     *     
     */
    public void setOtherIdentDoc(OtherIdentDocType value) {
        this.otherIdentDoc = value;
    }

    /**
     * 
     * 						En este campo se parametriza el tipo de cliente.
     * 					
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustType() {
        return custType;
    }

    /**
     * Define el valor de la propiedad custType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustType(String value) {
        this.custType = value;
    }

    /**
     * Obtiene el valor de la propiedad personName.
     * 
     * @return
     *     possible object is
     *     {@link PersonNameType }
     *     
     */
    public PersonNameType getPersonName() {
        return personName;
    }

    /**
     * Define el valor de la propiedad personName.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonNameType }
     *     
     */
    public void setPersonName(PersonNameType value) {
        this.personName = value;
    }

    /**
     * 
     * 						En este campo se parametriza la informaci�n de
     * 						autenticaci�n del usuario.
     * 					
     * 
     * @return
     *     possible object is
     *     {@link CustIdType }
     *     
     */
    public CustIdType getCustId() {
        return custId;
    }

    /**
     * Define el valor de la propiedad custId.
     * 
     * @param value
     *     allowed object is
     *     {@link CustIdType }
     *     
     */
    public void setCustId(CustIdType value) {
        this.custId = value;
    }

}
