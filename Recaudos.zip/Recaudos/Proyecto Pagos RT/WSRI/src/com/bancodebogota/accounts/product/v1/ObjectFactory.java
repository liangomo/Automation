
package com.bancodebogota.accounts.product.v1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bancodebogota.accounts.product.v1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AcctBal_QNAME = new QName("urn://bancodebogota.com/accounts/product/v1/", "AcctBal");
    private final static QName _AcctBalList_QNAME = new QName("urn://bancodebogota.com/accounts/product/v1/", "AcctBalList");
    private final static QName _DepAcctIdFrom_QNAME = new QName("urn://bancodebogota.com/accounts/product/v1/", "DepAcctIdFrom");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bancodebogota.accounts.product.v1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AcctBalType }
     * 
     */
    public AcctBalType createAcctBalType() {
        return new AcctBalType();
    }

    /**
     * Create an instance of {@link AcctBalListType }
     * 
     */
    public AcctBalListType createAcctBalListType() {
        return new AcctBalListType();
    }

    /**
     * Create an instance of {@link DepAcctIdType }
     * 
     */
    public DepAcctIdType createDepAcctIdType() {
        return new DepAcctIdType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AcctBalType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/accounts/product/v1/", name = "AcctBal")
    public JAXBElement<AcctBalType> createAcctBal(AcctBalType value) {
        return new JAXBElement<AcctBalType>(_AcctBal_QNAME, AcctBalType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AcctBalListType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/accounts/product/v1/", name = "AcctBalList")
    public JAXBElement<AcctBalListType> createAcctBalList(AcctBalListType value) {
        return new JAXBElement<AcctBalListType>(_AcctBalList_QNAME, AcctBalListType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepAcctIdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/accounts/product/v1/", name = "DepAcctIdFrom")
    public JAXBElement<DepAcctIdType> createDepAcctIdFrom(DepAcctIdType value) {
        return new JAXBElement<DepAcctIdType>(_DepAcctIdFrom_QNAME, DepAcctIdType.class, null, value);
    }

}
