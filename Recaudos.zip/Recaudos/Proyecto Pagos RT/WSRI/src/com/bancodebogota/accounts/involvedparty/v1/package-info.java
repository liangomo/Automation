@javax.xml.bind.annotation.XmlSchema(namespace = "urn://bancodebogota.com/accounts/involvedparty/v1/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.bancodebogota.accounts.involvedparty.v1;
