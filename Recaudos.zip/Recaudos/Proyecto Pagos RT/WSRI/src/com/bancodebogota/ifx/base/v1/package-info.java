@javax.xml.bind.annotation.XmlSchema(namespace = "urn://bancodebogota.com/ifx/base/v1/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.bancodebogota.ifx.base.v1;
