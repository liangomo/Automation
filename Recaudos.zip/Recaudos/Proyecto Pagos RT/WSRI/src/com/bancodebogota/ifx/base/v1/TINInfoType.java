
package com.bancodebogota.ifx.base.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TINInfo_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TINInfo_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}TINType" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}TaxId" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}CertCode" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TINInfo_Type", propOrder = {
    "tinType",
    "taxId",
    "certCode"
})
public class TINInfoType {

    @XmlElement(name = "TINType")
    protected String tinType;
    @XmlElement(name = "TaxId")
    protected String taxId;
    @XmlElement(name = "CertCode")
    protected String certCode;

    /**
     * Obtiene el valor de la propiedad tinType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTINType() {
        return tinType;
    }

    /**
     * Define el valor de la propiedad tinType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTINType(String value) {
        this.tinType = value;
    }

    /**
     * Obtiene el valor de la propiedad taxId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxId() {
        return taxId;
    }

    /**
     * Define el valor de la propiedad taxId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxId(String value) {
        this.taxId = value;
    }

    /**
     * Obtiene el valor de la propiedad certCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCertCode() {
        return certCode;
    }

    /**
     * Define el valor de la propiedad certCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCertCode(String value) {
        this.certCode = value;
    }

}
