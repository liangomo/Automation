
package com.bancodebogota.customers.customercollect.event;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bancodebogota.customers.customercollect.event package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CustomerCollectAddRq_QNAME = new QName("urn://bancodebogota.com/customers/customercollect/event/", "CustomerCollectAddRq");
    private final static QName _CustomerCollectAddRs_QNAME = new QName("urn://bancodebogota.com/customers/customercollect/event/", "CustomerCollectAddRs");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bancodebogota.customers.customercollect.event
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CustomerCollectAddRqType }
     * 
     */
    public CustomerCollectAddRqType createCustomerCollectAddRqType() {
        return new CustomerCollectAddRqType();
    }

    /**
     * Create an instance of {@link CustomerCollectAddRsType }
     * 
     */
    public CustomerCollectAddRsType createCustomerCollectAddRsType() {
        return new CustomerCollectAddRsType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CustomerCollectAddRqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/customercollect/event/", name = "CustomerCollectAddRq")
    public JAXBElement<CustomerCollectAddRqType> createCustomerCollectAddRq(CustomerCollectAddRqType value) {
        return new JAXBElement<CustomerCollectAddRqType>(_CustomerCollectAddRq_QNAME, CustomerCollectAddRqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CustomerCollectAddRsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/customercollect/event/", name = "CustomerCollectAddRs")
    public JAXBElement<CustomerCollectAddRsType> createCustomerCollectAddRs(CustomerCollectAddRsType value) {
        return new JAXBElement<CustomerCollectAddRsType>(_CustomerCollectAddRs_QNAME, CustomerCollectAddRsType.class, null, value);
    }

}
