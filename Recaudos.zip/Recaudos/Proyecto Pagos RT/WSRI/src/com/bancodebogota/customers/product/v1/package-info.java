@javax.xml.bind.annotation.XmlSchema(namespace = "urn://bancodebogota.com/customers/product/v1/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.bancodebogota.customers.product.v1;
