
package com.bancodebogota.customers.product.v1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ChkCollect_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ChkCollect_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}BalType" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}AcctId" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}TrnCount" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}Count" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}ChkNum" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}ChkNumEnd" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}Amt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}PayCurAmt" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ChkCollect_Type", propOrder = {
    "balType",
    "acctId",
    "trnCount",
    "count",
    "chkNum",
    "chkNumEnd",
    "amt",
    "payCurAmt"
})
public class ChkCollectType {

    @XmlElement(name = "BalType", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String balType;
    @XmlElement(name = "AcctId", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String acctId;
    @XmlElement(name = "TrnCount", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String trnCount;
    @XmlElement(name = "Count", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected Long count;
    @XmlElement(name = "ChkNum", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String chkNum;
    @XmlElement(name = "ChkNumEnd", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String chkNumEnd;
    @XmlElement(name = "Amt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected BigDecimal amt;
    @XmlElement(name = "PayCurAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected BigDecimal payCurAmt;

    /**
     * Obtiene el valor de la propiedad balType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBalType() {
        return balType;
    }

    /**
     * Define el valor de la propiedad balType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBalType(String value) {
        this.balType = value;
    }

    /**
     * Obtiene el valor de la propiedad acctId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctId() {
        return acctId;
    }

    /**
     * Define el valor de la propiedad acctId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctId(String value) {
        this.acctId = value;
    }

    /**
     * Obtiene el valor de la propiedad trnCount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnCount() {
        return trnCount;
    }

    /**
     * Define el valor de la propiedad trnCount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnCount(String value) {
        this.trnCount = value;
    }

    /**
     * Obtiene el valor de la propiedad count.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCount() {
        return count;
    }

    /**
     * Define el valor de la propiedad count.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCount(Long value) {
        this.count = value;
    }

    /**
     * Obtiene el valor de la propiedad chkNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkNum() {
        return chkNum;
    }

    /**
     * Define el valor de la propiedad chkNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkNum(String value) {
        this.chkNum = value;
    }

    /**
     * Obtiene el valor de la propiedad chkNumEnd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkNumEnd() {
        return chkNumEnd;
    }

    /**
     * Define el valor de la propiedad chkNumEnd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkNumEnd(String value) {
        this.chkNumEnd = value;
    }

    /**
     * Obtiene el valor de la propiedad amt.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmt() {
        return amt;
    }

    /**
     * Define el valor de la propiedad amt.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmt(BigDecimal value) {
        this.amt = value;
    }

    /**
     * Obtiene el valor de la propiedad payCurAmt.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPayCurAmt() {
        return payCurAmt;
    }

    /**
     * Define el valor de la propiedad payCurAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPayCurAmt(BigDecimal value) {
        this.payCurAmt = value;
    }

}
