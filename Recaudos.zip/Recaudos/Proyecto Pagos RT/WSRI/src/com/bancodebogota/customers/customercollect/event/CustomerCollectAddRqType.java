
package com.bancodebogota.customers.customercollect.event;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.bancodebogota.customers.product.v1.CollectInfoType;
import com.bancodebogota.ifx.base.v1.FlagList;
import com.bancodebogota.ifx.base.v1.RefInfoType;
import com.bancodebogota.ifx.base.v1.SvcRqType;
import com.bancodebogota.ifx.base.v1.TINInfoType;


/**
 * <p>Clase Java para CustomerCollectAddRq_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerCollectAddRq_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn://bancodebogota.com/ifx/base/v1/}SvcRq_Type"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}TrnType" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}EanCode" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}BranchId" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}BranchName" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}FlagList" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}BillCycleType" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}BillRefInfo" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}TINInfo" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}Desc" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/product/v1/}CollectInfo" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}NumRec" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/product/v1/}RefInfo" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerCollectAddRq_Type", propOrder = {
    "trnType",
    "eanCode",
    "branchId",
    "branchName",
    "flagList",
    "billCycleType",
    "billRefInfo",
    "tinInfo",
    "desc",
    "collectInfo",
    "numRec",
    "refInfo"
})
public class CustomerCollectAddRqType
    extends SvcRqType
{

    @XmlElement(name = "TrnType", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String trnType;
    @XmlElement(name = "EanCode", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String eanCode;
    @XmlElement(name = "BranchId", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String branchId;
    @XmlElement(name = "BranchName", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String branchName;
    @XmlElement(name = "FlagList", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected FlagList flagList;
    @XmlElement(name = "BillCycleType", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String billCycleType;
    @XmlElement(name = "BillRefInfo", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String billRefInfo;
    @XmlElement(name = "TINInfo", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected TINInfoType tinInfo;
    @XmlElement(name = "Desc", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String desc;
    @XmlElement(name = "CollectInfo", namespace = "urn://bancodebogota.com/customers/product/v1/")
    protected CollectInfoType collectInfo;
    @XmlElement(name = "NumRec", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected Long numRec;
    @XmlElement(name = "RefInfo", namespace = "urn://bancodebogota.com/customers/product/v1/")
    protected List<RefInfoType> refInfo;

    /**
     * Obtiene el valor de la propiedad trnType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnType() {
        return trnType;
    }

    /**
     * Define el valor de la propiedad trnType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnType(String value) {
        this.trnType = value;
    }

    /**
     * Obtiene el valor de la propiedad eanCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEanCode() {
        return eanCode;
    }

    /**
     * Define el valor de la propiedad eanCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEanCode(String value) {
        this.eanCode = value;
    }

    /**
     * Obtiene el valor de la propiedad branchId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchId() {
        return branchId;
    }

    /**
     * Define el valor de la propiedad branchId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchId(String value) {
        this.branchId = value;
    }

    /**
     * Obtiene el valor de la propiedad branchName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchName() {
        return branchName;
    }

    /**
     * Define el valor de la propiedad branchName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchName(String value) {
        this.branchName = value;
    }

    /**
     * Obtiene el valor de la propiedad flagList.
     * 
     * @return
     *     possible object is
     *     {@link FlagList }
     *     
     */
    public FlagList getFlagList() {
        return flagList;
    }

    /**
     * Define el valor de la propiedad flagList.
     * 
     * @param value
     *     allowed object is
     *     {@link FlagList }
     *     
     */
    public void setFlagList(FlagList value) {
        this.flagList = value;
    }

    /**
     * Obtiene el valor de la propiedad billCycleType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillCycleType() {
        return billCycleType;
    }

    /**
     * Define el valor de la propiedad billCycleType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillCycleType(String value) {
        this.billCycleType = value;
    }

    /**
     * Obtiene el valor de la propiedad billRefInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillRefInfo() {
        return billRefInfo;
    }

    /**
     * Define el valor de la propiedad billRefInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillRefInfo(String value) {
        this.billRefInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad tinInfo.
     * 
     * @return
     *     possible object is
     *     {@link TINInfoType }
     *     
     */
    public TINInfoType getTINInfo() {
        return tinInfo;
    }

    /**
     * Define el valor de la propiedad tinInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link TINInfoType }
     *     
     */
    public void setTINInfo(TINInfoType value) {
        this.tinInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad desc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesc() {
        return desc;
    }

    /**
     * Define el valor de la propiedad desc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesc(String value) {
        this.desc = value;
    }

    /**
     * Obtiene el valor de la propiedad collectInfo.
     * 
     * @return
     *     possible object is
     *     {@link CollectInfoType }
     *     
     */
    public CollectInfoType getCollectInfo() {
        return collectInfo;
    }

    /**
     * Define el valor de la propiedad collectInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link CollectInfoType }
     *     
     */
    public void setCollectInfo(CollectInfoType value) {
        this.collectInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad numRec.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNumRec() {
        return numRec;
    }

    /**
     * Define el valor de la propiedad numRec.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNumRec(Long value) {
        this.numRec = value;
    }

    /**
     * Gets the value of the refInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the refInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRefInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RefInfoType }
     * 
     * 
     */
    public List<RefInfoType> getRefInfo() {
        if (refInfo == null) {
            refInfo = new ArrayList<RefInfoType>();
        }
        return this.refInfo;
    }

}
