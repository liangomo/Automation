
package com.bancodebogota.customers.product.v1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.bancodebogota.ifx.base.v1.RefInfoType;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bancodebogota.customers.product.v1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ContributionCode_QNAME = new QName("urn://bancodebogota.com/customers/product/v1/", "ContributionCode");
    private final static QName _ServiceCode_QNAME = new QName("urn://bancodebogota.com/customers/product/v1/", "ServiceCode");
    private final static QName _InvoiceNum_QNAME = new QName("urn://bancodebogota.com/customers/product/v1/", "InvoiceNum");
    private final static QName _BilllingAcct_QNAME = new QName("urn://bancodebogota.com/customers/product/v1/", "BilllingAcct");
    private final static QName _RefInfo_QNAME = new QName("urn://bancodebogota.com/customers/product/v1/", "RefInfo");
    private final static QName _PayeeRef_QNAME = new QName("urn://bancodebogota.com/customers/product/v1/", "PayeeRef");
    private final static QName _BillPmtInfo_QNAME = new QName("urn://bancodebogota.com/customers/product/v1/", "BillPmtInfo");
    private final static QName _CollectAmtInfo_QNAME = new QName("urn://bancodebogota.com/customers/product/v1/", "CollectAmtInfo");
    private final static QName _CollectInfo_QNAME = new QName("urn://bancodebogota.com/customers/product/v1/", "CollectInfo");
    private final static QName _ChkCollect_QNAME = new QName("urn://bancodebogota.com/customers/product/v1/", "ChkCollect");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bancodebogota.customers.product.v1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BillPmtInfoType }
     * 
     */
    public BillPmtInfoType createBillPmtInfoType() {
        return new BillPmtInfoType();
    }

    /**
     * Create an instance of {@link CollectAmtInfoType }
     * 
     */
    public CollectAmtInfoType createCollectAmtInfoType() {
        return new CollectAmtInfoType();
    }

    /**
     * Create an instance of {@link CollectInfoType }
     * 
     */
    public CollectInfoType createCollectInfoType() {
        return new CollectInfoType();
    }

    /**
     * Create an instance of {@link ChkCollectType }
     * 
     */
    public ChkCollectType createChkCollectType() {
        return new ChkCollectType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/product/v1/", name = "ContributionCode")
    public JAXBElement<String> createContributionCode(String value) {
        return new JAXBElement<String>(_ContributionCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/product/v1/", name = "ServiceCode")
    public JAXBElement<String> createServiceCode(String value) {
        return new JAXBElement<String>(_ServiceCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/product/v1/", name = "InvoiceNum")
    public JAXBElement<String> createInvoiceNum(String value) {
        return new JAXBElement<String>(_InvoiceNum_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/product/v1/", name = "BilllingAcct")
    public JAXBElement<String> createBilllingAcct(String value) {
        return new JAXBElement<String>(_BilllingAcct_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RefInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/product/v1/", name = "RefInfo")
    public JAXBElement<RefInfoType> createRefInfo(RefInfoType value) {
        return new JAXBElement<RefInfoType>(_RefInfo_QNAME, RefInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/product/v1/", name = "PayeeRef")
    public JAXBElement<String> createPayeeRef(String value) {
        return new JAXBElement<String>(_PayeeRef_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BillPmtInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/product/v1/", name = "BillPmtInfo")
    public JAXBElement<BillPmtInfoType> createBillPmtInfo(BillPmtInfoType value) {
        return new JAXBElement<BillPmtInfoType>(_BillPmtInfo_QNAME, BillPmtInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CollectAmtInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/product/v1/", name = "CollectAmtInfo")
    public JAXBElement<CollectAmtInfoType> createCollectAmtInfo(CollectAmtInfoType value) {
        return new JAXBElement<CollectAmtInfoType>(_CollectAmtInfo_QNAME, CollectAmtInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CollectInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/product/v1/", name = "CollectInfo")
    public JAXBElement<CollectInfoType> createCollectInfo(CollectInfoType value) {
        return new JAXBElement<CollectInfoType>(_CollectInfo_QNAME, CollectInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChkCollectType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://bancodebogota.com/customers/product/v1/", name = "ChkCollect")
    public JAXBElement<ChkCollectType> createChkCollect(ChkCollectType value) {
        return new JAXBElement<ChkCollectType>(_ChkCollect_QNAME, ChkCollectType.class, null, value);
    }

}
