@javax.xml.bind.annotation.XmlSchema(namespace = "urn://bancodebogota.com/customers/customercollect/event/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.bancodebogota.customers.customercollect.event;
