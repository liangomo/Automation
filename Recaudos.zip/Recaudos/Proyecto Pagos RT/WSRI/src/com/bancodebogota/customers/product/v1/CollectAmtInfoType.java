
package com.bancodebogota.customers.product.v1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.bancodebogota.accounts.product.v1.AcctBalType;
import com.bancodebogota.ifx.base.v1.CurrencyAmountType;


/**
 * <p>Clase Java para CollectAmtInfo_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CollectAmtInfo_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}Amt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}PayCurAmt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}CashAmt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}AuthAmt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}SecAmt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}OrigCurAmt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}TotalCurAmt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}NetCurAmt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}TaxPaidCurAmt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}FeeAmt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}BalAmt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}Count" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/accounts/product/v1/}AcctBal" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CollectAmtInfo_Type", propOrder = {
    "amt",
    "payCurAmt",
    "cashAmt",
    "authAmt",
    "secAmt",
    "origCurAmt",
    "totalCurAmt",
    "netCurAmt",
    "taxPaidCurAmt",
    "feeAmt",
    "balAmt",
    "count",
    "acctBal"
})
public class CollectAmtInfoType {

    @XmlElement(name = "Amt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected BigDecimal amt;
    @XmlElement(name = "PayCurAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected BigDecimal payCurAmt;
    @XmlElement(name = "CashAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected CurrencyAmountType cashAmt;
    @XmlElement(name = "AuthAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected CurrencyAmountType authAmt;
    @XmlElement(name = "SecAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected CurrencyAmountType secAmt;
    @XmlElement(name = "OrigCurAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected CurrencyAmountType origCurAmt;
    @XmlElement(name = "TotalCurAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected CurrencyAmountType totalCurAmt;
    @XmlElement(name = "NetCurAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected CurrencyAmountType netCurAmt;
    @XmlElement(name = "TaxPaidCurAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected CurrencyAmountType taxPaidCurAmt;
    @XmlElement(name = "FeeAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected CurrencyAmountType feeAmt;
    @XmlElement(name = "BalAmt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected CurrencyAmountType balAmt;
    @XmlElement(name = "Count", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected Long count;
    @XmlElement(name = "AcctBal", namespace = "urn://bancodebogota.com/accounts/product/v1/")
    protected List<AcctBalType> acctBal;

    /**
     * Obtiene el valor de la propiedad amt.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmt() {
        return amt;
    }

    /**
     * Define el valor de la propiedad amt.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmt(BigDecimal value) {
        this.amt = value;
    }

    /**
     * Obtiene el valor de la propiedad payCurAmt.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPayCurAmt() {
        return payCurAmt;
    }

    /**
     * Define el valor de la propiedad payCurAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPayCurAmt(BigDecimal value) {
        this.payCurAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad cashAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getCashAmt() {
        return cashAmt;
    }

    /**
     * Define el valor de la propiedad cashAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setCashAmt(CurrencyAmountType value) {
        this.cashAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad authAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getAuthAmt() {
        return authAmt;
    }

    /**
     * Define el valor de la propiedad authAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setAuthAmt(CurrencyAmountType value) {
        this.authAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad secAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getSecAmt() {
        return secAmt;
    }

    /**
     * Define el valor de la propiedad secAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setSecAmt(CurrencyAmountType value) {
        this.secAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad origCurAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getOrigCurAmt() {
        return origCurAmt;
    }

    /**
     * Define el valor de la propiedad origCurAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setOrigCurAmt(CurrencyAmountType value) {
        this.origCurAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad totalCurAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getTotalCurAmt() {
        return totalCurAmt;
    }

    /**
     * Define el valor de la propiedad totalCurAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setTotalCurAmt(CurrencyAmountType value) {
        this.totalCurAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad netCurAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getNetCurAmt() {
        return netCurAmt;
    }

    /**
     * Define el valor de la propiedad netCurAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setNetCurAmt(CurrencyAmountType value) {
        this.netCurAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad taxPaidCurAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getTaxPaidCurAmt() {
        return taxPaidCurAmt;
    }

    /**
     * Define el valor de la propiedad taxPaidCurAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setTaxPaidCurAmt(CurrencyAmountType value) {
        this.taxPaidCurAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad feeAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getFeeAmt() {
        return feeAmt;
    }

    /**
     * Define el valor de la propiedad feeAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setFeeAmt(CurrencyAmountType value) {
        this.feeAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad balAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getBalAmt() {
        return balAmt;
    }

    /**
     * Define el valor de la propiedad balAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setBalAmt(CurrencyAmountType value) {
        this.balAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad count.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCount() {
        return count;
    }

    /**
     * Define el valor de la propiedad count.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCount(Long value) {
        this.count = value;
    }

    /**
     * Gets the value of the acctBal property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the acctBal property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAcctBal().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AcctBalType }
     * 
     * 
     */
    public List<AcctBalType> getAcctBal() {
        if (acctBal == null) {
            acctBal = new ArrayList<AcctBalType>();
        }
        return this.acctBal;
    }

}
