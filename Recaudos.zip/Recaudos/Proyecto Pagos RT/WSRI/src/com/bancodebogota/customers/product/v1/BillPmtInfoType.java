
package com.bancodebogota.customers.product.v1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.bancodebogota.ifx.base.v1.RefInfoType;


/**
 * <p>Clase Java para BillPmtInfo_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="BillPmtInfo_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/product/v1/}InvoiceNum" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/product/v1/}BilllingAcct" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/product/v1/}ServiceCode" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/product/v1/}ContributionCode" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/product/v1/}PayeeRef" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}Amt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/product/v1/}RefInfo" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillPmtInfo_Type", propOrder = {
    "invoiceNum",
    "billlingAcct",
    "serviceCode",
    "contributionCode",
    "payeeRef",
    "amt",
    "refInfo"
})
public class BillPmtInfoType {

    @XmlElement(name = "InvoiceNum")
    protected String invoiceNum;
    @XmlElement(name = "BilllingAcct")
    protected String billlingAcct;
    @XmlElement(name = "ServiceCode")
    protected String serviceCode;
    @XmlElement(name = "ContributionCode")
    protected String contributionCode;
    @XmlElement(name = "PayeeRef")
    protected String payeeRef;
    @XmlElement(name = "Amt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected BigDecimal amt;
    @XmlElement(name = "RefInfo")
    protected List<RefInfoType> refInfo;

    /**
     * Obtiene el valor de la propiedad invoiceNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceNum() {
        return invoiceNum;
    }

    /**
     * Define el valor de la propiedad invoiceNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceNum(String value) {
        this.invoiceNum = value;
    }

    /**
     * Obtiene el valor de la propiedad billlingAcct.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBilllingAcct() {
        return billlingAcct;
    }

    /**
     * Define el valor de la propiedad billlingAcct.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBilllingAcct(String value) {
        this.billlingAcct = value;
    }

    /**
     * Obtiene el valor de la propiedad serviceCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceCode() {
        return serviceCode;
    }

    /**
     * Define el valor de la propiedad serviceCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceCode(String value) {
        this.serviceCode = value;
    }

    /**
     * Obtiene el valor de la propiedad contributionCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContributionCode() {
        return contributionCode;
    }

    /**
     * Define el valor de la propiedad contributionCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContributionCode(String value) {
        this.contributionCode = value;
    }

    /**
     * Obtiene el valor de la propiedad payeeRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayeeRef() {
        return payeeRef;
    }

    /**
     * Define el valor de la propiedad payeeRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayeeRef(String value) {
        this.payeeRef = value;
    }

    /**
     * Obtiene el valor de la propiedad amt.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmt() {
        return amt;
    }

    /**
     * Define el valor de la propiedad amt.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmt(BigDecimal value) {
        this.amt = value;
    }

    /**
     * Gets the value of the refInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the refInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRefInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RefInfoType }
     * 
     * 
     */
    public List<RefInfoType> getRefInfo() {
        if (refInfo == null) {
            refInfo = new ArrayList<RefInfoType>();
        }
        return this.refInfo;
    }

}
