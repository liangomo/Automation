
package com.bancodebogota.customers.product.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.bancodebogota.accounts.involvedparty.v1.CustInfoType;
import com.bancodebogota.ifx.base.v1.LoanAcctIdType;


/**
 * <p>Clase Java para CollectInfo_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CollectInfo_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}TrnAuthId" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}TrnType" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}BalType" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}CardSeqNum" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}DepAcctId" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/accounts/product/v1/}DepAcctIdFrom" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}DepAcctIdTo" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}LoanAcctId" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}BillDt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}LastPmtDt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}OrigPmtDueDt" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/product/v1/}ChkCollect" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}BranchId" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/ifx/base/v1/}CardType" minOccurs="0"/&gt;
 *         &lt;element name="LoanType" type="{urn://bancodebogota.com/ifx/base/v1/}OpenEnum_Type" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/customers/product/v1/}CollectAmtInfo" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://bancodebogota.com/accounts/involvedparty/v1/}CustInfo" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CollectInfo_Type", propOrder = {
    "trnAuthId",
    "trnType",
    "balType",
    "cardSeqNum",
    "depAcctId",
    "depAcctIdFrom",
    "depAcctIdTo",
    "loanAcctId",
    "billDt",
    "lastPmtDt",
    "origPmtDueDt",
    "chkCollect",
    "branchId",
    "cardType",
    "loanType",
    "collectAmtInfo",
    "custInfo"
})
public class CollectInfoType {

    @XmlElement(name = "TrnAuthId", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String trnAuthId;
    @XmlElement(name = "TrnType", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String trnType;
    @XmlElement(name = "BalType", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String balType;
    @XmlElement(name = "CardSeqNum", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String cardSeqNum;
    @XmlElement(name = "DepAcctId", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected com.bancodebogota.ifx.base.v1.DepAcctIdType depAcctId;
    @XmlElement(name = "DepAcctIdFrom", namespace = "urn://bancodebogota.com/accounts/product/v1/")
    protected com.bancodebogota.accounts.product.v1.DepAcctIdType depAcctIdFrom;
    @XmlElement(name = "DepAcctIdTo", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected com.bancodebogota.ifx.base.v1.DepAcctIdType depAcctIdTo;
    @XmlElement(name = "LoanAcctId", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected LoanAcctIdType loanAcctId;
    @XmlElement(name = "BillDt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar billDt;
    @XmlElement(name = "LastPmtDt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar lastPmtDt;
    @XmlElement(name = "OrigPmtDueDt", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar origPmtDueDt;
    @XmlElement(name = "ChkCollect")
    protected ChkCollectType chkCollect;
    @XmlElement(name = "BranchId", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String branchId;
    @XmlElement(name = "CardType", namespace = "urn://bancodebogota.com/ifx/base/v1/")
    protected String cardType;
    @XmlElement(name = "LoanType", namespace = "")
    protected String loanType;
    @XmlElement(name = "CollectAmtInfo")
    protected CollectAmtInfoType collectAmtInfo;
    @XmlElement(name = "CustInfo", namespace = "urn://bancodebogota.com/accounts/involvedparty/v1/")
    protected CustInfoType custInfo;

    /**
     * Obtiene el valor de la propiedad trnAuthId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnAuthId() {
        return trnAuthId;
    }

    /**
     * Define el valor de la propiedad trnAuthId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnAuthId(String value) {
        this.trnAuthId = value;
    }

    /**
     * Obtiene el valor de la propiedad trnType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnType() {
        return trnType;
    }

    /**
     * Define el valor de la propiedad trnType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnType(String value) {
        this.trnType = value;
    }

    /**
     * Obtiene el valor de la propiedad balType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBalType() {
        return balType;
    }

    /**
     * Define el valor de la propiedad balType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBalType(String value) {
        this.balType = value;
    }

    /**
     * Obtiene el valor de la propiedad cardSeqNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardSeqNum() {
        return cardSeqNum;
    }

    /**
     * Define el valor de la propiedad cardSeqNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardSeqNum(String value) {
        this.cardSeqNum = value;
    }

    /**
     * Obtiene el valor de la propiedad depAcctId.
     * 
     * @return
     *     possible object is
     *     {@link com.bancodebogota.ifx.base.v1.DepAcctIdType }
     *     
     */
    public com.bancodebogota.ifx.base.v1.DepAcctIdType getDepAcctId() {
        return depAcctId;
    }

    /**
     * Define el valor de la propiedad depAcctId.
     * 
     * @param value
     *     allowed object is
     *     {@link com.bancodebogota.ifx.base.v1.DepAcctIdType }
     *     
     */
    public void setDepAcctId(com.bancodebogota.ifx.base.v1.DepAcctIdType value) {
        this.depAcctId = value;
    }

    /**
     * Obtiene el valor de la propiedad depAcctIdFrom.
     * 
     * @return
     *     possible object is
     *     {@link com.bancodebogota.accounts.product.v1.DepAcctIdType }
     *     
     */
    public com.bancodebogota.accounts.product.v1.DepAcctIdType getDepAcctIdFrom() {
        return depAcctIdFrom;
    }

    /**
     * Define el valor de la propiedad depAcctIdFrom.
     * 
     * @param value
     *     allowed object is
     *     {@link com.bancodebogota.accounts.product.v1.DepAcctIdType }
     *     
     */
    public void setDepAcctIdFrom(com.bancodebogota.accounts.product.v1.DepAcctIdType value) {
        this.depAcctIdFrom = value;
    }

    /**
     * Obtiene el valor de la propiedad depAcctIdTo.
     * 
     * @return
     *     possible object is
     *     {@link com.bancodebogota.ifx.base.v1.DepAcctIdType }
     *     
     */
    public com.bancodebogota.ifx.base.v1.DepAcctIdType getDepAcctIdTo() {
        return depAcctIdTo;
    }

    /**
     * Define el valor de la propiedad depAcctIdTo.
     * 
     * @param value
     *     allowed object is
     *     {@link com.bancodebogota.ifx.base.v1.DepAcctIdType }
     *     
     */
    public void setDepAcctIdTo(com.bancodebogota.ifx.base.v1.DepAcctIdType value) {
        this.depAcctIdTo = value;
    }

    /**
     * Obtiene el valor de la propiedad loanAcctId.
     * 
     * @return
     *     possible object is
     *     {@link LoanAcctIdType }
     *     
     */
    public LoanAcctIdType getLoanAcctId() {
        return loanAcctId;
    }

    /**
     * Define el valor de la propiedad loanAcctId.
     * 
     * @param value
     *     allowed object is
     *     {@link LoanAcctIdType }
     *     
     */
    public void setLoanAcctId(LoanAcctIdType value) {
        this.loanAcctId = value;
    }

    /**
     * Obtiene el valor de la propiedad billDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBillDt() {
        return billDt;
    }

    /**
     * Define el valor de la propiedad billDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBillDt(XMLGregorianCalendar value) {
        this.billDt = value;
    }

    /**
     * Obtiene el valor de la propiedad lastPmtDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastPmtDt() {
        return lastPmtDt;
    }

    /**
     * Define el valor de la propiedad lastPmtDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastPmtDt(XMLGregorianCalendar value) {
        this.lastPmtDt = value;
    }

    /**
     * Obtiene el valor de la propiedad origPmtDueDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getOrigPmtDueDt() {
        return origPmtDueDt;
    }

    /**
     * Define el valor de la propiedad origPmtDueDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setOrigPmtDueDt(XMLGregorianCalendar value) {
        this.origPmtDueDt = value;
    }

    /**
     * Obtiene el valor de la propiedad chkCollect.
     * 
     * @return
     *     possible object is
     *     {@link ChkCollectType }
     *     
     */
    public ChkCollectType getChkCollect() {
        return chkCollect;
    }

    /**
     * Define el valor de la propiedad chkCollect.
     * 
     * @param value
     *     allowed object is
     *     {@link ChkCollectType }
     *     
     */
    public void setChkCollect(ChkCollectType value) {
        this.chkCollect = value;
    }

    /**
     * Obtiene el valor de la propiedad branchId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchId() {
        return branchId;
    }

    /**
     * Define el valor de la propiedad branchId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchId(String value) {
        this.branchId = value;
    }

    /**
     * Obtiene el valor de la propiedad cardType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * Define el valor de la propiedad cardType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardType(String value) {
        this.cardType = value;
    }

    /**
     * Obtiene el valor de la propiedad loanType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanType() {
        return loanType;
    }

    /**
     * Define el valor de la propiedad loanType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanType(String value) {
        this.loanType = value;
    }

    /**
     * Obtiene el valor de la propiedad collectAmtInfo.
     * 
     * @return
     *     possible object is
     *     {@link CollectAmtInfoType }
     *     
     */
    public CollectAmtInfoType getCollectAmtInfo() {
        return collectAmtInfo;
    }

    /**
     * Define el valor de la propiedad collectAmtInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link CollectAmtInfoType }
     *     
     */
    public void setCollectAmtInfo(CollectAmtInfoType value) {
        this.collectAmtInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad custInfo.
     * 
     * @return
     *     possible object is
     *     {@link CustInfoType }
     *     
     */
    public CustInfoType getCustInfo() {
        return custInfo;
    }

    /**
     * Define el valor de la propiedad custInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link CustInfoType }
     *     
     */
    public void setCustInfo(CustInfoType value) {
        this.custInfo = value;
    }

}
