import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

public class index {

	public static void main(String[] args) throws RemoteException, ServiceException {
		
		CustomerAgreementInquirySvcLocator lc = new CustomerAgreementInquirySvcLocator();
		CustomerAgreementInqRq_Type  type = new CustomerAgreementInqRq_Type();

		/** Par�metros del CustomerAgreementInqRq_Type */
		
		type.setRqUID("12345654-2341-9876-9283-000000000011");
		
		CustId_Type cust = new CustId_Type();
			cust.setSPName("urn://gov.co/N");
			cust.setCustPermId("5462");
			cust.setCustLoginId("MBK00001");
		type.setCustId(cust);
		
		Boolean_Type b = new Boolean_Type("1");
		type.setNextDay(b);
		
		type.setClientTerminalSeqId("232323");
		type.setTrnStatusType("0");
		
		NetworkTrnInfo_Type nt = new NetworkTrnInfo_Type();
			nt.setNetworkOwner("OFC");
			nt.setTerminalId("OF01");
			nt.setTerminalType("PROV");
			nt.setBankId("BB");
			nt.setDesc("Prosegur");
			nt.setName("MBK00001");
		type.setNetworkTrnInfo(nt);
		
		type.setClientDt("2015-08-06T15:35:00");
		type.setTrnType("C");
		type.setBranchId("G002");
		type.setBranchName("0624");
		type.setEanCode("7700259940078");
		type.setAcctId("00000000040975625");
		type.setIndCtrCje("0");
		type.setIndCtaNal("0");
		
		TINInfo_Type tn = new TINInfo_Type();
			tn.setTINType("0");
			tn.setTaxId("0");
			tn.setCertCode("0");
		type.setTINInfo(tn);
		
		/* Obtener par�metros del Request */
		GetCustomerAgreementRequest gt = new GetCustomerAgreementRequest(type);
		
		
		CustomerAgreementInqRs_Type Respuesta = new CustomerAgreementInqRs_Type();
		
		Respuesta = lc.getCustomerAgreementInquiryPort().getCustomerAgreement(gt).getCustomerAgreementInqRs();
		
		System.out.println(Respuesta.getStatus().getAdditionalStatus(2).getStatusDesc());
		
	}
	
	
	
}