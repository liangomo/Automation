/**
 * CompanyAgreement_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

public class CompanyAgreement_Type  implements java.io.Serializable {
    private java.lang.String companyNameInd;

    private java.lang.String attachmentInd;

    private java.lang.String dateValInd;

    private java.lang.String currencyCode;

    private java.lang.String trnCode;

    private java.lang.String balTypeValInd;

    private java.lang.String curAmtValInd;

    private java.lang.String recVolumInd;

    private java.lang.String WSInd;

    private java.lang.String formatInd;

    private TINInfo_Type TINInfo;

    private java.lang.String collectType;

    private java.lang.String custPermId;

    private java.lang.String digitalCopyInd;

    private java.lang.String DBInd;

    private java.lang.String doubleCapInd;

    private java.lang.String creditCardInd;

    private java.lang.String debitCardInd;

    private java.lang.String chkInd;

    private java.math.BigDecimal rate;

    private java.lang.String billRefInfo;

    private CurrencyAmount_Type balAmt;

    private java.util.Date billDt;

    private java.util.Date trnDt;

    private java.lang.String effDt;

    private java.lang.String endDt;

    private java.lang.String serviceCode;

    private java.lang.String[] desc;

    private RefInfo_Type[] refInfo;

    private java.lang.String[] additionalFields;

    public CompanyAgreement_Type() {
    }

    public CompanyAgreement_Type(
           java.lang.String companyNameInd,
           java.lang.String attachmentInd,
           java.lang.String dateValInd,
           java.lang.String currencyCode,
           java.lang.String trnCode,
           java.lang.String balTypeValInd,
           java.lang.String curAmtValInd,
           java.lang.String recVolumInd,
           java.lang.String WSInd,
           java.lang.String formatInd,
           TINInfo_Type TINInfo,
           java.lang.String collectType,
           java.lang.String custPermId,
           java.lang.String digitalCopyInd,
           java.lang.String DBInd,
           java.lang.String doubleCapInd,
           java.lang.String creditCardInd,
           java.lang.String debitCardInd,
           java.lang.String chkInd,
           java.math.BigDecimal rate,
           java.lang.String billRefInfo,
           CurrencyAmount_Type balAmt,
           java.util.Date billDt,
           java.util.Date trnDt,
           java.lang.String effDt,
           java.lang.String endDt,
           java.lang.String serviceCode,
           java.lang.String[] desc,
           RefInfo_Type[] refInfo,
           java.lang.String[] additionalFields) {
           this.companyNameInd = companyNameInd;
           this.attachmentInd = attachmentInd;
           this.dateValInd = dateValInd;
           this.currencyCode = currencyCode;
           this.trnCode = trnCode;
           this.balTypeValInd = balTypeValInd;
           this.curAmtValInd = curAmtValInd;
           this.recVolumInd = recVolumInd;
           this.WSInd = WSInd;
           this.formatInd = formatInd;
           this.TINInfo = TINInfo;
           this.collectType = collectType;
           this.custPermId = custPermId;
           this.digitalCopyInd = digitalCopyInd;
           this.DBInd = DBInd;
           this.doubleCapInd = doubleCapInd;
           this.creditCardInd = creditCardInd;
           this.debitCardInd = debitCardInd;
           this.chkInd = chkInd;
           this.rate = rate;
           this.billRefInfo = billRefInfo;
           this.balAmt = balAmt;
           this.billDt = billDt;
           this.trnDt = trnDt;
           this.effDt = effDt;
           this.endDt = endDt;
           this.serviceCode = serviceCode;
           this.desc = desc;
           this.refInfo = refInfo;
           this.additionalFields = additionalFields;
    }


    /**
     * Gets the companyNameInd value for this CompanyAgreement_Type.
     * 
     * @return companyNameInd
     */
    public java.lang.String getCompanyNameInd() {
        return companyNameInd;
    }


    /**
     * Sets the companyNameInd value for this CompanyAgreement_Type.
     * 
     * @param companyNameInd
     */
    public void setCompanyNameInd(java.lang.String companyNameInd) {
        this.companyNameInd = companyNameInd;
    }


    /**
     * Gets the attachmentInd value for this CompanyAgreement_Type.
     * 
     * @return attachmentInd
     */
    public java.lang.String getAttachmentInd() {
        return attachmentInd;
    }


    /**
     * Sets the attachmentInd value for this CompanyAgreement_Type.
     * 
     * @param attachmentInd
     */
    public void setAttachmentInd(java.lang.String attachmentInd) {
        this.attachmentInd = attachmentInd;
    }


    /**
     * Gets the dateValInd value for this CompanyAgreement_Type.
     * 
     * @return dateValInd
     */
    public java.lang.String getDateValInd() {
        return dateValInd;
    }


    /**
     * Sets the dateValInd value for this CompanyAgreement_Type.
     * 
     * @param dateValInd
     */
    public void setDateValInd(java.lang.String dateValInd) {
        this.dateValInd = dateValInd;
    }


    /**
     * Gets the currencyCode value for this CompanyAgreement_Type.
     * 
     * @return currencyCode
     */
    public java.lang.String getCurrencyCode() {
        return currencyCode;
    }


    /**
     * Sets the currencyCode value for this CompanyAgreement_Type.
     * 
     * @param currencyCode
     */
    public void setCurrencyCode(java.lang.String currencyCode) {
        this.currencyCode = currencyCode;
    }


    /**
     * Gets the trnCode value for this CompanyAgreement_Type.
     * 
     * @return trnCode
     */
    public java.lang.String getTrnCode() {
        return trnCode;
    }


    /**
     * Sets the trnCode value for this CompanyAgreement_Type.
     * 
     * @param trnCode
     */
    public void setTrnCode(java.lang.String trnCode) {
        this.trnCode = trnCode;
    }


    /**
     * Gets the balTypeValInd value for this CompanyAgreement_Type.
     * 
     * @return balTypeValInd
     */
    public java.lang.String getBalTypeValInd() {
        return balTypeValInd;
    }


    /**
     * Sets the balTypeValInd value for this CompanyAgreement_Type.
     * 
     * @param balTypeValInd
     */
    public void setBalTypeValInd(java.lang.String balTypeValInd) {
        this.balTypeValInd = balTypeValInd;
    }


    /**
     * Gets the curAmtValInd value for this CompanyAgreement_Type.
     * 
     * @return curAmtValInd
     */
    public java.lang.String getCurAmtValInd() {
        return curAmtValInd;
    }


    /**
     * Sets the curAmtValInd value for this CompanyAgreement_Type.
     * 
     * @param curAmtValInd
     */
    public void setCurAmtValInd(java.lang.String curAmtValInd) {
        this.curAmtValInd = curAmtValInd;
    }


    /**
     * Gets the recVolumInd value for this CompanyAgreement_Type.
     * 
     * @return recVolumInd
     */
    public java.lang.String getRecVolumInd() {
        return recVolumInd;
    }


    /**
     * Sets the recVolumInd value for this CompanyAgreement_Type.
     * 
     * @param recVolumInd
     */
    public void setRecVolumInd(java.lang.String recVolumInd) {
        this.recVolumInd = recVolumInd;
    }


    /**
     * Gets the WSInd value for this CompanyAgreement_Type.
     * 
     * @return WSInd
     */
    public java.lang.String getWSInd() {
        return WSInd;
    }


    /**
     * Sets the WSInd value for this CompanyAgreement_Type.
     * 
     * @param WSInd
     */
    public void setWSInd(java.lang.String WSInd) {
        this.WSInd = WSInd;
    }


    /**
     * Gets the formatInd value for this CompanyAgreement_Type.
     * 
     * @return formatInd
     */
    public java.lang.String getFormatInd() {
        return formatInd;
    }


    /**
     * Sets the formatInd value for this CompanyAgreement_Type.
     * 
     * @param formatInd
     */
    public void setFormatInd(java.lang.String formatInd) {
        this.formatInd = formatInd;
    }


    /**
     * Gets the TINInfo value for this CompanyAgreement_Type.
     * 
     * @return TINInfo
     */
    public TINInfo_Type getTINInfo() {
        return TINInfo;
    }


    /**
     * Sets the TINInfo value for this CompanyAgreement_Type.
     * 
     * @param TINInfo
     */
    public void setTINInfo(TINInfo_Type TINInfo) {
        this.TINInfo = TINInfo;
    }


    /**
     * Gets the collectType value for this CompanyAgreement_Type.
     * 
     * @return collectType
     */
    public java.lang.String getCollectType() {
        return collectType;
    }


    /**
     * Sets the collectType value for this CompanyAgreement_Type.
     * 
     * @param collectType
     */
    public void setCollectType(java.lang.String collectType) {
        this.collectType = collectType;
    }


    /**
     * Gets the custPermId value for this CompanyAgreement_Type.
     * 
     * @return custPermId
     */
    public java.lang.String getCustPermId() {
        return custPermId;
    }


    /**
     * Sets the custPermId value for this CompanyAgreement_Type.
     * 
     * @param custPermId
     */
    public void setCustPermId(java.lang.String custPermId) {
        this.custPermId = custPermId;
    }


    /**
     * Gets the digitalCopyInd value for this CompanyAgreement_Type.
     * 
     * @return digitalCopyInd
     */
    public java.lang.String getDigitalCopyInd() {
        return digitalCopyInd;
    }


    /**
     * Sets the digitalCopyInd value for this CompanyAgreement_Type.
     * 
     * @param digitalCopyInd
     */
    public void setDigitalCopyInd(java.lang.String digitalCopyInd) {
        this.digitalCopyInd = digitalCopyInd;
    }


    /**
     * Gets the DBInd value for this CompanyAgreement_Type.
     * 
     * @return DBInd
     */
    public java.lang.String getDBInd() {
        return DBInd;
    }


    /**
     * Sets the DBInd value for this CompanyAgreement_Type.
     * 
     * @param DBInd
     */
    public void setDBInd(java.lang.String DBInd) {
        this.DBInd = DBInd;
    }


    /**
     * Gets the doubleCapInd value for this CompanyAgreement_Type.
     * 
     * @return doubleCapInd
     */
    public java.lang.String getDoubleCapInd() {
        return doubleCapInd;
    }


    /**
     * Sets the doubleCapInd value for this CompanyAgreement_Type.
     * 
     * @param doubleCapInd
     */
    public void setDoubleCapInd(java.lang.String doubleCapInd) {
        this.doubleCapInd = doubleCapInd;
    }


    /**
     * Gets the creditCardInd value for this CompanyAgreement_Type.
     * 
     * @return creditCardInd
     */
    public java.lang.String getCreditCardInd() {
        return creditCardInd;
    }


    /**
     * Sets the creditCardInd value for this CompanyAgreement_Type.
     * 
     * @param creditCardInd
     */
    public void setCreditCardInd(java.lang.String creditCardInd) {
        this.creditCardInd = creditCardInd;
    }


    /**
     * Gets the debitCardInd value for this CompanyAgreement_Type.
     * 
     * @return debitCardInd
     */
    public java.lang.String getDebitCardInd() {
        return debitCardInd;
    }


    /**
     * Sets the debitCardInd value for this CompanyAgreement_Type.
     * 
     * @param debitCardInd
     */
    public void setDebitCardInd(java.lang.String debitCardInd) {
        this.debitCardInd = debitCardInd;
    }


    /**
     * Gets the chkInd value for this CompanyAgreement_Type.
     * 
     * @return chkInd
     */
    public java.lang.String getChkInd() {
        return chkInd;
    }


    /**
     * Sets the chkInd value for this CompanyAgreement_Type.
     * 
     * @param chkInd
     */
    public void setChkInd(java.lang.String chkInd) {
        this.chkInd = chkInd;
    }


    /**
     * Gets the rate value for this CompanyAgreement_Type.
     * 
     * @return rate
     */
    public java.math.BigDecimal getRate() {
        return rate;
    }


    /**
     * Sets the rate value for this CompanyAgreement_Type.
     * 
     * @param rate
     */
    public void setRate(java.math.BigDecimal rate) {
        this.rate = rate;
    }


    /**
     * Gets the billRefInfo value for this CompanyAgreement_Type.
     * 
     * @return billRefInfo
     */
    public java.lang.String getBillRefInfo() {
        return billRefInfo;
    }


    /**
     * Sets the billRefInfo value for this CompanyAgreement_Type.
     * 
     * @param billRefInfo
     */
    public void setBillRefInfo(java.lang.String billRefInfo) {
        this.billRefInfo = billRefInfo;
    }


    /**
     * Gets the balAmt value for this CompanyAgreement_Type.
     * 
     * @return balAmt
     */
    public CurrencyAmount_Type getBalAmt() {
        return balAmt;
    }


    /**
     * Sets the balAmt value for this CompanyAgreement_Type.
     * 
     * @param balAmt
     */
    public void setBalAmt(CurrencyAmount_Type balAmt) {
        this.balAmt = balAmt;
    }


    /**
     * Gets the billDt value for this CompanyAgreement_Type.
     * 
     * @return billDt
     */
    public java.util.Date getBillDt() {
        return billDt;
    }


    /**
     * Sets the billDt value for this CompanyAgreement_Type.
     * 
     * @param billDt
     */
    public void setBillDt(java.util.Date billDt) {
        this.billDt = billDt;
    }


    /**
     * Gets the trnDt value for this CompanyAgreement_Type.
     * 
     * @return trnDt
     */
    public java.util.Date getTrnDt() {
        return trnDt;
    }


    /**
     * Sets the trnDt value for this CompanyAgreement_Type.
     * 
     * @param trnDt
     */
    public void setTrnDt(java.util.Date trnDt) {
        this.trnDt = trnDt;
    }


    /**
     * Gets the effDt value for this CompanyAgreement_Type.
     * 
     * @return effDt
     */
    public java.lang.String getEffDt() {
        return effDt;
    }


    /**
     * Sets the effDt value for this CompanyAgreement_Type.
     * 
     * @param effDt
     */
    public void setEffDt(java.lang.String effDt) {
        this.effDt = effDt;
    }


    /**
     * Gets the endDt value for this CompanyAgreement_Type.
     * 
     * @return endDt
     */
    public java.lang.String getEndDt() {
        return endDt;
    }


    /**
     * Sets the endDt value for this CompanyAgreement_Type.
     * 
     * @param endDt
     */
    public void setEndDt(java.lang.String endDt) {
        this.endDt = endDt;
    }


    /**
     * Gets the serviceCode value for this CompanyAgreement_Type.
     * 
     * @return serviceCode
     */
    public java.lang.String getServiceCode() {
        return serviceCode;
    }


    /**
     * Sets the serviceCode value for this CompanyAgreement_Type.
     * 
     * @param serviceCode
     */
    public void setServiceCode(java.lang.String serviceCode) {
        this.serviceCode = serviceCode;
    }


    /**
     * Gets the desc value for this CompanyAgreement_Type.
     * 
     * @return desc
     */
    public java.lang.String[] getDesc() {
        return desc;
    }


    /**
     * Sets the desc value for this CompanyAgreement_Type.
     * 
     * @param desc
     */
    public void setDesc(java.lang.String[] desc) {
        this.desc = desc;
    }

    public java.lang.String getDesc(int i) {
        return this.desc[i];
    }

    public void setDesc(int i, java.lang.String _value) {
        this.desc[i] = _value;
    }


    /**
     * Gets the refInfo value for this CompanyAgreement_Type.
     * 
     * @return refInfo
     */
    public RefInfo_Type[] getRefInfo() {
        return refInfo;
    }


    /**
     * Sets the refInfo value for this CompanyAgreement_Type.
     * 
     * @param refInfo
     */
    public void setRefInfo(RefInfo_Type[] refInfo) {
        this.refInfo = refInfo;
    }

    public RefInfo_Type getRefInfo(int i) {
        return this.refInfo[i];
    }

    public void setRefInfo(int i, RefInfo_Type _value) {
        this.refInfo[i] = _value;
    }


    /**
     * Gets the additionalFields value for this CompanyAgreement_Type.
     * 
     * @return additionalFields
     */
    public java.lang.String[] getAdditionalFields() {
        return additionalFields;
    }


    /**
     * Sets the additionalFields value for this CompanyAgreement_Type.
     * 
     * @param additionalFields
     */
    public void setAdditionalFields(java.lang.String[] additionalFields) {
        this.additionalFields = additionalFields;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CompanyAgreement_Type)) return false;
        CompanyAgreement_Type other = (CompanyAgreement_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.companyNameInd==null && other.getCompanyNameInd()==null) || 
             (this.companyNameInd!=null &&
              this.companyNameInd.equals(other.getCompanyNameInd()))) &&
            ((this.attachmentInd==null && other.getAttachmentInd()==null) || 
             (this.attachmentInd!=null &&
              this.attachmentInd.equals(other.getAttachmentInd()))) &&
            ((this.dateValInd==null && other.getDateValInd()==null) || 
             (this.dateValInd!=null &&
              this.dateValInd.equals(other.getDateValInd()))) &&
            ((this.currencyCode==null && other.getCurrencyCode()==null) || 
             (this.currencyCode!=null &&
              this.currencyCode.equals(other.getCurrencyCode()))) &&
            ((this.trnCode==null && other.getTrnCode()==null) || 
             (this.trnCode!=null &&
              this.trnCode.equals(other.getTrnCode()))) &&
            ((this.balTypeValInd==null && other.getBalTypeValInd()==null) || 
             (this.balTypeValInd!=null &&
              this.balTypeValInd.equals(other.getBalTypeValInd()))) &&
            ((this.curAmtValInd==null && other.getCurAmtValInd()==null) || 
             (this.curAmtValInd!=null &&
              this.curAmtValInd.equals(other.getCurAmtValInd()))) &&
            ((this.recVolumInd==null && other.getRecVolumInd()==null) || 
             (this.recVolumInd!=null &&
              this.recVolumInd.equals(other.getRecVolumInd()))) &&
            ((this.WSInd==null && other.getWSInd()==null) || 
             (this.WSInd!=null &&
              this.WSInd.equals(other.getWSInd()))) &&
            ((this.formatInd==null && other.getFormatInd()==null) || 
             (this.formatInd!=null &&
              this.formatInd.equals(other.getFormatInd()))) &&
            ((this.TINInfo==null && other.getTINInfo()==null) || 
             (this.TINInfo!=null &&
              this.TINInfo.equals(other.getTINInfo()))) &&
            ((this.collectType==null && other.getCollectType()==null) || 
             (this.collectType!=null &&
              this.collectType.equals(other.getCollectType()))) &&
            ((this.custPermId==null && other.getCustPermId()==null) || 
             (this.custPermId!=null &&
              this.custPermId.equals(other.getCustPermId()))) &&
            ((this.digitalCopyInd==null && other.getDigitalCopyInd()==null) || 
             (this.digitalCopyInd!=null &&
              this.digitalCopyInd.equals(other.getDigitalCopyInd()))) &&
            ((this.DBInd==null && other.getDBInd()==null) || 
             (this.DBInd!=null &&
              this.DBInd.equals(other.getDBInd()))) &&
            ((this.doubleCapInd==null && other.getDoubleCapInd()==null) || 
             (this.doubleCapInd!=null &&
              this.doubleCapInd.equals(other.getDoubleCapInd()))) &&
            ((this.creditCardInd==null && other.getCreditCardInd()==null) || 
             (this.creditCardInd!=null &&
              this.creditCardInd.equals(other.getCreditCardInd()))) &&
            ((this.debitCardInd==null && other.getDebitCardInd()==null) || 
             (this.debitCardInd!=null &&
              this.debitCardInd.equals(other.getDebitCardInd()))) &&
            ((this.chkInd==null && other.getChkInd()==null) || 
             (this.chkInd!=null &&
              this.chkInd.equals(other.getChkInd()))) &&
            ((this.rate==null && other.getRate()==null) || 
             (this.rate!=null &&
              this.rate.equals(other.getRate()))) &&
            ((this.billRefInfo==null && other.getBillRefInfo()==null) || 
             (this.billRefInfo!=null &&
              this.billRefInfo.equals(other.getBillRefInfo()))) &&
            ((this.balAmt==null && other.getBalAmt()==null) || 
             (this.balAmt!=null &&
              this.balAmt.equals(other.getBalAmt()))) &&
            ((this.billDt==null && other.getBillDt()==null) || 
             (this.billDt!=null &&
              this.billDt.equals(other.getBillDt()))) &&
            ((this.trnDt==null && other.getTrnDt()==null) || 
             (this.trnDt!=null &&
              this.trnDt.equals(other.getTrnDt()))) &&
            ((this.effDt==null && other.getEffDt()==null) || 
             (this.effDt!=null &&
              this.effDt.equals(other.getEffDt()))) &&
            ((this.endDt==null && other.getEndDt()==null) || 
             (this.endDt!=null &&
              this.endDt.equals(other.getEndDt()))) &&
            ((this.serviceCode==null && other.getServiceCode()==null) || 
             (this.serviceCode!=null &&
              this.serviceCode.equals(other.getServiceCode()))) &&
            ((this.desc==null && other.getDesc()==null) || 
             (this.desc!=null &&
              java.util.Arrays.equals(this.desc, other.getDesc()))) &&
            ((this.refInfo==null && other.getRefInfo()==null) || 
             (this.refInfo!=null &&
              java.util.Arrays.equals(this.refInfo, other.getRefInfo()))) &&
            ((this.additionalFields==null && other.getAdditionalFields()==null) || 
             (this.additionalFields!=null &&
              java.util.Arrays.equals(this.additionalFields, other.getAdditionalFields())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCompanyNameInd() != null) {
            _hashCode += getCompanyNameInd().hashCode();
        }
        if (getAttachmentInd() != null) {
            _hashCode += getAttachmentInd().hashCode();
        }
        if (getDateValInd() != null) {
            _hashCode += getDateValInd().hashCode();
        }
        if (getCurrencyCode() != null) {
            _hashCode += getCurrencyCode().hashCode();
        }
        if (getTrnCode() != null) {
            _hashCode += getTrnCode().hashCode();
        }
        if (getBalTypeValInd() != null) {
            _hashCode += getBalTypeValInd().hashCode();
        }
        if (getCurAmtValInd() != null) {
            _hashCode += getCurAmtValInd().hashCode();
        }
        if (getRecVolumInd() != null) {
            _hashCode += getRecVolumInd().hashCode();
        }
        if (getWSInd() != null) {
            _hashCode += getWSInd().hashCode();
        }
        if (getFormatInd() != null) {
            _hashCode += getFormatInd().hashCode();
        }
        if (getTINInfo() != null) {
            _hashCode += getTINInfo().hashCode();
        }
        if (getCollectType() != null) {
            _hashCode += getCollectType().hashCode();
        }
        if (getCustPermId() != null) {
            _hashCode += getCustPermId().hashCode();
        }
        if (getDigitalCopyInd() != null) {
            _hashCode += getDigitalCopyInd().hashCode();
        }
        if (getDBInd() != null) {
            _hashCode += getDBInd().hashCode();
        }
        if (getDoubleCapInd() != null) {
            _hashCode += getDoubleCapInd().hashCode();
        }
        if (getCreditCardInd() != null) {
            _hashCode += getCreditCardInd().hashCode();
        }
        if (getDebitCardInd() != null) {
            _hashCode += getDebitCardInd().hashCode();
        }
        if (getChkInd() != null) {
            _hashCode += getChkInd().hashCode();
        }
        if (getRate() != null) {
            _hashCode += getRate().hashCode();
        }
        if (getBillRefInfo() != null) {
            _hashCode += getBillRefInfo().hashCode();
        }
        if (getBalAmt() != null) {
            _hashCode += getBalAmt().hashCode();
        }
        if (getBillDt() != null) {
            _hashCode += getBillDt().hashCode();
        }
        if (getTrnDt() != null) {
            _hashCode += getTrnDt().hashCode();
        }
        if (getEffDt() != null) {
            _hashCode += getEffDt().hashCode();
        }
        if (getEndDt() != null) {
            _hashCode += getEndDt().hashCode();
        }
        if (getServiceCode() != null) {
            _hashCode += getServiceCode().hashCode();
        }
        if (getDesc() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDesc());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDesc(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRefInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRefInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRefInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAdditionalFields() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAdditionalFields());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAdditionalFields(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CompanyAgreement_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/agreement/v1/", "CompanyAgreement_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("companyNameInd");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CompanyNameInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "OpenEnum_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachmentInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AttachmentInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateValInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DateValInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currencyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CurrencyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trnCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TrnCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TrnCode_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("balTypeValInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BalTypeValInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("curAmtValInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CurAmtValInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recVolumInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RecVolumInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WSInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "WSInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formatInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FormatInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TINInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TINInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TINInfo_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("collectType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CollectType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("custPermId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustPermId"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CustPermId_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("digitalCopyInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DigitalCopyInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DBInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DBInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("doubleCapInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DoubleCapInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditCardInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CreditCardInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("debitCardInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DebitCardInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("chkInd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ChkInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "C"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Rate"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Decimal_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billRefInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BillRefInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BillRefInfo_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("balAmt");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BalAmt"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "CurrencyAmount_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billDt");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "BillDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Date_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trnDt");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "TrnDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Date_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("effDt");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "EffDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "DateTime_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endDt");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "EndDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "DateTime_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/product/v1/", "ServiceCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "OpenEnum_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desc");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Desc"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/ifx/base/v1/", "Desc"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/product/v1/", "RefInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/customers/product/v1/", "RefInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additionalFields");
        elemField.setXmlName(new javax.xml.namespace.QName("urn://bancodebogota.com/accounts/product/v1/", "AdditionalFields"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn://bancodebogota.com/accounts/product/v1/", "AdditionalFields_Type"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}