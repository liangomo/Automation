package Interfaz;


public class AppSingleton {

	private static App instance = new App();
	
	public AppSingleton() {		
	}
	
	public App getInstance() {
		
		if(instance == null) {
			instance = new App();
		}
		return instance;
	}

}
