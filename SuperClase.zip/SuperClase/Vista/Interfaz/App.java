package Interfaz;

import java.awt.ComponentOrientation;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import Ayudantes.MultiLineCellRenderer;
import Consultas.ConsultaTabla;
import Consultas.TraerAnalistas;
import Listeners.OyenteButton;

public class App extends JFrame
{
	private static final long serialVersionUID = 10;

	private JFrame frame = new JFrame();

	private JTabbedPane PanelSuperClase = new JTabbedPane(JTabbedPane.TOP),
			PanelEjecutar = new JTabbedPane(JTabbedPane.TOP);

	private JTextField textNomMetodo = new JTextField(),
			textBuscar = new JTextField();

	private JTextArea textAreaCodigo = new JTextArea(),
			txtAreaDescripcion = new JTextArea(),
			textAreaPreRequisitos = new JTextArea(),
			txtAutor = new JTextArea(),
			textAreaEjecucion = new JTextArea();

	private JButton btnAdicionar = new JButton("ADICIONAR"),
			btnLimpiar = new JButton("LIMPIAR"), 
			btnBuscar = new JButton("BUSCAR"),
			btnEjecutar = new JButton("EJECUTAR");

	private JPanel panelAgregar = new JPanel(),
			panelConsultarMetodo = new JPanel(),
			panelEjecutar = new JPanel();

	private JLabel lblNombreMetodo = new JLabel("Nombre Metodo"), 
			lblDescripcion = new JLabel("Descripci\u00F3n"),
			lblCodigo = new JLabel("Codigo"),
			lblAutor = new JLabel("Autor"),
			lblNewLabel_1 = new JLabel("Pre-Requisitos"),
			lblBuscar = new JLabel("Buscar Metodo");

	private JScrollPane scrollPane = new JScrollPane(), 
			scrollDescripcion = new JScrollPane(),
			scrollCodigo = new JScrollPane(),
			scrollPreRequisitos = new JScrollPane(),
			scrollTabla = new JScrollPane();

	private JTable tableMetodos = new JTable();

	private JMenuBar menuBar = new JMenuBar();
	private JMenu mnArchivo = new JMenu("Archivo");

	private JMenuItem mntmSuperclase = new JMenuItem("Super Clase"),
			mntmActualizarDatos = new JMenuItem("Actualizar Datos");

	private JCheckBox checkActClientes = new JCheckBox("Actualizar Clientes"),
			checkCtasCtes = new JCheckBox("Actualizar Cuentas Corrientes"),
			checkCreditos = new JCheckBox("Actualizar Creditos"),
			checkCtasAh = new JCheckBox("Actualizar Cuentas de Ahorros");

	private TraerAnalistas traerAnalistas = new TraerAnalistas();
	private ConsultaTabla consultarTabla = new ConsultaTabla();
	private DefaultTableModel model = new DefaultTableModel();
	private JLayeredPane layeredPane = new JLayeredPane();
	private JScrollPane scrollPane_1 = new JScrollPane();

	public App()
	{
		OyenteButton oyenteBoton = new OyenteButton();

		try 
		{
			Analista();
			cargarMetodos();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}

		frame.setBounds(100, 100, 925, 748);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		scrollPane.setSize(10, 106);
		mntmSuperclase.addActionListener(oyenteBoton);
		mntmActualizarDatos.addActionListener(oyenteBoton);
		PanelSuperClase.setBounds(0, 0, 909, 689);
		layeredPane.add(PanelSuperClase);

		PanelSuperClase.setVisible(false);
		btnBuscar.addActionListener(oyenteBoton);
		btnAdicionar.setBounds(692, 577, 106, 30);

		btnAdicionar.addActionListener(oyenteBoton);
		btnLimpiar.setBounds(557, 577, 106, 30);
		btnLimpiar.addActionListener(oyenteBoton);
		PanelSuperClase.addTab("Adicionar Metodo", null, panelAgregar, null);
		panelAgregar.setLayout(null);
		lblNombreMetodo.setBounds(31, 41, 106, 30);
		panelAgregar.add(lblNombreMetodo);
		textNomMetodo.setBounds(125, 46, 281, 20);
		panelAgregar.add(textNomMetodo);
		textNomMetodo.setColumns(10);
		lblAutor.setBounds(423, 49, 46, 14);
		panelAgregar.add(lblAutor);
		txtAutor.setBounds(531, 46, 281, 20);
		txtAutor.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtAutor.setForeground(SystemColor.desktop);
		txtAutor.setBackground(SystemColor.menu);
		txtAutor.setEditable(false);
		panelAgregar.add(txtAutor);
		lblDescripcion.setBounds(31, 89, 106, 30);
		panelAgregar.add(lblDescripcion);
		scrollDescripcion.setBounds(125, 96, 281, 134);

		scrollDescripcion.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		scrollDescripcion.setAutoscrolls(true);
		panelAgregar.add(scrollDescripcion);

		txtAreaDescripcion.setLineWrap(true);
		scrollDescripcion.setViewportView(txtAreaDescripcion);
		lblNewLabel_1.setBounds(423, 89, 106, 30);
		panelAgregar.add(lblNewLabel_1);
		scrollPreRequisitos.setBounds(517, 96, 281, 134);
		panelAgregar.add(scrollPreRequisitos);

		textAreaPreRequisitos.setLineWrap(true);
		textAreaPreRequisitos.setWrapStyleWord(true);
		textAreaPreRequisitos.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		textAreaPreRequisitos.setColumns(1);
		scrollPreRequisitos.setViewportView(textAreaPreRequisitos);
		lblCodigo.setBounds(31, 228, 106, 30);
		panelAgregar.add(lblCodigo);
		scrollCodigo.setBounds(125, 241, 675, 325);
		panelAgregar.add(scrollCodigo);

		textAreaCodigo.setLineWrap(true);
		scrollCodigo.setViewportView(textAreaCodigo);
		panelAgregar.add(btnAdicionar);
		panelAgregar.add(btnLimpiar);

		PanelSuperClase.addTab("Consultar Metodo", null, panelConsultarMetodo, null);
		panelConsultarMetodo.setLayout(null);
		lblBuscar.setBounds(62, 56, 102, 23);

		panelConsultarMetodo.add(lblBuscar);

		textBuscar.setBounds(171, 57, 401, 20);
		panelConsultarMetodo.add(textBuscar);
		textBuscar.setColumns(10);

		scrollTabla.setBounds(63, 106, 801, 478);
		panelConsultarMetodo.add(scrollTabla);

		scrollTabla.setViewportView(tableMetodos);
		tableMetodos.setColumnSelectionAllowed(true);
		tableMetodos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableMetodos.setCellSelectionEnabled(true);
		tableMetodos.setModel(model);
		centrar_datos(tableMetodos.getColumnCount());
		tableMetodos.setDefaultRenderer(Object.class, new MultiLineCellRenderer());
		tableMetodos.setRowHeight(100);

		btnBuscar.setBounds(612, 56, 89, 23);
		panelConsultarMetodo.add(btnBuscar);
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
				groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(layeredPane, GroupLayout.PREFERRED_SIZE, 909, GroupLayout.PREFERRED_SIZE)
				);
		groupLayout.setVerticalGroup(
				groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(layeredPane, GroupLayout.PREFERRED_SIZE, 689, GroupLayout.PREFERRED_SIZE)
				);
		PanelEjecutar.setBounds(0, 0, 909, 689);
		layeredPane.add(PanelEjecutar);
		PanelEjecutar.setVisible(false);
		PanelEjecutar.addTab("Ejecutar", null, panelEjecutar, null);
		panelEjecutar.setLayout(null);
		
		
				checkActClientes.setBounds(141, 110, 213, 23);
				panelEjecutar.add(checkActClientes);
				checkActClientes.addActionListener(oyenteBoton);
				
						checkCtasCtes.setBounds(141, 136, 213, 23);
						panelEjecutar.add(checkCtasCtes);
						checkCtasCtes.addActionListener(oyenteBoton);
						
								checkCreditos.setBounds(141, 188, 213, 23);
								panelEjecutar.add(checkCreditos);
								checkCtasAh.setBounds(141, 162, 213, 23);
								checkCreditos.addActionListener(oyenteBoton);
								checkCtasAh.addActionListener(oyenteBoton);
								panelEjecutar.add(checkCtasAh);
								
										btnEjecutar.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
										btnEjecutar.setActionCommand("EJECUTAR");
										btnEjecutar.setBounds(515, 352, 106, 30);
										btnEjecutar.addActionListener(oyenteBoton);
										panelEjecutar.add(btnEjecutar);
										scrollPane_1.setBounds(0, 0, 2, 2);
										
										
												panelEjecutar.add(scrollPane_1);
												
														textAreaEjecucion.setBounds(387, 95, 426, 237);
														panelEjecutar.add(textAreaEjecucion);
		frame.getContentPane().setLayout(groupLayout);

		frame.setJMenuBar(menuBar);

		menuBar.add(mnArchivo);
		mntmActualizarDatos.setActionCommand("ActualizarDatos");
		mnArchivo.add(mntmActualizarDatos);
		mnArchivo.add(mntmSuperclase);

		frame.setVisible(true);
	}


	public JFrame getFrame() {
		return frame;
	}


	public void setFrame(JFrame frame) {
		this.frame = frame;
	}


	public JTabbedPane getPanelSuperClase() {
		return PanelSuperClase;
	}


	public void setPanelSuperClase(JTabbedPane panelSuperClase) {
		PanelSuperClase = panelSuperClase;
	}

	public void setPanelEjecutar(JTabbedPane panelEjecutar) {
		PanelEjecutar = panelEjecutar;
	}


	public JTextField getTextNomMetodo() {
		return textNomMetodo;
	}


	public void setTextNomMetodo(JTextField textNomMetodo) {
		this.textNomMetodo = textNomMetodo;
	}


	public JTextField getTextBuscar() {
		return textBuscar;
	}


	public void setTextBuscar(JTextField textBuscar) {
		this.textBuscar = textBuscar;
	}


	public JTextArea getTextAreaCodigo() {
		return textAreaCodigo;
	}


	public void setTextAreaCodigo(JTextArea textAreaCodigo) {
		this.textAreaCodigo = textAreaCodigo;
	}


	public JTextArea getTxtAreaDescripcion() {
		return txtAreaDescripcion;
	}


	public void setTxtAreaDescripcion(JTextArea txtAreaDescripcion) {
		this.txtAreaDescripcion = txtAreaDescripcion;
	}


	public JTextArea getTextAreaPreRequisitos() {
		return textAreaPreRequisitos;
	}


	public void setTextAreaPreRequisitos(JTextArea textAreaPreRequisitos) {
		this.textAreaPreRequisitos = textAreaPreRequisitos;
	}


	public JTextArea getTxtAutor() {
		return txtAutor;
	}


	public void setTxtAutor(JTextArea txtAutor) {
		this.txtAutor = txtAutor;
	}


	public JTextArea getTextAreaEjecucion() {
		return textAreaEjecucion;
	}


	public void setTextAreaEjecucion(JTextArea textAreaEjecucion) {
		this.textAreaEjecucion = textAreaEjecucion;
	}


	public JButton getBtnAdicionar() {
		return btnAdicionar;
	}


	public void setBtnAdicionar(JButton btnAdicionar) {
		this.btnAdicionar = btnAdicionar;
	}


	public JButton getBtnLimpiar() {
		return btnLimpiar;
	}


	public void setBtnLimpiar(JButton btnLimpiar) {
		this.btnLimpiar = btnLimpiar;
	}


	public JButton getBtnBuscar() {
		return btnBuscar;
	}


	public void setBtnBuscar(JButton btnBuscar) {
		this.btnBuscar = btnBuscar;
	}


	public JPanel getPanelAgregar() {
		return panelAgregar;
	}


	public void setPanelAgregar(JPanel panelAgregar) {
		this.panelAgregar = panelAgregar;
	}


	public JPanel getPanelConsultarMetodo() {
		return panelConsultarMetodo;
	}


	public void setPanelConsultarMetodo(JPanel panelConsultarMetodo) {
		this.panelConsultarMetodo = panelConsultarMetodo;
	}


	public JPanel getPanelEjecutar() {
		return panelEjecutar;
	}


	public void setPanelEjecutar(JPanel panelEjecutar) {
		this.panelEjecutar = panelEjecutar;
	}


	public JLabel getLblNombreMetodo() {
		return lblNombreMetodo;
	}


	public void setLblNombreMetodo(JLabel lblNombreMetodo) {
		this.lblNombreMetodo = lblNombreMetodo;
	}


	public JLabel getLblDescripcion() {
		return lblDescripcion;
	}


	public void setLblDescripcion(JLabel lblDescripcion) {
		this.lblDescripcion = lblDescripcion;
	}


	public JLabel getLblCodigo() {
		return lblCodigo;
	}


	public void setLblCodigo(JLabel lblCodigo) {
		this.lblCodigo = lblCodigo;
	}


	public JLabel getLblAutor() {
		return lblAutor;
	}


	public void setLblAutor(JLabel lblAutor) {
		this.lblAutor = lblAutor;
	}


	public JLabel getLblNewLabel_1() {
		return lblNewLabel_1;
	}


	public void setLblNewLabel_1(JLabel lblNewLabel_1) {
		this.lblNewLabel_1 = lblNewLabel_1;
	}


	public JLabel getLblBuscar() {
		return lblBuscar;
	}


	public void setLblBuscar(JLabel lblBuscar) {
		this.lblBuscar = lblBuscar;
	}


	public JScrollPane getScrollPane() {
		return scrollPane;
	}


	public void setScrollPane(JScrollPane scrollPane) {
		this.scrollPane = scrollPane;
	}


	public JScrollPane getScrollDescripcion() {
		return scrollDescripcion;
	}


	public void setScrollDescripcion(JScrollPane scrollDescripcion) {
		this.scrollDescripcion = scrollDescripcion;
	}


	public JScrollPane getScrollCodigo() {
		return scrollCodigo;
	}


	public void setScrollCodigo(JScrollPane scrollCodigo) {
		this.scrollCodigo = scrollCodigo;
	}


	public JScrollPane getScrollPreRequisitos() {
		return scrollPreRequisitos;
	}


	public void setScrollPreRequisitos(JScrollPane scrollPreRequisitos) {
		this.scrollPreRequisitos = scrollPreRequisitos;
	}


	public JScrollPane getScrollTabla() {
		return scrollTabla;
	}


	public void setScrollTabla(JScrollPane scrollTabla) {
		this.scrollTabla = scrollTabla;
	}


	public JTable getTableMetodos() {
		return tableMetodos;
	}


	public void setTableMetodos(JTable tableMetodos) {
		this.tableMetodos = tableMetodos;
	}

	public void setMenuBar(JMenuBar menuBar) {
		this.menuBar = menuBar;
	}


	public JMenu getMnArchivo() {
		return mnArchivo;
	}


	public void setMnArchivo(JMenu mnArchivo) {
		this.mnArchivo = mnArchivo;
	}


	public JMenuItem getMntmSuperclase() {
		return mntmSuperclase;
	}


	public void setMntmSuperclase(JMenuItem mntmSuperclase) {
		this.mntmSuperclase = mntmSuperclase;
	}


	public JMenuItem getMntmActualizarDatos() {
		return mntmActualizarDatos;
	}


	public void setMntmActualizarDatos(JMenuItem mntmActualizarDatos) {
		this.mntmActualizarDatos = mntmActualizarDatos;
	}


	public TraerAnalistas getTraerAnalistas() {
		return traerAnalistas;
	}


	public void setTraerAnalistas(TraerAnalistas traerAnalistas) {
		this.traerAnalistas = traerAnalistas;
	}


	public ConsultaTabla getConsultarTabla() {
		return consultarTabla;
	}


	public void setConsultarTabla(ConsultaTabla consultarTabla) {
		this.consultarTabla = consultarTabla;
	}


	public DefaultTableModel getModel() {
		return model;
	}


	public void setModel(DefaultTableModel model) {
		this.model = model;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public JLayeredPane getLayeredPane() {
		return layeredPane;
	}


	public JCheckBox getCheckBox() {
		return checkCtasAh;
	}


	public JScrollPane getScrollPane_1() {
		return scrollPane_1;
	}


	public void limpiar() throws Exception
	{
		this.textAreaCodigo.setText("");
		this.textAreaPreRequisitos.setText("");
		this.textNomMetodo.setText("");
		this.txtAreaDescripcion.setText("");
		Analista();
		cargarMetodos();
		this.tableMetodos.setModel(model);
	}

	public void habilitar(String variable)
	{
		if(variable.equals("SuperClase"))
		{
			this.mntmSuperclase.setEnabled(false);
			this.mntmActualizarDatos.setEnabled(true);
			this.PanelSuperClase.setVisible(true);
			this.PanelEjecutar.setVisible(false);
		}
		if(variable.equals("ActualizarDatos"))
		{
			this.mntmSuperclase.setEnabled(true);
			this.mntmActualizarDatos.setEnabled(false);
			this.PanelSuperClase.setVisible(false);
			this.PanelEjecutar.setVisible(true);
		}		
	}

	public void Analista() throws Exception
	{
		String Analista = traerAnalistas.ConsultarAnalista();
		
		this.txtAutor.setText(Analista);
	}

	public void cargarMetodos() throws Exception
	{
		model = consultarTabla.ConsultarMetodos("SELECT S.CodMetodo as 'Cod Metodo', S.NombreMetodo as 'Nom Metodo', "
				+ "S.Descripcion as Descripcion, S.PreRequisitos as PreRequisitos, S.CodigoFuente as 'Codigo Fuente', "
				+ "A.NombreAnalista as 'Analista' FROM SuperClase S, Analistas A WHERE A.CodAnalista = S.CodAnalista");
	}

	public void mensaje() {
		JOptionPane.showMessageDialog(null,"REGISTRO AGREGADO CON EXITO", "Information", JOptionPane.INFORMATION_MESSAGE);
	}

	public void centrar_datos(int col)
	{  
		DefaultTableCellRenderer modelocentrar = new DefaultTableCellRenderer(); 

		for(int i = 0; i < col; i++)
		{
			if(i == 0 ||  i == 5)
			{
				modelocentrar.setVerticalAlignment(SwingConstants.CENTER);
				modelocentrar.setHorizontalAlignment(SwingConstants.CENTER);
				tableMetodos.getColumnModel().getColumn(i).setCellRenderer(modelocentrar);
			}
		}
	}

	public void consultaTabla(String query) throws Exception 
	{
		model = consultarTabla.ConsultarMetodos(query);
		this.tableMetodos.setModel(model);
	}


	public void ejecutando(String mensaje) {
		System.out.println(mensaje);
		
	}	
}