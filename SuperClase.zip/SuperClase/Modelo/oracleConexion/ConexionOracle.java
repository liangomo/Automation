package oracleConexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConexionOracle 
{
	Connection conn;

	@SuppressWarnings("unused")
	public void conectar() throws SQLException 
	{
		DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
		conn = DriverManager.getConnection("jdbc:oracle:thin:@AQUILES48:1526:PRCRTO", "Calidad_Consulta", "C4lid4d$");
		Statement stmt = conn.createStatement();
		ResultSet rset = stmt.executeQuery("select BANNER from SYS.V_$VERSION");
	}

	public ResultSet consultar(String sql) 
	{
		ResultSet resultado = null;

		try 
		{
			Statement sentencia;
			sentencia = getConn().createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			resultado = sentencia.executeQuery(sql);
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			return null;
		}
		return resultado;
	}

	/** desconecta de la base de datos */
	public void desconectar()throws Exception
	{
		if(!this.getConn().isClosed())
			this.setConn(null);
	}
	public Connection getConn() 
	{
		return conn;
	}
	public void setConn(Connection conn)
	{
		this.conn = conn;
	}
}
