package lecturaEscrituraArchivos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Lectura 
{
	String rutaArchivo = "\\\\juno13p\\LISTADOS\\";
	static final String[] MESES_ABREV = {"ENE","FEB","MAR","ABR","MAY","JUN","JUL","AGO","SEP","OCT","NOV","DIC"};
	static final String[] MESES = {"ENERO","FEBRERO","MARZO","ABRIL","MAYO","JUNIO","JULIO","AGOSTO","SEPTIEMBRE","OCTUBRE","NOVIEMBRE","DICIEMBRE"};

	// M�todo para la generacion o apertura del archivo 
	public FileReader generacionArchivo(String nombreArchivo) throws FileNotFoundException
	{	
		FileReader fichero = null;
		NombreArchivo(nombreArchivo);
		fichero = new FileReader(rutaArchivo);
		return fichero;	
	}

	public void lectura (FileReader fichero) throws IOException
	{
		@SuppressWarnings("unused")
		BufferedReader bf = new BufferedReader(fichero);
	}

	// M�todo para cerrar y cuardar el archivo	
	public void cerrarArchivo(FileReader fichero) throws IOException 
	{
		fichero.close();
	}

	public String reemplazar(String cadena, String busqueda, String reemplazo)
	{
		return cadena.replaceAll(busqueda, reemplazo);	
	}

	public void NombreArchivo(String arch)
	{
		String nombArch = null;
		String[] fech = null;
		int i = 0;

		for(i = 0; i < 31; i++)
		{
			fech = fechas(i);
			rutaArchivo = "\\\\juno13p\\LISTADOS\\";

			if(arch.equals("AHORROS"))
				nombArch = "DISPLAY_AHORROS_FIDELITY.TXT";

			if(arch.equals("CTASCTES"))
				nombArch = "DISPLAY_IMPACS_FIDELITY.TXT";

			rutaArchivo = rutaArchivo + arch + "\\SNV2\\" + fech[3] + "\\" + fech[2] + "\\" + fech[1] + "_" + fech[0] + "\\" + nombArch;
			File comp = new File(rutaArchivo);

			if(comp.exists())
				i = 31;
		}
	}

	public String[] fechas(int i)
	{
		String[] fechas = {"0", "0", "0", "0"};
		String dia, mes , annio;

		Calendar c = Calendar.getInstance();
		GregorianCalendar calendar = new GregorianCalendar();

		int MM = c.get(Calendar.MONTH) + 1;
		int DD = (c.get(Calendar.DATE) - i);
		int AA = c.get(Calendar.YEAR);

		if(DD <= 0)
		{
			if (MM == 1)
				MM = 12;
			else
				MM = MM - 1;

			if(MM == 1 || MM == 3 || MM == 5 || MM == 7 || MM == 8 || MM == 10 || MM == 12)
				DD = 31 + DD;
			if(MM == 4 || MM == 6 || MM == 9 || MM == 11)
				DD = 30 + DD;
			if(MM == 2)
			{
				if(calendar.isLeapYear(AA))
				{
					DD = 29 + DD;
				}
				else
					DD = 28 + DD;
			}

		}

		dia = Integer.toString(DD);
		mes = Integer.toString(MM);

		if(MM < 10)
		{
			mes = "0" + mes; 
		}

		if(DD < 10)
		{
			dia = "0" + dia;
		}

		annio = Integer.toString(c.get(Calendar.YEAR));

		char op = 0;

		if(mes.equals("01") || mes.equals("03") || mes.equals("05") || mes.equals("07") || mes.equals("08") || mes.equals("10") || mes.equals("12"))
			op = '1';
		else
			if(mes.equals("04") || mes.equals("06") || mes.equals("09") || mes.equals("11"))
				op = '2';
			else
				op = '3';

		switch (op)
		{
		case '1':
			fechas[0] = dia; 
			fechas[1] = MESES_ABREV[MM - 1];
			fechas[2] = MESES[MM - 1];
			fechas[3] = annio;
			break;

		case '2':
			fechas[0] = dia; 
			fechas[1] = MESES_ABREV[MM - 1];
			fechas[2] = MESES[MM - 1];
			fechas[3] = annio;
			break;

		case '3':
			fechas[0] = dia; 
			fechas[1] = MESES_ABREV[MM - 1];
			fechas[2] = MESES[MM - 1];
			fechas[3] = annio;
			break;
		}
		return fechas;
	}

	public String mes31(String d, String m, String a)
	{
		String ds, ms, as, fs;

		if(d.equals("31"))
		{
			ds = "01";

			if(m.equals("12"))
			{
				ms = "01";
				int AA = Integer.parseInt(a);
				AA = AA + 1;

				as = Integer.toString(AA);
				fs = ds + ms + as;
			}
			else
			{
				int MM = Integer.parseInt(m);
				MM = MM + 1;

				ms = Integer.toString(MM);

				if( MM < 10)
					ms = "0" + ms;

				as = a;
				fs = ds + ms + as;
			}
		}
		else
		{
			int di = Integer.parseInt(d);
			di = di + 1 ;

			ds = Integer.toString(di);

			if(di < 10)
				ds = "0" + ds;

			fs = ds + m + a;
		}

		return fs;
	}

	public String mes30(String d, String m, String a)
	{
		String ds, ms, as, fs;

		if(d.equals("30"))
		{
			ds = "01";

			int MM = Integer.parseInt(m);
			MM = MM + 1;

			ms = Integer.toString(MM);

			if( MM < 10)
				ms = "0" + ms;

			as = a;
			fs = ds + ms + as;
		}
		else
		{
			int di = Integer.parseInt(d);
			di = di + 1 ;

			ds = Integer.toString(di);

			if(di < 10)
				ds = "0" + ds;

			fs = ds + m + a;
		}

		return fs;
	}

	public String mesF(String d, String m, String a)
	{
		String ds = null, ms, fs = null;

		int AA = Integer.parseInt(a);

		GregorianCalendar calendar = new GregorianCalendar();

		if(calendar.isLeapYear(AA))
		{
			if(d.equals("29"))
			{
				ds = "01";

				int MM = Integer.parseInt(m);
				MM = MM + 1;

				ms = Integer.toString(MM);

				if( MM < 10)
					ms = "0" + ms;

				fs = ds + ms + a;
			}
			else
			{
				int di = Integer.parseInt(d);
				di = di + 1 ;

				ds = Integer.toString(di);

				if(di < 10)
					ds = "0" + ds;

				fs = ds + m + a;
			}
		}
		else
		{
			if(d.equals("28"))
			{
				ds = "01";

				int MM = Integer.parseInt(m);
				MM = MM + 1;

				ms = Integer.toString(MM);

				if( MM < 10)
					ms = "0" + ms;

				fs = ds + ms + a;
			}
			else
			{
				int di = Integer.parseInt(d);
				di = di + 1 ;

				ds = Integer.toString(di);

				if(di < 10)
					ds = "0" + ds;

				fs = ds + m + a;
			}
		}
		return fs;
	}
}
