package sqlConexion;

import java.sql.ResultSet;
import java.sql.Statement;

public class ConsultaSQL {

	public ResultSet Consulta (String Sentencia) throws Exception {

		ConexionSQL conexion = new ConexionSQL();

		conexion.conectar();

		Statement st = conexion.getConexion().createStatement();

		ResultSet rs = st.executeQuery(Sentencia); 

		conexion.desconectar();

		return rs;

	}

}
