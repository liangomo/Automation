package Ejecutable;

import Interfaz.AppSingleton;

public class Ejecutable 
{
	public static void main(String[] args) {	
		new AppSingleton();
	}
}