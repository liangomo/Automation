package displayAhorros;

import java.io.BufferedReader;
import java.sql.ResultSet;
import java.sql.Statement;

import Interfaz.App;
import Interfaz.AppSingleton;

import lecturaEscrituraArchivos.Lectura;
import sqlConexion.ConexionSQL;

public class Ahorros {

	AppSingleton appSingleton = new Interfaz.AppSingleton();
	App app = null;

	public Ahorros() throws Exception {

		Lectura lectura = new Lectura();

		app = appSingleton.getInstance();

		ConexionSQL conexion = new ConexionSQL();

		conexion.conectar();

		Statement st = conexion.getConexion().createStatement();
		ResultSet rs = null;

		BufferedReader bf = new BufferedReader(lectura.generacionArchivo("AHORROS"));

		String linea = "";
		String stringTipoID = "", stringNoID = "", stringNoCuenta = "", stringTipoCuenta = "", stringEstadoCuenta = "",
				stringOficina = "", stringTipoTitularidad = "";

		int contador = 0;
		String SaldoCuenta = "";

		bf.readLine();

		// st.executeUpdate( "DELETE FROM
		// [DesembolsosPPE].[dbo].[CuentasAhorros]");

		while ((linea = bf.readLine()) != null) {

			if (linea.length() > 0) {

				if (linea.substring(0, 1).equals("0")) {

					stringTipoID = linea.substring(35, 36);
					stringNoID = linea.substring(37, 48);
					stringNoCuenta = linea.substring(15, 29);
					stringTipoCuenta = linea.substring(99, 102);
					stringEstadoCuenta = linea.substring(103, 105);
					SaldoCuenta = linea.substring(133, 146).trim();
					stringOficina = linea.substring(30, 34);
					stringTipoTitularidad = linea.substring(1448, 1449);

					if (stringTipoID.equals("0")) {
						stringTipoID = "C";
					} else {
						if (stringTipoID.equals("1")) {
							stringTipoID = "N";
						} else {
							if (stringTipoID.equals("2")) {
								stringTipoID = "T";
							} else {
								if (stringTipoID.equals("3")) {
									stringTipoID = "R";
								} else {
									if (stringTipoID.equals("4")) {

										if (stringNoID.length() > 7)
											stringTipoID = "I";
										else
											stringTipoID = "E";
									} else {
										if (stringTipoID.equals("5")) {
											stringTipoID = "P";
										} else {
											if (stringTipoID.equals("6")) {
												stringTipoID = "S";
											} else {
												stringTipoID = "L";
											}
										}
									}
								}
							}
						}
					}

				}

				stringNoCuenta = stringNoCuenta.substring(stringNoCuenta.length() - 9, stringNoCuenta.length());

				stringNoID = stringNoID.replaceAll(" ", "");

				long Variabletmp2 = Long.parseLong(stringNoID);

				stringNoID = Variabletmp2 + "";

				rs = st.executeQuery("SELECT * FROM Cuenta WHERE No_Cuenta='" + stringNoCuenta + "'");

				
				
				if (!rs.next()) {
					
					System.out.println("INSERT INTO Cuenta(No_Cuenta, Tipo_Cuenta, Saldo, Oficina, Tipo_Titularidad, Automatizacion, "
							+ "Codigo_Estado, Codigo_Producto)"
							+ " VALUES('" + stringNoCuenta + "', 'Ahorros', '" + SaldoCuenta + "', '"
							+ stringOficina + "', '" + stringTipoTitularidad + "', 0, " + "'" + stringEstadoCuenta
							+ "', '" + stringTipoCuenta + "')");
					st.executeUpdate("INSERT INTO Cuenta(No_Cuenta, Tipo_Cuenta, Saldo, Oficina, Tipo_Titularidad, Automatizacion, "
							+ "Codigo_Estado, Codigo_Producto)"
							+ " VALUES('" + stringNoCuenta + "', 'Ahorros', '" + SaldoCuenta + "', '"
							+ stringOficina + "', '" + stringTipoTitularidad + "', 0, " + "'" + stringEstadoCuenta
							+ "', '" + stringTipoCuenta + "')");

					System.out.println("INSERT INTO Cliente_Cuenta(No_Documento, TipoID, No_Cuenta) "
							+ "VALUES('" + stringNoID + "', '" + stringTipoID + "', '" + stringNoCuenta + "')");
					
					st.executeUpdate("INSERT INTO Cliente_Cuenta(No_Documento, TipoID, No_Cuenta) "
							+ "VALUES('" + stringNoID + "', '" + stringTipoID + "', '" + stringNoCuenta + "')");
					
					contador++;
				}
			}
		}

		app.ejecutando("" + contador);

		bf.close();

		conexion.desconectar();

	}

}
