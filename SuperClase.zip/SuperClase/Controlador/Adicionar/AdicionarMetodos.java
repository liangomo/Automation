package Adicionar;

import java.sql.ResultSet;
import java.sql.Statement;

import sqlConexion.ConexionSQL;
import sqlConexion.ConsultaSQL;

public class AdicionarMetodos {

	public AdicionarMetodos(String metodo, String descripcion, String preRequisitos, String codigo, String autor) throws Exception
	{
		ConexionSQL conexion = new ConexionSQL();
		ConsultaSQL consulta = new ConsultaSQL();

		conexion.conectar();

		Statement st = conexion.getConexion().createStatement();
		ResultSet rs = null;

		rs = consulta.Consulta("SELECT CodMetodo FROM SuperClase");
		String Cadena;
		int valor = 0;

		while (rs.next()) 
		{ 
			Cadena = rs.getString("CodMetodo");
			valor = Integer.parseInt(Cadena.substring(3));
		}
		
		String ID = "";
		valor++;
		
		if(valor < 10)
			ID = "ME-00" + valor;
		else
			if(valor < 100)
				ID ="ME-0"+ valor;
			else
				ID = "ME-"+ valor;
		
		rs = consulta.Consulta("SELECT CodAnalista FROM Analistas WHERE NombreAnalista = '" + autor + "'");
		rs.next();
		
		autor = rs.getString("CodAnalista");
		System.out.println("INSERT INTO SuperClase VALUES('"+ ID +"','" + metodo + "','" + descripcion + "','" + preRequisitos + "','" + codigo + "','" + autor +"')");
		st.executeUpdate("INSERT INTO SuperClase VALUES('"+ ID +"','" + metodo + "','" + descripcion + "','" + preRequisitos + "','" + codigo + "','" + autor +"')");
		
		conexion.desconectar();
		
	}
}

