package displayCorrientes;

import java.io.BufferedReader;
import java.sql.ResultSet;
import java.sql.Statement;

import Interfaz.App;
import Interfaz.AppSingleton;

import sqlConexion.*;
import lecturaEscrituraArchivos.*;

public class Corrientes {

	AppSingleton appSingleton = new Interfaz.AppSingleton();
	App app = null;

	public Corrientes() throws Exception {

		Lectura lectura = new Lectura();

		ConexionSQL conexion = new ConexionSQL();

		app = appSingleton.getInstance();

		conexion.conectar();

		Statement st = conexion.getConexion().createStatement();
		ResultSet rs = null;

		BufferedReader bf = new BufferedReader(lectura.generacionArchivo("CTASCTES"));

		String linea = "";

		String stringTipoID = "", stringNoID = "", stringNoIDtmp = "", stringNoCuenta = "", stringTipoCuenta = "",
				stringEstadoCuenta = "", stringSaldoCuenta = "", stringOficina = "", stringTipoTitularidad = "";

		int contador = 0;

		while ((linea = bf.readLine()) != null) {

			stringTipoID = linea.substring(100, 101);
			stringNoIDtmp = linea.substring(101, 111);

			stringNoCuenta = linea.substring(13, 22);
			stringTipoCuenta = linea.substring(305, 308);

			if (!stringTipoCuenta.equals("020"))
				stringTipoCuenta = "010";

			stringEstadoCuenta = linea.substring(23, 25);
			stringSaldoCuenta = linea.substring(26, 43);
			stringOficina = linea.substring(62, 66);
			stringTipoTitularidad = linea.substring(1, 2);

			if (stringTipoID.equals("C")) {
				if (!stringNoIDtmp.substring(stringNoIDtmp.length() - 1, stringNoIDtmp.length()).equals("0")) {
					stringNoID = stringNoIDtmp;
				} else {
					stringNoID = stringNoIDtmp.substring(0, 9);
				}
			} else {
				stringNoID = stringNoIDtmp;
			}

			stringNoID = stringNoID.replaceAll(" ", "");

			long Variabletmp2 = Long.parseLong(stringNoID);

			stringNoID = Variabletmp2 + "";

			stringSaldoCuenta = stringSaldoCuenta.replace(",", ""); 
			
			rs = st.executeQuery("SELECT * FROM Cuenta WHERE No_Cuenta='" + stringNoCuenta + "'");

			if (!rs.next()) {

				System.out.println(
						"INSERT INTO Cuenta(No_Cuenta, Tipo_Cuenta, Saldo, Oficina, Tipo_Titularidad, Automatizacion, "
								+ "Codigo_Estado, Codigo_Producto)" + " VALUES('" + stringNoCuenta + "', 'Corriente', "
								+ stringSaldoCuenta + ", '" + stringOficina + "', '" + stringTipoTitularidad + "', 0, "
								+ "'" + stringEstadoCuenta + "', '" + stringTipoCuenta + "')");

				System.out.println("INSERT INTO Cliente_Cuenta(No_Documento, TipoID, No_Cuenta) " + "VALUES('"
						+ stringNoID + "', '" + stringTipoID + "', '" + stringNoCuenta + "')");

				st.executeUpdate(
						"INSERT INTO Cuenta(No_Cuenta, Tipo_Cuenta, Saldo, Oficina, Tipo_Titularidad, Automatizacion, "
								+ "Codigo_Estado, Codigo_Producto)" + " VALUES('" + stringNoCuenta + "', 'Corriente', '"
								+ stringSaldoCuenta + "', '" + stringOficina + "', '" + stringTipoTitularidad + "', 0, "
								+ "'" + stringEstadoCuenta + "', '" + stringTipoCuenta + "')");

				st.executeUpdate("INSERT INTO Cliente_Cuenta(No_Documento, TipoID, No_Cuenta) " + "VALUES('"
						+ stringNoID + "', '" + stringTipoID + "', '" + stringNoCuenta + "')");
				//
				// "INSERT INTO Cuenta "
				// + "(TipoID "
				// + ",NoID "
				// + ",NoCuenta "
				// + ",TipoCuenta "
				// + ",Estado "
				// + ",Saldo "
				// + ",Oficina "
				// + ",TipoTitularidad) "
				// + "VALUES "
				// + "('"+stringTipoID+"', "
				// + " '"+stringNoID+"', "
				// + " '"+stringNoCuenta+"', "
				// + " '"+stringTipoCuenta+"', "
				// + " '"+stringEstadoCuenta+"', "
				// + " '"+stringSaldoCuenta+"', "
				// + " '"+stringOficina+"', "
				// + " '"+stringTipoTitularidad+"') " );
				contador++;
			}
		}

		app.ejecutando("" + contador);

		bf.close();

		conexion.desconectar();
	}
}
