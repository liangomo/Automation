package actualizarClientes;

import java.sql.ResultSet;
import java.sql.Statement;

import Interfaz.App;
import Interfaz.AppSingleton;

import oracleConexion.ConexionOracle;
import sqlConexion.ConexionSQL;

public class ClientesCreditos {

	@SuppressWarnings("unused")
	public ClientesCreditos() throws Exception {

		String stringTipoID = "", DigitoVerificacion = "", stringNoID = "";
		AppSingleton appSingleton = new Interfaz.AppSingleton();
		App app = null;
		app = appSingleton.getInstance();
		ConexionOracle conexionOracle = new ConexionOracle();
		conexionOracle.conectar();
		Statement stOracle = conexionOracle.getConn().createStatement();
		ResultSet rsOracle = null;

		ConexionSQL conexionSQL = new ConexionSQL();
		conexionSQL.conectar();
		Statement stSql = conexionSQL.getConexion().createStatement();
		ResultSet rsSql = null;

		rsOracle = stOracle.executeQuery("select unique " + "t.CLI_TIPO_IDENTIFICACION, "
				+ "t.CLI_IDENTIFICACION_CLIENTE, " + "t.NUMERO_CREDITO, " + "t.ES_ESTADO, " + "t.PRODUCTO_ALS "
				+ "from cartera.creditos t, cartera.estados c, cartera.lineas_creditos l "
				+ "where trim(t.es_estado)=trim(c.estado) " + "and trim(t.licre_codigo_linea)=trim(l.codigo_linea) "
				+ "and t.PRODUCTO_ALS is not null " + "order by CLI_TIPO_IDENTIFICACION asc");

		while (rsOracle.next()) {

			stringTipoID = "";
			DigitoVerificacion = "";
			stringNoID = rsOracle.getString("CLI_IDENTIFICACION_CLIENTE").replaceAll(" ", "");

			// INICIO COMPARACION DE TIPO DE CLIENTE
			if (rsOracle.getString("CLI_TIPO_IDENTIFICACION").replaceAll(" ", "").equals("CC")) {
				stringTipoID = "C";
			} else {
				if (rsOracle.getString("CLI_TIPO_IDENTIFICACION").replaceAll(" ", "").equals("NIT")) {
					stringTipoID = "N";
				} else {
					if (rsOracle.getString("CLI_TIPO_IDENTIFICACION").replaceAll(" ", "").equals("TI")) {
						stringTipoID = "T";
					} else {
						if (rsOracle.getString("CLI_TIPO_IDENTIFICACION").replaceAll(" ", "").equals("RC")) {
							stringTipoID = "R";
						} else {
							if (rsOracle.getString("CLI_TIPO_IDENTIFICACION").replaceAll(" ", "").equals("CE")) {
								if (rsOracle.getString("CLI_TIPO_IDENTIFICACION").length() > 7)
									stringTipoID = "I";
								else
									stringTipoID = "E";
							} else {
								if (rsOracle.getString("CLI_TIPO_IDENTIFICACION").replaceAll(" ", "").equals("PAS")) {
									stringTipoID = "P";
								} else {
									if (rsOracle.getString("CLI_TIPO_IDENTIFICACION").replaceAll(" ", "")
											.equals("SES")) {
										stringTipoID = "S";
									} else {
										if (rsOracle.getString("CLI_TIPO_IDENTIFICACION").replaceAll(" ", "")
												.equals("NEX")) {
											stringTipoID = "I";
										} else {
											if (rsOracle.getString("CLI_TIPO_IDENTIFICACION").replaceAll(" ", "")
													.equals("TSE")) {
												stringTipoID = "D";
											} else {
												stringTipoID = "A";
											}
										}
									}
								}
							}
						}
					}
				}
			}
			// FIN DE COMPARACION DE TIPO DE CLIENTE

			if (stringTipoID.replaceAll(" ", "").equals("N") || stringTipoID.replaceAll(" ", "").equals("I")) {

				stringNoID = stringNoID + generarDv(Long.parseLong(stringNoID)) + "";

			}

			stringNoID = stringNoID.replaceAll(" ", "");
			long Variabletmp2 = Long.parseLong(stringNoID);

			stringNoID = Variabletmp2 + "";
			rsSql = stSql.executeQuery("SELECT TipoID, No_Documento FROM Cliente where TipoID = '" + stringTipoID
					+ "' AND No_Documento ='" + stringNoID + "'");

			if (!rsSql.next()) {
				stSql.executeUpdate("INSERT INTO Cliente(TipoID, No_Documento)VALUES('" + stringTipoID + "'," + "'"
						+ stringNoID + "')");
			}

		}
		conexionOracle.desconectar();
		conexionSQL.desconectar();

		app.ejecutando("TERMINA INSERCCION CREDITOS");
	}

	public static byte generarDv(long nit) {

		int[] nums = { 3, 7, 13, 17, 19, 23, 29, 37, 41, 43, 47, 53, 59, 67, 71 };

		int sum = 0;

		String str = String.valueOf(nit);

		for (int i = str.length() - 1, j = 0; i >= 0; i--, j++) {
			sum += Character.digit(str.charAt(i), 10) * nums[j];
		}

		byte dv = (byte) ((sum % 11) > 1 ? (11 - (sum % 11)) : (sum % 11));
		return dv;
	}

}
