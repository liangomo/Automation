package actualizarClientes;

import Interfaz.App;
import Interfaz.AppSingleton;

public class Clientes {

	AppSingleton appSingleton= new Interfaz.AppSingleton();
	App app = null;
	
	@SuppressWarnings("unused")
	public Clientes() throws Exception
	{
		app = appSingleton.getInstance();
		app.ejecutando("EMPIEZA INSERCCI�N CLIENTES");
		ClientesCorrientes clientesCorrientes = new ClientesCorrientes();
		ClientesAhorros clientesAhorros = new ClientesAhorros();
		ClientesCreditos clientesCreditos = new ClientesCreditos();
		app.ejecutando("TERMINA INSERCCION CLIENTES");
	}
	
}
