package actualizarClientes;

import java.io.BufferedReader;
import java.sql.ResultSet;
import java.sql.Statement;

import Interfaz.App;
import Interfaz.AppSingleton;

import lecturaEscrituraArchivos.Lectura;
import sqlConexion.ConexionSQL;

public class ClientesCorrientes 
{
	public ClientesCorrientes() throws Exception
	{
		Lectura lectura = new Lectura();
		AppSingleton appSingleton = new Interfaz.AppSingleton();
		App app = null;
		app = appSingleton.getInstance();
		ConexionSQL conexion = new ConexionSQL();

		conexion.conectar();

		Statement st = conexion.getConexion().createStatement();
		ResultSet rs = null;
																
		BufferedReader bf = new BufferedReader(lectura.generacionArchivo("CTASCTES"));

		String linea = "";

		String 	stringTipoID = "", stringNoIDtmp = "", stringNoID = "";

		while((linea=bf.readLine()) != null)
		{
			stringTipoID = linea.substring(100, 101);
			stringNoIDtmp = linea.substring(101, 111);

			if (stringTipoID.equals("C"))
			{
				if (!stringNoIDtmp.substring(stringNoIDtmp.length() - 1, stringNoIDtmp.length()).equals("0"))
					stringNoID = stringNoIDtmp;		
				else 
					stringNoID = stringNoIDtmp.substring(0, 9);
			}
			else
				stringNoID = stringNoIDtmp;
			
			stringNoID= stringNoID.replaceAll(" ", "");
			
			long Variabletmp2 = Long.parseLong(stringNoID);
			
			stringNoID = Variabletmp2 + "";
			
			rs = st.executeQuery("SELECT TipoID, No_Documento FROM Cliente where TipoID = '" + stringTipoID + "' AND No_Documento ='"
					+ stringNoID + "'");
			
			if (!rs.next()) 
				st.executeUpdate("INSERT INTO Cliente(TipoID, No_Documento)VALUES('" + stringTipoID + "'," + "'"
						+ stringNoID + "')");	
		}
		bf.close();		
		conexion.desconectar();
		app.ejecutando("TERMINA INSERCCION CORRIENTES");
	}
}
