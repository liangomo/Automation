package actualizarClientes;

import java.io.BufferedReader;
import java.sql.ResultSet;
import java.sql.Statement;

import Interfaz.App;
import Interfaz.AppSingleton;

import lecturaEscrituraArchivos.Lectura;
import sqlConexion.ConexionSQL;

public class ClientesAhorros {

	AppSingleton appSingleton = new Interfaz.AppSingleton();
	App app = null;

	public ClientesAhorros() throws Exception {

		app = appSingleton.getInstance();
		Lectura lectura = new Lectura();

		ConexionSQL conexion = new ConexionSQL();

		conexion.conectar();

		Statement st = conexion.getConexion().createStatement();
		ResultSet rs = null;

		BufferedReader bf = new BufferedReader(lectura.generacionArchivo("AHORROS"));

		String linea = "";

		String stringTipoID = "", stringNoID = "";

		bf.readLine();

		while ((linea = bf.readLine()) != null) {
			if (linea.length() > 0) {
				if (linea.substring(0, 1).equals("0")) {
					stringTipoID = linea.substring(35, 36);
					stringNoID = linea.substring(37, 48);

					if (stringTipoID.equals("0"))
						stringTipoID = "C";
					else if (stringTipoID.equals("1"))
						stringTipoID = "N";
					else if (stringTipoID.equals("2"))
						stringTipoID = "T";
					else if (stringTipoID.equals("3"))
						stringTipoID = "R";
					else if (stringTipoID.equals("4")) {
						if (stringNoID.length() > 7)
							stringTipoID = "I";
						else
							stringTipoID = "E";
					} else if (stringTipoID.equals("5"))
						stringTipoID = "P";
					else if (stringTipoID.equals("6"))
						stringTipoID = "S";
					else if (stringTipoID.equals("7"))
						stringTipoID = "L";
					else
						app.ejecutando("ERROR AL MOMENTO DE ASIGNAR TIPO ID " + stringTipoID + " - " + stringNoID);

				}

				stringNoID = stringNoID.replaceAll(" ", "");

				long Variabletmp2 = Long.parseLong(stringNoID);

				stringNoID = Variabletmp2 + "";

				rs = st.executeQuery("SELECT TipoID, No_Documento FROM Cliente where TipoID = '" + stringTipoID + "' AND No_Documento ='"
						+ stringNoID + "'");

				if (!rs.next())
					st.executeUpdate("INSERT INTO Cliente(TipoID, No_Documento)VALUES('" + stringTipoID + "'," + "'"
							+ stringNoID + "')");
			}
		}
		bf.close();
		conexion.desconectar();
		app.ejecutando("TERMINA INSERCCION AHORROS");
	}
}
