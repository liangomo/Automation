package Consultas;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.swing.table.DefaultTableModel;

import sqlConexion.ConsultaSQL;

public class ConsultaTabla {
	public DefaultTableModel ConsultarMetodos(String Query) throws Exception
	{
		
		DefaultTableModel modelo = new DefaultTableModel();
		ConsultaSQL consulta = new ConsultaSQL();
		ResultSet rs = consulta.Consulta(Query);
		ResultSetMetaData rsMd = rs.getMetaData();

		int cantidadColumnas = rsMd.getColumnCount();
		String nomColumna;
		
		for (int i = 1; i <= cantidadColumnas; i++)
		{
			nomColumna = rsMd.getColumnName(i);
			modelo.addColumn(nomColumna);
		}
		
		while (rs.next()) 
		{
			Object[] fila = new Object[cantidadColumnas];
			
			for (int i = 0; i < cantidadColumnas; i++)
				fila[i]=rs.getObject( i + 1 );
			
			modelo.addRow(fila);
		}
		
		return modelo;
	}
}
