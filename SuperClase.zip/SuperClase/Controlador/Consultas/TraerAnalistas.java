package Consultas;

import java.sql.ResultSet;

import sqlConexion.ConsultaSQL;

public class TraerAnalistas {
	
	public String ConsultarAnalista() throws Exception
	{
		ConsultaSQL consulta = new ConsultaSQL();
		String Cadena = null;
		ResultSet rs = consulta.Consulta("SELECT NombreAnalista FROM Analistas WHERE CodAnalista = '" + System.getProperty("user.name") + "'");
		
		while (rs.next()) 
		{ 
			Cadena = rs.getString("NombreAnalista");
		}
		return Cadena;
	}
}
