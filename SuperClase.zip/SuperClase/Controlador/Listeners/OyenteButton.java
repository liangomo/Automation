package Listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import actualizarClientes.Clientes;
import displayAhorros.Ahorros;
import displayCorrientes.Corrientes;

import Adicionar.AdicionarMetodos;
import CarteraConsolidada.Creditos;
import Interfaz.App;
import Interfaz.AppSingleton;

public class OyenteButton implements ActionListener {

	AppSingleton appSingleton = new Interfaz.AppSingleton();
	App app = null;
	String Metodo, Descripcion, PreRequisitos, Codigo, Autor, Busqueda;

	private boolean ActualizarClientes = false;
	private boolean ActualizarCAHO = false;
	private boolean ActualizarCCTE = false;
	private boolean ActualizarCreditos = false;

	public void actionPerformed(ActionEvent e) {
		try {
			app = appSingleton.getInstance();
		} catch (Exception e2) {
			e2.printStackTrace();
		}

		if (e.getActionCommand().equals("ADICIONAR")) {
			System.out.println(app.getLblAutor().getText());
			Metodo = app.getTextNomMetodo().getText();
			Descripcion = app.getTxtAreaDescripcion().getText();
			PreRequisitos = app.getTextAreaPreRequisitos().getText();
			Codigo = app.getTextAreaCodigo().getText();
			Autor = app.getTxtAutor().getText();

			try {
				new AdicionarMetodos(Metodo, Descripcion, PreRequisitos, Codigo, Autor);
				app.mensaje();
				app.limpiar();
			} catch (Exception e1) {
				e1.printStackTrace();
			}

		}

		if (e.getActionCommand().equals("LIMPIAR")) {
			try {
				app.limpiar();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		if (e.getActionCommand().equals("BUSCAR")) {
			try {
				Busqueda = app.getTextBuscar().getText();
				app.consultaTabla("SELECT S.CodMetodo as 'Cod Metodo', S.NombreMetodo as 'Nom Metodo', "
						+ "S.Descripcion as Descripcion, S.PreRequisitos as PreRequisitos, S.CodigoFuente as 'Codigo Fuente', "
						+ "A.NombreAnalista as 'Analista' FROM SuperClase S, Analistas A "
						+ "WHERE A.CodAnalista = S.CodAnalista AND S.NombreMetodo LIKE '%" + Busqueda + "%'");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		if (e.getActionCommand().equals("Super Clase")) {
			app.habilitar("SuperClase");
		}

		if (e.getActionCommand().equals("ActualizarDatos")) {
			app.habilitar("ActualizarDatos");
		}

		if (e.getActionCommand().equals("Actualizar Clientes")) {
			ActualizarClientes = !ActualizarClientes;
		}

		if (e.getActionCommand().equals("Actualizar Cuentas de Ahorros")) {
			ActualizarCAHO = !ActualizarCAHO;
		}
		if (e.getActionCommand().equals("Actualizar Cuentas Corrientes")) {
			ActualizarCCTE = !ActualizarCCTE;
		}
		if (e.getActionCommand().equals("Actualizar Creditos")) {
			ActualizarCreditos = !ActualizarCreditos;
		}
		if (e.getActionCommand().equals("EJECUTAR")) {

			app.getTextAreaEjecucion().setText("Ejecutandose, espere un momento");

			if (ActualizarClientes) {

				try {
					new Clientes();
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}

			if (ActualizarCAHO) {

				try {
					new Ahorros();
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}

			if (ActualizarCCTE) {

				try {
					new Corrientes();
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}

			if (ActualizarCreditos) {

				try {
					new Creditos();
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}

		}

	}
}
