package telefoniaMovil_consultas.objects;

import org.openqa.selenium.By;
import utilities.Helper;

public class ConsumoALaFecha_Object {

	Helper help;
	By linkConsumos = By.linkText("Consumos a la fecha");
	By body = By.tagName("body");
	By body2 = By.cssSelector("body");
	By linkDetalleConsumo = By.linkText("aquí");
	By linkVolverDetalle = By.linkText("Volver");

	public ConsumoALaFecha_Object(Helper help) {
		this.help = help;
	}

	/** 
	 * ACCIONES EN LOS OBJETOS
	 * 
	 * */
	
	public void clickLinkConsumos() {
		this.help.getDriver().findElement(linkConsumos).click();
	}
	
	public String getBody() {
		return this.help.getDriver().findElement(body).getText();
	}
	
	public void getBodyFrameDetalle() {
		this.help.getDriver().switchTo().frame("ctl00_ContentPlaceHolder1_iframe_MN");
	}
	
	public void clickLinkDetalleConsumo() {
		this.help.getDriver().findElement(linkDetalleConsumo).click();
	}
	
	public void clickLinkVolverDetalle() throws InterruptedException {
		this.help.getDriver().findElement(linkVolverDetalle).click();
	}

}