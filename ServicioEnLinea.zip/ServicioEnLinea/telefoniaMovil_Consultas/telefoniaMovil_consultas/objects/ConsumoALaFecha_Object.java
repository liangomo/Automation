package telefoniaMovil_consultas.objects;

import org.openqa.selenium.By;

import utilities.Helper;

public class ConsumoALaFecha_Object {

	Helper help;
	By linkConsumos2 = By.linkText("Consumos a la fecha");
	By lblConsumoVoz = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_divTablaTasacion\"]/article[1]/div[1]/text()");
	By linkConsumos = By.xpath("//*[@id=\"idLiMenu1\"]/div/div/ul/li[2]/a");

	public ConsumoALaFecha_Object(Helper help) {
		this.help = help;
	}

	/** 
	 * ACCIONES EN LOS OBJETOS
	 * 
	 * */
	
	public void clickLinkConsumos() {
		
		this.help.getDriver().findElement(linkConsumos).click();
	}
	
	public String getLblConsumoVoz() {
		return this.help.getDriver().findElement(lblConsumoVoz).getText();
	}
	
	
	

}
