package telefoniaMovil_consultas.objects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import utilities.Helper;

public class DetalleConsumos_Object {

	Helper help;
	By linkDetalle = By.linkText("Detalle de consumos");
	By selectTipoConsumos = By.id("cmbtipcons");
	By linkBorrarFiltros = By.linkText("Borrar filtros");
	By linkDescargar = By.linkText("Descargar");
	By linkArchivoConsumosCSV = By.linkText("Consumos.csv");
	By linkVolver = By.linkText("Volver");
	By linkLlamadas = By.linkText("Llamadas caídas");
	By alertLlamadas = By.xpath("//*[@id=\"contiene_paginas\"]/div/article");


	By linkPrueba1 = By.xpath("//*[@id=\"url\"]");
	By linkPrueba2 = By.xpath("//*[@id=\"file-link\"]");
	By link = By.xpath("//*[@id=\"centeredContent\"]");

	//*[@id="url"]


	public DetalleConsumos_Object(Helper help) {
		this.help = help;
	}

	/** 
	 * ACCIONES EN LOS OBJETOS
	 * 
	 * */

	public void clickLinkDetalle() {
		this.help.getDriver().findElement(linkDetalle).click();
	}

	public void selectTipoConsumo(String tipoConsumo) {
		Select dropdown = new Select(this.help.getDriver().findElement(selectTipoConsumos));
		dropdown.selectByVisibleText(tipoConsumo);
	}

	public String getTipoConsumo() {
		String selectedOption = new Select(this.help.getDriver().findElement(selectTipoConsumos)).getFirstSelectedOption().getText();
		return selectedOption;
	}

	public void clickLinkBorrarFiltros() {
		this.help.getDriver().findElement(linkBorrarFiltros).click();
	}

	public void clickLinkDescargar() {
		this.help.getDriver().findElement(linkDescargar).click();
	}

	public By getLinkArchivoConsumosCSV() {
		return (linkArchivoConsumosCSV);
	}

	public void keyPressUrlDescargas() throws AWTException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_J);
	}

	public void clickLinkVolver() {
		this.help.getDriver().findElement(linkVolver).click();
	}
	
	public void clickLinkLlamadasCaidas() {
		this.help.getDriver().findElement(linkLlamadas).click();
	}
	
	public String getAlertLlamadas() {
		return this.help.getDriver().findElement(alertLlamadas).getText();
	}
	
	
	
	

	public String getHrefArchivoDescargado() {
		return this.help.getDriver().findElement(linkPrueba1).getAttribute("href");
	}
	
	public String getHrefArchivoDescargado2() {
		return this.help.getDriver().findElement(linkPrueba2).getAttribute("href");
	}
	
	public void getHrefArchivoDescargado3() {
		this.help.getDriver().findElement(link).sendKeys("AAAA");
	}
}
