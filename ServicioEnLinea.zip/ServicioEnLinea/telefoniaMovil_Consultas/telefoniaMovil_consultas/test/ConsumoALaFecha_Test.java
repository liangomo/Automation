package telefoniaMovil_consultas.test;

import telefoniaMovil_Home.objects.Home_Object;
import telefoniaMovil_consultas.objects.ConsumoALaFecha_Object;
import utilities.Helper;

public class ConsumoALaFecha_Test {
	Helper help;
	Home_Object home;
	ConsumoALaFecha_Object cons;

	String 	consumo = "",
			detalle = "",
			volverDetalle,
			veredicto;
	
	String	ok = "OK",
			fall = "FALL";

	/**
	 * LLAMADO DE OBJETOS Y ACCIONES (EVENTOS)
	 */

	public ConsumoALaFecha_Test (Helper help) {
		this.help = help;
		home = new Home_Object(help);
		cons = new ConsumoALaFecha_Object(help);
	}

	public void constMain() throws InterruptedException {

		home.clicklinkConsultas();
		cons.clickLinkConsumos();

		if (cons.getBody().contains("Consumo de Voz") || cons.getBody().contains("Consumo de Mensajes de Texto")
				|| cons.getBody().contains("Consumo de Datos")) {
			System.out.println("CONSUMO OK");
			consumo = "OK";
		} else {
			System.out.println("CONSUMO FALL");
			consumo = "FALL";
		}

		cons.clickLinkDetalleConsumo();
		cons.getBodyFrameDetalle();

		if (cons.getBody().contains("Detalles de Consumo")) {
			System.out.println("DETALLE OK");
			detalle = "OK";
		} else {
			System.out.println("DETALLE FALL");
			detalle = "FALL";
		}

		cons.clickLinkVolverDetalle();
		
		home.getBodyFrameHome();
		if (cons.getBody().contains("Telefonía móvil")) {
			System.out.println("VOLVER_DET OK");
			volverDetalle = ok;
		} else {
			System.out.println("VOLVER_DET FALL");
			volverDetalle = "FALL";
		}
		
		
		if (consumo.equals(ok) && detalle.equals(ok) && volverDetalle.equals(ok)) {
			System.out.println("VEREDICTO EXITOSO");
			veredicto = ok;
		} else {
			System.out.println("VEREDICTO FALLIDO");
			veredicto = fall;
		}
	}

}