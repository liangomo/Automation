package telefoniaMovil_consultas.test;

import telefoniaMovil_Home.objects.Home_Object;
import telefoniaMovil_consultas.objects.ConsumoALaFecha_Object;
import utilities.Helper;

public class ConsumoALaFecha_Test {
	Helper help;
	Home_Object home;
	ConsumoALaFecha_Object cons;
	
	/**
	 * LLAMADO DE OBJETOS Y ACCIONES (EVENTOS)
	 */
	
	public ConsumoALaFecha_Test (Helper help) {
		this.help = help;
		home = new Home_Object(help);
		cons = new ConsumoALaFecha_Object(help);
	}
	
	public void constMain () throws InterruptedException {

//		home.clicklinkConsultas();
		cons.clickLinkConsumos();
		
		if (cons.getLblConsumoVoz().contains("Consumo de Voz")) {
			System.out.println("CONSUMO VOZ OK");
		}
		
	}

	


	
}