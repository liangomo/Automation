package telefoniaMovil_consultas.test;

import java.awt.AWTException;
import telefoniaMovil_Home.objects.Home_Object;
import telefoniaMovil_consultas.objects.ConsumoALaFecha_Object;
import telefoniaMovil_consultas.objects.DetalleConsumos_Object;
import utilities.Helper;

public class DetalleConsumos_Test {

	Helper help;
	Home_Object home;
	ConsumoALaFecha_Object cons;
	DetalleConsumos_Object detalle;

	/**
	 * LLAMADO DE OBJETOS Y ACCIONES (EVENTOS)
	 */

	public DetalleConsumos_Test (Helper help) {
		this.help = help;
		home = new Home_Object(help);
		cons = new ConsumoALaFecha_Object(help);
		detalle = new DetalleConsumos_Object(help);
	}


	public void detalleMain() throws InterruptedException, AWTException {

		
		/**
		 * CASO 1
		 * */ 
		
		home.clicklinkConsultas();
		detalle.clickLinkDetalle();

		cons.getBodyFrameDetalle();

		if (cons.getBody().contains("Detalles de Consumo")) {
			System.out.println("DETALLE OK");
		} else {
			System.out.println("DETALLE FALL");
		}

		detalle.selectTipoConsumo("Voz"); Thread.sleep(3000);

		/////VALIDACION TABLA

		detalle.clickLinkBorrarFiltros();

		if (detalle.getTipoConsumo().equals("Tipo de consumos"))
			System.out.println("TIPO CONSUMO OK");
		else
			System.out.println("TIPO CONSUMO FALL");


		detalle.clickLinkDescargar();
		/////VALIDACION ARCHIVO DESCARGADO    "chrome://downloads/"
		detalle.keyPressUrlDescargas();
		

		detalle.getHrefArchivoDescargado3();

		System.out.println("111111" + detalle.getHrefArchivoDescargado());
		System.out.println("222222" + detalle.getHrefArchivoDescargado2());

		if (help.buscarObjeto(detalle.getLinkArchivoConsumosCSV()))
			System.out.println("DESCARGA OK");
		else
			System.out.println("DESCARGA FALL");


		detalle.clickLinkVolver();

		home.getBodyFrameHome();
		if (cons.getBody().contains("Telefonía móvil")) {
			System.out.println("VOLVER_DETALLE_CONS OK");
		} else {
			System.out.println("VOLVER_DETALLE_CONS FALL");
		}


		
		/**
		 * CASO 2
		 * */

		if (cons.getBody().contains("Telefonía móvil")) {
			home.clicklinkConsultas();
			detalle.clickLinkDetalle();
			cons.getBodyFrameDetalle();
		} else if (cons.getBody().contains("Detalles de Consumo")) {
			Thread.sleep(3000);
			detalle.clickLinkLlamadasCaidas(); 

			if (cons.getBody().contains("Consulta llamadas caídas")) {
				System.out.println("LLAMADAS_CAIDAS OK");
			} else {
				System.out.println("LLAMADAS_CAIDAS FALL");
			}

			// "Durante este mes no presentas llamadas caídas, puedes seleccionar otro mes para consultar."
			System.out.println(detalle.getAlertLlamadas()); 
		}
	}

}
