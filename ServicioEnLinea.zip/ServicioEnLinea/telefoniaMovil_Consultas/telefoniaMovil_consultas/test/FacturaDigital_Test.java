package telefoniaMovil_consultas.test;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.awt.AWTException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import login.test.Login_Test;
import telefoniaMovil_Home.objects.Home_Object;
import telefoniaMovil_Home.test.Home_Test;
import telefoniaMovil_Home.test.SelecProducto_Test;
import telefoniaMovil_consultas.objects.FacturaDigital_Object;
import utilities.Helper;

public class FacturaDigital_Test {

	Helper help;
	Home_Object home;
	FacturaDigital_Object fact;
	boolean presentFlag = false;

	String 	barraNovedades = "",
			barraNovedades2 = "",
			detalle = "",
			volverDetalle,
			veredicto;

	String	ok = "OK",
			fall = "FALL";

	
//	public FacturaDigital_Test (Helper help) {
//	this.help = help;
//	home = new Home_Object(help);
//	fact = new FacturaDigital_Object(help);
//}

	@BeforeTest
	public void beforeMethod() throws InterruptedException, AWTException {
		
		this.help = help;
		home = new Home_Object(help);
		fact = new FacturaDigital_Object(help);

		Helper help =  new Helper();
		Login_Test login = new Login_Test(help);
		SelecProducto_Test producto = new SelecProducto_Test(help);
		Home_Test homeTelMov = new Home_Test(help);

		help.getChrome("https://mi.movistar.co/");
		//				help.getFirefox("https://mi.movistar.co/");
		//				help.getExplorer("https://mi.movistar.co/");


		login.loginMain();   Thread.sleep(3000);
		producto.SelecProdMain();
		homeTelMov.HomeMain(); Thread.sleep(3000);
	}


	
	@Test
	public void factMain() throws InterruptedException {

		//		String testCase = "2";
		//		if (testCase.equals("1")) {

		home.clicklinkConsultas();
		fact.clickLinkFactura();

		help.cambiarVentana();
		fact.getBodyFramePresenta();
		if (help.buscarObjeto(fact.getBarTitulo())) {
			System.out.println("NOVED OK");
			barraNovedades = "OK";
		} else {
			System.out.println("NOVED OK FALL");
			barraNovedades = "FALL";
		}

		fact.clickImgCerrar();
		if (help.buscarObjeto(fact.getImgFacturaDigital())) {
			System.out.println("IMG_FACT_OK");
			barraNovedades = "OK";
		} else {
			System.out.println("IMG_FACT_FALL");
			barraNovedades = "FALL";
		}
	}
	//		} else if (testCase.equals("2")) {

	@Test
	public void factMain2() throws InterruptedException {

		if (help.buscarObjeto(fact.getImgFacturaDigital())) {

			fact.clickImgNovedades(); Thread.sleep(2000);
			if (help.buscarObjeto(fact.getBarTitulo())) {
				System.out.println("NOVED2 OK");
				barraNovedades2 = "OK";
			}

			fact.clickImgCerrar();


			fact.clickImgImprimir(); Thread.sleep(2000);

			if (help.buscarObjeto(fact.getBarTitulo())) {
				System.out.println("IMPRIMIR OK");
				barraNovedades2 = "OK";
			}
			fact.clickImgCerrar(); Thread.sleep(2000);


			fact.clickImgExportarFact(); Thread.sleep(2000);
			if (help.buscarObjeto(fact.getBarTitulo())) {
				System.out.println("EXPORTAR OK");
				barraNovedades2 = "OK";
			}
			fact.clickImgCerrar(); Thread.sleep(2000);



			fact.clickImgInfoGrafica(); Thread.sleep(2000);
			if (help.buscarObjeto(fact.getSpanDetalleInfoGrafica())) {
				System.out.println("INFO GRÁFICA OK");
				barraNovedades2 = "OK";
			}


			fact.clickImgAdminCorreos(); Thread.sleep(2000);
			if (help.buscarObjeto(fact.getBarTitulo())) {
				System.out.println("ADMIN CORREOS OK");
				barraNovedades2 = "OK";
			}

			fact.clickImgCerrar(); Thread.sleep(2000);

		} 
	}

	//		} else if (testCase.equals("3")) {

	@Test
	public void factMain3() throws InterruptedException {

		if (help.buscarObjeto(fact.getImgFacturaDigital())) {

			fact.getBodyFrameFactura();
			if (fact.getBody().contains("Señor(a):")) {
				System.out.println("NombreCliente en Factura OK");
				barraNovedades2 = "OK";
			}
			Thread.sleep(2000);

			help.cambiarVentana();
			fact.getBodyFramePresenta();
			fact.clickImgSiguientePag();  Thread.sleep(2000);
			fact.getBodyFrameFactura();
			if (fact.getBody().contains("Nit ó Cédula")) {
				System.out.println("SIGUIENTE PAG OK");
				barraNovedades2 = "OK";
			} else {
				System.out.println("SIGUIENTE PAG FALLÓ");
			}

			help.cambiarVentana();
			fact.getBodyFramePresenta();
			fact.clickImgAnteriorPag(); Thread.sleep(2000);
			fact.getBodyFrameFactura();
			if (fact.getBody().contains("Señor(a):")) {
				System.out.println("ANTERIOR PAG OK");
				barraNovedades2 = "OK";
			}

			help.cambiarVentana();
			fact.getBodyFramePresenta();
			fact.clickImgUltimaPag(); Thread.sleep(2000);
			fact.clickImgUltimaPag(); Thread.sleep(2000);
			fact.getBodyAlertAccept();
			System.out.println("ULTIMA PAG OK");
			barraNovedades2 = "OK";

			help.cambiarVentana();
			fact.getBodyFramePresenta();
			fact.clickImgPrimeraPag(); Thread.sleep(2000);
			fact.getBodyFrameFactura();
			if (fact.getBody().contains("Señor(a):")) {
				System.out.println("PRIMERA PAG OK");
				barraNovedades2 = "OK";
			}
			help.cambiarVentana();
			fact.getBodyFramePresenta();
		}

	}

	//		} else if (testCase.equals("4")) {

	@Test
	public void factMain4() throws InterruptedException {

		if (help.buscarObjeto(fact.getImgFacturaDigital())) {
			fact.clickImgSiguientePag();  Thread.sleep(2000);
			fact.getBodyFrameFactura();

			String nitCedula = fact.getSpanNitCedula(); 					// " 1030"
			String telefono = fact.getSpanTelefono(); 						// " 3174304601 - "
			String clienteNo = fact.getSpanClienteNo(); 					// " 39132203"
			String facturaVenta = fact.getSpanFacturaVenta();				// "EC - 142430867"
			String fechaExpedicion = fact.getSpanFechaExpedicion();			// "VACIO"
			String facturaMes= fact.getSpanFacturaMes();					// "VACIO"
			String fechaProximaFactura = fact.getSpanFechaProximaFactura();	// "VACIO"
			String numeroParaPagos = fact.getSpanNumeroParaPagos();			// "39132203"
			String fechaLimitePago = fact.getSpanFechaLimitePago();			// "VACIO"		
			String totalPagar = fact.getSpanTotalPagar();					// "VACIO"

			assertTrue(nitCedula.contains("1030"));
			assertTrue(telefono.contains("3174304601"));
			assertTrue(clienteNo.contains("39132203"));
			assertNotNull(facturaVenta);
			assertNotNull(fechaExpedicion);
			assertNotNull(facturaMes);
			assertNotNull(fechaProximaFactura);
			assertTrue(numeroParaPagos.contains("39132203"));
			assertNotNull(fechaLimitePago);
			assertNotNull(totalPagar);
		}

	}	
}