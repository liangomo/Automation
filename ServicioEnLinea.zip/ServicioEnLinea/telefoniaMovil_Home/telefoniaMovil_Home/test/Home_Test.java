package telefoniaMovil_Home.test;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;

import selu_Home.objects.Selu_Home_Object;
import telefoniaMovil_Home.objects.Home_Object;
import telefoniaMovil_consultas.objects.ConsumoALaFecha_Object;
import utilities.Helper;

public class Home_Test {

	String veredicto;

	Helper help;
	Home_Object home;
	Selu_Home_Object seluHome;
	ConsumoALaFecha_Object cons;

	public Home_Test(Helper help) {
		this.help = help;
		home = new Home_Object(help); 
		seluHome = new Selu_Home_Object(help);
		cons = new ConsumoALaFecha_Object(help);
	}

	/**
	 * LLAMADO DE OBJETOS Y ACCIONES (EVENTOS)
	 * @throws AWTException 
	 *
	 */

	public void HomeMain() throws InterruptedException, AWTException {

		/**
		 *  CASO 1 
		 */

//		Integer caracter = Integer.valueOf(home.getLblNombreCliente().length());
//
//
//		if (home.getBody().contains("Hola") && home.getBody().contains("para ingresar a otra") && caracter > 1) {
//			veredicto = "EXITOSO";
//			System.out.println("INGRESO HOME EXITOSO");
//		} else {
//			veredicto = "FALLIDO";
//			System.out.println("INGRESO HOME FALLIDO");
//		}
//
//		String nombreCliente = home.getLblNombreCliente();		// ""
//		String apellidoCliente = home.getLblApellidoCliente();	// ""
//
//		home.getBodyFrameHome();
//		String numCelular = home.getLblNumCelular(); 			// ""
//		String direccion = home.getLblDireccion();				// ""
//		String ciudad = home.getLblCiudad();					// ""
//
//		assertTrue(numCelular.equals("3174304601"));
//		assertTrue(nombreCliente.equals("Lilana Andrea"));
//		assertTrue(apellidoCliente.equals("Gómez"));
//		assertTrue(direccion.equals("Dirección: TV 60 # 114 A - 55"));
//		assertTrue(ciudad.equals("Ciudad: BOGOTA"));
//
//		home.getBodyDefaultContent();
//		home.clickLinkOtraLinea();
//
//		if (help.buscarObjeto(home.getImgPhotoUser())) {
//			veredicto = "EXITOSO";
//			System.out.println("LINK_OTRA_LINEA OK");
//		} else {
//			veredicto = "FALLIDO";
//			System.out.println("LINK_OTRA_LINEA FALL");
//		}


		/**
		 *  CASO 2
		 */

		//		&& help.buscarObjeto(home.getImgBannerDetalle()
		//
		//		/* CASO 3 */
		//		// comparando los datos que se encuentran en SCL
		//		
		//		
		//		/* CASO 4, 5 Y 6 */
		//		if (help.buscarObjeto(home.getImgBannerFactura())) {
		//			veredicto = "EXITOSO";
		//			System.out.println("EXITOSO");
		//		} else {
		//			veredicto = "FALLIDO";
		//			System.out.println("FALLIDO");
		//		}



		home.getBodyFrameHome();
		home.clickImgChatServicio();
		help.cambiarVentana();
		home.getBodyFrameChat();
		if (home.getLblChat().equals("Chat")) 
			System.out.println("CHAT_SERVICIO OK");
		else
			System.out.println("CHAT_SERVICIO FALL");

//		home.keyPressCerrarPestaña();
		System.out.println("TITLE1" + help.getDriver().getTitle());
		
		help.cambiarVentana();
		System.out.println("TITLE2" + help.getDriver().getTitle());
		
		home.getBodyDefaultContent();
		home.getBodyFrameHome();
		home.clickImgImprimir();
//		help.cambiarVentana();
//		// Validar opcion imprimir 
//
//		home.clickImgFacebook();
//		help.cambiarVentana();
//
//
//		home.clickImgTwittear();
//		help.cambiarVentana();


	}

}
