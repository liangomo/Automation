package telefoniaMovil_Home.test;

import telefoniaMovil_Home.objects.Home_Object;
import utilities.Helper;

public class Home_Test {

	String veredicto;
	
	Helper help;
	Home_Object home;

	public Home_Test(Helper help) {
		this.help = help;
		home = new Home_Object(help); 
	}

	/**
	 * LLAMADO DE OBJETOS Y ACCIONES (EVENTOS)
	 *
	 */

	public void HomeMain() throws InterruptedException {

		/* CASO 1 */
		Integer caracter = Integer.valueOf(home.setSpanNombres().length());
    	

		if (home.getBody().contains("Hola") && home.getBody().contains("para ingresar a otra l�nea") && caracter > 1) {
			veredicto = "EXITOSO";
			System.out.println("EXITOSO");
		} else {
			veredicto = "FALLIDO";
			System.out.println("FALLIDO");
		}
    	
//		/* CASO 2 */
//		home.ClickLinkOtraLinea();
//		
//		if (help.buscarObjeto(home.getImgPhotoUser())) {
//			veredicto = "EXITOSO";
//			System.out.println("EXITOSO");
//		} else {
//			veredicto = "FALLIDO";
//			System.out.println("FALLIDO");
//		}
//		&& help.buscarObjeto(home.getImgBannerDetalle()
//
//		/* CASO 3 */
//		// comparando los datos que se encuentran en SCL
//		
//		
//		/* CASO 4, 5 Y 6 */
//		if (help.buscarObjeto(home.getImgBannerFactura())) {
//			veredicto = "EXITOSO";
//			System.out.println("EXITOSO");
//		} else {
//			veredicto = "FALLIDO";
//			System.out.println("FALLIDO");
//		}
//		Thread.sleep(5000);
//		/* CASO 5 */
//		home.ClickImgChatServicio();
//		help.cambiarVentana();
//		// Validar o
//		
//		/* CASO 6 */
//		home.ClickImgImprimir();
//		help.cambiarVentana();
//		// Validar opcion imprimir 
//		
//		/* CASO 7 */
//		home.ClickImgFacebook();
//		help.cambiarVentana();
//		
//		
//		/* CASO 8 */
//		home.ClickImgTwittear();
//		help.cambiarVentana();


	}

}
