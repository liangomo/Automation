package telefoniaMovil_Home.test;

import telefoniaMovil_Home.objects.SelecProducto_Object;
import utilities.Helper;

public class SelecProducto_Test {

	Helper help;
	SelecProducto_Object prod;

	public SelecProducto_Test(Helper help) {
		this.help = help;
		prod = new SelecProducto_Object(help); 
	}

	/**
	 * LLAMADO DE OBJETOS Y ACCIONES (EVENTOS)
	 *
	 */
	
	public void SelecProdMain() throws InterruptedException {

		prod.getCssProducto();
		Thread.sleep(3000);
		

	}

}