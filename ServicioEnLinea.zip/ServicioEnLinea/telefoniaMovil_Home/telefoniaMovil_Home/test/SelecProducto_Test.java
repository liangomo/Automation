package telefoniaMovil_Home.test;

import selu_Home.objects.Selu_Home_Object;

//import java.util.List;
//import java.util.concurrent.TimeUnit;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;

import telefoniaMovil_Home.objects.SelecProducto_Object;
import telefoniaMovil_consultas.objects.ConsumoALaFecha_Object;
import utilities.Helper;

public class SelecProducto_Test {

	Helper help;
	Selu_Home_Object seluHome;
	SelecProducto_Object prod;
	ConsumoALaFecha_Object cons;
	

	public SelecProducto_Test(Helper help) {
		this.help = help;
		prod = new SelecProducto_Object(help); 
		seluHome = new Selu_Home_Object(help);
		cons = new ConsumoALaFecha_Object(help);
	}

	/**
	 * LLAMADO DE OBJETOS Y ACCIONES (EVENTOS)
	 *
	 */

	public void SelecProdMain() throws InterruptedException {

		String email = seluHome.getLblEmail();
		
		if (email.equals("lilianaandrea.gomez@telefonica.com"))
			System.out.println("EMAIL OK");
		else
			System.out.println("EMAIL FALL");
		
		
		prod.getCssProducto();

	}

}