package telefoniaMovil_Home.objects;

import org.openqa.selenium.By;

import utilities.Helper;

public class SelecProducto_Object {
	Helper help;
	By cssProducto = By.xpath("//*[@id=\"mCSB_1_container\"]/div/ul/a[2]/li/span");

	public SelecProducto_Object(Helper help) {
		this.help = help;
	}

	public void getCssProducto() {
		this.help.getDriver().findElement(cssProducto).click();
	}

}