package telefoniaMovil_Home.objects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import utilities.Helper;

public class Home_Object {
	
	/** INICIALIZACI�N DE VARIABLES */
	
	String veredicto = "";
	
	Helper help;
	By body = By.tagName("body");
	By lblNumCelular = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_NumeroCelular\"]");
	By lblNombreCliente = By.xpath("//*[@id=\"content\"]/section/div[1]/div/div[1]/p[1]/span[1]");
	By lblApellidoCliente = By.xpath("//*[@id=\"content\"]/section/div[1]/div/div[1]/p[1]/span[2]");
	By lblDireccion = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_divInfoContacto\"]/p[1]");
	By lblCiudad = By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_divInfoContacto\"]/p[2]");

	By linkOtraLinea = By.linkText("click aquí");
	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");
	By imgBannerFactura = By.xpath("//*[@id=\"slides\"]/div/div/a[1]/img");
	By imgBannerDetalle = By.xpath("//*[@id=\"slides\"]/div/div/a[2]/img");

	By imgChatServicio = By.id("ctl00_lnChat");
	By lblChat = By.xpath("//*[@id=\"contenedor\"]/div[1]/section/header/h1");

	By imgImprimir = By.cssSelector("span.ladop");
	
	By imgFacebook = By.cssSelector("a.contiene_facebook > img");
	
	By imgTwittear = By.id("l");
	
	By linkConsultas = By.id("idLiMenu1");
	By linkTransacciones = By.linkText("Transacciones");
	By linkServicios = By.linkText("Servicios");
	
	
	public Home_Object(Helper help) {
		this.help = help;
	}

	public String getBody() {
		return this.help.getDriver().findElement(body).getText();
	}
	
	public void getBodyDefaultContent() {
		this.help.getDriver().switchTo().defaultContent();
	}
	
	public void getBodyFrameHome() {
		this.help.getDriver().switchTo().frame("LegacyContainer");
	}
	
	public void getBodyFrameChat() {
		this.help.getDriver().switchTo().frame("main");
	}
	
	

	public String getLblNumCelular() {
		return this.help.getDriver().findElement(lblNumCelular).getText();
	}
	
	public String getLblNombreCliente() {
		return this.help.getDriver().findElement(lblNombreCliente).getText();
	}
	
	public String getLblApellidoCliente() {
		return this.help.getDriver().findElement(lblApellidoCliente).getText();
	}
	
	public String getLblDireccion() {
		return this.help.getDriver().findElement(lblDireccion).getText();
	}
	
	public String getLblCiudad() {
		return this.help.getDriver().findElement(lblCiudad).getText();
	}

	public void clickLinkOtraLinea() {
		this.help.getDriver().findElement(linkOtraLinea).click();
	}

	
	public By getImgPhotoUser() {
		return (imgPhotoUser);
	}

	public By getImgBannerFactura() {
		return (imgBannerFactura);
	}

	public void getImgBannerFactura2() {
		this.help.getDriver().findElement(imgBannerFactura).click();
	}

	public By getImgBannerDetalle() {
		return (imgBannerDetalle);
	}

	
	
	public void clickImgChatServicio() {
		this.help.getDriver().findElement(imgChatServicio).click();
	}
	
	public String getLblChat() {
		return this.help.getDriver().findElement(lblChat).getText();
	}
	
	public void clickImgImprimir() {
		this.help.getDriver().findElement(imgImprimir).click();
	}
	
	public void clickImgFacebook() {
		this.help.getDriver().findElement(imgFacebook).click();
	}
	
	public void clickImgTwittear() {
		this.help.getDriver().findElement(imgTwittear).click();
	}
	
	public void keyPressCerrarPestaña() throws AWTException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_W);
	}
	
	public void clicklinkConsultas() {
		this.help.getDriver().switchTo().frame("LegacyContainer");
		this.help.getDriver().findElement(linkConsultas).click();
	}
	
	public void clickLinkTransacciones() {
		this.help.getDriver().findElement(linkTransacciones).click();
	}
	
	public void clicklinkServicios() {
		this.help.getDriver().findElement(linkServicios).click();
	}

}