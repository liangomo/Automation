package telefoniaMovil_Home.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import utilities.Helper;

public class Home_Object {
	
	/** INICIALIZACI�N DE VARIABLES */
	
	String veredicto = "";
	
	
	
	Helper help;
	By spanNombres = By.xpath("//*[@id=\"content\"]/section/div[1]/div/div[1]/p[1]/span[1]");
	By body = By.tagName("body");
	By linkOtraLinea = By.linkText("click aqu�");
	By imgPhotoUser = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[1]/div/img");
	By imgBannerFactura = By.xpath("//*[@id=\"slides\"]/div/div/a[1]/img");
	By imgBannerDetalle = By.xpath("//*[@id=\"slides\"]/div/div/a[2]/img");

	By imgChatServicio = By.id("ctl00_lnChat");

	By imgImprimir = By.cssSelector("span.ladop");
	
	By imgFacebook = By.cssSelector("a.contiene_facebook > img");
	
	By imgTwittear = By.id("l");
	
	By linkConsultas = By.linkText("Consultas");
	By linkTransacciones = By.linkText("Transacciones");
	By linkServicios = By.linkText("Servicios");
	

	
	
	public Home_Object(Helper help) {
		this.help = help;
	}

	public String getBody() {
		return this.help.getDriver().findElement(body).getText();
	}

	public String setSpanNombres() {
		return this.help.getDriver().findElement(spanNombres).getText();
	}

	public void ClickLinkOtraLinea() {
		this.help.getDriver().findElement(linkOtraLinea).click();
	}

	public By getImgPhotoUser() {
		return (imgPhotoUser);
	}

	public By getImgBannerFactura() {
		return (imgBannerFactura);
	}

	public void getImgBannerFactura2() {
		this.help.getDriver().findElement(imgBannerFactura).click();
	}

	public By getImgBannerDetalle() {
		return (imgBannerDetalle);
	}

	
	
	public void clickImgChatServicio() {
		this.help.getDriver().findElement(imgChatServicio).click();
	}
	
	public void clickImgImprimir() {
		this.help.getDriver().findElement(imgImprimir).click();
	}
	
	public void clickImgFacebook() {
		this.help.getDriver().findElement(imgFacebook).click();
	}
	
	public void clickImgTwittear() {
		this.help.getDriver().findElement(imgTwittear).click();
	}
	
	
	public void clicklinkConsultas() {
	//	this.help.getDriver().findElement(linkConsultas).click();
		
		Select dropdown = new Select(this.help.getDriver().findElement(linkConsultas));
		dropdown.selectByVisibleText("Consumos a la fecha");
	}
	
	public void clickLinkTransacciones() {
		this.help.getDriver().findElement(linkTransacciones).click();
	}
	
	public void clicklinkServicios() {
		this.help.getDriver().findElement(linkServicios).click();
	}
	
	
	
	
	


	
		

}