package login.test;

//import java.awt.event.KeyEvent;
import login.objects.Login_Object;
import utilities.Helper;

public class Login_Test {
	Helper help;
	Login_Object login;

	public Login_Test(Helper help){
		this.help = help;
		login = new Login_Object(help); 
	}

	public void loginMain() throws InterruptedException{

		login.setTxtMail("lilianaandrea.gomez@telefonica.com");
		login.setTxtPassword("Telefonica_987");

		
//		login.setTxtMail("alejo1984_2008@hotmail.com");
//		login.setTxtPassword("Sofi7491$");
		login.clickBtnSubmit();

		Thread.sleep(5000);



	}
}