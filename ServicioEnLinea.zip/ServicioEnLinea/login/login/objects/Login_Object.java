package login.objects;

import org.openqa.selenium.By;

import utilities.Helper;

public class Login_Object {

	Helper help;
	By txtMail = By.id("formValidar");
	By txtPassword = By.id("Password");
	By btnSubmit = By.cssSelector("input.submit");

	
	public Login_Object(Helper help) {
		this.help = help;
	}
		
	public void setTxtMail(String mail) {
		this.help.getDriver().findElement(txtMail).sendKeys(mail);
	}
	
	public boolean setTxtMailExist() {
		return (txtMail) != null;
	}
	
	public void setTxtPassword(String password) {
		this.help.getDriver().findElement(txtPassword).sendKeys(password);
	}
	
	public void clickBtnSubmit() {
		this.help.getDriver().findElement(btnSubmit).click();
	}
	

}