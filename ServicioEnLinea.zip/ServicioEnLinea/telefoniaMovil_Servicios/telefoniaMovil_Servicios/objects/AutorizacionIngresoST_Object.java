package telefoniaMovil_Servicios.objects;

public class AutorizacionIngresoST_Object {

}
