package telefoniaMovil_Servicios.objects;

public class ServicioFamiliaAmigos_Object {

}
