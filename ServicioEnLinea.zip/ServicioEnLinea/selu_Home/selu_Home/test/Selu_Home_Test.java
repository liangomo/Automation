package selu_Home.test;

import selu_Home.objects.Selu_Home_Object;
import utilities.Helper;

public class Selu_Home_Test {

	Helper help;
	Selu_Home_Object seluHome;

	public Selu_Home_Test(Helper help) {
		this.help = help;
		seluHome = new Selu_Home_Object(help); 
	}

	/**
	 * LLAMADO DE OBJETOS Y ACCIONES (EVENTOS)
	 *
	 */

	public void SeluHomeMain() throws InterruptedException {

		
	}

}
