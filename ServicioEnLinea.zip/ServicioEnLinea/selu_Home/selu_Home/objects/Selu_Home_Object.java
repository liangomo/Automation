package selu_Home.objects;

import org.openqa.selenium.By;

import utilities.Helper;

public class Selu_Home_Object {

	/** INICIALIZACIÓN DE VARIABLES */

	Helper help;
	By lblEmail = By.xpath("//*[@id=\"content\"]/div/section/div[2]/div[1]/div/div[2]/span[1]");
	
	
	public Selu_Home_Object(Helper help) {
		this.help = help;
	}
	
	public String getLblEmail() {
		return this.help.getDriver().findElement(lblEmail).getText();
	}
}