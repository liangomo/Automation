/**
 * Main
 * @author lagomezmo1
 *
 */
package automationFramework;

import java.awt.AWTException;

import login.test.Login_Test;
import telefoniaMovil_Home.test.Home_Test;
import telefoniaMovil_Home.test.SelecProducto_Test;
//import telefoniaMovil_consultas.test.ConsumoALaFecha_Test;
import telefoniaMovil_consultas.test.DetalleConsumos_Test;
//import telefoniaMovil_consultas.test.FacturaDigital_Test;
import utilities.Helper;

public class Main 
{

	//	@Test
	public static void main(String[] args) throws InterruptedException, AWTException
	{
		Helper help =  new Helper();
		Login_Test login = new Login_Test(help);
		SelecProducto_Test producto = new SelecProducto_Test(help);
		Home_Test homeTelMov = new Home_Test(help);
//		FacturaDigital_Test factura = new FacturaDigital_Test(help);
//		ConsumoALaFecha_Test consumo = new ConsumoALaFecha_Test(help);
		DetalleConsumos_Test detalle = new DetalleConsumos_Test(help);


		help.getChrome("https://mi.movistar.co/");
//		help.getFirefox("https://mi.movistar.co/");
//		help.getExplorer("https://mi.movistar.co/");


		login.loginMain();   Thread.sleep(3000);
		producto.SelecProdMain();
		homeTelMov.HomeMain(); Thread.sleep(3000);
//		factura.factMain();
//		consumo.constMain();
//		detalle.detalleMain();
	}

}