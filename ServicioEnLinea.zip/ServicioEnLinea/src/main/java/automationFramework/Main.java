/**
 * Main
 * @author lagomezmo1
 *
 */
package automationFramework;

import login.test.Login_Test;
import telefoniaMovil_Home.test.Home_Test;
import telefoniaMovil_Home.test.SelecProducto_Test;
import telefoniaMovil_consultas.test.ConsumoALaFecha_Test;
import utilities.Helper;

public class Main 
{

	public static void main( String[] args ) throws InterruptedException
	{
		Helper help =  new Helper();
		Login_Test login = new Login_Test(help);
		SelecProducto_Test prod = new SelecProducto_Test(help);
		Home_Test test = new Home_Test(help);
		ConsumoALaFecha_Test cons = new ConsumoALaFecha_Test(help);


		help.getChrome("https://mi.movistar.co/");
		//				help.getFirefox("https://mi.movistar.co/");
		//				help.getExplorer("https://mi.movistar.co/");


		login.loginMain();   Thread.sleep(3000);
		prod.SelecProdMain();
		test.HomeMain(); Thread.sleep(3000);
		cons.constMain();
	}

}