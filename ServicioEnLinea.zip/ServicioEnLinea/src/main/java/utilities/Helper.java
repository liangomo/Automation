/**
 * Clase que contiene los m�todos utilizados en el proyecto
 * @author lagomezmo1
 */
package utilities;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Helper {
	int numeroKill = 0;
	String[] Datos;
	protected int i;
	String cont;
	private WebDriver driver;

	public WebDriver getDriver()
	{
		return driver;
	}

	public void setDriver(WebDriver driver)
	{
		this.driver = driver;
	}

	public void getExplorer(String baseUrl) throws InterruptedException
	{
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
//		capabilities.setCapability("requireWindowFocus", true);
		
		capabilities.setCapability("enablePersistentHover", false);
		
		setDriver(new InternetExplorerDriver(capabilities));

		getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		getDriver().get(baseUrl);
		getDriver().manage().window().maximize();

		Thread.sleep(3000);
	}


	public void getChrome(String baseUrl)
	{
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		setDriver(new ChromeDriver(capabilities));

		getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		getDriver().get(baseUrl);
		getDriver().manage().window().maximize();	
	}


	public void getFirefox(String baseUrl) throws InterruptedException
	{
		ProfilesIni profile = new ProfilesIni();
		FirefoxProfile myprofile = profile.getProfile("Selenium");
//		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
//		capabilities.setCapability("marionette", true);
		
		setDriver(new FirefoxDriver(myprofile));

		getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		getDriver().get(baseUrl);
		getDriver().manage().window().maximize();

		Thread.sleep(15000);
	}

	public void cambiarVentana() throws InterruptedException
	{
		Thread.sleep(5000);

		Set<String> allHandles = getDriver().getWindowHandles();

		allHandles.remove(allHandles.iterator().next());

		String lastHandle = allHandles.iterator().next();
		lastHandle = allHandles.iterator().next();

		getDriver().switchTo().window(lastHandle);
		getDriver().manage().window().maximize();

		Thread.sleep(5000);
	}

	public boolean buscarObjeto(By by)
	{
		try
		{
			getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			getDriver().findElement(by);
			getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			return true;
		}
		catch(NoSuchElementException e) {
			return false;
		}
	}

	public String getRecorrerTabla(By path, String validar) {
		String retorno = "No Encontrado";
		WebElement tabla = getDriver().findElement(path);
		List<WebElement> filas = tabla.findElements(By.tagName("tr"));

		int row_num, col_num;
		row_num = 1;
		if(buscarObjeto(path)) {
			for(WebElement trElement : filas) {

				List<WebElement> td_collection = trElement.findElements(By.tagName("td"));

				col_num = 1;

				for(WebElement tdElement : td_collection) {
					if(validar.equals("ALL")) {
						System.out.print(tdElement.getText() + "\t");

						if(row_num > 1)
							retorno = "Movimientos Generados Exitosamente";
						else
							retorno = "No se encontraron Movimientos";
					}
					if(tdElement.getText().equals(validar)) {
						retorno = "tr[" + row_num + "]/td[" + col_num + "]";
					}
					col_num++;
				}
				row_num++;
			} 
		}
		return retorno;
	}

	public void scrollDown() {
		JavascriptExecutor jse = (JavascriptExecutor)getDriver();
		jse.executeScript("window.scrollBy(0, 200)", "");
	}
}