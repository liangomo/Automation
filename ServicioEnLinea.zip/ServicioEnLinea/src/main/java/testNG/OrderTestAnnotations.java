package testNG;

import org.testng.annotations.Test;

public class OrderTestAnnotations {

	@Test (priority = 2)
	public void testInternetExplorer ()
	{
	System.out.println("Test Script 3 - Cross Browser Testing in Internet Explorer");
	}
	@Test (priority = 3)
	public void testFirefox ()
	{
	System.out.println("Test Script 1 - Cross Browser Testing in Firefox");
	}
	@Test (priority = 1)
	public void testGoogle ()
	{
	System.out.println("Test Script 2 - Cross Browser Testing in Google");
	}
	
}