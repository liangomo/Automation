package testNG;

import org.testng.annotations.Test;

public class ExecuteTestAnnotations {

	@Test
	public void testInternetExplorer ()
	{System.out.println("Test Script 3 - Cross Browser Testing in Internet Explorer");
	}
	
	@Test
	public void testFirefox ()
	{
	System.out.println("Test Script 1 - Cross Browser Testing in Firefox");
	}
	@Test
	public void testGoogle ()
	{
	System.out.println("Test Script 2 - Cross Browser Testing in Google");
	}
}
