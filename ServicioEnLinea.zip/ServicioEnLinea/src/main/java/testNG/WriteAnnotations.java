package testNG;

import org.testng.annotations.Test;

public class WriteAnnotations {

	@Test
	public void testFirstScript ()
	{
		System.out.println("This is the first test script");
	}

}
