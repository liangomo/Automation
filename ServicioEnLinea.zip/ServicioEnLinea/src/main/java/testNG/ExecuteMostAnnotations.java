package testNG;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ExecuteMostAnnotations {

	@BeforeMethod // Execute before each test (i.e., @Test)
	public void openBrowser()
	{
		System.out.println("Open Browser");
	}
	@AfterMethod // Execute after each test (i.e., @Test)
	public void closeBrowser()
	{
		System.out.println("Close Browser \n");
	}
	@BeforeTest // Before all test scripts are executed
	public void connectDataBase()
	{
		System.out.println("Connect to a Database \n");
	}
	@AfterTest // After all test scripts are executed
	public void disconnectDataBase()
	{
		System.out.println("Disconnect from the Database");
	}
	@Test (priority = 1)
	public void testFirefox ()
	{
		System.out.println("Test Script 1 - Cross Browser Testing in Firefox");
	}
	@Test (priority = 2)
	public void testGoogle ()
	{
		System.out.println("Test Script 2 - Cross Browser Testing in Google");
	}
	@Test (priority = 3)
	public void testInternetExplorer ()
	{
		System.out.println("Test Script 3 - Cross Browser Testing in Internet Explorer");
	}
}
